# MYRA project fix notes

## Changes in this pass
- Voice transcript text is buffered until Gemini signals turn completion, reducing fragmented/duplicate response bubbles.
- Structured phone actions are only recognized when the complete model response is a single command line; normal prose mentioning a command will not trigger it.
- Internal/thinking-style phrases are cleaned case-insensitively from visible responses.
- The assistant prompt now asks MYRA to reply in the user's language (including Bengali/Bangla-English) rather than forcing Hinglish.
- Action execution errors now produce a user-facing message rather than silently failing.
- Android cleartext traffic is disabled in the manifest.
- Added R8/ProGuard rules and enabled release shrinking/obfuscation.

## Important limitations
- This is a source-project patch, not a verified APK. The build could not be run in this environment because Gradle 8.7 could not be downloaded (network/DNS unavailable).
- The app still contains the existing client-side Gemini API-key flow. A real production security fix requires a secure backend/proxy and server-side authentication/entitlement checks; obfuscation does not hide a key embedded in an APK.
- Firebase Google Sign-In, verified Google Play Billing, server-side Premium entitlement, Play Integrity verification, and remote update publishing are not implemented by this patch.
- Review Android permissions and Google Play policy before publishing. Keep microphone/accessibility/overlay/device-admin capabilities disabled unless the user explicitly enables the relevant feature.
- Test voice turn-taking, structured actions, all permissions, and a minified release build on a physical Android device before distributing.
