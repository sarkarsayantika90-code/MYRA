# MYRA Super Admin (Android project)

এটি MYRA-র আলাদা Android Admin app-এর source project। বর্তমান Admin HTML-কে trusted local WebView-তে প্যাক করা হয়েছে, তাই Android Studio-তে খুলে build করা যাবে। এটি APK নয়।

## Included
- Admin email/password Firebase Auth REST login + refresh-token session (existing HTML implementation)
- Existing users, payment pending/history, grant/revoke UI
- API-key entry intentionally deferred; do not store Gemini secrets in RTDB from a client app
- User, payment, premium, block status and optional error-log views/actions in the admin UI
- Android WebView wrapper with internet permission

## Setup
1. Open this folder in Android Studio.
2. Check `app/src/main/assets/admin.html`: set the Firebase Web API key and database URL to your project values. These are Firebase client configuration values, not service-account credentials.
3. Ensure Firebase Authentication Email/Password provider is enabled, and the admin account is verified.
4. Apply carefully reviewed Realtime Database rules (see `FIREBASE_RULES_EXAMPLE.json`). Do not publish broad `.read` / `.write` permissions.
5. Build > Build APK(s). Test with a non-owner account to confirm admin data is denied.

## Important security and integration limits
- API key is stored under an admin-only RTDB path. This is not equivalent to Google Secret Manager. Restrict the path to the exact admin UID and prevent all ordinary clients from reading it. Never put a service-account JSON or Firebase Admin SDK private key in this app or MYRA.
- This Admin app only saves the Gemini key to Firebase. The current MYRA client does not magically become keyless or always-online from this alone. A trusted backend must read the key with Firebase Admin SDK and proxy model requests; the MYRA Android client then needs code changes to call that backend instead of connecting directly to Gemini.
- Gemini Live is a bidirectional WebSocket audio protocol. This starter does NOT implement a production Live WebSocket relay. A normal HTTPS text proxy is not a drop-in replacement for MYRA's existing Live voice pipeline. Live relay, auth verification, quotas, abuse controls, key rotation and reconnect behavior remain backend integration work.
- No service can guarantee 24/7 online status: Android may stop background microphone services, and server/model access depends on connectivity, quotas, billing, and provider availability. Keep the user's visible microphone consent and Android foreground-service notification.
- Manual UPI/PhonePe/Google Pay UTR cannot be independently confirmed from the UTR alone. Keep payments pending until owner compares bank/UPI transaction records and approves. After approval MYRA can refresh entitlement automatically.
- User details shown depend on MYRA actually writing profile/device/version/lastSeen/error logs. Collect only necessary diagnostics; do not collect passwords, auth tokens, private chats, or microphone audio.

## Expected data shape
- `users/{uid}/profile`: `email`, `device`, `androidVersion`, `ver`, `lastSeen`
- `premium/{uid}`: `plan`, `until`, `by`, `at` (matches the current MYRA `Premium.refresh()` path)
- `users/{uid}/status`: `active` or `blocked`
- `payments/{uid}/{paymentId}`: `email`, `utr`, `amount`, `plan`, `createdAt`, `status`, `by`
- `errorLogs/{uid}/{logId}`: `type`, `message`, `appVersion`, `device`, `timestamp`

Plan IDs/prices must match `PremiumPlans.kt` in the MYRA app. Do not trust prices or expiry supplied by a client; calculate them server-side.

## Current integration notes (admin-first phase)
- Admin premium grant/revoke writes `premium/{uid}` because the uploaded MYRA source reads this path in `Premium.refresh()`. User metadata remains under `users/{uid}/profile`.
- The UI includes account block/unblock and error-log viewing, but these actions require narrowly scoped, tested Firebase rules or trusted backend authorization before they will work. Do not publish permissive rules.
- The UI uses the uploaded MYRA plan configuration: weekly ₹29/7 days, monthly ₹99/30 days, quarterly ₹249/90 days, yearly ₹799/365 days, lifetime ₹1999/36500 days. Verify this is the intended commercial pricing before granting users.
- This project is source code, not a compiled or runtime-tested APK.

## GitHub Actions APK build (wrapper-independent)
এই ZIP-এ `gradlew` নেই, তাই পুরোনো workflow-এর `chmod +x ./gradlew` ধাপটি ব্যর্থ হয়েছিল। নতুন `.github/workflows/android-build.yml` GitHub runner-এ Gradle 8.7 install করে `app/build.gradle` খুঁজে সরাসরি build চালায়।

1. ZIP extract করে `MYRA_Admin_Android` ফোল্ডারের **ভেতরের সব ফাইল ও `.github` ফোল্ডার** repository-র root-এ commit করো (পুরো ZIP-টি শুধু upload করলে workflow project খুঁজে নাও পেতে পারে)।
2. পুরোনো workflow-তে `chmod +x ./gradlew` থাকা build YAML থাকলে সেটি disable/delete করো, যাতে পুরোনো job আর না চলে।
3. Actions tab থেকে `MYRA Admin APK` workflow চালাও; push করলেও এটি চলবে।
4. সফল হলে `MYRA-Admin-Debug-APK` artifact থেকে APK নাও।

নোট: GitHub runner-এ Gradle download ও Android SDK setup-এর জন্য internet access দরকার। Workflow build pass করলেও Firebase login এবং ফোনে runtime আলাদাভাবে পরীক্ষা করতে হবে।


## Admin login troubleshooting
- The admin login uses Firebase Authentication Email/Password. The email/password are NOT hard-coded in the APK.
- In Firebase Console, Authentication → Sign-in method → Email/Password must be enabled.
- The admin email must exist under Authentication → Users.
- If login returns `INVALID_PASSWORD` or `INVALID_LOGIN_CREDENTIALS`, reset the Firebase user's password rather than changing the Android code.
- Do not put a Firebase Admin SDK service-account private key or any admin password into this APK.
