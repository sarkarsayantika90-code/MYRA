# MYRA SUPER ADMIN (Android APK source)

এটি `myra-admin.html`-কে Android WebView অ্যাপের ভিতরে প্যাকেজ করে। Firebase Auth/Realtime Database endpoint ও বর্তমান HTML-এর Payment, Premium users এবং App update UI রাখা হয়েছে।

## Build
- Android Studio-তে এই ফোল্ডারটি Open করো, Gradle Sync করো।
- Build > Build APK(s)। APK: `app/build/outputs/apk/debug/app-debug.apk`
- CLI: `./gradlew assembleDebug`

## জরুরি ইন্টিগ্রেশন নোট
1. HTML-এ Firebase project `sayantika-afefe` ও API key সেট করা আছে। API key project identifier, কিন্তু Firebase Security Rules-ই প্রকৃত access control।
2. `MYRA/app/.../account/Premium.kt` ও `PaymentWatcher.kt` Premium `premium/{uid}`-এ পড়ে/লেখে। বর্তমানে HTML Admin `users/{uid}/premium`-এ grant/revoke করে। এই path mismatch ঠিক না করলে Admin থেকে দেয়া Premium MYRA অ্যাপে প্রতিফলিত নাও হতে পারে।
3. HTML-এ users data দেখা হয় `users` path থেকে; বর্তমান MYRA code-এর মধ্যে registration profile name/email/last-login tracking পূর্ণভাবে লেখা আছে—এমন নিশ্চয়তা নেই। Firebase Auth-এর সম্পূর্ণ user directory / user disable করার নিরাপদ ক্ষমতা client APK-তে দেওয়া হয়নি; এর জন্য Firebase Admin SDK-সহ authenticated backend/Cloud Functions লাগবে।
4. Database-এ test mode ব্যবহার করবে না। Firebase Setup-এর admin email verified rule প্রয়োগ করতে হবে এবং শুধুমাত্র নিজের verified admin account-কে অনুমতি দিতে হবে।
5. কোনো Admin password, service-account private key বা Firebase Admin SDK credential APK-তে রাখবে না।

এই source হলো প্রথম APK wrapper deliverable; নিচের backend/schema items পূরণ না করে এটিকে full remote-control production system ধরে নিও না।
