# MYRA SUPER ADMIN (Android APK source)

এই Android app-টি WebView-তে `app/src/main/assets/admin.html` চালায়। এটি Firebase project `sayantika-afefe`-এর Email/Password Authentication ও Realtime Database REST API ব্যবহার করে।

## Build
- Android Studio-তে এই ফোল্ডার Open করে Gradle Sync করো।
- Build > Build APK(s)। APK: `app/build/outputs/apk/debug/app-debug.apk`
- GitHub Actions/CLI-তে `./gradlew assembleDebug` চালানো যায় (wrapper-সহ)।

## Firebase Rules — জরুরি
Admin App `payments` এবং `users`-এর root path পড়তে চায়। Realtime Database-এ child-এর `.read` permission দিয়ে root query অনুমোদিত হয় না। Admin email-টি নিজের verified admin account-এর সঙ্গে হুবহু মিলিয়ে বসাও। উদাহরণে screenshot-এ ব্যবহৃত `sarksayantika90@gmail.com` আছে; তোর আসল admin email আলাদা হলে সেটি বসাবি।

```json
{
  "rules": {
    "users": {
      ".read": "auth != null && auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        "premium": {
          ".write": "auth != null && auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true"
        }
      }
    },
    "payments": {
      ".read": "auth != null && auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        "$pid": {
          ".write": "auth != null && ((auth.uid === $uid && !data.exists() && newData.child('status').val() === 'pending') || (auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true))"
        }
      }
    },
    "config": {
      "update": {
        ".read": true,
        ".write": "auth != null && auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true"
      }
    },
    "utrs": {
      ".read": "auth != null && auth.token.email === 'sarksayantika90@gmail.com' && auth.token.email_verified === true",
      "$utr": {
        ".write": "auth != null && !data.exists() && newData.val() === auth.uid"
      }
    }
  }
}
```

`config/update`-এ `.read: true` রাখা হয়েছে কারণ MYRA-এর update checker unauthenticated GET করে; এতে শুধু update metadata public হয়, user/payment data নয়। Admin UI-র update write verified admin-এ সীমিত। `users` root read কেবল verified admin-এর জন্য, যাতে user directory অন্য user-রা না দেখতে পারে।

## কী কী করে
- Pending payment list, approve/reject
- Premium grant/revoke under `users/{uid}/premium`
- Premium users list
- App update metadata at `config/update`

## গুরুত্বপূর্ণ সীমা
- এটি Firebase Auth user directory থেকে Gmail/name/login history সংগ্রহ করে না; Realtime Database-এ সংরক্ষিত তথ্যই দেখাতে পারে।
- Firebase Auth account disable/delete করার জন্য secure Admin SDK backend/Cloud Functions দরকার; APK-তে service-account key রাখা নিরাপদ নয়।
- Main app-এর পুরোনো `account/PaymentWatcher.kt` module `premium/{uid}` ব্যবহার করে, কিন্তু বর্তমান UI/feature path `premium/PremiumManager.kt` হলো `users/{uid}/premium`। Active call sites `PremiumManager` ব্যবহার করছে; তাই এই Admin UI current premium flow-এর সঙ্গে মেলে।
- Admin email অবশ্যই verified হতে হবে এবং Rules-এ ব্যবহৃত email-এর সঙ্গে হুবহু মিলতে হবে।
