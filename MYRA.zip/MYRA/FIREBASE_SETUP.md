# Firebase setup for MYRA (5 minutes, one time)

MYRA talks to Firebase project **sayantika-afefe** through its REST API (no google-services plugin needed).

1. **Authentication → Sign-in method → Email/Password → Enable.**
2. `FirebaseConfig.kt` already lists both owner emails in `ADMIN_EMAILS` (anikmondal71001@gmail.com and
   sarkarsayantika90@gmail.com). **Create both accounts in the app first** (Create account → open the
   verification email link each) before anyone else can register either email.
3. **Realtime Database → Rules → paste this** (publish). This is the complete, current list - both
   admin emails, and every path the app actually reads or writes (`usage` / `deviceUsage` so a reinstall
   can't reset anyone's free 20 minutes, `appconfig` / `secrets` / `notices` / `broadcasts` for the admin
   website's Remote config and Notify tabs). If the admin website's own "Rules & settings" tab shows
   something older, paste this version there too so both match:

```json
{
  "rules": {
    "users": {
      ".read": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || ((auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true))",
        "premium": {
          ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
        },
        "profile": {
          ".write": "auth != null && auth.uid === $uid"
        }
      }
    },
    "usage": {
      "$uid": {
        "$day": {
          ".read": "auth != null && auth.uid === $uid",
          ".write": "auth != null && auth.uid === $uid"
        }
      }
    },
    "deviceUsage": {
      "$deviceId": {
        "$day": {
          ".read": "auth != null",
          ".write": "auth != null"
        }
      }
    },
    "payments": {
      ".read": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        "$pid": {
          ".write": "auth != null && ((auth.uid === $uid && !data.exists() && newData.child('status').val() === 'pending') || ((auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true))"
        }
      }
    },
    "utrs": {
      ".read": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true",
      "$utr": {
        ".write": "auth != null && !data.exists() && newData.val() === auth.uid"
      }
    },
    "config": {
      ".read": true,
      ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
    },
    "appconfig": {
      ".read": "auth != null",
      ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
    },
    "secrets": {
      "gemini": {
        ".read": "auth != null && auth.token.email_verified === true",
        ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
      }
    },
    "notices": {
      "all": {
        ".read": "auth != null",
        ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
      },
      "users": {
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
        }
      }
    },
    "broadcasts": {
      ".read": "auth != null",
      ".write": "auth != null && (auth.token.email === 'anikmondal71001@gmail.com' || auth.token.email === 'sarkarsayantika90@gmail.com') && auth.token.email_verified === true"
    }
  }
}
```
4. **Do NOT leave the database in "test mode"** (open read/write) — anyone could give themselves Premium.
5. In Google Cloud → APIs & Services → Credentials, you may restrict the API key to
   *Identity Toolkit API* + *Token Service API*.

## Google Sign-In ("Continue with Google")
1. **Firebase Console → Authentication → Sign-in method → Google → Enable → Save.** Firebase shows a
   **Web client ID** (ends in `.apps.googleusercontent.com`) - copy it.
2. Paste it into `FirebaseConfig.kt` as `GOOGLE_WEB_CLIENT_ID`.
3. Google also needs to know this exact app is allowed to use it - it checks the app's signing
   certificate. After your next GitHub Actions build, open that build's run summary (Actions tab, on
   your phone is fine) and copy the **SHA-1** printed there under "Signing certificate fingerprint".
4. **Firebase Console → Project settings → Your apps → (the Android app) → Add fingerprint** → paste
   that SHA-1 → Save. (If there's no Android app listed yet, "Add app" → Android → package name
   `com.myra.assistant` → any nickname → skip the config file step, since MYRA doesn't use it.)
5. Rebuild once more after adding the fingerprint, reinstall, and the Google button will work.
Without steps 1-2 the button shows "Google login e somossa hoyeche"; without steps 3-4 it shows
"Google login kaj korlo na" even though the Web client ID is correct.

## How premium payment works
User pays your UPI QR → types the 12-digit **UTR** in the app → app writes `payments/{uid}/{id}` (status *pending*)
and claims `utrs/{UTR}` (a UTR can be used once, ever).
- **Auto-verify:** on YOUR phone (signed in as admin, with MYRA's *Notification access* on) MYRA reads bank/PhonePe
  "credited" notifications. When one has the same UTR and amount ≥ plan price, it approves automatically and the user's
  app flips to Premium within seconds.
- **Manual:** if the notification hides the UTR / your phone was off, open *Premium → Admin: payments* and tap Approve.

Edit prices in `PremiumPlans.kt`. Set `GATING_ENABLED = false` to make everything free again.


## Admin website (myra-admin.html)
Login: **anikmondal71001@gmail.com** or **sarkarsayantika90@gmail.com** (create these accounts in the app first and verify the email from the link Firebase sends for each).
Tabs: Dashboard (users, active, new, premium, downloads, versions) • Users (premium / notify / ban / CSV) • Payments •
Notify (push messages to all or one user) • App update • Remote config (Gemini API key, model, free minutes, maintenance mode,
announcement) • Audit log • Rules & settings (the CURRENT rules - copy them from there, they are always up to date).
**The rules in the admin site's "Rules & settings" tab replace the rules written above.**

Open `myra-admin.html` (double-click, or host it free: Firebase Hosting `firebase deploy`, GitHub Pages, Netlify).
Login with your admin email. Tabs: Pending payments (Approve/Reject), History, Premium users (grant / revoke), App update.

## App updates (admin pushes an update, every phone shows a popup)
Android only installs an update if it is signed with the SAME key as the installed app. One-time setup:
1. Make a key (keep the file safe, never lose it):
   `keytool -genkeypair -v -keystore myra.jks -alias myra -keyalg RSA -keysize 2048 -validity 36500`
2. `base64 -w0 myra.jks` and add these **GitHub → Settings → Secrets → Actions**:
   `MYRA_KEYSTORE_B64` (that base64 text), `MYRA_KEYSTORE_PASSWORD`, `MYRA_KEY_ALIAS` (= myra), `MYRA_KEY_PASSWORD`.
3. Every push now builds a signed APK, numbers it automatically (versionCode = run number + 100) and publishes a
   GitHub Release. The run summary shows the **versionCode, APK link and sha256**.
4. Admin website → *App update* → paste them → **Publish update**. Done: all users see "Update available",
   MYRA tells them once (in her own sweet way) and stays silent while the update installs.
The first build with the new key cannot install over an old build made with a different key: uninstall once, then updates work forever.
