# Firebase setup for MYRA (5 minutes, one time)

MYRA talks to Firebase project **sayantika-afefe** through its REST API (no google-services plugin needed).

1. **Authentication → Sign-in method → Email/Password → Enable.**
2. **Edit `FirebaseConfig.kt`**: set `ADMIN_EMAIL` to YOUR email, build, install, and **create your account first**
   (Create account → open the verification email link). Do this before anyone else can register your email.
3. **Realtime Database → Rules → paste this** (replace `YOUR_EMAIL@gmail.com`, publish):

```json
{
  "rules": {
    "users": {
      ".read": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || (auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true))",
        "premium": {
          ".write": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true"
        }
      }
    },
    "payments": {
      ".read": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        "$pid": {
          ".write": "auth != null && ((auth.uid === $uid && !data.exists() && newData.child('status').val() === 'pending') || (auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true))"
        }
      }
    },
    "config": {
      ".read": true,
      ".write": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true"
    },
    "utrs": {
      ".read": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true",
      "$utr": {
        ".write": "auth != null && !data.exists() && newData.val() === auth.uid"
      }
    }
  }
}
```
4. **Do NOT leave the database in "test mode"** (open read/write) — anyone could give themselves Premium.
5. In Google Cloud → APIs & Services → Credentials, you may restrict the API key to
   *Identity Toolkit API* + *Token Service API*.

## How premium payment works
User pays your UPI QR → types the 12-digit **UTR** in the app → app writes `payments/{uid}/{id}` (status *pending*)
and claims `utrs/{UTR}` (a UTR can be used once, ever).
- **Auto-verify:** on YOUR phone (signed in as admin, with MYRA's *Notification access* on) MYRA reads bank/PhonePe
  "credited" notifications. When one has the same UTR and amount ≥ plan price, it approves automatically and the user's
  app flips to Premium within seconds.
- **Manual:** if the notification hides the UTR / your phone was off, open *Premium → Admin: payments* and tap Approve.

Edit prices in `PremiumPlans.kt`. Set `GATING_ENABLED = false` to make everything free again.


## Admin website
Open `myra-admin.html` (double-click, or host it free: Firebase Hosting `firebase deploy`, GitHub Pages, Netlify).
Login with your admin email. Tabs: Pending payments (Approve/Reject), History, Premium users (grant / revoke), App update.

## App updates (admin pushes an update, every phone shows a popup)
Android only installs an update if it is signed with the SAME key as the installed app. One-time setup:
1. Make a key (keep the file safe, never lose it):
   `keytool -genkeypair -v -keystore myra.jks -alias myra -keyalg RSA -keysize 2048 -validity 36500`
2. `base64 -w0 myra.jks` and add these **GitHub → Settings → Secrets → Actions**:
   `MYRA_KEYSTORE_B64` (that base64 text), `MYRA_KEYSTORE_PASSWORD`, `MYRA_KEY_ALIAS` (= myra), `MYRA_KEY_PASSWORD`.
3. Every push now builds a signed APK, numbers it automatically (versionCode = run number + 100) and publishes a
   GitHub Release. The run summary shows the **versionCode, APK link and sha256**.
4. Admin website → *App update* → paste them → **Publish update**. Done: all users see "Update available",
   MYRA tells them once (in her own sweet way) and stays silent while the update installs.
The first build with the new key cannot install over an old build made with a different key: uninstall once, then updates work forever.
