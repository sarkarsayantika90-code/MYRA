# Firebase setup for MYRA (5 minutes, one time)

MYRA talks to Firebase project **sayantika-afefe** through its REST API (no google-services plugin needed).

1. **Authentication → Sign-in method → Email/Password → Enable.**
2. **Edit `FirebaseConfig.kt`**: set `ADMIN_EMAIL` to YOUR email, build, install, and **create your account first**
   (Create account → open the verification email link). Do this before anyone else can register your email.
3. **Realtime Database → Rules → paste this** (replace `YOUR_EMAIL@gmail.com`, publish):

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || (auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true))",
        "premium": {
          ".write": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true"
        }
      }
    },
    "payments": {
      ".read": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true",
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        "$pid": {
          ".write": "auth != null && ((auth.uid === $uid && !data.exists() && newData.child('status').val() === 'pending') || (auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true))"
        }
      }
    },
    "utrs": {
      ".read": "auth != null && auth.token.email === 'YOUR_EMAIL@gmail.com' && auth.token.email_verified === true",
      "$utr": {
        ".write": "auth != null && !data.exists() && newData.val() === auth.uid"
      }
    }
  }
}
```
4. **Do NOT leave the database in "test mode"** (open read/write) — anyone could give themselves Premium.
5. In Google Cloud → APIs & Services → Credentials, you may restrict the API key to
   *Identity Toolkit API* + *Token Service API*.

## How premium payment works
User pays your UPI QR → types the 12-digit **UTR** in the app → app writes `payments/{uid}/{id}` (status *pending*)
and claims `utrs/{UTR}` (a UTR can be used once, ever).
- **Auto-verify:** on YOUR phone (signed in as admin, with MYRA's *Notification access* on) MYRA reads bank/PhonePe
  "credited" notifications. When one has the same UTR and amount ≥ plan price, it approves automatically and the user's
  app flips to Premium within seconds.
- **Manual:** if the notification hides the UTR / your phone was off, open *Premium → Admin: payments* and tap Approve.

Edit prices in `PremiumPlans.kt`. Set `GATING_ENABLED = false` to make everything free again.
