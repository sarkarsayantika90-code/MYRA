# MYRA Admin (Android)

Owner-only control app for MYRA. Same Firebase project and database rules as the MYRA app - **no rule changes needed**.

## Build
1. Create a new GitHub repo, upload this folder, push to `main`.
2. Actions > "Build MYRA Admin APK" > download the `MYRA-Admin-apk` artifact and install it.
3. Log in with `anikmondal71001@gmail.com` + password. (If that account was made with Google, set a password first in MYRA > Settings > Account > Set password. The email must be verified.)

## What it controls
| Tab | What you can do |
|---|---|
| Dashboard | Users, active 24h/7d, new, premium, banned, pending payments, app versions |
| Users | See every user's Gmail, device, last seen. **Activate / Extend / Deactivate premium**, message, ban/unban, remote log-out, 7-day usage |
| Payments | Approve (premium turns on) or reject UTR payments |
| Control | Gemini key, model, free minutes/day, announcement, maintenance mode, **switch single MYRA tools on/off**, **log out all users** |
| Notify | Message everyone or one user |
| Live | Minutes talked today, per user, auto-refresh |
| Update | Publish / remove an app update |
| Audit | Every admin action |

## Built to never need an update
- Firebase key, database URL and admin email can be changed in **Settings** (no rebuild).
- Premium plans are editable in **Control > Premium plans**; tools can be switched off by name, including future ones.
- **Control > Advanced** edits any `appconfig` value, so new MYRA settings work from this app on day one.
- All lists/fields read with tolerant parsing, so extra fields in the database never break a screen.

## Alerts
New pending payments and new users raise a phone notification (checked every minute while the app is open, every 15+ min in the background) and are listed in the **Alerts** tab. **Send** composes a message to everyone, premium, free or one user.

## Needs the updated MYRA app
Tool on/off, "log out all", per-user remote log-out and instant premium refresh need the new MYRA build (it reads `appconfig/disabledTools`, `appconfig/forceLogoutAt` and silent notices with `action: logout|refresh`). Older MYRA builds ignore these and keep working.

Phones pick changes up within ~1 minute while MYRA is on, ~15 minutes otherwise.
