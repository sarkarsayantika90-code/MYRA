package com.myra.assistant.control

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.ContactLookup
import com.myra.assistant.utils.Logger
import com.myra.assistant.whatsapp.ConfirmGate
import com.myra.assistant.whatsapp.UtteranceLog
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/**
 * SMS by voice, two steps, same safety model as WhatsApp:
 *  1) prepare(): find the ONE contact, hold a draft, return awaiting_confirmation
 *  2) confirm(): only after the person's own "yes" said AFTER MYRA read the draft back.
 * The message is written by MYRA from what the person said, sent through SmsManager (no typing UI
 * needed), and the real send result from Android is reported - not assumed.
 */
object SmsAgent {
    private const val TAG = "SMS_AGENT"
    private const val TTL_MS = 3 * 60 * 1000L
    private val mutex = Mutex()

    private class Draft(val id: String, val name: String, val number: String, val text: String, val at: Long)
    @Volatile private var draft: Draft? = null

    private fun has(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    suspend fun prepare(ctx: Context, to: String, message: String): String = mutex.withLock {
        if (!has(ctx)) return "failed: SMS permission nai (Settings > Grant permissions)"
        if (message.isBlank()) return "failed: Ki likhbo? Message ta bolo"
        if (to.isBlank()) return "failed: Kake pathabo? Naam ba number bolo"

        val name: String
        val number: String
        if (to.count { it.isDigit() } >= 6) {
            name = to; number = to.filter { it.isDigit() || it == '+' }
        } else {
            val matches = ContactLookup.findAll(ctx, to)
            if (matches.isEmpty()) return "contact_not_found: '$to' naame kono contact nai"
            val exact = matches.filter { it.first.equals(to.trim(), true) }
            val pick = if (exact.size == 1) exact else matches
            if (pick.map { it.first.lowercase() }.distinct().size > 1)
                return "contact_ambiguous: " + pick.take(5).joinToString(", ") { it.first } + ". Kon ta?"
            name = pick.first().first; number = pick.first().second
        }
        val d = Draft(UUID.randomUUID().toString().take(6), name, number, message.trim(), System.currentTimeMillis())
        draft = d
        Logger.d(TAG, "draft ready len=${d.text.length}")
        "awaiting_confirmation: task ${d.id}. SMS to ${d.name}: \"${d.text}\". " +
            "User ke naam ar exact message poRe shunao, jiggesh koro 'pathabo?'. Sudhu 'haan' shunle confirm_sms koro. Ekhono pathai ni."
    }

    suspend fun confirm(ctx: Context): String = mutex.withLock {
        val d = draft ?: return "failed: Kono SMS draft nai"
        if (System.currentTimeMillis() - d.at > TTL_MS) { draft = null; return "failed: Draft onek purono, notun kore bolo" }

        var ok = false
        var readbackDone = false
        for (i in 0 until 10) {
            val said = UtteranceLog.sinceReadback(d.at)
            if (said != null) {
                readbackDone = true
                if (ConfirmGate.isAffirmative(said)) { ok = true; break }
                if (ConfirmGate.isNegative(said)) break
            }
            delay(300)
        }
        if (!ok) {
            return if (readbackDone)
                "awaiting_confirmation: User er spashto 'haan' shuni nai, pathai ni. Abar jiggesh koro. Draft ekhono ache."
            else
                "awaiting_confirmation: Age draft ta user ke poRe shunao, uttor er jonno opekkha koro, tarpor abar confirm_sms koro."
        }
        draft = null
        return send(ctx, d)
    }

    fun cancel(): String {
        draft = null
        return "cancelled: SMS draft muche dilam, kichu pathai ni"
    }

    private suspend fun send(ctx: Context, d: Draft): String {
        val action = "com.myra.assistant.SMS_SENT_${d.id}"
        var result = Int.MIN_VALUE
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { result = resultCode }
        }
        return try {
            val filter = IntentFilter(action)
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else ctx.registerReceiver(receiver, filter)

            @Suppress("DEPRECATION")
            val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val pi = PendingIntent.getBroadcast(
                ctx, d.id.hashCode(), Intent(action).setPackage(ctx.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val parts = sms.divideMessage(d.text)
            if (parts.size > 1) {
                val pis = ArrayList<PendingIntent>().apply { repeat(parts.size) { add(pi) } }
                sms.sendMultipartTextMessage(d.number, null, parts, pis, null)
            } else {
                sms.sendTextMessage(d.number, null, d.text, pi, null)
            }
            var waited = 0
            while (result == Int.MIN_VALUE && waited < 8000) { delay(250); waited += 250 }
            when (result) {
                Activity.RESULT_OK -> "sent: ${d.name}-ke SMS pathano hoyeche"
                Int.MIN_VALUE -> "submitted_unverified: SMS pathiyechi kintu Android ekhono confirm kore ni"
                else -> "failed: SMS jay ni (code $result). Balance/network/SIM check koro"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "send failed: ${e.message}")
            "failed: SMS pathate parlam na"
        } finally {
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }
}
