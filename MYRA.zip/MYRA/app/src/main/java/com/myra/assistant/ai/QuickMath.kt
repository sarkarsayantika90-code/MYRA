package com.myra.assistant.ai

import java.math.BigDecimal
import java.math.RoundingMode

/** Pure helpers (no Android) behind the calculator / converter tools, so they can be unit-tested. */
object QuickMath {

    fun fmt(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "undefined"
        return BigDecimal(d).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    /** Evaluates + - * / % ^ ( ) sqrt() abs() sin/cos/tan (degrees) ln() log() pi e. Throws on bad input. */
    fun eval(src: String): Double {
        val s = src.lowercase()
            .replace("×", "*").replace("÷", "/").replace(",", "").replace(" ", "")
        val p = Parser(s)
        val v = p.parseExpr()
        if (p.pos != s.length) throw IllegalArgumentException("unexpected '${s[p.pos]}'")
        return v
    }

    private class Parser(val s: String) {
        var pos = 0

        fun parseExpr(): Double {
            var v = parseTerm()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val r = parseTerm()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun parseTerm(): Double {
            var v = parsePow()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/' || s[pos] == '%')) {
                val op = s[pos++]
                val r = parsePow()
                v = when (op) {
                    '*' -> v * r
                    '/' -> { if (r == 0.0) throw ArithmeticException("division by zero"); v / r }
                    else -> { if (r == 0.0) throw ArithmeticException("division by zero"); v % r }
                }
            }
            return v
        }

        fun parsePow(): Double {
            val b = parseUnary()
            if (pos < s.length && s[pos] == '^') { pos++; return Math.pow(b, parsePow()) }
            return b
        }

        fun parseUnary(): Double {
            if (pos < s.length && s[pos] == '-') { pos++; return -parseUnary() }
            if (pos < s.length && s[pos] == '+') { pos++; return parseUnary() }
            return parseAtom()
        }

        fun parseAtom(): Double {
            if (pos >= s.length) throw IllegalArgumentException("incomplete expression")
            val c = s[pos]
            if (c == '(') {
                pos++
                val v = parseExpr()
                if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("missing )")
                pos++
                return v
            }
            if (c.isLetter()) {
                val st = pos
                while (pos < s.length && s[pos].isLetter()) pos++
                val name = s.substring(st, pos)
                if (name == "pi") return Math.PI
                if (name == "e") return Math.E
                if (pos < s.length && s[pos] == '(') {
                    pos++
                    val a = parseExpr()
                    if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("missing )")
                    pos++
                    return when (name) {
                        "sqrt" -> { if (a < 0) throw ArithmeticException("sqrt of negative"); Math.sqrt(a) }
                        "abs" -> Math.abs(a)
                        "sin" -> Math.sin(Math.toRadians(a))
                        "cos" -> Math.cos(Math.toRadians(a))
                        "tan" -> Math.tan(Math.toRadians(a))
                        "ln" -> { if (a <= 0) throw ArithmeticException("ln of non-positive"); Math.log(a) }
                        "log" -> { if (a <= 0) throw ArithmeticException("log of non-positive"); Math.log10(a) }
                        else -> throw IllegalArgumentException("unknown function $name")
                    }
                }
                throw IllegalArgumentException("unknown word $name")
            }
            val st = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (st == pos) throw IllegalArgumentException("unexpected '${s[pos]}'")
            return s.substring(st, pos).toDoubleOrNull() ?: throw IllegalArgumentException("bad number")
        }
    }

    // ───────────── unit conversion ─────────────

    private val tables: Map<String, Map<String, Double>> = mapOf(
        "length" to mapOf("m" to 1.0, "km" to 1000.0, "cm" to 0.01, "mm" to 0.001, "mile" to 1609.344, "yard" to 0.9144, "foot" to 0.3048, "inch" to 0.0254),
        "mass" to mapOf("kg" to 1.0, "g" to 0.001, "mg" to 1e-6, "lb" to 0.45359237, "oz" to 0.028349523125, "ton" to 1000.0, "quintal" to 100.0),
        "volume" to mapOf("l" to 1.0, "ml" to 0.001, "gallon" to 3.785411784, "cup" to 0.2365882365, "tbsp" to 0.01478676478, "tsp" to 0.00492892159),
        "speed" to mapOf("mps" to 1.0, "kmh" to 1.0 / 3.6, "mph" to 0.44704, "knot" to 0.5144444444),
        "data" to mapOf("byte" to 1.0, "kb" to 1024.0, "mb" to 1048576.0, "gb" to 1073741824.0, "tb" to 1099511627776.0),
        "time" to mapOf("second" to 1.0, "minute" to 60.0, "hour" to 3600.0, "day" to 86400.0, "week" to 604800.0),
        "area" to mapOf("sqm" to 1.0, "sqft" to 0.09290304, "sqkm" to 1e6, "acre" to 4046.8564224, "hectare" to 10000.0, "bigha" to 1337.8)
    )

    private val alias = mapOf(
        "meter" to "m", "metre" to "m", "meters" to "m", "metres" to "m",
        "kilometer" to "km", "kilometre" to "km", "kilometers" to "km", "kilometres" to "km",
        "centimeter" to "cm", "centimetre" to "cm", "millimeter" to "mm", "mi" to "mile", "miles" to "mile",
        "feet" to "foot", "ft" to "foot", "inches" to "inch", "in" to "inch", "yards" to "yard", "yd" to "yard",
        "kilogram" to "kg", "kilograms" to "kg", "kgs" to "kg", "gram" to "g", "grams" to "g", "pound" to "lb", "pounds" to "lb", "lbs" to "lb",
        "ounce" to "oz", "ounces" to "oz", "tonne" to "ton", "tons" to "ton",
        "liter" to "l", "litre" to "l", "liters" to "l", "litres" to "l", "milliliter" to "ml", "gallons" to "gallon", "cups" to "cup",
        "kph" to "kmh", "km/h" to "kmh", "kmph" to "kmh", "m/s" to "mps", "knots" to "knot",
        "bytes" to "byte", "kilobyte" to "kb", "megabyte" to "mb", "gigabyte" to "gb", "terabyte" to "tb",
        "sec" to "second", "seconds" to "second", "min" to "minute", "minutes" to "minute", "hours" to "hour", "hr" to "hour", "days" to "day", "weeks" to "week",
        "sqmeter" to "sqm", "acres" to "acre", "hectares" to "hectare", "sqfeet" to "sqft", "sqfoot" to "sqft",
        "celsius" to "c", "centigrade" to "c", "fahrenheit" to "f", "kelvin" to "k"
    )

    private fun canon(u: String): String {
        val x = u.trim().lowercase().replace(" ", "")
        return alias[x] ?: x
    }

    fun convert(value: Double, from: String, to: String): String? {
        val f = canon(from); val t = canon(to)
        val temps = setOf("c", "f", "k")
        if (f in temps && t in temps) {
            val c = when (f) { "c" -> value; "f" -> (value - 32) * 5 / 9; else -> value - 273.15 }
            val out = when (t) { "c" -> c; "f" -> c * 9 / 5 + 32; else -> c + 273.15 }
            return "${fmt(value)} ${f.uppercase()} = ${fmt(out)} ${t.uppercase()}"
        }
        for ((_, table) in tables) {
            val a = table[f]; val b = table[t]
            if (a != null && b != null) return "${fmt(value)} $f = ${fmt(value * a / b)} $t"
        }
        return null
    }

    // ───────────── money / health ─────────────

    /** Monthly EMI for a loan. [annualRatePercent] e.g. 9.5 */
    fun emi(principal: Double, annualRatePercent: Double, months: Int): Double {
        require(months > 0) { "months must be > 0" }
        val r = annualRatePercent / 12.0 / 100.0
        if (r == 0.0) return principal / months
        val pow = Math.pow(1 + r, months.toDouble())
        return principal * r * pow / (pow - 1)
    }

    fun bmi(weightKg: Double, heightCm: Double): Double {
        require(weightKg > 0 && heightCm > 0) { "weight and height must be positive" }
        val m = heightCm / 100.0
        return weightKg / (m * m)
    }

    fun bmiCategory(b: Double) = when {
        b < 18.5 -> "underweight"
        b < 25.0 -> "healthy range"
        b < 30.0 -> "overweight"
        else -> "obese range"
    }
}
