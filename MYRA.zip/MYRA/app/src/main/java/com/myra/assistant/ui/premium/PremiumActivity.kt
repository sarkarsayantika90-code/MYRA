package com.myra.assistant.ui.premium

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.R
import com.myra.assistant.auth.FirebaseConfig
import com.myra.assistant.auth.Session
import com.myra.assistant.premium.PremiumManager
import com.myra.assistant.premium.PremiumPlans
import com.myra.assistant.ui.UiKit
import com.myra.assistant.ui.UiKit.dp
import com.myra.assistant.ui.main.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MYRA Premium: plans, styled QR, "Pay with UPI app", UTR submit. The status line refreshes every
 * 10s, so as soon as the payment is verified (auto on the owner's phone, or approved by the owner)
 * the screen flips to "Premium active" by itself.
 */
class PremiumActivity : AppCompatActivity() {
    private var selected: PremiumPlans.Plan = PremiumPlans.ALL[1]
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var payBox: LinearLayout
    private lateinit var planViews: List<Pair<PremiumPlans.Plan, LinearLayout>>
    private lateinit var payTitle: TextView
    private var accent = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        accent = ThemeManager.accent(this)
        val scroll = ScrollView(this).apply { background = UiKit.screenBg(this@PremiumActivity, accent) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PremiumActivity, 18), dp(this@PremiumActivity, 46), dp(this@PremiumActivity, 18), dp(this@PremiumActivity, 40))
        }
        scroll.addView(col)
        setContentView(scroll)

        col.addView(UiKit.label(this, "✨ MYRA Premium", 27f, accent, true).apply { setShadowLayer(18f, 0f, 0f, accent) })
        status = UiKit.label(this, "Checking your plan...", 14f, UiKit.DIM)
        col.addView(status)

        // features
        val feat = UiKit.card(this, accent and 0x00FFFFFF or 0x55000000)
        PremiumPlans.FEATURES.forEach { feat.addView(UiKit.label(this, "✔  $it", 13f, UiKit.TEXT)) }
        col.addView(feat, UiKit.lp(top = 14, c = this))

        // plans
        col.addView(UiKit.label(this, "CHOOSE A PLAN", 12f, accent, true).apply { letterSpacing = 0.15f; setPadding(0, dp(this@PremiumActivity, 22), 0, dp(this@PremiumActivity, 6)) })
        val rows = ArrayList<Pair<PremiumPlans.Plan, LinearLayout>>()
        PremiumPlans.ALL.forEach { plan ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(this@PremiumActivity, 16), dp(this@PremiumActivity, 14), dp(this@PremiumActivity, 16), dp(this@PremiumActivity, 14))
                setOnClickListener { selected = plan; paintPlans(); updatePay() }
            }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            titleRow.addView(UiKit.label(this, plan.title, 16f, UiKit.TEXT, true))
            if (plan.tag.isNotEmpty()) titleRow.addView(UiKit.label(this, "  ${plan.tag}", 10f, accent, true))
            left.addView(titleRow)
            left.addView(UiKit.label(this, plan.blurb, 12f, UiKit.DIM))
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(UiKit.label(this, "₹${plan.price}", 20f, UiKit.TEXT, true))
            rows.add(plan to row)
            col.addView(row, UiKit.lp(top = 8, c = this))
        }
        planViews = rows
        paintPlans()

        // payment box
        payBox = UiKit.card(this, accent and 0x00FFFFFF or 0x66000000)
        payTitle = UiKit.label(this, "", 16f, UiKit.TEXT, true)
        payBox.addView(payTitle)
        payBox.addView(UiKit.label(this, "1) Pay from any UPI app  •  2) paste the 12-digit UTR below", 12f, UiKit.DIM))
        val qr = ImageView(this).apply { setImageResource(R.drawable.premium_qr_card); adjustViewBounds = true }
        payBox.addView(qr, UiKit.lp(top = 12, c = this))
        payBox.addView(UiKit.button(this, "Pay with UPI app", accent) { openUpi() }, UiKit.lp(top = 12, c = this))
        val utr = UiKit.input(this, "UTR / Transaction ID (12 digits)").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        payBox.addView(utr, UiKit.lp(top = 12, c = this))
        payBox.addView(UiKit.button(this, "I have paid - verify", accent, filled = false) { submit(utr) }, UiKit.lp(top = 10, c = this))
        payBox.addView(UiKit.label(this, "Verification is automatic once the payment reaches the owner's phone — usually within a minute or two. If it takes longer, it is approved manually.", 11f, UiKit.DIM))
        col.addView(payBox, UiKit.lp(top = 18, c = this))
        updatePay()

        history = UiKit.label(this, "", 12f, UiKit.DIM)
        col.addView(history, UiKit.lp(top = 14, c = this))

        if (Session.isAdmin(this)) {
            col.addView(UiKit.button(this, "Admin: payments", accent, filled = false) {
                startActivity(Intent(this, PremiumAdminActivity::class.java))
            }, UiKit.lp(top = 16, c = this))
        }

        lifecycleScope.launch {
            while (isActive) {
                withContext(Dispatchers.IO) { PremiumManager.refresh(this@PremiumActivity) }
                val list = withContext(Dispatchers.IO) { PremiumManager.myPayments(this@PremiumActivity) }
                renderStatus(list)
                delay(10_000)
            }
        }
    }

    private fun paintPlans() {
        planViews.forEach { (plan, row) ->
            val on = plan.id == selected.id
            row.background = UiKit.rounded(if (on) 0xFF1A1226.toInt() else 0xFF0E0E18.toInt(), 18,
                if (on) accent else 0x22FFFFFF, if (on) 2 else 1, this)
        }
    }

    private fun updatePay() { payTitle.text = "Pay ₹${selected.price} for ${selected.title}" }

    private fun openUpi() {
        val uri = Uri.parse(
            "upi://pay?pa=${FirebaseConfig.UPI_ID}&pn=${Uri.encode(FirebaseConfig.UPI_NAME)}" +
                "&am=${selected.price}.00&cu=INR&tn=${Uri.encode("MYRA " + selected.title)}"
        )
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, uri), "Pay with")) }
        catch (e: Exception) { Toast.makeText(this, "UPI app pailam na - QR scan koro", Toast.LENGTH_LONG).show() }
    }

    private fun submit(utr: EditText) {
        val value = utr.text.toString().trim()
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { PremiumManager.submitPayment(this@PremiumActivity, selected, value) }
            if (r == "OK") {
                utr.setText("")
                Toast.makeText(this@PremiumActivity, "Payment verify hochche...", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this@PremiumActivity, r, Toast.LENGTH_LONG).show()
        }
    }

    private fun renderStatus(list: List<PremiumManager.Payment>) {
        val premium = PremiumManager.isPremium(this)
        status.text = if (premium) "✅ ${PremiumManager.planName(this)} • ${PremiumManager.expiryText(this)}"
        else "Free plan • ${PremiumManager.usedMinutesToday(this)}/${PremiumPlans.FREE_MINUTES_PER_DAY} min used today"
        status.setTextColor(if (premium) 0xFF69F0AE.toInt() else UiKit.DIM)
        history.text = if (list.isEmpty()) "" else "Your payments:\n" + list.take(5).joinToString("\n") {
            val st = when (it.status) { "approved" -> "✅ approved"; "rejected" -> "❌ rejected"; else -> "⏳ verifying" }
            "• ${PremiumPlans.byId(it.plan)?.title ?: it.plan} ₹${it.amount}  $st"
        }
    }
}
