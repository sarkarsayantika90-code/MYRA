package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.ImageView
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.prefs
import java.io.File

/** Home-screen look: accent colour + optional background picture (stored privately in the app). */
object ThemeManager {
    val PRESETS: List<Pair<String, Int>> = listOf(
        "Rose" to 0xFFFF4D8D.toInt(),
        "Crimson" to 0xFFFF1744.toInt(),
        "Purple" to 0xFFD500F9.toInt(),
        "Cyan" to 0xFF00E5FF.toInt(),
        "Mint" to 0xFF00E676.toInt(),
        "Gold" to 0xFFFFC400.toInt(),
        "Blue" to 0xFF448AFF.toInt(),
        "Orange" to 0xFFFF6D00.toInt()
    )

    fun accent(ctx: Context): Int = ctx.prefs().getInt(Constants.KEY_ACCENT, PRESETS[0].second)
    fun setAccent(ctx: Context, color: Int) = ctx.prefs().edit().putInt(Constants.KEY_ACCENT, color).apply()

    private fun bgFile(ctx: Context) = File(ctx.filesDir, "home_bg.jpg")

    fun hasBackground(ctx: Context) = bgFile(ctx).exists()

    /** 0..80 (% darkness laid over the picture so the orb stays readable). */
    fun dim(ctx: Context): Int = ctx.prefs().getInt(Constants.KEY_BG_DIM, 45)
    fun setDim(ctx: Context, v: Int) = ctx.prefs().edit().putInt(Constants.KEY_BG_DIM, v.coerceIn(0, 80)).apply()

    /** Copies the picked image into private storage, downscaled so it never blows memory. */
    fun saveBackground(ctx: Context, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) false else {
            bgFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            ctx.prefs().edit().putString(Constants.KEY_BG_IMAGE, "home_bg.jpg").apply()
            true
        }
    } catch (e: Exception) { false }

    fun clearBackground(ctx: Context) {
        bgFile(ctx).delete()
        ctx.prefs().edit().remove(Constants.KEY_BG_IMAGE).apply()
    }

    fun loadInto(ctx: Context, view: ImageView) {
        val f = bgFile(ctx)
        if (f.exists()) {
            view.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            view.visibility = android.view.View.VISIBLE
        } else {
            view.setImageDrawable(null)
            view.visibility = android.view.View.GONE
        }
    }
}
