package com.myra.admin

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Launcher screen: drifting stars, ripple rings, the MYRA logo, status lines and a progress bar. */
class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        setContentView(SplashView(this))
        val tab = intent?.getStringExtra("tab")
        handler.postDelayed({
            val next = if (Auth.isLoggedIn(this)) MainActivity::class.java else LoginActivity::class.java
            startActivity(Intent(this, next).apply { if (tab != null) putExtra("tab", tab) })
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, SplashView.TOTAL_MS)
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private class SplashView(ctx: Context) : View(ctx) {
        companion object { const val TOTAL_MS = 2600L }

        private val accent = 0xFFFF2D3D.toInt()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val logo: Bitmap = BitmapFactory.decodeResource(ctx.resources, R.drawable.myra_logo)
        private val stars = List(70) { Star(Random.nextFloat(), Random.nextFloat(), 0.4f + Random.nextFloat() * 1.8f, 0.02f + Random.nextFloat() * 0.06f, Random.nextFloat()) }
        private class Star(var x: Float, var y: Float, val r: Float, val speed: Float, val phase: Float)
        private var t = 0f
        private var clock = 0f
        private val lines = listOf("opening the control room...", "syncing users...", "checking payments...", "ready, boss")

        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = TOTAL_MS; interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; clock = t * TOTAL_MS / 1000f; invalidate() }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

        private fun ease(x: Float) = 1f - (1f - x) * (1f - x)
        private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val d = resources.displayMetrics.density
            c.drawColor(0xFF040408.toInt())

            p.shader = RadialGradient(w * 0.2f, h * 0.15f, w, intArrayOf(withA(accent, 70), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = RadialGradient(w * 0.9f, h * 0.9f, w, intArrayOf(withA(0xFF7C4DFF.toInt(), 60), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            for (s in stars) {
                s.y -= s.speed * 0.016f
                if (s.y < 0f) { s.y = 1f; s.x = Random.nextFloat() }
                val tw = 0.4f + 0.6f * (0.5f + 0.5f * sin(clock * 2f + s.phase * 6f))
                p.color = withA(Color.WHITE, (tw * 170).toInt())
                c.drawCircle(s.x * w, s.y * h, s.r * d, p)
            }

            val cx = w / 2f; val cy = h * 0.40f
            val base = min(w, h) * 0.20f
            val appear = ease((t / 0.25f).coerceIn(0f, 1f))
            val breathe = 1f + 0.04f * sin(clock * 3.2f)
            val r = maxOf(base * appear * breathe, 2f)

            for (i in 0 until 3) {
                val ph = ((clock * 0.7f) + i / 3f) % 1f
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d
                p.color = withA(accent, ((1f - ph) * 120 * appear).toInt())
                c.drawCircle(cx, cy, r * (1f + ph * 1.1f), p)
            }
            p.style = Paint.Style.FILL

            p.shader = RadialGradient(cx, cy, r * 2.4f, intArrayOf(withA(accent, 150), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 2.4f, p)
            p.shader = null

            val half = r * 1.15f
            val dst = RectF(cx - half, cy - half, cx + half, cy + half)
            val clip = Path().apply { addRoundRect(dst, half * 0.44f, half * 0.44f, Path.Direction.CW) }
            c.save(); c.clipPath(clip)
            p.alpha = (255 * appear).toInt()
            c.drawBitmap(logo, null, dst, p)
            p.alpha = 255
            c.restore()

            val a = clock * 2.4f
            p.color = Color.WHITE
            c.drawCircle(cx + cos(a) * r * 1.6f, cy + sin(a) * r * 1.6f, 3.5f * d, p)

            val ty = cy + base * 2.1f + 30f * d
            p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            p.textSize = 22f * d; p.letterSpacing = 0.3f
            val title = "ADMIN"
            p.color = withA(accent, (255 * ease(((t - 0.25f) / 0.2f).coerceIn(0f, 1f))).toInt())
            p.setShadowLayer(18f * d, 0f, 0f, accent)
            c.drawText(title, cx - p.measureText(title) / 2f, ty, p)
            p.clearShadowLayer(); p.letterSpacing = 0f

            val idx = min((t * lines.size).toInt(), lines.size - 1)
            p.typeface = Typeface.DEFAULT; p.textSize = 13f * d; p.color = 0xFFB0B0C8.toInt()
            val line = lines[idx]
            c.drawText(line, cx - p.measureText(line) / 2f, ty + 34f * d, p)

            val bw = w * 0.5f; val bh = 4f * d; val by = h * 0.86f
            p.color = 0x22FFFFFF
            c.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + bh, bh, bh, p)
            p.shader = LinearGradient(cx - bw / 2, 0f, cx + bw / 2, 0f, intArrayOf(accent, Color.WHITE), null, Shader.TileMode.CLAMP)
            c.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * t, by + bh, bh, bh, p)
            p.shader = null

            p.typeface = Typeface.create("sans-serif-light", Typeface.ITALIC); p.textSize = 11f * d; p.color = 0xFF8A8AA0.toInt()
            val credit = "Made by Anik"
            c.drawText(credit, cx - p.measureText(credit) / 2f, h - 28f * d, p)
        }
    }
}
