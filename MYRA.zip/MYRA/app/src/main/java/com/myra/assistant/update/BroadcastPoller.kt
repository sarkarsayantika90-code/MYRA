package com.myra.assistant.update

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.myra.assistant.R
import com.myra.assistant.auth.FirebaseRest
import com.myra.assistant.auth.Session
import com.myra.assistant.premium.PremiumManager
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.prefs
import org.json.JSONObject

/**
 * Admin notifications. The admin site writes broadcasts/b<time>; phones check every minute while
 * MYRA is on, and every ~15 minutes in the background (Android's minimum for background work).
 * Target: all | premium | free | a single user id.
 */
object BroadcastPoller {
    /** Returns how many new notifications were shown. Blocking. */
    fun check(ctx: Context): Int {
        val s = Session.get(ctx) ?: return 0
        val p = ctx.prefs()
        var last = p.getString("bc_last", "") ?: ""
        if (last.isEmpty()) {
            val first = p.getLong("first_seen", System.currentTimeMillis())
            last = "b%013d".format(first)          // a fresh install never gets old messages
        }
        val raw = try {
            FirebaseRest.dbGetQ(ctx, "broadcasts", "orderBy=%22%24key%22&startAt=%22$last%22&limitToLast=10")
        } catch (e: Exception) { return 0 }
        if (raw == "null" || raw.isBlank()) return 0
        val o = JSONObject(raw)
        val now = System.currentTimeMillis()
        val premium = PremiumManager.isPremium(ctx)
        var shown = 0
        var newest = last
        for (key in o.keys().asSequence().sorted()) {
            if (key <= last) continue
            if (key > newest) newest = key
            val b = o.optJSONObject(key) ?: continue
            val target = b.optString("target", "all")
            val ok = target == "all" || target == s.uid || (target == "premium" && premium) || (target == "free" && !premium)
            val exp = b.optLong("expires", 0L)
            if (!ok || (exp in 1 until now)) continue
            show(ctx, key.hashCode(), b.optString("title", "MYRA"), b.optString("body"), b.optString("url"))
            com.myra.assistant.services.ForegroundVoiceService.instance?.announceBroadcast(b.optString("title"), b.optString("body"))
            shown++
        }
        if (newest != last) p.edit().putString("bc_last", newest).apply()
        return shown
    }

    private fun show(ctx: Context, id: Int, title: String, body: String, url: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("myra_news", "MYRA news", NotificationManager.IMPORTANCE_DEFAULT))
        val intent = if (url.startsWith("https://")) Intent(Intent.ACTION_VIEW, Uri.parse(url)) else Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            nm.notify(id, NotificationCompat.Builder(ctx, "myra_news")
                .setSmallIcon(R.drawable.ic_myra_notif).setContentTitle(title).setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(pi).setAutoCancel(true).build())
        } catch (_: SecurityException) {}
    }
}

class BroadcastWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            BroadcastPoller.check(applicationContext)
            if (!com.myra.assistant.services.ForegroundVoiceService.isRunning) com.myra.assistant.auth.ProfileSync.sync(applicationContext)
        } catch (_: Exception) {}
        return Result.success()
    }
}
