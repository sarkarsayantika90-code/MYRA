package com.myra.assistant.utils

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Is any MYRA screen on the display right now? Used so the "Hey Myra" glow and the standby mode only
 * apply while the user is in ANOTHER app / on the home screen.
 */
object AppVisibility {
    fun interface Listener { fun onChanged(foreground: Boolean) }

    @Volatile private var started = 0
    @Volatile var isForeground = false
        private set

    private val listeners = CopyOnWriteArraySet<Listener>()
    private val main = Handler(Looper.getMainLooper())
    private val goBackground = Runnable {
        if (started == 0 && isForeground) { isForeground = false; notifyAll(false) }
    }

    fun add(l: Listener) { listeners.add(l) }
    fun remove(l: Listener) { listeners.remove(l) }

    private fun notifyAll(fg: Boolean) { for (l in listeners) try { l.onChanged(fg) } catch (_: Exception) {} }

    fun install(app: Application) {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                started++
                main.removeCallbacks(goBackground)
                if (!isForeground) { isForeground = true; notifyAll(true) }
            }
            override fun onActivityStopped(activity: Activity) {
                if (started > 0) started--
                // Moving between two of our screens (or rotating) stops one activity before the next starts:
                // wait a moment before calling it "background".
                if (started == 0) main.postDelayed(goBackground, 1000)
            }
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
