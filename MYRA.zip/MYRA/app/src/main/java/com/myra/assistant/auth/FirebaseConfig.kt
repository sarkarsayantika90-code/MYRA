package com.myra.assistant.auth

/**
 * Firebase project "sayantika-afefe" (from google-services.json).
 * We talk to Firebase over its public REST API, so the google-services Gradle plugin is NOT needed
 * (it would fail anyway: that json is registered for package "sayantikaanik.com", not com.myra.assistant).
 * A Firebase web/API key is not a secret; real protection = the Realtime Database RULES in FIREBASE_SETUP.md.
 */
object FirebaseConfig {
    const val API_KEY = "AIzaSyDeRgRglK6lyAtcpJBdZD5l-hoGfMnm4xs"
    const val DB_URL = "https://sayantika-afefe-default-rtdb.firebaseio.com"

    /** The owner's email: always premium + sees the Admin payments screen. */
    const val ADMIN_EMAIL = "anikmondal71001@gmail.com"

    /**
     * Google login: paste the "Web client ID" here (Firebase console > Authentication > Sign-in method >
     * Google > Web SDK configuration). Looks like 1234567890-abc123.apps.googleusercontent.com
     */
    const val GOOGLE_WEB_CLIENT_ID = ""

    /** UPI details from the PhonePe QR (used for the "Pay with UPI app" button). */
    const val UPI_ID = "9775171981-4@axl"
    const val UPI_NAME = "ANIK MONDAL"
}
