package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.control.PhoneController
import com.myra.assistant.models.CommandType
import com.myra.assistant.models.VoiceCommand
import com.myra.assistant.utils.ContactLookup
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.PrimeContacts
import com.myra.assistant.whatsapp.WhatsAppAgent
import org.json.JSONArray
import org.json.JSONObject

/**
 * The tool belt handed to Gemini (function calling) + the dispatcher that runs each call.
 * The model decides WHICH tool; Android code does the doing, checks the result and returns a
 * short text the model then speaks. No coordinates ever go to or come from the model.
 */
object MyraTools {
    private const val TAG = "MYRA_TOOLS"

    internal fun prop(type: String, desc: String, enum: List<String>? = null) = JSONObject().apply {
        put("type", type)
        put("description", desc)
        if (enum != null) put("enum", JSONArray(enum))
    }

    internal fun fn(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList()) =
        JSONObject().apply {
            put("name", name)
            put("description", desc)
            if (props.isNotEmpty()) {
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().also { o -> props.forEach { (k, v) -> o.put(k, v) } })
                    if (required.isNotEmpty()) put("required", JSONArray(required))
                })
            }
        }

    fun declarations(): JSONArray = JSONArray().apply {
        val extra = ToolRegistry.declarations()
        for (i in 0 until extra.length()) put(extra.get(i))
        put(fn("open_app", "Open any installed app. Pass the app name in English exactly as it appears on the phone (e.g. WhatsApp, YouTube, Instagram, Chrome, Settings, Camera).",
            mapOf("app_name" to prop("STRING", "App name")), listOf("app_name")))
        put(fn("search_in_app", "Search inside an app (YouTube, Play Store, Chrome/Google, Maps, Spotify, Instagram, Amazon, Flipkart, Settings ... any app with a search box). Leave app_name empty for a normal Google search.",
            mapOf("app_name" to prop("STRING", "App to search in, or empty for Google"), "query" to prop("STRING", "What to search")), listOf("query")))
        put(fn("open_url", "Open a web link in the browser.", mapOf("url" to prop("STRING", "Full URL")), listOf("url")))
        put(fn("read_screen", "Read what is on the phone screen right now (app name, texts, buttons). Use it whenever the user asks what is on screen / what is happening, and BEFORE tapping if you are unsure what is visible.", emptyMap()))
        put(fn("tap_text", "Tap a button/link/item on the CURRENT screen by its visible label (e.g. 'Search', 'Subscribe', 'Allow', 'Next').",
            mapOf("text" to prop("STRING", "Visible label of the thing to tap")), listOf("text")))
        put(fn("scroll", "Scroll the current screen. 'down' reveals content further down the page.",
            mapOf("direction" to prop("STRING", "Direction", listOf("down", "up", "left", "right")),
                "times" to prop("INTEGER", "How many times, default 1")), listOf("direction")))
        put(fn("type_text", "Type text into the text box that is focused/visible on screen. Set press_enter true to submit (search/send-in-search).",
            mapOf("text" to prop("STRING", "Text to type"), "press_enter" to prop("BOOLEAN", "Press enter/search after typing")), listOf("text")))
        put(fn("press_key", "System buttons and panels.",
            mapOf("key" to prop("STRING", "Which one", listOf("back", "home", "recents", "notifications", "quick_settings", "screenshot", "power_menu", "lock"))), listOf("key")))
        put(fn("open_settings", "Open a phone Settings page.",
            mapOf("page" to prop("STRING", "wifi, bluetooth, display, sound, battery, location, airplane, apps, accessibility, storage, data, or general")), listOf("page")))
        put(fn("call_contact", "Phone-call a contact by name (or a number). Prime contacts are checked first. If it says contact_ambiguous, ask which one.",
            mapOf("name" to prop("STRING", "Contact name or phone number")), listOf("name")))
        put(fn("answer_call", "Answer the phone call that is ringing right now.", emptyMap()))
        put(fn("end_call", "End the current call or reject the ringing call.", emptyMap()))
        put(fn("send_sms", "Write and send a text SMS. STEP 1 of 2: creates a draft only and returns awaiting_confirmation. If the user has not told you WHO or WHAT to write, ASK first (one short question). Write a natural, correct message yourself from what the user meant, in the language they want.",
            mapOf("name" to prop("STRING", "Contact name or phone number"), "message" to prop("STRING", "Final SMS text you wrote")), listOf("name", "message")))
        put(fn("confirm_sms", "STEP 2 of 2: actually send the pending SMS. Call ONLY after you read the recipient and exact text aloud and the user clearly said yes.", emptyMap()))
        put(fn("cancel_sms", "Discard the pending SMS draft (user said no or wants changes).", emptyMap()))
        put(fn("take_photo", "Open the camera app and take a photo by pressing the shutter yourself. Only when the user asks for a photo now.",
            mapOf("camera" to prop("STRING", "back or front (selfie)", listOf("back", "front")),
                "timer_seconds" to prop("INTEGER", "Wait this many seconds before shooting, 0-10")), emptyList()))
        put(fn("long_press_text", "Long-press an item on the current screen by its visible label.", mapOf("text" to prop("STRING", "Label")), listOf("text")))
        put(fn("wait", "Wait a moment for a screen to load (max 5 seconds).", mapOf("seconds" to prop("INTEGER", "Seconds 1-5")), emptyList()))
        put(fn("list_prime_contacts", "List the user's prime (favourite) contacts by name.", emptyMap()))
        put(fn("execute_whatsapp_task",
            "Do ONE WhatsApp job for the owner. send_message only creates a DRAFT and returns awaiting_confirmation. Never for more than one recipient at once.",
            mapOf(
                "action" to prop("STRING", "What to do", listOf("send_message", "read_unread", "read_chat", "mute_chat", "unmute_chat", "mark_read", "search_chat", "video_call", "voice_call")),
                "contact_query" to prop("STRING", "Contact/chat name"),
                "message" to prop("STRING", "Message text (send_message only)"),
                "count" to prop("INTEGER", "How many latest messages for read_chat (default 3)")
            ), listOf("action")))
        put(fn("whatsapp_task_control",
            "Control the pending WhatsApp draft. Call confirm ONLY after you read the exact draft and recipient aloud AND the user clearly said yes.",
            mapOf("command" to prop("STRING", "Command", listOf("confirm", "reject", "cancel", "resume", "status")),
                "task_id" to prop("STRING", "Task id from the draft, optional")), listOf("command")))
        put(fn("read_notifications", "Read the latest notifications aloud.", emptyMap()))
        put(fn("clear_notifications", "Clear all notifications.", emptyMap()))
        put(fn("read_missed_calls", "Tell the user about missed calls.", emptyMap()))
        put(fn("media_control", "Control music/video playback.",
            mapOf("action" to prop("STRING", "Action", listOf("PLAY", "PAUSE", "NEXT", "PREVIOUS", "STOP"))), listOf("action")))
        put(fn("set_alarm", "Set an alarm.", mapOf("hour" to prop("INTEGER", "Hour 0-23"), "minute" to prop("INTEGER", "Minute 0-59"),
            "label" to prop("STRING", "Label")), listOf("hour")))
        put(fn("set_timer", "Set a countdown timer.", mapOf("minutes" to prop("INTEGER", "Minutes")), listOf("minutes")))
        put(fn("flashlight", "Turn the torch on or off.", mapOf("on" to prop("BOOLEAN", "true = on")), listOf("on")))
        put(fn("change_volume", "Change media volume.", mapOf("direction" to prop("STRING", "up or down", listOf("up", "down"))), listOf("direction")))
        put(fn("get_battery", "Battery level and charging state.", emptyMap()))
        put(fn("set_clipboard", "Copy text to the clipboard.", mapOf("text" to prop("STRING", "Text")), listOf("text")))
        put(fn("lock_phone", "Lock the phone screen now.", emptyMap()))
        put(fn("get_time", "Current date and time.", emptyMap()))
        put(fn("set_volume", "Set an exact volume percent.",
            mapOf("percent" to prop("INTEGER", "0-100"), "stream" to prop("STRING", "media, ring, alarm or call", listOf("media", "ring", "alarm", "call"))), listOf("percent")))
        put(fn("set_brightness", "Set screen brightness percent (needs 'modify system settings' permission).",
            mapOf("percent" to prop("INTEGER", "1-100")), listOf("percent")))
        put(fn("toggle_setting", "Flip a quick setting by tapping its tile: wifi, bluetooth, airplane, dnd, rotate, location, hotspot, data, battery saver, flashlight.",
            mapOf("name" to prop("STRING", "Which setting")), listOf("name")))
        put(fn("power_off_phone", "Switch the phone OFF (or restart). VERY disruptive: first ask the user 'phone bondho kori?' and only pass confirmed=true after they clearly said yes in reply.",
            mapOf("confirmed" to prop("BOOLEAN", "true only after the user said yes"), "restart" to prop("BOOLEAN", "true = restart instead of off")), listOf("confirmed")))
        put(fn("navigate_to", "Start Google Maps navigation to a place.", mapOf("place" to prop("STRING", "Destination")), listOf("place")))
        put(fn("create_event", "Add a calendar event.",
            mapOf("title" to prop("STRING", "Event title"), "hour" to prop("INTEGER", "0-23"), "minute" to prop("INTEGER", "0-59"),
                "days_from_today" to prop("INTEGER", "0 = today, 1 = tomorrow")), listOf("title", "hour")))
        put(fn("add_prime_contact", "Save a person as a PRIME contact in MYRA (name + phone number).",
            mapOf("name" to prop("STRING", "Name"), "number" to prop("STRING", "Phone number")), listOf("name", "number")))
        put(fn("save_new_contact", "Open the phone's new-contact form pre-filled with a name and number.",
            mapOf("name" to prop("STRING", "Name"), "number" to prop("STRING", "Number")), listOf("name", "number")))
        put(fn("self_check", "Check MYRA's own health (API key, mic, internet, accessibility, permissions) and get exactly what must be fixed. Use when something did not work, or the user says MYRA has a problem. Tell the user the fix in simple words.", emptyMap()))
        put(fn("stop_myra", "Turn MYRA fully off. Only when the user clearly asks you to stop / go off.", emptyMap()))
    }

    private fun cmd(ctx: Context, type: CommandType, raw: String, vararg args: Pair<String, String>) =
        VoiceCommand(raw, type, args.toMap())

    private suspend fun engine(ctx: Context, c: VoiceCommand): String =
        DynamicDecisionEngine.execute(ctx, c).ifBlank { "done" }

    suspend fun execute(ctx: Context, name: String, a: JSONObject): String {
        Logger.d(TAG, "tool=$name")
        if (com.myra.assistant.premium.PremiumPlans.GATING_ENABLED &&
            name in com.myra.assistant.premium.PremiumPlans.PREMIUM_TOOLS &&
            !com.myra.assistant.premium.PremiumManager.isPremium(ctx)) {
            return "premium_required: Ei feature MYRA Premium e ache. User ke mishti kore bolo Settings > Premium theke plan nite, tahole tumi eta korte parbe."
        }
        return try {
            ToolRegistry.run(ctx, name, a)?.let { return it }
            when (name) {
                "open_app" -> PhoneController.openApp(ctx, a.optString("app_name"))
                "search_in_app" -> PhoneController.searchInApp(ctx, a.optString("app_name"), a.optString("query"))
                "open_url" -> engine(ctx, cmd(ctx, CommandType.OPEN_URL, "open url", "url" to a.optString("url")))
                "read_screen" -> PhoneController.readScreen()
                "tap_text" -> PhoneController.tapTextWait(a.optString("text"))
                "scroll" -> PhoneController.scroll(a.optString("direction", "down"), a.optInt("times", 1))
                "type_text" -> PhoneController.typeText(a.optString("text"), a.optBoolean("press_enter", false))
                "press_key" -> PhoneController.globalAction(a.optString("key"))
                "open_settings" -> PhoneController.openSettings(ctx, a.optString("page", "general"))
                "call_contact" -> callContact(ctx, a.optString("name"))
                "answer_call" -> PhoneController.answerCall(ctx)
                "end_call" -> PhoneController.endCall(ctx)
                "send_sms" -> com.myra.assistant.control.SmsAgent.prepare(ctx, a.optString("name"), a.optString("message"))
                "confirm_sms" -> com.myra.assistant.control.SmsAgent.confirm(ctx)
                "cancel_sms" -> com.myra.assistant.control.SmsAgent.cancel()
                "take_photo" -> com.myra.assistant.control.CameraController.takePhoto(
                    ctx, a.optString("camera", "back") == "front", a.optInt("timer_seconds", 0))
                "long_press_text" -> PhoneController.longPressText(a.optString("text"))
                "wait" -> { kotlinx.coroutines.delay(a.optInt("seconds", 1).coerceIn(1, 5) * 1000L); "waited" }
                "list_prime_contacts" -> {
                    val l = PrimeContacts.all(ctx)
                    if (l.isEmpty()) "Kono prime contact add kora nai (Personalize > Prime contacts e add koro)"
                    else l.joinToString(", ") { it.name }
                }
                "execute_whatsapp_task" -> WhatsAppAgent.run(
                    ctx, a.optString("action"), a.optString("contact_query").ifBlank { null },
                    a.optString("message").ifBlank { null }, a.optInt("count", 3)
                )
                "whatsapp_task_control" -> WhatsAppAgent.control(ctx, a.optString("command"), a.optString("task_id").ifBlank { null })
                "read_notifications" -> engine(ctx, cmd(ctx, CommandType.READ_NOTIFICATIONS, "read notifications"))
                "clear_notifications" -> engine(ctx, cmd(ctx, CommandType.CLEAR_NOTIFICATIONS, "clear notifications"))
                "read_missed_calls" -> engine(ctx, cmd(ctx, CommandType.READ_MISSED_CALLS, "missed calls"))
                "media_control" -> engine(ctx, cmd(ctx, CommandType.MEDIA_CONTROL, "media", "action" to a.optString("action")))
                "set_alarm" -> engine(ctx, cmd(ctx, CommandType.SET_ALARM, "alarm",
                    "hour" to a.optInt("hour", -1).toString(), "minute" to a.optInt("minute", 0).toString(), "label" to a.optString("label")))
                "set_timer" -> engine(ctx, cmd(ctx, CommandType.SET_TIMER, "timer", "minutes" to a.optInt("minutes", 0).toString()))
                "flashlight" -> engine(ctx, cmd(ctx, if (a.optBoolean("on", true)) CommandType.FLASHLIGHT_ON else CommandType.FLASHLIGHT_OFF, "torch"))
                "change_volume" -> engine(ctx, cmd(ctx, if (a.optString("direction") == "down") CommandType.VOLUME_DOWN else CommandType.VOLUME_UP, "volume"))
                "get_battery" -> engine(ctx, cmd(ctx, CommandType.GET_BATTERY, "battery"))
                "set_clipboard" -> engine(ctx, cmd(ctx, CommandType.SET_CLIPBOARD, "clipboard", "text" to a.optString("text")))
                "lock_phone" -> engine(ctx, cmd(ctx, CommandType.LOCK_DEVICE, "lock"))
                "get_time" -> com.myra.assistant.control.SystemTools.getTime()
                "set_volume" -> com.myra.assistant.control.SystemTools.setVolume(ctx, a.optInt("percent", 50), a.optString("stream", "media"))
                "set_brightness" -> com.myra.assistant.control.SystemTools.setBrightness(ctx, a.optInt("percent", 50))
                "toggle_setting" -> com.myra.assistant.control.SystemTools.toggleQuickSetting(a.optString("name"))
                "power_off_phone" ->
                    if (!a.optBoolean("confirmed", false)) "awaiting_confirmation: User ke jiggesh koro 'phone ${if (a.optBoolean("restart")) "restart" else "bondho"} kori?', 'haan' shunle confirmed=true diye abar call koro."
                    else com.myra.assistant.control.SystemTools.powerMenu(a.optBoolean("restart", false))
                "navigate_to" -> com.myra.assistant.control.SystemTools.navigate(ctx, a.optString("place"))
                "create_event" -> com.myra.assistant.control.SystemTools.createEvent(
                    ctx, a.optString("title"), a.optInt("hour", 9), a.optInt("minute", 0), a.optInt("days_from_today", 0))
                "add_prime_contact" -> com.myra.assistant.control.SystemTools.addPrimeContact(ctx, a.optString("name"), a.optString("number"))
                "save_new_contact" -> com.myra.assistant.control.SystemTools.saveNewContact(ctx, a.optString("name"), a.optString("number"))
                "self_check" -> com.myra.assistant.utils.HealthCheck.problemsOnly(ctx)
                "stop_myra" -> "ok"   // the service performs the actual shutdown after speaking
                else -> "unknown tool: $name"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "tool $name failed: ${e.message}")
            "error: ${e.message ?: "tool failed"}"
        }
    }

    private fun callContact(ctx: Context, nameOrNumber: String): String {
        val q = nameOrNumber.trim()
        if (q.isBlank()) return "Kake call korbo?"
        val number: String
        var shown = q
        if (q.count { it.isDigit() } >= 6) {
            number = q
        } else {
            val matches = ContactLookup.findAll(ctx, q)
            if (matches.isEmpty()) return "contact_not_found: '$q' naame kono contact nai"
            val exact = matches.filter { it.first.equals(q, true) }
            val pick = if (exact.size == 1) exact else matches
            if (pick.map { it.first.lowercase() }.distinct().size > 1) {
                return "contact_ambiguous: " + pick.take(5).joinToString(", ") { it.first } + ". Kon ta?"
            }
            number = pick.first().second
            shown = pick.first().first
        }
        return if (com.myra.assistant.automation.CallAutomation.makeCall(ctx, number)) "calling $shown"
        else "Call permission nai, Settings e Grant permissions koro"
    }
}
