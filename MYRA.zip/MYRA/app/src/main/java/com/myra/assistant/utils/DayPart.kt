package com.myra.assistant.utils

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** One place that knows what part of the day it is, so MYRA never says "good morning" at night. */
object DayPart {
    /** morning 5-11, afternoon 12-16, evening 17-20, night 21-23, late night 0-4. */
    fun name(hour: Int): String = when (hour) {
        in 5..11 -> "morning"
        in 12..16 -> "afternoon"
        in 17..20 -> "evening"
        in 21..23 -> "night"
        else -> "late night"
    }

    fun greeting(hour: Int): String = when (name(hour)) {
        "morning" -> "Good morning"
        "afternoon" -> "Good afternoon"
        "evening" -> "Good evening"
        else -> "Hello"            // night / late night: never "good morning"
    }

    /** What a caring assistant would naturally ask at this time of day. */
    fun careHint(hour: Int): String = when (name(hour)) {
        "morning" -> "ask about sleep and breakfast"
        "afternoon" -> "ask if he had lunch"
        "evening" -> "ask about tea/snacks and how his day went"
        "night" -> "ask about dinner, and gently when he will sleep"
        else -> "it is very late: lovingly tell him to sleep soon"
    }

    /** e.g. "It is 11:42 PM (23:42), Saturday, 03 October 2026 - night. Time zone: Asia/Kolkata." */
    fun describe(now: Date = Date()): String {
        val c = Calendar.getInstance().apply { time = now }
        val loc = Locale.ENGLISH
        val t12 = SimpleDateFormat("hh:mm a", loc).format(now)
        val t24 = SimpleDateFormat("HH:mm", loc).format(now)
        val day = SimpleDateFormat("EEEE, dd MMMM yyyy", loc).format(now)
        return "It is $t12 ($t24), $day - ${name(c.get(Calendar.HOUR_OF_DAY))}. Time zone: ${java.util.TimeZone.getDefault().id}."
    }
}
