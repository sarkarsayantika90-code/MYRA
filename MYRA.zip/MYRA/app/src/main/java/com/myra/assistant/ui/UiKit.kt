package com.myra.assistant.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny helpers so code-built screens look consistent (dark glass + accent colour). */
object UiKit {
    const val BG = 0xFF040408.toInt()
    const val TEXT = 0xFFE8E8FF.toInt()
    const val DIM = 0xFF8888A0.toInt()

    /** Dark base with a soft accent glow in the top corner - one look for every screen. */
    fun screenBg(c: Context, accent: Int): android.graphics.drawable.Drawable {
        val glow = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(c, 420).toFloat()
            setGradientCenter(0.15f, 0.0f)
            colors = intArrayOf((accent and 0x00FFFFFF) or 0x55000000, Color.TRANSPARENT)
        }
        val glow2 = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(c, 380).toFloat()
            setGradientCenter(1.0f, 1.0f)
            colors = intArrayOf(0x447C4DFF, Color.TRANSPARENT)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(android.graphics.drawable.ColorDrawable(BG), glow, glow2))
    }

    fun dp(c: Context, v: Int) = (c.resources.displayMetrics.density * v).toInt()

    fun rounded(color: Int, radius: Int, stroke: Int = 0, strokeW: Int = 0, c: Context): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(c, radius).toFloat()
            if (stroke != 0) setStroke(dp(c, strokeW.coerceAtLeast(1)), stroke)
        }

    fun label(c: Context, t: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false, center: Boolean = false) =
        TextView(c).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            if (center) gravity = Gravity.CENTER
            setPadding(0, dp(c, 2), 0, dp(c, 2))
        }

    fun input(c: Context, hint: String, password: Boolean = false, email: Boolean = false) = EditText(c).apply {
        this.hint = hint
        setHintTextColor(0xFF666688.toInt()); setTextColor(TEXT)
        background = rounded(0xFF14141F.toInt(), 14, 0x33FFFFFF, 1, c)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        setSingleLine(true)
        inputType = when {
            password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            email -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            else -> InputType.TYPE_CLASS_TEXT
        }
    }

    fun button(c: Context, t: String, accent: Int, filled: Boolean = true, onClick: () -> Unit) = Button(c).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(if (filled) Color.WHITE else accent)
        background = if (filled) rounded(accent, 16, 0, 0, c) else rounded(Color.TRANSPARENT, 16, accent, 2, c)
        setOnClickListener { onClick() }
        minimumHeight = dp(c, 50)
    }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0, c: Context) =
        LinearLayout.LayoutParams(w, h).also { it.topMargin = dp(c, top) }

    fun card(c: Context, accentBorder: Int = 0x22FFFFFF): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(0xFF0E0E18.toInt(), 20, accentBorder, 1, c)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    fun visible(v: View, show: Boolean) { v.visibility = if (show) View.VISIBLE else View.GONE }
}
