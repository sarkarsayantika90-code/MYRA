package com.myra.assistant.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.myra.assistant.utils.Logger
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * PDF §8 Notification Tools — read_notifications / clear_notifications /
 * read_missed_calls.
 *
 * IMPORTANT: This requires a SEPARATE permission that cannot be requested
 * via a normal runtime dialog or manifest <uses-permission>. The user must
 * manually enable it: Settings → Apps → Special access → Notification
 * access → MYRA → Allow. There is no way around this — it's an
 * Android platform restriction (notification content is sensitive).
 *
 * Per PDF §16 safety rules: this NEVER auto-reads OTPs aloud, and content is
 * only surfaced when the user explicitly asks ("Notifications padho").
 * This class only captures/holds recent notifications; it does not decide
 * when to speak them — that's the caller's job (DynamicDecisionEngine).
 */
class MyraNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Never capture our own notifications (foreground service, overlay etc.)
        if (sbn.packageName == packageName) return

        // WhatsApp unread tracker (read-only, in-memory, never logged)
        com.myra.assistant.whatsapp.WhatsAppNotificationStore.onPosted(sbn)

        // Owner phone only: look for "money received" notifications to auto-verify premium payments.
        if (com.myra.assistant.auth.Session.isAdmin(this)) {
            try {
                val ex = sbn.notification.extras
                val txt = listOfNotNull(
                    ex.getCharSequence(android.app.Notification.EXTRA_TITLE),
                    ex.getCharSequence(android.app.Notification.EXTRA_TEXT),
                    ex.getCharSequence(android.app.Notification.EXTRA_BIG_TEXT)
                ).joinToString(" ")
                com.myra.assistant.premium.PaymentAutoVerifier.onNotificationText(txt)
                com.myra.assistant.premium.PaymentAutoVerifier.start(this)
            } catch (_: Exception) {}
        }

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val entry = CapturedNotification(
            appPackage = sbn.packageName,
            appLabel = appLabelFor(sbn.packageName),
            title = title,
            text = text,
            postedAt = sbn.postTime
        )

        recent.add(entry)
        while (recent.size > MAX_HELD) recent.poll()

        Logger.d(TAG, "Captured notification from ${entry.appLabel}")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        com.myra.assistant.whatsapp.WhatsAppNotificationStore.onRemoved(sbn)
        // No-op: we keep our own short rolling history regardless of
        // whether the system notification was dismissed, so
        // read_notifications still works for "what did I just get".
    }

    private fun appLabelFor(packageName: String): String = try {
        val pm = applicationContext.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
    } catch (e: Exception) {
        packageName
    }

    /** Clears MYRA's own captured history AND the actual status bar (clear_notifications tool). */
    fun clearAll() {
        recent.clear()
        try {
            cancelAllNotifications()
        } catch (e: Exception) {
            Logger.e(TAG, "cancelAllNotifications failed: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "NOTIF_LISTENER"
        private const val MAX_HELD = 20

        // Simple in-memory rolling buffer. This is intentionally NOT part of
        // the Phase 2 Task/Room persistence layer — it's transient device
        // state, not something that needs to survive app restart.
        private val recent = ConcurrentLinkedQueue<CapturedNotification>()

        @Volatile private var instance: MyraNotificationListenerService? = null

        /** Returns false if the listener isn't connected (permission not granted). */
        fun clearAllNotifications(): Boolean {
            val svc = instance ?: return false
            svc.clearAll()
            return true
        }

        fun isEnabled(context: android.content.Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            ) ?: return false
            return enabled.contains(context.packageName)
        }

        fun getRecent(limit: Int = 5): List<CapturedNotification> =
            recent.toList().takeLast(limit).reversed()
    }

    data class CapturedNotification(
        val appPackage: String,
        val appLabel: String,
        val title: String,
        val text: String,
        val postedAt: Long
    )
}
