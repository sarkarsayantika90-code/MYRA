package com.myra.assistant.task

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.work.ExistingWorkPolicy
import java.util.concurrent.TimeUnit

/**
 * Wraps WorkManager so the rest of the task system doesn't talk to it
 * directly. This is intentionally a thin scheduling layer only — it does
 * NOT execute task logic itself (see Phase 2 note in TaskManager: execution
 * is a separate concern, added when a real executor/Hermes adapter exists).
 *
 * Per Phase 1 guidance: Android cannot run unlimited background work.
 * WorkManager gives best-effort deferred/periodic execution subject to
 * Doze/App Standby — it is not a guarantee of exact timing. Long, actively
 * running tasks should also keep the existing ForegroundVoiceService (or a
 * dedicated foreground service) alive while RUNNING, rather than relying on
 * WorkManager alone.
 */
class TaskScheduler(private val context: Context) {

    private val workManager get() = WorkManager.getInstance(context)

    /** Enqueue a one-off background continuation for an existing task (e.g. after WAITING_FOR_NETWORK). */
    fun enqueueResume(taskId: String) {
        val request = OneTimeWorkRequestBuilder<TaskWorker>()
            .setInputData(Data.Builder().putString(KEY_TASK_ID, taskId).build())
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, MIN_BACKOFF_MS, TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniqueWork(uniqueName(taskId), ExistingWorkPolicy.REPLACE, request)
    }

    /** Recurring task, e.g. "every morning summarize my emails" (Phase 1 scheduled-task example). */
    fun enqueueDaily(taskId: String, hour: Int, minute: Int) {
        val request = PeriodicWorkRequestBuilder<TaskWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(millisUntilNext(hour, minute), TimeUnit.MILLISECONDS)
            .setInputData(Data.Builder().putString(KEY_TASK_ID, taskId).build())
            .build()
        workManager.enqueueUniquePeriodicWork(
            uniqueName(taskId),
            androidx.work.ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun cancel(taskId: String) {
        workManager.cancelUniqueWork(uniqueName(taskId))
    }

    private fun uniqueName(taskId: String) = "myra_task_$taskId"

    private fun millisUntilNext(hour: Int, minute: Int): Long {
        val now = java.util.Calendar.getInstance()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (before(now)) add(java.util.Calendar.DAY_OF_MONTH, 1)
        }
        return target.timeInMillis - now.timeInMillis
    }

    companion object {
        const val KEY_TASK_ID = "task_id"
        // Matches androidx.work.WorkRequest.MIN_BACKOFF_MILLIS — WorkManager
        // rejects any backoff shorter than this.
        private const val MIN_BACKOFF_MS = 10_000L
    }
}

/**
 * Placeholder worker: on Phase 2 this only re-marks a heartbeat / logs that
 * a scheduled trigger fired. Actual execution wiring belongs to whatever
 * later phase provides a real task executor — kept out of scope here so
 * Phase 2 stays "infrastructure only" per the approved plan.
 */
class TaskWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val taskId = inputData.getString(TaskScheduler.KEY_TASK_ID) ?: return Result.failure()
        val repository = RoomTaskRepository(TaskDatabase.getInstance(applicationContext))
        val manager = TaskManager(repository)
        val task = manager.getTask(taskId) ?: return Result.failure()
        if (task.status.isTerminal) return Result.success()
        // No executor wired yet in Phase 2 — just record that the trigger fired.
        manager.reportStepProgress(taskId, task.currentStep, task.progress, message = "Scheduled trigger fired")
        return Result.success()
    }
}
