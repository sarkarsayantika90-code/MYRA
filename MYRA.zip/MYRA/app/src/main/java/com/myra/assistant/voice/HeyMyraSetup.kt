package com.myra.assistant.voice

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.PermissionUtils
import com.myra.assistant.utils.prefs

/** Shared by the home screen prompt and the Settings switch: everything "Hey Myra" needs, in one place. */
object HeyMyraSetup {
    fun isOn(activity: Activity) = activity.prefs().getBoolean(Constants.KEY_WAKE_BG, false) && WakeWordModel.isReady(activity)

    fun overlayGranted(activity: Activity) = Settings.canDrawOverlays(activity)

    /**
     * Asks for what is missing (mic, "Draw over other apps" for the glow) and starts the one-time voice model download.
     * When the download finishes, "Hey Myra" switches itself on (see [WakeWordModel.downloadAndEnable]).
     */
    fun start(activity: Activity) {
        if (!PermissionUtils.hasMicPermission(activity)) PermissionUtils.requestMissing(activity, 100)
        if (!Settings.canDrawOverlays(activity)) {
            Toast.makeText(activity, "Glow dekhate 'Draw over other apps' on koro, tarpor back e esho", Toast.LENGTH_LONG).show()
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))
                )
            } catch (_: Exception) {}
        }
        WakeWordModel.downloadAndEnable(activity.applicationContext)
    }
}
