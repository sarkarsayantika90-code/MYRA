package com.myra.assistant.task

/**
 * Phase 2 — Core Task System
 *
 * Lifecycle states for a LongTask. Transitions are enforced centrally in
 * [TaskManager] — nothing else should mutate a task's status directly.
 *
 * IMPORTANT (per approved Phase 1 architecture):
 * A task reaches COMPLETED only after actual tool/action verification.
 * The model claiming success is never sufficient on its own.
 */
enum class TaskStatus {
    QUEUED,
    PLANNING,
    RUNNING,
    WAITING_FOR_USER,
    WAITING_FOR_PERMISSION,
    WAITING_FOR_NETWORK,
    PAUSED,
    RETRYING,
    COMPLETED,
    FAILED,
    CANCELLED;

    val isTerminal: Boolean
        get() = this == COMPLETED || this == FAILED || this == CANCELLED

    val isWaiting: Boolean
        get() = this == WAITING_FOR_USER || this == WAITING_FOR_PERMISSION || this == WAITING_FOR_NETWORK

    companion object {
        /**
         * Legal next-states for each status. Any transition not listed here
         * is rejected by TaskManager.transition() and logged as an error —
         * this is what prevents e.g. a CANCELLED task from silently
         * resuming, or a task jumping straight to COMPLETED without RUNNING.
         */
        val ALLOWED_TRANSITIONS: Map<TaskStatus, Set<TaskStatus>> = mapOf(
            QUEUED to setOf(PLANNING, CANCELLED),
            PLANNING to setOf(RUNNING, PAUSED, FAILED, CANCELLED),
            RUNNING to setOf(
                WAITING_FOR_USER, WAITING_FOR_PERMISSION, WAITING_FOR_NETWORK,
                PAUSED, RETRYING, COMPLETED, FAILED, CANCELLED
            ),
            WAITING_FOR_USER to setOf(RUNNING, CANCELLED, FAILED),
            WAITING_FOR_PERMISSION to setOf(RUNNING, CANCELLED, FAILED),
            WAITING_FOR_NETWORK to setOf(RUNNING, RETRYING, CANCELLED, FAILED),
            PAUSED to setOf(RUNNING, CANCELLED),
            // PLANNING/RETRYING -> PAUSED covers TaskRecoveryManager marking
            // an interrupted (process-killed mid-flight) task safe-to-resume.
            RETRYING to setOf(RUNNING, PAUSED, FAILED, CANCELLED),
            COMPLETED to emptySet<TaskStatus>(),
            FAILED to emptySet<TaskStatus>(),
            CANCELLED to emptySet<TaskStatus>()
        )
    }
}
