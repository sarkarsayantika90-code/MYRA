package com.myra.assistant.task

import android.content.ContentValues
import android.database.Cursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/** SQLite-backed [TaskRepository]. Observers re-query whenever any write happens. */
class SqliteTaskRepository(private val helper: TaskDatabase) : TaskRepository {

    private val changes = MutableStateFlow(0L)
    private fun bump() { changes.value = changes.value + 1 }

    override suspend fun save(task: LongTask) = withContext(Dispatchers.IO) {
        helper.writableDatabase.insertWithOnConflict(
            "tasks", null, task.toValues(), android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
        )
        bump()
    }

    override suspend fun get(taskId: String): LongTask? = withContext(Dispatchers.IO) { getSync(taskId) }

    private fun getSync(taskId: String): LongTask? =
        helper.readableDatabase.query("tasks", null, "taskId = ?", arrayOf(taskId), null, null, null)
            .use { if (it.moveToFirst()) it.toTask() else null }

    private fun allSync(): List<LongTask> =
        helper.readableDatabase.query("tasks", null, null, null, null, null, "createdAt DESC")
            .use { c -> buildList { while (c.moveToNext()) add(c.toTask()) } }

    override fun observe(taskId: String): Flow<LongTask?> =
        changes.map { withContext(Dispatchers.IO) { getSync(taskId) } }

    override fun observeAll(): Flow<List<LongTask>> =
        changes.map { withContext(Dispatchers.IO) { allSync() } }

    override suspend fun getAll(): List<LongTask> = withContext(Dispatchers.IO) { allSync() }

    override suspend fun getInterruptedTasks(): List<LongTask> = withContext(Dispatchers.IO) {
        helper.readableDatabase.query(
            "tasks", null, "status IN ('RUNNING','PLANNING','RETRYING')", null, null, null, null
        ).use { c -> buildList { while (c.moveToNext()) add(c.toTask()) } }
    }

    override suspend fun delete(taskId: String) {
        withContext(Dispatchers.IO) {
            val db = helper.writableDatabase
            db.delete("tasks", "taskId = ?", arrayOf(taskId))
            db.delete("task_events", "taskId = ?", arrayOf(taskId))
            db.delete("task_checkpoints", "taskId = ?", arrayOf(taskId))
            bump()
        }
    }

    override suspend fun appendEvent(event: TaskEvent) {
        withContext(Dispatchers.IO) {
            helper.writableDatabase.insertWithOnConflict(
                "task_events", null, event.toValues(),
                android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
            )
            bump()
        }
    }

    private fun eventsSync(taskId: String): List<TaskEvent> =
        helper.readableDatabase.query(
            "task_events", null, "taskId = ?", arrayOf(taskId), null, null, "timestamp ASC"
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEvent()) } }

    override suspend fun getEvents(taskId: String): List<TaskEvent> =
        withContext(Dispatchers.IO) { eventsSync(taskId) }

    override fun observeEvents(taskId: String): Flow<List<TaskEvent>> =
        changes.map { withContext(Dispatchers.IO) { eventsSync(taskId) } }

    override suspend fun saveCheckpoint(checkpoint: TaskCheckpoint) {
        withContext(Dispatchers.IO) {
            val v = ContentValues().apply {
                put("checkpointId", checkpoint.checkpointId)
                put("taskId", checkpoint.taskId)
                put("stepIndex", checkpoint.stepIndex)
                put("stateJson", checkpoint.stateJson)
                put("createdAt", checkpoint.createdAt)
            }
            helper.writableDatabase.insertWithOnConflict(
                "task_checkpoints", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
            )
        }
    }

    override suspend fun getLatestCheckpoint(taskId: String): TaskCheckpoint? = withContext(Dispatchers.IO) {
        helper.readableDatabase.query(
            "task_checkpoints", null, "taskId = ?", arrayOf(taskId), null, null, "createdAt DESC", "1"
        ).use {
            if (it.moveToFirst()) TaskCheckpoint(
                checkpointId = it.str("checkpointId")!!,
                taskId = it.str("taskId")!!,
                stepIndex = it.int("stepIndex"),
                stateJson = it.str("stateJson")!!,
                createdAt = it.long("createdAt")
            ) else null
        }
    }

    // ---- mapping helpers ----

    private fun Cursor.str(col: String): String? = getColumnIndexOrThrow(col).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.int(col: String): Int = getInt(getColumnIndexOrThrow(col))
    private fun Cursor.long(col: String): Long = getLong(getColumnIndexOrThrow(col))

    private fun Cursor.toTask() = LongTask(
        taskId = str("taskId")!!,
        userRequest = str("userRequest")!!,
        status = TaskStatus.valueOf(str("status")!!),
        priority = int("priority"),
        createdAt = long("createdAt"),
        updatedAt = long("updatedAt"),
        currentStep = int("currentStep"),
        totalSteps = int("totalSteps"),
        plan = str("plan"),
        checkpoint = str("checkpoint"),
        progress = int("progress"),
        requiredPermissions = splitList(str("requiredPermissions")),
        pendingConfirmation = str("pendingConfirmation"),
        retryCount = int("retryCount"),
        maxRetries = int("maxRetries"),
        parentTaskId = str("parentTaskId"),
        childTaskIds = splitList(str("childTaskIds")),
        result = str("result"),
        error = str("error"),
        lastHeartbeat = long("lastHeartbeat")
    )

    private fun Cursor.toEvent() = TaskEvent(
        eventId = str("eventId")!!,
        taskId = str("taskId")!!,
        timestamp = long("timestamp"),
        eventType = TaskEventType.valueOf(str("eventType")!!),
        stepId = str("stepId"),
        message = str("message"),
        progress = if (isNull(getColumnIndexOrThrow("progress"))) null else int("progress"),
        metadata = decodeMetadata(str("metadata").orEmpty())
    )

    private fun splitList(raw: String?): List<String> =
        if (raw.isNullOrBlank()) emptyList() else raw.split(",")

    private fun LongTask.toValues() = ContentValues().apply {
        put("taskId", taskId)
        put("userRequest", userRequest)
        put("status", status.name)
        put("priority", priority)
        put("createdAt", createdAt)
        put("updatedAt", updatedAt)
        put("currentStep", currentStep)
        put("totalSteps", totalSteps)
        put("plan", plan)
        put("checkpoint", checkpoint)
        put("progress", progress)
        put("requiredPermissions", requiredPermissions.joinToString(","))
        put("pendingConfirmation", pendingConfirmation)
        put("retryCount", retryCount)
        put("maxRetries", maxRetries)
        put("parentTaskId", parentTaskId)
        put("childTaskIds", childTaskIds.joinToString(","))
        put("result", result)
        put("error", error)
        put("lastHeartbeat", lastHeartbeat)
    }

    private fun TaskEvent.toValues() = ContentValues().apply {
        put("eventId", eventId)
        put("taskId", taskId)
        put("timestamp", timestamp)
        put("eventType", eventType.name)
        put("stepId", stepId)
        put("message", message)
        if (progress != null) put("progress", progress) else putNull("progress")
        put("metadata", encodeMetadata(metadata))
    }

    private fun encodeMetadata(map: Map<String, String>): String =
        map.entries.joinToString(";") { "${it.key}=${it.value}" }

    private fun decodeMetadata(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return raw.split(";").filter { it.contains("=") }.associate {
            val (k, v) = it.split("=", limit = 2)
            k to v
        }
    }
}
