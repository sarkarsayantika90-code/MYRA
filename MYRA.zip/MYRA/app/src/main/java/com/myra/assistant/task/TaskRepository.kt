package com.myra.assistant.task

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Thin wrapper around the Room DAOs. Kept as an interface + impl so
 * TaskManager can be unit-tested against a fake, without touching Room/
 * Robolectric (see Phase 2 requirement #13: unit tests).
 */
interface TaskRepository {
    suspend fun save(task: LongTask)
    suspend fun get(taskId: String): LongTask?
    fun observe(taskId: String): Flow<LongTask?>
    fun observeAll(): Flow<List<LongTask>>
    suspend fun getAll(): List<LongTask>
    suspend fun getInterruptedTasks(): List<LongTask>
    suspend fun delete(taskId: String)

    suspend fun appendEvent(event: TaskEvent)
    suspend fun getEvents(taskId: String): List<TaskEvent>
    fun observeEvents(taskId: String): Flow<List<TaskEvent>>

    suspend fun saveCheckpoint(checkpoint: TaskCheckpoint)
    suspend fun getLatestCheckpoint(taskId: String): TaskCheckpoint?
}

class RoomTaskRepository(private val db: TaskDatabase) : TaskRepository {

    override suspend fun save(task: LongTask) = db.taskDao().upsert(task.toEntity())

    override suspend fun get(taskId: String): LongTask? = db.taskDao().getById(taskId)?.toDomain()

    override fun observe(taskId: String): Flow<LongTask?> =
        db.taskDao().observeById(taskId).map { it?.toDomain() }

    override fun observeAll(): Flow<List<LongTask>> =
        db.taskDao().observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getAll(): List<LongTask> = db.taskDao().getAll().map { it.toDomain() }

    override suspend fun getInterruptedTasks(): List<LongTask> =
        db.taskDao().getInterruptedTasks().map { it.toDomain() }

    override suspend fun delete(taskId: String) {
        db.taskDao().delete(taskId)
        db.taskEventDao().deleteForTask(taskId)
        db.taskCheckpointDao().deleteForTask(taskId)
    }

    override suspend fun appendEvent(event: TaskEvent) = db.taskEventDao().insert(event.toEntity())

    override suspend fun getEvents(taskId: String): List<TaskEvent> =
        db.taskEventDao().getForTask(taskId).map { it.toDomain() }

    override fun observeEvents(taskId: String): Flow<List<TaskEvent>> =
        db.taskEventDao().observeForTask(taskId).map { list -> list.map { it.toDomain() } }

    override suspend fun saveCheckpoint(checkpoint: TaskCheckpoint) =
        db.taskCheckpointDao().upsert(checkpoint.toEntity())

    override suspend fun getLatestCheckpoint(taskId: String): TaskCheckpoint? =
        db.taskCheckpointDao().getLatest(taskId)?.toDomain()
}

/**
 * In-memory fake used by unit tests and by TaskUiViewModel before a real
 * backend/Hermes exists (Phase 3's "mock gateway" reuses this shape).
 */
class InMemoryTaskRepository : TaskRepository {
    private val tasks = LinkedHashMap<String, LongTask>()
    private val events = LinkedHashMap<String, MutableList<TaskEvent>>()
    private val checkpoints = LinkedHashMap<String, MutableList<TaskCheckpoint>>()

    private val taskFlows = kotlinx.coroutines.flow.MutableStateFlow<List<LongTask>>(emptyList())
    private fun publish() { taskFlows.value = tasks.values.toList() }

    override suspend fun save(task: LongTask) {
        tasks[task.taskId] = task
        publish()
    }

    override suspend fun get(taskId: String): LongTask? = tasks[taskId]

    override fun observe(taskId: String): Flow<LongTask?> =
        taskFlows.map { it.find { t -> t.taskId == taskId } }

    override fun observeAll(): Flow<List<LongTask>> = taskFlows

    override suspend fun getAll(): List<LongTask> = tasks.values.toList()

    override suspend fun getInterruptedTasks(): List<LongTask> =
        tasks.values.filter { it.status in setOf(TaskStatus.RUNNING, TaskStatus.PLANNING, TaskStatus.RETRYING) }

    override suspend fun delete(taskId: String) {
        tasks.remove(taskId)
        events.remove(taskId)
        checkpoints.remove(taskId)
        publish()
    }

    override suspend fun appendEvent(event: TaskEvent) {
        events.getOrPut(event.taskId) { mutableListOf() }.add(event)
    }

    override suspend fun getEvents(taskId: String): List<TaskEvent> = events[taskId].orEmpty()

    override fun observeEvents(taskId: String): Flow<List<TaskEvent>> =
        taskFlows.map { events[taskId].orEmpty() }

    override suspend fun saveCheckpoint(checkpoint: TaskCheckpoint) {
        checkpoints.getOrPut(checkpoint.taskId) { mutableListOf() }.add(checkpoint)
    }

    override suspend fun getLatestCheckpoint(taskId: String): TaskCheckpoint? =
        checkpoints[taskId]?.maxByOrNull { it.createdAt }
}
