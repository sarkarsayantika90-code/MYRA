package com.myra.assistant.utils

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/** The SHA-1 of the key this installed app is signed with (Firebase / Google login needs exactly this). */
object AppSignature {
    fun sha1(ctx: Context): String {
        return try {
            val pm = ctx.packageManager
            val sig = if (Build.VERSION.SDK_INT >= 28) {
                pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners?.firstOrNull()
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
            }
            if (sig == null) "unknown"
            else MessageDigest.getInstance("SHA-1").digest(sig.toByteArray()).joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) {
            "unknown"
        }
    }
}
