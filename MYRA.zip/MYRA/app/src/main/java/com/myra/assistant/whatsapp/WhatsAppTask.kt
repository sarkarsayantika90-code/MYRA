package com.myra.assistant.whatsapp

/** Result codes (PDF section 12). Returned to the model as "<code>: <human text>". */
object WaCode {
    const val SENT = "sent"
    const val SUBMITTED_UNVERIFIED = "submitted_unverified"
    const val DRAFT_READY = "draft_ready"
    const val AWAITING_CONFIRMATION = "awaiting_confirmation"
    const val FAILED = "failed"
    const val CANCELLED = "cancelled"
    const val REJECTED = "rejected"
    const val BUSY = "busy"
    const val APP_NOT_INSTALLED = "app_not_installed"
    const val ACCESSIBILITY_NOT_ENABLED = "accessibility_not_enabled"
    const val CONTACT_NOT_FOUND = "contact_not_found"
    const val CONTACT_AMBIGUOUS = "contact_ambiguous"
    const val USER_ACTION_REQUIRED = "user_action_required"
    const val UNSUPPORTED_ACTION = "unsupported_action"
    const val OK = "ok"
}

enum class WaStatus { RESOLVING, OPENING, DRAFTED, AWAITING_CONFIRMATION, CONFIRMED, SENDING, DONE, REJECTED, CANCELLED, FAILED }

/**
 * One WhatsApp job. The important rule lives here so it can be unit-tested without a phone:
 * [canTapSend] is only true after [confirm] was called with THIS task's id while the task was
 * awaiting confirmation and the draft was not too old.
 */
class WhatsAppTask(
    val taskId: String,
    val action: String,
    val contactQuery: String,
    val resolvedName: String,
    val resolvedNumber: String,
    val message: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    @Volatile var status: WaStatus = WaStatus.RESOLVING
    @Volatile var draftAt: Long = 0L
    @Volatile var retryCount = 0
    val maxRetries = 1
    @Volatile private var confirmed = false

    fun markAwaiting(now: Long = System.currentTimeMillis()) {
        draftAt = now
        status = WaStatus.AWAITING_CONFIRMATION
    }

    /** Returns true only when the gate opens. */
    fun confirm(id: String, now: Long = System.currentTimeMillis()): Boolean {
        if (id != taskId) return false
        if (status != WaStatus.AWAITING_CONFIRMATION) return false
        if (now - draftAt > DRAFT_TTL_MS) return false
        confirmed = true
        status = WaStatus.CONFIRMED
        return true
    }

    fun canTapSend(): Boolean = confirmed && status == WaStatus.CONFIRMED

    companion object {
        const val DRAFT_TTL_MS = 3 * 60 * 1000L
    }
}
