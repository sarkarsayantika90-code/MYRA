package com.myra.admin

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private lateinit var screens: Screens
    private val handler = Handler(Looper.getMainLooper())
    private var tab = "dash"
    private var ticker: Runnable? = null

    private val tabs = linkedMapOf(
        "dash" to "Dashboard", "users" to "Users", "pay" to "Payments", "alerts" to "Alerts", "ctl" to "Control",
        "notify" to "Send", "live" to "Live", "update" to "Update", "audit" to "Audit", "settings" to "Settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Auth.isLoggedIn(this)) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }
        screens = Screens(this)
        tab = intent?.getStringExtra("tab")?.takeIf { it in tabs } ?: "dash"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }

        val bar = Ui.row(this).apply { setPadding(Ui.dp(context, 16), Ui.dp(context, 10), Ui.dp(context, 10), Ui.dp(context, 6)) }
        bar.addView(Ui.text(this, "MYRA ADMIN", 18f, Ui.ACCENT, true).apply { letterSpacing = 0.15f }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(Ui.button(this, "Refresh") { show(tab) })
        bar.addView(Ui.spacer(this, 1).apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(context, 6), 1) })
        bar.addView(Ui.button(this, "Logout") {
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Log out of admin?")
                .setPositiveButton("Log out") { _, _ -> Auth.logout(this); Watcher.cancel(this); startActivity(Intent(this, LoginActivity::class.java)); finish() }
                .setNegativeButton("Cancel", null).show()
        })
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 14), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(context, 8), Ui.dp(context, 6), Ui.dp(context, 8), Ui.dp(context, 6)) }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; setBackgroundColor(Ui.CARD); addView(nav)
        })
        setContentView(root)
        show(tab)

        if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.canPost(this)) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        Watcher.schedule(this)
        Thread { try { Plans.current = Db.getObject(applicationContext, "config/adminPlans").let { o -> o.keys().asSequence().associateWith { k -> o.optInt(k) }.filterValues { it != 0 } } } catch (_: Exception) {} }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("tab")?.takeIf { it in tabs }?.let { show(it) }
    }

    private val watch = object : Runnable {
        override fun run() {
            Thread {
                val found = try { Watcher.check(applicationContext) } catch (_: Exception) { 0 }
                if (found > 0) runOnUiThread { if (!isFinishing && !isDestroyed) drawNav() }
            }.start()
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onResume() { super.onResume(); handler.postDelayed(watch, 4_000L) }
    override fun onPause() { handler.removeCallbacks(watch); super.onPause() }

    fun drawNav() {
        nav.removeAllViews()
        for ((k, v) in tabs) {
            val on = k == tab
            val unread = if (k == "alerts") AlertStore.unread(this) else 0
            nav.addView(TextView(this).apply {
                text = if (unread > 0) "$v ($unread)" else v; textSize = 13f
                setTextColor(if (on) android.graphics.Color.WHITE else Ui.DIM)
                background = if (on) Ui.rounded(Ui.ACCENT, 18, context) else null
                gravity = Gravity.CENTER
                setPadding(Ui.dp(context, 14), Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 8))
                setOnClickListener { show(k) }
            }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = Ui.dp(this@MainActivity, 4) })
        }
    }

    fun show(t: String) {
        tab = t
        stopTicker()
        drawNav()
        when (t) {
            "dash" -> screens.dashboard()
            "users" -> screens.users()
            "pay" -> screens.payments()
            "ctl" -> screens.control()
            "notify" -> screens.notify()
            "live" -> screens.live()
            "update" -> screens.update()
            "alerts" -> screens.alerts()
            "settings" -> screens.settings()
            else -> screens.audit()
        }
    }

    /** Runs [work] on a background thread, then [ui] on the main thread. Errors become a toast. */
    fun <T> load(work: () -> T, ui: (T) -> Unit) {
        val shown = tab
        Thread {
            try {
                val r = work()
                runOnUiThread { if (!isFinishing && !isDestroyed && tab == shown) ui(r) }
            } catch (e: Exception) {
                runOnUiThread { if (!isFinishing && !isDestroyed) fail(e) }
            }
        }.start()
    }

    /** Fire-and-forget background action with a result toast. [then] runs on the main thread after success. */
    fun act(work: () -> Unit, ok: String, then: () -> Unit = {}) {
        Thread {
            try {
                work()
                runOnUiThread { if (!isFinishing && !isDestroyed) { toast(ok); then() } }
            } catch (e: Exception) {
                runOnUiThread { if (!isFinishing && !isDestroyed) fail(e) }
            }
        }.start()
    }

    fun fail(e: Exception) {
        toast("Error: ${e.message}")
        if (content.childCount <= 1) {
            content.removeAllViews()
            content.addView(Ui.card(this).apply { addView(Ui.text(context, e.message ?: "Something went wrong", 14f, Ui.BAD)) })
        }
    }

    fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    fun startTicker(ms: Long, r: () -> Unit) {
        stopTicker()
        val run = object : Runnable { override fun run() { r(); handler.postDelayed(this, ms) } }
        ticker = run
        handler.postDelayed(run, ms)
    }

    fun stopTicker() { ticker?.let { handler.removeCallbacks(it) }; ticker = null }

    override fun onDestroy() { stopTicker(); super.onDestroy() }
}
