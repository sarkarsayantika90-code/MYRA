package com.myra.assistant.auth

import android.content.Context
import org.json.JSONObject

/**
 * Gemini API keys live ONLY in the database (secrets/gemini, managed from the admin website) -
 * never in the APK or the GitHub repo. Held in memory only. Several keys = automatic fallback
 * when one runs out of quota.
 * Honest note: the phone must receive the key to talk to Gemini, so a determined, logged-in
 * user could capture it. Rules limit it to VERIFIED, non-banned accounts; rotate keys from the
 * admin site any time. For real secrecy, put a proxy server in front (see FIREBASE_SETUP.md).
 */
object RemoteKeys {
    @Volatile private var keys: List<String> = emptyList()
    @Volatile private var idx = 0
    @Volatile var lastError = ""

    fun hasKeys() = keys.isNotEmpty()
    fun current(): String? = keys.takeIf { it.isNotEmpty() }?.get(idx % keys.size)
    fun rotate() { if (keys.size > 1) idx++ }

    /** Blocking. */
    fun load(ctx: Context): Boolean {
        for (attempt in 0..1) {
            try {
                val raw = FirebaseRest.dbGet(ctx, "secrets/gemini")
                if (raw == "null" || raw.isBlank()) { lastError = "Admin ekhono kono API key add kore ni"; keys = emptyList(); return false }
                val o = JSONObject(raw)
                val list = ArrayList<String>()
                for (k in o.keys()) {
                    val e = o.optJSONObject(k) ?: continue
                    if (e.optBoolean("enabled", true) && e.optString("key").isNotBlank()) list.add(e.optString("key").trim())
                }
                keys = list; lastError = if (list.isEmpty()) "Sob API key disabled" else ""
                return list.isNotEmpty()
            } catch (e: FirebaseRest.FirebaseError) {
                if (e.code == "PERMISSION_DENIED" && attempt == 0 && FirebaseRest.forceRefresh(ctx) != null) continue
                lastError = if (e.code == "PERMISSION_DENIED")
                    "Email verify koro (inbox/spam e link), tarpor abar chalu koro. Ba account blocked."
                else FirebaseRest.friendly(e.code)
                return false
            }
        }
        return false
    }
}
