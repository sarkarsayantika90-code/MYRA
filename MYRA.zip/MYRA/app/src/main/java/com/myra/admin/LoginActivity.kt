package com.myra.admin

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LoginActivity : AppCompatActivity() {
    private lateinit var msg: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Auth.isLoggedIn(this)) { startActivity(Intent(this, MainActivity::class.java)); finish(); return }

        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isFillViewport = true }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(Ui.dp(context, 26), Ui.dp(context, 40), Ui.dp(context, 26), Ui.dp(context, 24))
        }
        scroll.addView(col, android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))

        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_foreground)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF000000.toInt())
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.22f) }
            }
        }, LinearLayout.LayoutParams(Ui.dp(this, 130), Ui.dp(this, 130)))

        col.addView(Ui.text(this, "MYRA ADMIN", 26f, Ui.ACCENT, true).apply { letterSpacing = 0.2f }, Ui.lp(this, 14))
        col.addView(Ui.text(this, "Control panel - owner only", 13f, Ui.DIM), Ui.lp(this, 2))

        val email = Ui.input(this, "Admin email").apply { setText(Config.ADMIN); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        val pass = Ui.input(this, "Password", password = true)
        col.addView(email, Ui.lp(this, 28)); col.addView(pass, Ui.lp(this, 12))

        progress = ProgressBar(this).apply { visibility = View.GONE }
        msg = Ui.text(this, "", 13f, Ui.BAD).apply { gravity = Gravity.CENTER }
        col.addView(Ui.button(this, "Login", filled = true) { submit(email.text.toString().trim(), pass.text.toString()) }, Ui.lp(this, 16))
        col.addView(progress, Ui.lp(this, 10, Ui.dp(this, 28), Ui.dp(this, 28)))
        col.addView(msg, Ui.lp(this, 8))
        col.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        col.addView(Ui.text(this, "Made by Anik", 11f, Ui.DIM).apply { typeface = Typeface.create("sans-serif-light", Typeface.ITALIC) })
        setContentView(scroll)
    }

    private fun submit(email: String, pw: String) {
        msg.text = ""
        if (email.isEmpty() || pw.isEmpty()) { msg.text = "Enter email and password"; return }
        progress.visibility = View.VISIBLE
        Thread {
            val err = try { Auth.signIn(applicationContext, email, pw); null } catch (e: Exception) { e.message ?: "Login failed" }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                progress.visibility = View.GONE
                if (err == null) { startActivity(Intent(this, MainActivity::class.java)); finish() } else msg.text = err
            }
        }.start()
    }
}
