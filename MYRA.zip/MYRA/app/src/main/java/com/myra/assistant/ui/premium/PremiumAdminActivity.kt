package com.myra.assistant.ui.premium

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.auth.Session
import com.myra.assistant.premium.PremiumManager
import com.myra.assistant.premium.PremiumPlans
import com.myra.assistant.ui.UiKit
import com.myra.assistant.ui.UiKit.dp
import com.myra.assistant.ui.main.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Owner only: pending payments, with manual Approve / Reject (auto-verify handles most of them). */
class PremiumAdminActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var info: TextView
    private var accent = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.isAdmin(this)) { finish(); return }
        window.statusBarColor = Color.TRANSPARENT
        accent = ThemeManager.accent(this)
        val scroll = ScrollView(this).apply { setBackgroundColor(UiKit.BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PremiumAdminActivity, 18), dp(this@PremiumAdminActivity, 46), dp(this@PremiumAdminActivity, 18), dp(this@PremiumAdminActivity, 30))
        }
        scroll.addView(col); setContentView(scroll)
        col.addView(UiKit.label(this, "Payments to verify", 24f, accent, true))
        info = UiKit.label(this, "Loading...", 12f, UiKit.DIM)
        col.addView(info)
        col.addView(UiKit.button(this, "Refresh", accent, filled = false) { load() }, UiKit.lp(top = 10, c = this))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                try { PremiumManager.allPending(this@PremiumAdminActivity) } catch (e: Exception) { null }
            }
            list.removeAllViews()
            if (items == null) { info.text = "Load kora gelo na (internet / Firebase rules check koro)"; return@launch }
            info.text = if (items.isEmpty()) "No pending payments 🎉" else "${items.size} pending — check your bank/PhonePe for the same UTR before approving."
            items.forEach { p ->
                val c = UiKit.card(this@PremiumAdminActivity)
                c.addView(UiKit.label(this@PremiumAdminActivity, "${p.email}", 14f, UiKit.TEXT, true))
                c.addView(UiKit.label(this@PremiumAdminActivity, "${PremiumPlans.byId(p.plan)?.title ?: p.plan} • ₹${p.amount} • UTR ${p.utr}", 13f, UiKit.DIM))
                val row = LinearLayout(this@PremiumAdminActivity).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(UiKit.button(this@PremiumAdminActivity, "Approve", accent) { act(p, true) }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(UiKit.button(this@PremiumAdminActivity, "Reject", 0xFF5A2A2A.toInt()) { act(p, false) },
                    LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(this@PremiumAdminActivity, 8) })
                c.addView(row, UiKit.lp(top = 8, c = this@PremiumAdminActivity))
                list.addView(c, UiKit.lp(top = 10, c = this@PremiumAdminActivity))
            }
        }
    }

    private fun act(p: PremiumManager.Payment, ok: Boolean) {
        lifecycleScope.launch {
            val done = withContext(Dispatchers.IO) {
                if (ok) PremiumManager.approve(this@PremiumAdminActivity, p, "admin") else PremiumManager.reject(this@PremiumAdminActivity, p)
            }
            Toast.makeText(this@PremiumAdminActivity, if (done) "Done" else "Failed", Toast.LENGTH_SHORT).show()
            load()
        }
    }
}
