package com.myra.assistant.whatsapp

/**
 * Decides whether what the person actually SAID counts as "yes, send it".
 * This is the second lock: the model must call confirm, AND the person's own words (from speech
 * transcription or typed chat) after the draft was read back must be an affirmative.
 */
object ConfirmGate {
    private val YES = setOf(
        "yes", "yeah", "yep", "yup", "ok", "okay", "sure", "send", "confirm", "confirmed", "correct", "right",
        "haan", "han", "haa", "ha", "hnn", "theek", "thik", "bhej", "bhejo", "bhejdo", "kardo", "karo",
        "hyan", "hya", "hyaa", "pathao", "pathiye", "paṭhāo",
        "हाँ", "हां", "हा", "ठीक", "भेज", "भेजो", "भेजदो", "कर",
        "হ্যাঁ", "হ্যা", "হাঁ", "ঠিক", "পাঠাও", "পাঠিয়ে", "পাঠান"
    )
    private val NO = setOf(
        "no", "nope", "nah", "not", "dont", "don't", "do not", "cancel", "stop", "wait", "ruko", "ruk", "mat", "nahi",
        "nahin", "na", "nai", "naa", "change", "edit", "wrong", "galat",
        "नहीं", "नही", "मत", "रुको", "रुक", "गलत",
        "না", "নয়", "থামো", "দাঁড়াও", "ভুল"
    )

    private fun tokens(text: String): List<String> =
        text.lowercase().replace(Regex("[\\p{P}\\p{S}]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }

    fun isAffirmative(text: String): Boolean {
        val t = tokens(text)
        if (t.isEmpty()) return false
        // A real "yes" is short. A long sentence (e.g. the original request "... bhejo") is not one.
        if (t.size > 8) return false
        if (t.any { it in NO }) return false
        return t.any { it in YES }
    }

    fun isNegative(text: String): Boolean = tokens(text).any { it in NO }
}

/** Rolling log of what the PERSON said (not the model). Fed by speech transcription and typed chat. */
object UtteranceLog {
    private data class Frag(val at: Long, val text: String)
    private val frags = ArrayList<Frag>()

    @Synchronized fun add(text: String, now: Long = System.currentTimeMillis()) {
        if (text.isBlank()) return
        frags.add(Frag(now, text))
        while (frags.size > 40) frags.removeAt(0)
    }

    /** Everything the person said strictly after [t]. */
    @Synchronized fun since(t: Long): String =
        frags.filter { it.at > t }.joinToString(" ") { it.text }

    private val turnEnds = ArrayList<Long>()

    /** Called whenever MYRA finishes a spoken turn (the read-back of a draft ends with one). */
    @Synchronized fun markTurnEnd(now: Long = System.currentTimeMillis()) {
        turnEnds.add(now)
        while (turnEnds.size > 20) turnEnds.removeAt(0)
    }

    /**
     * What the person said AFTER MYRA finished reading the draft back. Returns null while the
     * read-back has not finished yet - so the original request ("... bhejo") can never be
     * mistaken for the "yes".
     */
    @Synchronized fun sinceReadback(draftAt: Long): String? {
        val end = readbackEnd(draftAt) ?: return null
        return frags.filter { it.at > end }.joinToString(" ") { it.text }
    }

    /** First spoken turn that ended at least 1.2s after the draft = the read-back (skips a short "ok..." before it). */
    @Synchronized fun readbackEnd(draftAt: Long): Long? = turnEnds.firstOrNull { it > draftAt + 1200 }

    private val voice = ArrayList<Long>()

    /** Called for every 40ms mic chunk that contains speech-level sound. */
    @Synchronized fun addVoice(now: Long = System.currentTimeMillis()) {
        voice.add(now)
        while (voice.size > 400) voice.removeAt(0)
    }

    /** Milliseconds of speech-level mic sound after [t] (each chunk = 40ms). */
    @Synchronized fun voiceMsSince(t: Long): Long = voice.count { it > t } * 40L

    @Synchronized fun clear() { frags.clear(); turnEnds.clear(); voice.clear() }
}


/**
 * Waits for the person's answer to a read-back. Primary evidence = transcript of THEIR words after
 * MYRA finished speaking. If the speech-to-text is late/missing, a clear burst of their voice after
 * the read-back (and no "no" in any transcript) is accepted, so a working "haan" is never lost.
 */
object ReplyWatcher {
    enum class Result { YES, NO, UNCLEAR, WAITING_READBACK, NO_REPLY }

    suspend fun await(draftAt: Long, timeoutMs: Long = 6000): Result {
        val started = System.currentTimeMillis()
        var last = Result.WAITING_READBACK
        while (System.currentTimeMillis() - started < timeoutMs) {
            val end = UtteranceLog.readbackEnd(draftAt)
            if (end != null) {
                val said = UtteranceLog.sinceReadback(draftAt).orEmpty()
                last = Result.NO_REPLY
                if (said.isNotBlank()) {
                    if (ConfirmGate.isNegative(said)) return Result.NO
                    if (ConfirmGate.isAffirmative(said)) return Result.YES
                    last = Result.UNCLEAR
                } else if (System.currentTimeMillis() - end > 2500 &&
                    UtteranceLog.voiceMsSince(end + 300) >= 320) {
                    // They clearly spoke but no transcript arrived.
                    return Result.YES
                }
            }
            kotlinx.coroutines.delay(200)
        }
        return last
    }
}
