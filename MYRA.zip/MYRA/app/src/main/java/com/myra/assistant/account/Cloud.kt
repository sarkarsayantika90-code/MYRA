package com.myra.assistant.account

import android.content.Context
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Firebase Auth + Realtime Database over plain REST (no Firebase SDK, so no google-services plugin
 * and nothing extra that can break the GitHub build).
 */
object Cloud {
    private const val TAG = "CLOUD"
    private const val PREF = "myra_account"
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()

    data class Result(val ok: Boolean, val msg: String = "", val body: String = "")

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isLoggedIn(ctx: Context) = !p(ctx).getString("refresh", null).isNullOrEmpty()
    fun uid(ctx: Context) = p(ctx).getString("uid", "") ?: ""
    fun email(ctx: Context) = p(ctx).getString("email", "") ?: ""
    fun isOwner(ctx: Context) = AccountConfig.OWNER_UID.isNotEmpty() && uid(ctx) == AccountConfig.OWNER_UID
    fun signOut(ctx: Context) = p(ctx).edit().clear().apply()

    // ───────────── http ─────────────
    private suspend fun exec(req: Request): Pair<Int, String> = withContext(Dispatchers.IO) {
        try {
            http.newCall(req).execute().use { it.code to (it.body?.string() ?: "") }
        } catch (e: Exception) {
            Logger.e(TAG, "http error: ${e.javaClass.simpleName}")
            -1 to (e.message ?: "network error")
        }
    }

    private fun friendly(raw: String): String {
        val m = try { JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw } catch (_: Exception) { raw }
        return when {
            m.startsWith("EMAIL_EXISTS") -> "An account with this email already exists. Please log in."
            m.startsWith("EMAIL_NOT_FOUND") || m.startsWith("INVALID_LOGIN_CREDENTIALS") || m.startsWith("INVALID_PASSWORD") ->
                "Email ba password bhul."
            m.startsWith("WEAK_PASSWORD") -> "Password must be at least 6 characters."
            m.startsWith("INVALID_EMAIL") -> "This email is not valid."
            m.startsWith("TOO_MANY_ATTEMPTS") -> "Too many attempts, please try again later."
            m.startsWith("OPERATION_NOT_ALLOWED") -> "Email/Password sign-in is not enabled in Firebase (Authentication > Sign-in method)."
            m.contains("API key") || m.contains("PERMISSION_DENIED") || m.contains("blocked") ->
                "The Firebase API key is restricted. Add com.myra.assistant to the key's Android restriction in Google Cloud, or remove the restriction."
            m.startsWith("USER_DISABLED") -> "This account is disabled."
            else -> "Login failed: ${m.take(80)}"
        }
    }

    private fun save(ctx: Context, j: JSONObject, email: String? = null) {
        val expires = System.currentTimeMillis() + (j.optString("expiresIn", "3600").toLongOrNull() ?: 3600L) * 1000L
        p(ctx).edit()
            .putString("uid", j.optString("localId", j.optString("user_id", uid(ctx))))
            .putString("email", email ?: j.optString("email", email(ctx)))
            .putString("id", j.optString("idToken", j.optString("id_token")))
            .putString("refresh", j.optString("refreshToken", j.optString("refresh_token")))
            .putLong("exp", expires).apply()
    }

    private suspend fun auth(ctx: Context, endpoint: String, email: String, pw: String): Result {
        val body = JSONObject().put("email", email.trim()).put("password", pw).put("returnSecureToken", true)
        val req = Request.Builder()
            .url("https://identitytoolkit.googleapis.com/v1/accounts:$endpoint?key=${AccountConfig.API_KEY}")
            .post(body.toString().toRequestBody(JSON)).build()
        val (code, text) = exec(req)
        if (code == -1) return Result(false, "No internet / could not connect")
        if (code !in 200..299) return Result(false, friendly(text))
        save(ctx, JSONObject(text), email.trim())
        return Result(true)
    }

    suspend fun signUp(ctx: Context, email: String, pw: String) = auth(ctx, "signUp", email, pw)
    suspend fun signIn(ctx: Context, email: String, pw: String) = auth(ctx, "signInWithPassword", email, pw)

    suspend fun resetPassword(email: String): Result {
        val body = JSONObject().put("requestType", "PASSWORD_RESET").put("email", email.trim())
        val req = Request.Builder()
            .url("https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${AccountConfig.API_KEY}")
            .post(body.toString().toRequestBody(JSON)).build()
        val (code, text) = exec(req)
        return if (code in 200..299) Result(true, "Password reset link email e pathiyechi") else Result(false, friendly(text))
    }

    /** A valid ID token, refreshing it when needed. Null = not logged in / offline and expired. */
    suspend fun token(ctx: Context): String? {
        val sp = p(ctx)
        val id = sp.getString("id", null)
        if (id != null && System.currentTimeMillis() < sp.getLong("exp", 0) - 60_000) return id
        val refresh = sp.getString("refresh", null) ?: return null
        val req = Request.Builder()
            .url("https://securetoken.googleapis.com/v1/token?key=${AccountConfig.API_KEY}")
            .post(FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", refresh).build()).build()
        val (code, text) = exec(req)
        if (code !in 200..299) return null
        val j = JSONObject(text)
        sp.edit().putString("id", j.optString("id_token")).putString("refresh", j.optString("refresh_token", refresh))
            .putLong("exp", System.currentTimeMillis() + (j.optString("expires_in", "3600").toLongOrNull() ?: 3600L) * 1000L).apply()
        return j.optString("id_token")
    }

    // ───────────── realtime database ─────────────
    private suspend fun db(ctx: Context, method: String, path: String, json: String?): Result {
        val t = token(ctx) ?: return Result(false, "Check login / internet")
        val rb = json?.toRequestBody(JSON)
        val req = Request.Builder().url("${AccountConfig.DB_URL}/$path.json?auth=$t")
            .method(method, if (method == "GET" || method == "DELETE") null else rb).build()
        val (code, text) = exec(req)
        return if (code in 200..299) Result(true, body = text)
        else Result(false, if (code == 401 || code == 403) "Database permission denied (check the rules)" else "DB error $code", text)
    }

    suspend fun get(ctx: Context, path: String) = db(ctx, "GET", path, null)
    suspend fun put(ctx: Context, path: String, json: String) = db(ctx, "PUT", path, json)
    suspend fun post(ctx: Context, path: String, json: String) = db(ctx, "POST", path, json)
    suspend fun patch(ctx: Context, path: String, json: String) = db(ctx, "PATCH", path, json)
}
