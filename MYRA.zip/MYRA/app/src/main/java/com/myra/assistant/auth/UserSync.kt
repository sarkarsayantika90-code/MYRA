package com.myra.assistant.auth

import android.content.Context
import android.os.Build
import com.myra.assistant.update.UpdateManager
import org.json.JSONObject

/** Tells the admin panel who is using the app (email, last seen, app version, phone model). */
object UserSync {
    /** Blocking. Never throws. */
    fun touch(ctx: Context, firstTime: Boolean = false) {
        val s = Session.get(ctx) ?: return
        try {
            val o = JSONObject()
                .put("email", s.email)
                .put("lastSeen", System.currentTimeMillis())
                .put("appVersion", UpdateManager.installedName(ctx))
                .put("appCode", UpdateManager.installedCode(ctx))
                .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
                .put("android", Build.VERSION.SDK_INT)
            if (firstTime) o.put("createdAt", System.currentTimeMillis())
            FirebaseRest.dbPatch(ctx, "users/${s.uid}/profile", o)
        } catch (_: Exception) {}
    }
}
