package com.myra.assistant.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import com.myra.assistant.auth.FirebaseConfig
import com.myra.assistant.utils.prefs
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * In-app updates. The admin website writes config/update = {versionCode, versionName, apkUrl,
 * notes, force, sha256?}. The app checks it, shows a popup, MYRA nudges once per version, and while
 * an update is downloading/installing MYRA stays completely quiet about it.
 *
 * Android only installs an update signed with the SAME key as the installed app, so the key must be
 * the same on every build (see FIREBASE_SETUP.md > "Updates" - GitHub secret keystore).
 */
object UpdateManager {
    data class Info(val code: Long, val name: String, val url: String, val notes: String, val force: Boolean, val sha256: String)

    enum class State { IDLE, DOWNLOADING, INSTALLING }
    @Volatile var state = State.IDLE
        private set
    /** True while MYRA must not talk about updates (or chatter at all). */
    fun busy() = state != State.IDLE

    private val http = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    fun installedCode(ctx: Context): Long {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        return if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
    }
    fun installedName(ctx: Context): String = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    /** Blocking. Returns an Info only when a NEWER version is published. */
    fun check(ctx: Context): Info? = try {
        val req = Request.Builder().url("${FirebaseConfig.DB_URL}/config/update.json").get().build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            val raw = r.body?.string().orEmpty()
            if (raw == "null" || raw.isBlank()) return null
            val o = JSONObject(raw)
            val info = Info(o.optLong("versionCode"), o.optString("versionName"), o.optString("apkUrl"),
                o.optString("notes"), o.optBoolean("force"), o.optString("sha256").lowercase())
            if (info.code > installedCode(ctx) && info.url.startsWith("https://")) info else null
        }
    } catch (e: Exception) { null }

    /** MYRA only mentions a given version once. */
    fun shouldNudge(ctx: Context, i: Info): Boolean = ctx.prefs().getLong("update_nudged", 0L) != i.code
    fun markNudged(ctx: Context, i: Info) = ctx.prefs().edit().putLong("update_nudged", i.code).apply()

    fun canInstall(ctx: Context) = ctx.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Blocking download with progress (0..100). Returns the file, or throws. */
    fun download(ctx: Context, i: Info, onProgress: (Int) -> Unit): File {
        state = State.DOWNLOADING
        try {
            val dir = File(ctx.cacheDir, "updates").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
            val out = File(dir, "myra-${i.code}.apk")
            http.newCall(Request.Builder().url(i.url).build()).execute().use { r ->
                if (!r.isSuccessful) throw Exception("Download failed (HTTP ${r.code})")
                val body = r.body ?: throw Exception("Empty download")
                val total = body.contentLength()
                var done = 0L
                val md = MessageDigest.getInstance("SHA-256")
                body.byteStream().use { input ->
                    out.outputStream().use { o ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf); if (n < 0) break
                            o.write(buf, 0, n); md.update(buf, 0, n); done += n
                            if (total > 0) onProgress((done * 100 / total).toInt())
                        }
                    }
                }
                if (out.length() < 1_000_000) throw Exception("Downloaded file is not an APK")
                if (i.sha256.isNotBlank()) {
                    val got = md.digest().joinToString("") { "%02x".format(it) }
                    if (got != i.sha256) { out.delete(); throw Exception("APK checksum mismatch - update blocked for safety") }
                }
            }
            return out
        } catch (e: Exception) { state = State.IDLE; throw e }
    }

    fun install(ctx: Context, apk: File) {
        state = State.INSTALLING
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.updates", apk)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Call when the user comes back without installing. */
    fun reset() { state = State.IDLE }
}
