package com.myra.assistant.task

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val taskId: String,
    val userRequest: String,
    val status: String,
    val priority: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val currentStep: Int,
    val totalSteps: Int,
    val plan: String?,
    val checkpoint: String?,
    val progress: Int,
    val requiredPermissions: String, // comma-joined
    val pendingConfirmation: String?,
    val retryCount: Int,
    val maxRetries: Int,
    val parentTaskId: String?,
    val childTaskIds: String, // comma-joined
    val result: String?,
    val error: String?,
    val lastHeartbeat: Long
)

fun TaskEntity.toDomain(): LongTask = LongTask(
    taskId = taskId,
    userRequest = userRequest,
    status = TaskStatus.valueOf(status),
    priority = priority,
    createdAt = createdAt,
    updatedAt = updatedAt,
    currentStep = currentStep,
    totalSteps = totalSteps,
    plan = plan,
    checkpoint = checkpoint,
    progress = progress,
    requiredPermissions = if (requiredPermissions.isBlank()) emptyList() else requiredPermissions.split(","),
    pendingConfirmation = pendingConfirmation,
    retryCount = retryCount,
    maxRetries = maxRetries,
    parentTaskId = parentTaskId,
    childTaskIds = if (childTaskIds.isBlank()) emptyList() else childTaskIds.split(","),
    result = result,
    error = error,
    lastHeartbeat = lastHeartbeat
)

fun LongTask.toEntity(): TaskEntity = TaskEntity(
    taskId = taskId,
    userRequest = userRequest,
    status = status.name,
    priority = priority,
    createdAt = createdAt,
    updatedAt = updatedAt,
    currentStep = currentStep,
    totalSteps = totalSteps,
    plan = plan,
    checkpoint = checkpoint,
    progress = progress,
    requiredPermissions = requiredPermissions.joinToString(","),
    pendingConfirmation = pendingConfirmation,
    retryCount = retryCount,
    maxRetries = maxRetries,
    parentTaskId = parentTaskId,
    childTaskIds = childTaskIds.joinToString(","),
    result = result,
    error = error,
    lastHeartbeat = lastHeartbeat
)

@Entity(tableName = "task_events")
data class TaskEventEntity(
    @PrimaryKey val eventId: String,
    val taskId: String,
    val timestamp: Long,
    val eventType: String,
    val stepId: String?,
    val message: String?,
    val progress: Int?,
    val metadataJson: String // simple "k1=v1;k2=v2" encoding, no external JSON dep needed here
)

fun TaskEventEntity.toDomain(): TaskEvent = TaskEvent(
    eventId = eventId,
    taskId = taskId,
    timestamp = timestamp,
    eventType = TaskEventType.valueOf(eventType),
    stepId = stepId,
    message = message,
    progress = progress,
    metadata = decodeMetadata(metadataJson)
)

fun TaskEvent.toEntity(): TaskEventEntity = TaskEventEntity(
    eventId = eventId,
    taskId = taskId,
    timestamp = timestamp,
    eventType = eventType.name,
    stepId = stepId,
    message = message,
    progress = progress,
    metadataJson = encodeMetadata(metadata)
)

private fun encodeMetadata(map: Map<String, String>): String =
    map.entries.joinToString(";") { "${it.key}=${it.value}" }

private fun decodeMetadata(raw: String): Map<String, String> {
    if (raw.isBlank()) return emptyMap()
    return raw.split(";").filter { it.contains("=") }.associate {
        val (k, v) = it.split("=", limit = 2)
        k to v
    }
}

@Entity(tableName = "task_checkpoints")
data class TaskCheckpointEntity(
    @PrimaryKey val checkpointId: String,
    val taskId: String,
    val stepIndex: Int,
    val stateJson: String,
    val createdAt: Long
)

fun TaskCheckpointEntity.toDomain(): TaskCheckpoint = TaskCheckpoint(
    checkpointId = checkpointId,
    taskId = taskId,
    stepIndex = stepIndex,
    stateJson = stateJson,
    createdAt = createdAt
)

fun TaskCheckpoint.toEntity(): TaskCheckpointEntity = TaskCheckpointEntity(
    checkpointId = checkpointId,
    taskId = taskId,
    stepIndex = stepIndex,
    stateJson = stateJson,
    createdAt = createdAt
)
