package com.myra.assistant.account

/**
 * >>> THINGS YOU MUST EDIT ONCE <<<
 *
 * OWNER_UID   : after you create YOUR account in the app, open Settings > Premium. It shows "Account ID".
 *               Paste it here AND into the Firebase Realtime Database rules (see FIREBASE_SETUP.md).
 *               The owner panel (approve payments, auto-verify) only works for this account.
 * OWNER_EMAIL : your login email. Gives YOU free premium inside the app.
 */
object AccountConfig {
    const val OWNER_UID = ""
    const val OWNER_EMAIL = ""

    // From google-services.json (project sayantika-afefe). This key is NOT a secret - it only
    // identifies the Firebase project. Real protection = the database rules + Auth.
    const val API_KEY = "AIzaSyDeRgRglK6lyAtcpJBdZD5l-hoGfMnm4xs"
    const val DB_URL = "https://sayantika-afefe-default-rtdb.firebaseio.com"

    // Payee details from your PhonePe QR
    const val UPI_ID = "9775171981-4@axl"
    const val UPI_NAME = "ANIK MONDAL"

    const val FREE_ACTIONS_PER_DAY = 25
}
