package com.myra.assistant.voice

/**
 * Decides whether recognized text is the wake phrase "Hey Myra".
 *
 * A speech model has never heard the made-up name "Myra", so it writes it as mira / meera / maira...
 * We accept those spellings, but ONLY directly after a greeting word, so the ordinary word "mira"
 * (or a name said in passing) does not wake her.
 */
object WakeWordMatcher {
    private val greetings = setOf("hey", "hay", "hi", "hello", "okay", "ok", "hei", "ae", "aye")
    private val names = setOf("myra", "mira", "meera", "maira", "mayra", "miera", "myraa", "mirra")

    /** Phrases handed to the recognizer so it only listens for these (+ "[unk]" for everything else). */
    val grammar: String = buildString {
        append("[")
        for (g in listOf("hey", "hi", "hay", "okay")) for (n in listOf("myra", "mira", "meera", "maira")) {
            append('"').append(g).append(' ').append(n).append("\", ")
        }
        append("\"[unk]\"]")
    }

    fun matches(text: String): Boolean {
        val tokens = text.lowercase().split(Regex("[^a-z\\[\\]]+")).filter { it.isNotEmpty() }
        for (i in 0 until tokens.size - 1) {
            if (tokens[i] in greetings && tokens[i + 1] in names) return true
        }
        return false
    }
}
