package com.myra.assistant.apps

import com.myra.assistant.models.AppModel

/**
 * Scores installed apps against a spoken app name. Handles nicknames ("insta", "fb", "yt"),
 * spacing ("what's app"), small mishearings (edit distance) and ignores generic words.
 * This replaces the old "first contains-match wins" logic, which often opened the wrong app
 * or none at all.
 */
object AppMatcher {

    private val ALIASES = mapOf(
        "insta" to "instagram", "ig" to "instagram", "fb" to "facebook", "yt" to "youtube",
        "you tube" to "youtube", "whats app" to "whatsapp", "whatsap" to "whatsapp",
        "watsapp" to "whatsapp", "hoyatsapp" to "whatsapp", "gpay" to "google pay",
        "g pay" to "google pay", "play store" to "play store", "playstore" to "play store",
        "google play" to "play store", "camera" to "camera", "gallery" to "gallery",
        "photos" to "photos", "dialer" to "phone", "call" to "phone", "contacts" to "contacts",
        "sms" to "messages", "message" to "messages", "msg" to "messages", "setting" to "settings",
        "clock" to "clock", "alarm" to "clock", "calc" to "calculator", "map" to "maps",
        "google map" to "maps", "google maps" to "maps", "browser" to "chrome", "gmail" to "gmail",
        "mail" to "gmail", "telegram" to "telegram", "snap" to "snapchat", "twitter" to "x",
        "prime video" to "prime video", "amazon" to "amazon", "flipkart" to "flipkart",
        "paytm" to "paytm", "phonepe" to "phonepe", "phone pe" to "phonepe", "netflix" to "netflix",
        "spotify" to "spotify", "meesho" to "meesho", "zomato" to "zomato", "swiggy" to "swiggy"
    )

    private val NOISE = setOf("app", "application", "the", "open", "kholo", "khol", "chalu", "koro", "kar", "do", "please")

    fun normalize(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    fun best(apps: List<AppModel>, query: String): AppModel? {
        var q = normalize(query).split(" ").filter { it !in NOISE }.joinToString(" ")
        if (q.isEmpty()) return null
        ALIASES[q]?.let { q = it }
        val compactQ = q.replace(" ", "")

        var best: AppModel? = null
        var bestScore = 0
        for (app in apps) {
            val name = normalize(app.label)
            val compact = name.replace(" ", "")
            var score = 0
            when {
                name == q || compact == compactQ -> score = 100
                name.startsWith(q) || compact.startsWith(compactQ) -> score = 85
                name.split(" ").any { it == q } -> score = 75
                name.contains(q) || compact.contains(compactQ) -> score = 65
                q.contains(name) && name.length >= 4 -> score = 60
                app.packageName.lowercase().contains(compactQ) && compactQ.length >= 4 -> score = 45
                else -> {
                    val d = editDistance(compact, compactQ)
                    if (compactQ.length >= 4 && d <= 2) score = 55 - d * 5
                    else {
                        val qt = q.split(" ").filter { it.length >= 3 }
                        val hits = qt.count { t -> name.contains(t) }
                        if (hits > 0) score = 30 + hits * 5
                    }
                }
            }
            // Prefer shorter (more specific) names on ties, e.g. "Instagram" over "Instagram Lite Beta".
            score = score * 100 - minOf(name.length, 99)
            if (score > bestScore) { bestScore = score; best = app }
        }
        return if (bestScore >= 30 * 100 - 100) best else null
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
