package com.myra.assistant.task

/**
 * Persistent representation of a long-running / multi-step / resumable task.
 * This is the in-memory domain model; [TaskEntity] is its Room row shape.
 *
 * Kept deliberately separate from Gemini Live / ConversationMemory — this is
 * task state, not conversation state (see Phase 1 "Memory" section).
 */
data class LongTask(
    val taskId: String,
    val userRequest: String,
    val status: TaskStatus,
    val priority: Int = 0,
    val createdAt: Long,
    val updatedAt: Long,
    val currentStep: Int = 0,
    val totalSteps: Int = 0,
    val plan: String? = null,
    val checkpoint: String? = null,
    val progress: Int = 0,
    val requiredPermissions: List<String> = emptyList(),
    val pendingConfirmation: String? = null,
    val retryCount: Int = 0,
    val maxRetries: Int = 3,
    val parentTaskId: String? = null,
    val childTaskIds: List<String> = emptyList(),
    val result: String? = null,
    val error: String? = null,
    val lastHeartbeat: Long = createdAt
) {
    /**
     * A task is only "done" once this is true. Set exclusively by
     * TaskManager.completeTask(), and only after a verification result
     * is supplied — never from the model's own claim of success.
     */
    val isVerifiedComplete: Boolean
        get() = status == TaskStatus.COMPLETED && result != null
}
