package com.myra.assistant.update

import android.app.Activity
import android.app.AlertDialog
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.main.ChatStore

/** The "Update available" popup + download/install flow. */
object UpdateDialog {
    @Volatile private var showing = false

    fun checkAndShow(act: Activity) {
        if (showing || UpdateManager.busy()) return
        Thread {
            val info = UpdateManager.check(act) ?: return@Thread
            act.runOnUiThread {
                if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                show(act, info)
                // MYRA mentions it once per version, in her own sweet way.
                if (UpdateManager.shouldNudge(act, info)) {
                    UpdateManager.markNudged(act, info)
                    ForegroundVoiceService.instance?.announceUpdate(info.name)
                    ChatStore.addBot("Notun update ashche (v${info.name}) — popup theke Update koro, sona 💕")
                }
            }
        }.start()
    }

    private fun show(act: Activity, info: UpdateManager.Info) {
        showing = true
        val b = AlertDialog.Builder(act)
            .setTitle("Update available  •  v${info.name}")
            .setMessage(info.notes.ifBlank { "Bug fixes and improvements." })
            .setCancelable(!info.force)
            .setPositiveButton("Update now", null)
        if (!info.force) b.setNegativeButton("Later") { d, _ -> d.dismiss() }
        val dlg = b.create()
        dlg.setOnDismissListener { showing = false }
        dlg.show()
        // keep the dialog open until we decide (so a failed download doesn't close it)
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { dlg.dismiss(); startUpdate(act, info) }
    }

    private fun startUpdate(act: Activity, info: UpdateManager.Info) {
        if (!UpdateManager.canInstall(act)) {
            Toast.makeText(act, "'Install unknown apps' MYRA ke allow koro, tarpor abar Update dao", Toast.LENGTH_LONG).show()
            UpdateManager.openInstallPermission(act)
            return
        }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val label = TextView(act).apply { text = "Downloading v${info.name}..."; setPadding(0, 0, 0, 16) }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 32, 48, 8); addView(label); addView(bar) }
        val dlg = AlertDialog.Builder(act).setTitle("Updating MYRA").setView(box).setCancelable(false).create()
        dlg.show()
        // From here on MYRA stays quiet: no chatter, no update talk.
        Thread {
            try {
                val apk = UpdateManager.download(act, info) { p -> act.runOnUiThread { bar.progress = p } }
                act.runOnUiThread { dlg.dismiss(); UpdateManager.install(act, apk) }
            } catch (e: Exception) {
                act.runOnUiThread {
                    dlg.dismiss()
                    Toast.makeText(act, e.message ?: "Update failed", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
