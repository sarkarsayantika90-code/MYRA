package com.myra.admin

import android.view.View
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All admin screens. Every network call runs on a background thread through MainActivity.load/act. */
class Screens(private val a: MainActivity) {

    private val time = SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH)
    private fun fmt(t: Long) = if (t <= 0) "-" else time.format(Date(t))
    private fun now() = System.currentTimeMillis()
    private fun c() = a.content

    private fun loading() {
        c().removeAllViews()
        c().addView(Ui.text(a, "Loading...", 14f, Ui.DIM))
    }

    private fun clear(title: String) {
        c().removeAllViews()
        c().addView(Ui.title(a, title))
    }

    private fun confirm(title: String, msg: String, okText: String, onOk: () -> Unit) {
        AlertDialog.Builder(a).setTitle(title).setMessage(msg)
            .setPositiveButton(okText) { _, _ -> onOk() }.setNegativeButton("Cancel", null).show()
    }

    // ───────────────────────── Dashboard ─────────────────────────

    fun dashboard() {
        loading()
        a.load({
            Triple(Models.users(Db.getObject(a, "users")), Db.getObject(a, "bans"), Db.getObject(a, "payments"))
        }) { (users, bans, pay) ->
            clear("Dashboard")
            val n = now(); val day = 86_400_000L
            var pending = 0
            for (uid in pay.keys()) {
                val o = pay.optJSONObject(uid) ?: continue
                for (id in o.keys()) if (o.optJSONObject(id)?.optString("status") == "pending") pending++
            }
            val stats = listOf(
                "Users" to users.size, "Active 24h" to users.count { n - it.lastSeen < day },
                "Active 7d" to users.count { n - it.lastSeen < 7 * day }, "New 7d" to users.count { n - it.createdAt < 7 * day },
                "Premium" to users.count { it.premiumActive(n) }, "Banned" to bans.length(), "Pending payments" to pending
            )
            var rowBox: LinearLayout? = null
            stats.forEachIndexed { i, (label, value) ->
                if (i % 2 == 0) { rowBox = Ui.row(a); c().addView(rowBox, Ui.lp(a, 8)) }
                rowBox!!.addView(Ui.card(a).apply {
                    addView(Ui.text(a, value.toString(), 26f, Ui.ACCENT, true))
                    addView(Ui.text(a, label, 12f, Ui.DIM))
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 8) })
            }
            val versions = users.groupingBy { it.ver.ifBlank { "?" } }.eachCount().toSortedMap()
            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "App versions in use", 14f, Ui.TEXT, true))
                versions.forEach { (v, k) -> addView(Ui.text(a, "v$v   -   $k user(s)", 13f, Ui.DIM), Ui.lp(a, 4)) }
            }, Ui.lp(a, 8))
        }
    }

    // ───────────────────────── Users ─────────────────────────

    fun users() {
        loading()
        a.load({ Models.users(Db.getObject(a, "users")) to Db.getObject(a, "bans") }) { (list, bans) ->
            val data = list.toMutableList()
            val banned = HashSet<String>().apply { bans.keys().forEach { add(it) } }
            clear("Users")
            val count = Ui.text(a, "", 12f, Ui.DIM)
            val search = Ui.input(a, "Search Gmail / device / id")
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            c().addView(search); c().addView(count, Ui.lp(a, 6)); c().addView(box, Ui.lp(a, 4))

            lateinit var draw: () -> Unit
            draw = {
                box.removeAllViews()
                val q = search.text.toString().trim().lowercase()
                val rows = data.filter { (it.email + it.uid + it.device).lowercase().contains(q) }.sortedByDescending { it.lastSeen }
                val prem = data.count { it.premiumActive(now()) }
                count.text = "${data.size} users  -  $prem premium  -  ${banned.size} banned" + if (rows.size > 120) "  (showing 120)" else ""
                rows.take(120).forEach { u ->
                    box.addView(userCard(u, banned.contains(u.uid), onChange = { nu ->
                        val i = data.indexOfFirst { it.uid == nu.uid }; if (i >= 0) data[i] = nu; draw()
                    }, onBan = { isBanned -> if (isBanned) banned.add(u.uid) else banned.remove(u.uid); draw() }), Ui.lp(a, 8))
                }
            }
            draw()
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { draw() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
    }

    private fun userCard(u: UserRow, isBanned: Boolean, onChange: (UserRow) -> Unit, onBan: (Boolean) -> Unit): View {
        val n = now()
        val active = u.premiumActive(n)
        val name = u.email.ifBlank { "(no Gmail yet)" }
        return Ui.card(a).apply {
            addView(Ui.text(a, name, 15f, Ui.TEXT, true))
            addView(Ui.text(a, u.uid, 10f, Ui.DIM))
            addView(Ui.text(a, "App v${u.ver.ifBlank { "?" }}  -  ${u.device.ifBlank { "unknown device" }}", 12f, Ui.DIM), Ui.lp(a, 4))
            addView(Ui.text(a, "Last seen: ${fmt(u.lastSeen)}   Joined: ${fmt(u.createdAt)}", 12f, Ui.DIM))
            val chips = Ui.row(a)
            chips.addView(if (active) Ui.chip(a, "PREMIUM - " + Plans.label(u.premiumUntil, n), Ui.OK) else Ui.chip(a, if (u.hasPremium) "PREMIUM EXPIRED" else "FREE", Ui.DIM))
            if (isBanned) chips.addView(Ui.chip(a, "BANNED", Ui.BAD), LinearLayout.LayoutParams(-2, -2).apply { marginStart = Ui.dp(a, 6) })
            addView(chips, Ui.lp(a, 8))

            val r1 = Ui.row(a)
            if (active) {
                r1.addView(Ui.button(a, "Deactivate premium", color = Ui.BAD) { deactivate(u, onChange) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
                r1.addView(Ui.button(a, "Extend", color = Ui.OK) { grantDialog(u, onChange) })
            } else {
                r1.addView(Ui.button(a, "Activate premium", filled = true, color = Ui.OK) { grantDialog(u, onChange) }, LinearLayout.LayoutParams(0, -2, 1f))
            }
            addView(r1, Ui.lp(a, 10))

            val r2 = Ui.row(a)
            fun small(label: String, color: Int = Ui.ACCENT, f: () -> Unit) =
                r2.addView(Ui.button(a, label, color = color) { f() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 4) })
            small("Message") { messageDialog(u) }
            small("Usage") { usageDialog(u) }
            small(if (isBanned) "Unban" else "Ban", Ui.BAD) { toggleBan(u, isBanned, onBan) }
            small("Log out", Ui.WARN) {
                confirm("Log out ${u.email.ifBlank { "this user" }}?", "Their MYRA signs out within about a minute if it is on, or ~15 minutes otherwise.", "Log out") {
                    a.act({ Db.notice(a, u.uid, "", "", "logout"); Db.audit(a, "remote logout", u.uid) }, "Logout command sent")
                }
            }
            addView(r2, Ui.lp(a, 6))
        }
    }

    private fun deactivate(u: UserRow, onChange: (UserRow) -> Unit) {
        confirm("Deactivate premium?", "${u.email.ifBlank { u.uid }} goes back to the free plan immediately.", "Deactivate") {
            a.act({
                Db.delete(a, "users/${u.uid}/premium")
                Db.notice(a, u.uid, "", "", "refresh")
                Db.audit(a, "revoke premium", u.uid)
            }, "Premium deactivated") { onChange(u.copy(plan = "", premiumUntil = 0L, hasPremium = false)) }
        }
    }

    private fun grantDialog(u: UserRow, onChange: (UserRow) -> Unit) {
        val plans = Plans.all()
        val ids = plans.keys.toList() + "custom"
        val labels = ids.map { if (it == "custom") "custom days..." else "$it (" + (plans[it]!!.let { d -> if (d < 0) "lifetime" else "$d days" }) + ")" }
        val spinner = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, labels) }
        val days = Ui.input(a, "Custom days (-1 = lifetime)", number = true)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0)
            addView(Ui.text(a, "Time is added on top of any premium that is still left.", 12f, Ui.DIM))
            addView(spinner, Ui.lp(a, 8)); addView(days, Ui.lp(a, 8))
        }
        AlertDialog.Builder(a).setTitle("Activate premium - ${u.email.ifBlank { u.uid }}").setView(box)
            .setPositiveButton("Activate") { _, _ ->
                val id = ids[spinner.selectedItemPosition]
                val d = if (id == "custom") days.text.toString().trim().toIntOrNull() else plans[id]
                if (d == null || d == 0 || d < -1) { a.toast("Enter the number of days (or -1 for lifetime)"); return@setPositiveButton }
                val cur = if (u.hasPremium) u.premiumUntil else 0L
                val until = Plans.until(now(), cur, d)
                a.act({
                    Db.put(a, "users/${u.uid}/premium", JSONObject().put("plan", id).put("until", until).put("by", Auth.email(a)).put("at", now()))
                    Db.notice(a, u.uid, "", "", "refresh")
                    Db.audit(a, "grant $id", u.uid)
                }, "Premium activated") { onChange(u.copy(plan = id, premiumUntil = until, hasPremium = true)) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun toggleBan(u: UserRow, isBanned: Boolean, onBan: (Boolean) -> Unit) {
        confirm(if (isBanned) "Unban user?" else "Ban user?",
            if (isBanned) "${u.email} gets access again." else "${u.email} loses the Gemini key and app config, so MYRA stops working for them.",
            if (isBanned) "Unban" else "Ban") {
            a.act({
                if (isBanned) Db.delete(a, "bans/${u.uid}") else Db.put(a, "bans/${u.uid}", true)
                Db.audit(a, if (isBanned) "unban" else "ban", u.uid)
            }, if (isBanned) "Unbanned" else "Banned") { onBan(!isBanned) }
        }
    }

    private fun messageDialog(u: UserRow) {
        val t = Ui.input(a, "Title (optional)"); val b = Ui.input(a, "Message", multiline = true)
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0); addView(t); addView(b, Ui.lp(a, 8)) }
        AlertDialog.Builder(a).setTitle("Message to ${u.email.ifBlank { u.uid }}").setView(box)
            .setPositiveButton("Send") { _, _ ->
                val body = b.text.toString().trim()
                if (body.isEmpty()) { a.toast("Write a message"); return@setPositiveButton }
                a.act({ Db.notice(a, u.uid, t.text.toString().trim().ifEmpty { "MYRA" }, body); Db.audit(a, "notify", u.uid) }, "Sent")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun usageDialog(u: UserRow) {
        a.toast("Loading usage...")
        Thread {
            try {
                val o = Db.getObject(a, "usage/${u.uid}")
                val keys = o.keys().asSequence().toList().sorted().takeLast(7)
                val text = if (keys.isEmpty()) "No voice usage yet." else keys.joinToString("\n") { "${dayLabel(it)}:  ${o.optInt(it) / 60} min" }
                a.runOnUiThread { AlertDialog.Builder(a).setTitle("Voice usage - last 7 days").setMessage(text).setPositiveButton("Close", null).show() }
            } catch (e: Exception) { a.runOnUiThread { a.fail(e) } }
        }.start()
    }

    private fun dayLabel(k: String) = if (k.length == 8) "${k.substring(6)}/${k.substring(4, 6)}/${k.substring(0, 4)}" else k

    // ───────────────────────── Payments ─────────────────────────

    private data class Pay(val uid: String, val id: String, val email: String, val plan: String, val amount: String, val utr: String, val status: String, val at: Long)

    fun payments() {
        loading()
        a.load({ Db.getObject(a, "payments") }) { o ->
            val all = ArrayList<Pay>()
            for (uid in o.keys()) {
                val per = o.optJSONObject(uid) ?: continue
                for (id in per.keys()) {
                    val p = per.optJSONObject(id) ?: continue
                    all.add(Pay(uid, id, p.optString("email"), p.optString("plan"), p.optString("amount"), p.optString("utr"), p.optString("status"), p.optLong("createdAt")))
                }
            }
            all.sortWith(compareBy<Pay> { it.status != "pending" }.thenByDescending { it.at })
            clear("Payments")
            if (all.isEmpty()) c().addView(Ui.text(a, "No payments yet.", 14f, Ui.DIM))
            all.take(150).forEach { p ->
                c().addView(Ui.card(a).apply {
                    addView(Ui.text(a, p.email.ifBlank { p.uid }, 15f, Ui.TEXT, true))
                    addView(Ui.text(a, "${p.plan}  -  Rs ${p.amount}", 13f, Ui.DIM))
                    addView(Ui.text(a, "UTR ${p.utr}   ${fmt(p.at)}", 12f, Ui.DIM))
                    val color = when (p.status) { "approved" -> Ui.OK; "rejected" -> Ui.BAD; else -> Ui.WARN }
                    addView(Ui.chip(a, p.status.uppercase(), color), Ui.lp(a, 6, -2))
                    if (p.status == "pending") {
                        val r = Ui.row(a)
                        r.addView(Ui.button(a, "Approve", filled = true, color = Ui.OK) { approve(p) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
                        r.addView(Ui.button(a, "Reject", color = Ui.BAD) { reject(p) }, LinearLayout.LayoutParams(0, -2, 1f))
                        addView(r, Ui.lp(a, 10))
                    }
                }, Ui.lp(a, 8))
            }
        }
    }

    private fun approve(p: Pay) {
        val days = Plans.all()[p.plan]
        if (days == null) { a.toast("Unknown plan '${p.plan}'. Use Users > Activate premium instead."); return }
        confirm("Approve payment?", "${p.email}: ${p.plan} for Rs ${p.amount}\nUTR ${p.utr}\n\nCheck your bank/UPI app first.", "Approve") {
            a.act({
                val cur = Db.getObject(a, "users/${p.uid}/premium").optLong("until", 0L)
                val until = Plans.until(now(), cur, days)
                Db.put(a, "users/${p.uid}/premium", JSONObject().put("plan", p.plan).put("until", until).put("by", Auth.email(a)).put("at", now()))
                Db.put(a, "payments/${p.uid}/${p.id}/status", "approved")
                Db.put(a, "payments/${p.uid}/${p.id}/by", Auth.email(a))
                Db.notice(a, p.uid, "", "", "refresh")
                Db.audit(a, "approve payment", "${p.uid}/${p.id}")
            }, "Approved - premium is on") { payments() }
        }
    }

    private fun reject(p: Pay) {
        confirm("Reject payment?", "${p.email}: UTR ${p.utr}", "Reject") {
            a.act({
                Db.put(a, "payments/${p.uid}/${p.id}/status", "rejected")
                Db.audit(a, "reject payment", "${p.uid}/${p.id}")
            }, "Rejected") { payments() }
        }
    }

    // ───────────────────────── Control (remote config) ─────────────────────────

    fun control() {
        loading()
        a.load({ Db.getObject(a, "appconfig") }) { cfg ->
            clear("Control")
            val maint = cfg.optJSONObject("maintenance")
            val off = HashSet<String>(cfg.optString("disabledTools").split(',').map { it.trim() }.filter { it.isNotEmpty() })

            val key = Ui.input(a, "Gemini API key (leave empty = keep current)")
            val model = Ui.input(a, "Model (empty = app default)").apply { setText(cfg.optString("model")) }
            val free = Ui.input(a, "Free minutes per day", number = true).apply { setText(cfg.optInt("freeMinutes", 20).toString()) }
            val announce = Ui.input(a, "Announcement shown once in chat").apply { setText(cfg.optString("announcement")) }
            val mm = Ui.input(a, "Maintenance message").apply { setText(maint?.optString("message").orEmpty()) }
            val mOn = CheckBox(a).apply { text = "Maintenance mode (users are locked out, admin never)"; setTextColor(Ui.TEXT); isChecked = maint?.optBoolean("on", false) ?: false }

            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "App settings", 15f, Ui.TEXT, true))
                addView(Ui.text(a, "Every logged-in, non-banned phone downloads these. Current key: " + (if (cfg.optString("geminiKey").isBlank()) "none" else "..." + cfg.optString("geminiKey").takeLast(4)), 12f, Ui.WARN), Ui.lp(a, 4))
                addView(Ui.label(a, "Gemini API key")); addView(key)
                addView(Ui.label(a, "Model")); addView(model)
                addView(Ui.label(a, "Free minutes per day")); addView(free)
                addView(Ui.label(a, "Announcement")); addView(announce)
                addView(mOn, Ui.lp(a, 10)); addView(mm, Ui.lp(a, 4))
            })

            // Tool switches
            val toolBoxes = HashMap<String, CheckBox>()
            val toolsBody = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            ToolNames.GROUPS.forEach { (group, names) ->
                toolsBody.addView(Ui.label(a, group.uppercase()))
                names.forEach { nm ->
                    toolsBody.addView(CheckBox(a).apply {
                        text = nm; setTextColor(Ui.TEXT); textSize = 13f
                        isChecked = nm !in off           // checked = ON
                        toolBoxes[nm] = this
                    })
                }
            }
            val toolsHeader = Ui.text(a, "", 14f, Ui.ACCENT, true)
            fun refreshHeader() { toolsHeader.text = (if (toolsBody.visibility == View.VISIBLE) "v " else "> ") + "Tool switches  (" + toolBoxes.values.count { !it.isChecked } + " off)" }
            toolsHeader.setOnClickListener { toolsBody.visibility = if (toolsBody.visibility == View.VISIBLE) View.GONE else View.VISIBLE; refreshHeader() }
            // keep CSV for tools not in the known list (so nothing is silently re-enabled)
            val known = ToolNames.GROUPS.values.flatten().toSet()
            val otherOff = Ui.input(a, "other tool names to switch off, comma separated").apply {
                setText(off.filter { it !in known }.joinToString(", "))
            }
            toolsBody.addView(Ui.label(a, "OTHER / NEW TOOLS")); toolsBody.addView(otherOff)
            c().addView(Ui.card(a).apply {
                addView(toolsHeader)
                addView(Ui.text(a, "Untick a tool to stop MYRA from using it on every phone.", 12f, Ui.DIM), Ui.lp(a, 2))
                addView(toolsBody)
            }, Ui.lp(a, 10))
            refreshHeader()
            toolBoxes.values.forEach { it.setOnCheckedChangeListener { _, _ -> refreshHeader() } }

            c().addView(Ui.button(a, "Save all settings", filled = true) {
                val extra = otherOff.text.toString().split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() && it != "stop_myra" }
                val disabled = (toolBoxes.filter { !it.value.isChecked }.keys + extra).toSortedSet().joinToString(",")
                val minutes = free.text.toString().trim().toIntOrNull()
                if (minutes == null || minutes < 0) { a.toast("Free minutes must be a number"); return@button }
                a.act({
                    val k = key.text.toString().trim()
                    if (k.isNotEmpty()) Db.put(a, "appconfig/geminiKey", k)
                    Db.put(a, "appconfig/model", model.text.toString().trim())
                    Db.put(a, "appconfig/freeMinutes", minutes)
                    Db.put(a, "appconfig/announcement", announce.text.toString().trim())
                    Db.put(a, "appconfig/maintenance/on", mOn.isChecked)
                    Db.put(a, "appconfig/maintenance/message", mm.text.toString().trim())
                    Db.put(a, "appconfig/disabledTools", disabled)
                    Db.audit(a, "save config", "tools off: ${if (disabled.isEmpty()) "none" else disabled}")
                }, "Saved - phones pick it up within ~10 minutes") { control() }
            }, Ui.lp(a, 12))

            // Premium plans used by the admin app (so new plans never need an app update)
            val planRows = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val planInputs = ArrayList<Pair<android.widget.EditText, android.widget.EditText>>()
            fun addPlanRow(id: String, days: String) {
                val idIn = Ui.input(a, "plan id").apply { setText(id) }
                val dIn = Ui.input(a, "days (-1 = lifetime)", number = true).apply { setText(days) }
                planInputs.add(idIn to dIn)
                planRows.addView(Ui.row(a).apply {
                    addView(idIn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
                    addView(dIn, LinearLayout.LayoutParams(0, -2, 1f))
                }, Ui.lp(a, 6))
            }
            Plans.all().forEach { (k, v) -> addPlanRow(k, v.toString()) }
            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "Premium plans (admin app)", 15f, Ui.TEXT, true))
                addView(Ui.text(a, "Used by Activate / Extend and payment approval. Empty the id to remove a plan.", 12f, Ui.DIM), Ui.lp(a, 2))
                addView(planRows)
                val r = Ui.row(a)
                r.addView(Ui.button(a, "+ Add plan") { addPlanRow("", "30") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
                r.addView(Ui.button(a, "Save plans", filled = true) {
                    val m = LinkedHashMap<String, Int>()
                    for ((i, d) in planInputs) {
                        val id = i.text.toString().trim().lowercase(); val days = d.text.toString().trim().toIntOrNull()
                        if (id.isEmpty()) continue
                        if (!Plans.validKey(id) || days == null || days == 0 || days < -1) { a.toast("Bad plan '$id'"); return@button }
                        m[id] = days
                    }
                    if (m.isEmpty()) { a.toast("Keep at least one plan"); return@button }
                    a.act({
                        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, v) }
                        Db.put(a, "config/adminPlans", o); Db.audit(a, "save plans", m.keys.joinToString(","))
                    }, "Plans saved") { Plans.current = m }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(r, Ui.lp(a, 10))
            }, Ui.lp(a, 12))

            // Raw editor: any setting MYRA reads from appconfig, including ones added in future versions
            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "Advanced - raw settings", 15f, Ui.TEXT, true))
                addView(Ui.text(a, "Every value under appconfig. Add any new setting a future MYRA version reads.", 12f, Ui.DIM), Ui.lp(a, 2))
                cfg.keys().asSequence().toList().sorted().forEach { k ->
                    val shown = if (k.contains("key", true) || k.contains("secret", true)) "..." + cfg.opt(k).toString().takeLast(4) else cfg.opt(k).toString().take(70)
                    addView(Ui.row(a).apply {
                        addView(Ui.text(a, "$k = $shown", 12f, Ui.TEXT), LinearLayout.LayoutParams(0, -2, 1f))
                        addView(Ui.button(a, "Edit") { rawDialog(k, if (k.contains("key", true)) "" else cfg.opt(k).toString()) })
                    }, Ui.lp(a, 6))
                }
                addView(Ui.button(a, "+ Add / change a setting", filled = true) { rawDialog("", "") }, Ui.lp(a, 10))
            }, Ui.lp(a, 12))

            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "Danger zone", 15f, Ui.BAD, true))
                addView(Ui.text(a, "Signs EVERY user out of MYRA (they can log in again). Your own phone too.", 12f, Ui.DIM), Ui.lp(a, 2))
                addView(Ui.button(a, "Log out all users", color = Ui.BAD) {
                    confirm("Log out ALL users?", "Everyone is signed out on their next check (about a minute if MYRA is on).", "Log out all") {
                        a.act({ Db.put(a, "appconfig/forceLogoutAt", now()); Db.audit(a, "logout everyone") }, "Done")
                    }
                }, Ui.lp(a, 8))
            }, Ui.lp(a, 12))
        }
    }

    private fun rawDialog(key0: String, value0: String) {
        val k = Ui.input(a, "setting name (letters, digits, _)").apply { setText(key0); if (key0.isNotEmpty()) isEnabled = false }
        val v = Ui.input(a, "value: text, number, true/false or JSON", multiline = true).apply { setText(value0) }
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0); addView(k); addView(v, Ui.lp(a, 8)) }
        val b = AlertDialog.Builder(a).setTitle(if (key0.isEmpty()) "Add setting" else "Edit $key0").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val name = k.text.toString().trim()
                if (!Plans.validKey(name)) { a.toast("Bad setting name"); return@setPositiveButton }
                a.act({ Db.put(a, "appconfig/$name", Plans.parseValue(v.text.toString())); Db.audit(a, "raw setting", name) }, "Saved") { control() }
            }.setNegativeButton("Cancel", null)
        if (key0.isNotEmpty()) b.setNeutralButton("Delete") { _, _ ->
            confirm("Delete $key0?", "MYRA falls back to its default for this setting.", "Delete") {
                a.act({ Db.delete(a, "appconfig/$key0"); Db.audit(a, "delete setting", key0) }, "Deleted") { control() }
            }
        }
        b.show()
    }

    // ───────────────────────── Send to MYRA ─────────────────────────

    fun notify() {
        loading()
        a.load({ Models.users(Db.getObject(a, "users")).filter { it.email.isNotBlank() }.sortedBy { it.email } }) { users ->
            clear("Send to MYRA")
            val n = now()
            val segs = listOf("Everyone", "All premium users", "All free users", "One user...")
            val seg = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, segs) }
            val one = Spinner(a).apply {
                adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, users.map { it.email })
                visibility = View.GONE
            }
            seg.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { one.visibility = if (pos == 3) View.VISIBLE else View.GONE }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
            val title = Ui.input(a, "Title (optional)")
            val body = Ui.input(a, "Message", multiline = true)
            c().addView(Ui.card(a).apply {
                addView(Ui.label(a, "To")); addView(seg); addView(one, Ui.lp(a, 6))
                addView(Ui.label(a, "Title")); addView(title)
                addView(Ui.label(a, "Message")); addView(body)
                addView(Ui.text(a, "Phones show it within ~1 minute while MYRA is on, ~15 minutes otherwise.", 12f, Ui.DIM), Ui.lp(a, 8))
                addView(Ui.button(a, "SEND TO MYRA", filled = true) {
                    val text = body.text.toString().trim()
                    if (text.isEmpty()) { a.toast("Write a message"); return@button }
                    val t = title.text.toString().trim().ifEmpty { "MYRA" }
                    val which = seg.selectedItemPosition
                    val targets: List<UserRow> = when (which) {
                        1 -> users.filter { it.premiumActive(n) }
                        2 -> users.filter { !it.premiumActive(n) }
                        3 -> listOfNotNull(users.getOrNull(one.selectedItemPosition))
                        else -> emptyList()
                    }
                    if (which != 0 && targets.isEmpty()) { a.toast("No users in that group"); return@button }
                    val label = if (which == 0) "everyone" else "${targets.size} user(s)"
                    confirm("Send to $label?", "\"$t\"\n\n$text", "Send") {
                        a.act({
                            if (which == 0) Db.notice(a, null, t, text) else targets.forEach { Db.notice(a, it.uid, t, text) }
                            Db.audit(a, "notify", if (which == 0) "all" else "${targets.size} users")
                            AlertStore.add(a, "sent", "Sent to $label", "$t: $text", unread = false)
                        }, "Sent to $label") { body.setText(""); notify() }
                    }
                }, Ui.lp(a, 12))
            })

            val sent = AlertStore.all(a).filter { it.kind == "sent" }.take(8)
            if (sent.isNotEmpty()) {
                c().addView(Ui.label(a, "RECENTLY SENT"))
                sent.forEach { al ->
                    c().addView(Ui.card(a).apply {
                        addView(Ui.text(a, al.title, 13f, Ui.TEXT, true))
                        addView(Ui.text(a, al.text.take(140), 12f, Ui.DIM))
                        addView(Ui.text(a, fmt(al.at), 11f, Ui.DIM))
                    }, Ui.lp(a, 6))
                }
            }
        }
    }

    // ───────────────────────── Alerts inbox ─────────────────────────

    fun alerts() {
        AlertStore.markRead(a); a.drawNav()
        clear("Alerts")
        val bar = Ui.row(a)
        bar.addView(Ui.button(a, "Check now", filled = true) {
            a.act({ Watcher.check(a) }, "Checked") { alerts() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
        bar.addView(Ui.button(a, "Clear", color = Ui.BAD) { AlertStore.clear(a); alerts() })
        c().addView(bar)
        c().addView(Ui.text(a, "New payments and new users show up here and as phone notifications.", 12f, Ui.DIM), Ui.lp(a, 6))
        val list = AlertStore.all(a).filter { it.kind != "sent" }
        if (list.isEmpty()) c().addView(Ui.text(a, "No alerts yet.", 14f, Ui.DIM), Ui.lp(a, 10))
        list.forEach { al ->
            c().addView(Ui.card(a).apply {
                val color = if (al.kind == "pay") Ui.WARN else Ui.OK
                addView(Ui.text(a, al.title, 14f, color, true))
                addView(Ui.text(a, al.text, 13f, Ui.TEXT))
                addView(Ui.text(a, fmt(al.at), 11f, Ui.DIM))
                setOnClickListener { a.show(if (al.kind == "pay") "pay" else "users") }
            }, Ui.lp(a, 6))
        }
    }

    // ───────────────────────── Settings ─────────────────────────

    fun settings() {
        clear("Settings")
        val key = Ui.input(a, "Firebase Web API key").apply { setText(Config.apiKey) }
        val db = Ui.input(a, "Database URL (https://...)").apply { setText(Config.db) }
        val adm = Ui.input(a, "Admin email").apply { setText(Config.admin) }
        c().addView(Ui.card(a).apply {
            addView(Ui.text(a, "Connection", 15f, Ui.TEXT, true))
            addView(Ui.text(a, "Change these if you ever move to another Firebase project - no app update needed.", 12f, Ui.DIM), Ui.lp(a, 2))
            addView(Ui.label(a, "API key")); addView(key)
            addView(Ui.label(a, "Database URL")); addView(db)
            addView(Ui.label(a, "Admin email")); addView(adm)
            addView(Ui.button(a, "Save connection", filled = true) {
                val u = db.text.toString().trim()
                if (!u.startsWith("https://") || key.text.toString().isBlank() || !adm.text.toString().contains("@")) { a.toast("Check the key, https URL and email"); return@button }
                confirm("Save and log out?", "You will log in again with the admin account of the new project.", "Save") {
                    Config.save(a, key.text.toString(), u, adm.text.toString())
                    Auth.logout(a); Watcher.cancel(a)
                    a.startActivity(android.content.Intent(a, LoginActivity::class.java)); a.finish()
                }
            }, Ui.lp(a, 12))
            addView(Ui.button(a, "Reset to defaults", color = Ui.WARN) {
                Config.resetDefaults(a); a.toast("Defaults restored. Log in again."); Auth.logout(a); Watcher.cancel(a)
                a.startActivity(android.content.Intent(a, LoginActivity::class.java)); a.finish()
            }, Ui.lp(a, 6))
        })

        val pay = CheckBox(a).apply { text = "Alert me about new payments"; setTextColor(Ui.TEXT); isChecked = Watcher.wantsPay(a) }
        val usr = CheckBox(a).apply { text = "Alert me about new users"; setTextColor(Ui.TEXT); isChecked = Watcher.wantsUsers(a) }
        val intervals = listOf(15, 30, 60, 180)
        val spin = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, intervals.map { if (it < 60) "every $it min" else "every ${it / 60} h" })
            setSelection(intervals.indexOf(Watcher.intervalMinutes(a)).coerceAtLeast(0))
        }
        c().addView(Ui.card(a).apply {
            addView(Ui.text(a, "Notifications", 15f, Ui.TEXT, true))
            addView(pay, Ui.lp(a, 6)); addView(usr)
            addView(Ui.label(a, "Background check")); addView(spin)
            addView(Ui.text(a, "Checked every minute while this app is open; Android limits background checks to 15 min or more.", 11f, Ui.DIM), Ui.lp(a, 4))
            val r = Ui.row(a)
            r.addView(Ui.button(a, "Save", filled = true) {
                Watcher.setWants(a, pay.isChecked, usr.isChecked)
                Watcher.setInterval(a, intervals[spin.selectedItemPosition]); Watcher.schedule(a)
                a.toast("Saved")
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
            r.addView(Ui.button(a, "Test") {
                if (!Notifier.canPost(a)) a.toast("Allow notifications for this app in Android settings")
                else { Notifier.post(a, 1, "MYRA Admin", "Notifications are working", "dash"); a.toast("Sent a test notification") }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(r, Ui.lp(a, 10))
        }, Ui.lp(a, 10))

        c().addView(Ui.text(a, "Made by Anik", 11f, Ui.DIM).apply { gravity = android.view.Gravity.CENTER }, Ui.lp(a, 16))
    }

    // ───────────────────────── Live usage ─────────────────────────

    fun live() {
        loading()
        fun fetch() {
            a.load({
                val users = Models.users(Db.getObject(a, "users")).associateBy { it.uid }
                val usage = Db.getObject(a, "usage")
                users to usage
            }) { (users, usage) ->
                val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                val rows = ArrayList<Pair<String, Int>>()
                for (uid in usage.keys()) {
                    val s = usage.optJSONObject(uid)?.optInt(today, 0) ?: 0
                    if (s > 0) rows.add(uid to s)
                }
                rows.sortByDescending { it.second }
                val n = now()
                val online = users.values.count { n - it.lastSeen < 5 * 60_000L }
                clear("Live usage")
                c().addView(Ui.card(a).apply {
                    addView(Ui.text(a, "${rows.sumOf { it.second } / 60} min", 28f, Ui.ACCENT, true))
                    addView(Ui.text(a, "talked today by ${rows.size} user(s)  -  $online seen in the last 5 min", 12f, Ui.DIM))
                    addView(Ui.text(a, "Auto-refreshes every 20 s", 11f, Ui.DIM), Ui.lp(a, 4))
                })
                rows.take(40).forEach { (uid, s) ->
                    val u = users[uid]
                    c().addView(Ui.card(a).apply {
                        val r = Ui.row(a)
                        r.addView(Ui.text(a, u?.email?.ifBlank { uid } ?: uid, 14f, Ui.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                        r.addView(Ui.text(a, "${s / 60} min", 14f, if (u?.premiumActive(n) == true) Ui.OK else Ui.TEXT, true))
                        addView(r)
                        addView(Ui.text(a, (if (u?.premiumActive(n) == true) "Premium" else "Free") + "  -  last seen ${fmt(u?.lastSeen ?: 0L)}", 11f, Ui.DIM))
                    }, Ui.lp(a, 6))
                }
                if (rows.isEmpty()) c().addView(Ui.text(a, "Nobody has talked to MYRA yet today.", 14f, Ui.DIM), Ui.lp(a, 10))
            }
        }
        fetch()
        a.startTicker(20_000L) { fetch() }
    }

    // ───────────────────────── App update ─────────────────────────

    fun update() {
        loading()
        a.load({ Db.getObject(a, "config/update") }) { u ->
            clear("Publish app update")
            val vc = Ui.input(a, "versionCode", number = true).apply { if (u.has("versionCode")) setText(u.optLong("versionCode").toString()) }
            val vn = Ui.input(a, "versionName").apply { setText(u.optString("versionName")) }
            val url = Ui.input(a, "APK link (https)").apply { setText(u.optString("apkUrl")) }
            val sha = Ui.input(a, "sha256 (optional)").apply { setText(u.optString("sha256")) }
            val notes = Ui.input(a, "What's new", multiline = true).apply { setText(u.optString("notes")) }
            val force = CheckBox(a).apply { text = "Force update"; setTextColor(Ui.TEXT); isChecked = u.optBoolean("force", false) }
            c().addView(Ui.card(a).apply {
                addView(Ui.text(a, "Use versionCode, link and sha256 from the GitHub Actions run summary.", 12f, Ui.DIM))
                addView(Ui.label(a, "versionCode")); addView(vc)
                addView(Ui.label(a, "versionName")); addView(vn)
                addView(Ui.label(a, "APK link")); addView(url)
                addView(Ui.label(a, "sha256")); addView(sha)
                addView(Ui.label(a, "What's new")); addView(notes)
                addView(force, Ui.lp(a, 8))
                val r = Ui.row(a)
                r.addView(Ui.button(a, "Publish", filled = true) {
                    val code = vc.text.toString().trim().toLongOrNull()
                    val link = url.text.toString().trim()
                    if (code == null || code <= 0 || !link.startsWith("https://")) { a.toast("versionCode and an https APK link are required"); return@button }
                    a.act({
                        Db.put(a, "config/update", JSONObject().put("versionCode", code).put("versionName", vn.text.toString().trim())
                            .put("apkUrl", link).put("sha256", sha.text.toString().trim().lowercase())
                            .put("notes", notes.text.toString().trim()).put("force", force.isChecked))
                        Db.audit(a, "publish update", code.toString())
                    }, "Published")
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 6) })
                r.addView(Ui.button(a, "Remove update", color = Ui.BAD) {
                    a.act({ Db.delete(a, "config/update"); Db.audit(a, "remove update") }, "Removed") { update() }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(r, Ui.lp(a, 12))
            })
        }
    }

    // ───────────────────────── Audit ─────────────────────────

    fun audit() {
        loading()
        a.load({ Db.getObject(a, "audit", "orderBy=%22%24key%22&limitToLast=100") }) { o ->
            clear("Audit log")
            val keys = o.keys().asSequence().toList().sortedDescending()
            if (keys.isEmpty()) c().addView(Ui.text(a, "Empty.", 14f, Ui.DIM))
            keys.forEach { k ->
                val r = o.optJSONObject(k) ?: return@forEach
                c().addView(Ui.card(a).apply {
                    addView(Ui.text(a, r.optString("action"), 14f, Ui.TEXT, true))
                    addView(Ui.text(a, r.optString("target"), 11f, Ui.DIM))
                    addView(Ui.text(a, "${fmt(r.optLong("at"))}  -  ${r.optString("by")}", 11f, Ui.DIM))
                }, Ui.lp(a, 6))
            }
        }
    }
}
