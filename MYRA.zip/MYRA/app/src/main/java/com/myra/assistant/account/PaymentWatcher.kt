package com.myra.assistant.account

import android.content.Context
import com.myra.assistant.utils.Logger
import org.json.JSONArray
import org.json.JSONObject

/**
 * OWNER-SIDE auto-verify.
 *
 * UPI to a personal QR has no API that tells an app "this payment arrived". The one place the
 * proof exists is YOUR phone: the PhonePe / bank notification or SMS "Received Rs 99...".
 * When MYRA runs on your phone (signed in as the owner) it reads those credit alerts, matches them
 * with payments users submitted (UTR, or amount + time), and switches premium on in the database.
 * Users' phones then see premium appear by themselves.
 *
 * It never stores notification text - only amount, optional UTR and time of each credit.
 */
object PaymentWatcher {
    private const val TAG = "PAYWATCH"
    private val CREDIT = Regex("(?i)(received|credited|paid you|sent you|has sent|deposited)")
    private val AMOUNT = Regex("(?i)(?:₹|rs\\.?|inr)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
    private val UTR = Regex("(?<!\\d)(\\d{12})(?!\\d)")

    private data class Credit(val at: Long, val amount: Double, val utr: String?, var used: Boolean = false)
    private val credits = ArrayList<Credit>()

    /** Called for every notification; cheap, does nothing unless it is a payment credit and we are the owner. */
    @Synchronized
    fun onText(ctx: Context, text: String) {
        if (!Cloud.isOwner(ctx)) return
        if (!CREDIT.containsMatchIn(text)) return
        val amount = AMOUNT.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return
        val utr = UTR.find(text)?.groupValues?.get(1)
        credits.add(Credit(System.currentTimeMillis(), amount, utr))
        while (credits.size > 40) credits.removeAt(0)
        Logger.d(TAG, "credit noted")
    }

    @Synchronized fun creditSummary(): String =
        if (credits.isEmpty()) "No payment alerts seen yet on this phone"
        else credits.takeLast(6).joinToString("\n") { "₹${it.amount}${if (it.utr != null) "  UTR ${it.utr}" else ""}${if (it.used) "  ✓used" else ""}" }

    data class Pending(val uid: String, val pid: String, val email: String, val plan: String, val amount: Int, val utr: String, val at: Long)

    suspend fun pending(ctx: Context): List<Pending> {
        val r = Cloud.get(ctx, "payments")
        if (!r.ok || r.body == "null" || r.body.isBlank()) return emptyList()
        val out = ArrayList<Pending>()
        try {
            val root = JSONObject(r.body)
            for (uid in root.keys()) {
                val per = root.optJSONObject(uid) ?: continue
                for (pid in per.keys()) {
                    val o = per.optJSONObject(pid) ?: continue
                    if (o.optString("status") != "pending") continue
                    out.add(Pending(uid, pid, o.optString("email"), o.optString("plan"), o.optInt("amount"), o.optString("utr"), o.optLong("at")))
                }
            }
        } catch (e: Exception) { Logger.e(TAG, "parse: ${e.message}") }
        return out.sortedBy { it.at }
    }

    suspend fun approve(ctx: Context, p: Pending, by: String): Boolean {
        val plan = Premium.planById(p.plan) ?: return false
        val existing = Cloud.get(ctx, "premium/${p.uid}")
        var base = System.currentTimeMillis()
        try {   // renewing before expiry extends instead of overwriting
            if (existing.ok && existing.body != "null") base = maxOf(base, JSONObject(existing.body).optLong("until", 0L))
        } catch (_: Exception) {}
        val until = base + plan.days * 86400_000L
        val prem = JSONObject().put("plan", plan.id).put("until", until).put("by", by).put("at", System.currentTimeMillis())
        val a = Cloud.put(ctx, "premium/${p.uid}", prem.toString())
        if (!a.ok) return false
        Cloud.patch(ctx, "payments/${p.uid}/${p.pid}", JSONObject().put("status", "approved").put("by", by).toString())
        return true
    }

    suspend fun reject(ctx: Context, p: Pending): Boolean =
        Cloud.patch(ctx, "payments/${p.uid}/${p.pid}", JSONObject().put("status", "rejected").toString()).ok

    /** Match unused credits against pending payments. Returns how many were approved. */
    suspend fun reconcile(ctx: Context): Int {
        if (!Cloud.isOwner(ctx)) return 0
        val list = pending(ctx)
        if (list.isEmpty()) return 0
        var done = 0
        for (p in list) {
            val match: Credit? = synchronized(this) {
                val candidates = credits.filter { !it.used && it.amount + 0.001 >= p.amount }
                // 1) exact UTR match is the strongest proof
                candidates.firstOrNull { it.utr != null && it.utr == p.utr }
                    // 2) no UTR in the alert: same amount, close in time, and only ONE pending with that amount
                    ?: candidates.filter { it.utr == null && Math.abs(it.amount - p.amount) < 0.01 &&
                            it.at in (p.at - 45 * 60_000L)..(p.at + 20 * 60_000L) }
                        .takeIf { list.count { q -> q.amount == p.amount } == 1 }?.firstOrNull()
            }
            if (match != null && approve(ctx, p, "auto")) {
                synchronized(this) { match.used = true }
                done++
            }
        }
        return done
    }
}
