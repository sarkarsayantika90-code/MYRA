package com.myra.assistant.ui.main

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.prefs
import com.myra.assistant.utils.toast
import com.myra.assistant.voice.VoiceStateManager

/** Full-screen text chat with MYRA. Same conversation as the voice orb (shared ChatStore). */
class ChatActivity : AppCompatActivity() {
    private lateinit var adapter: ChatAdapter
    private lateinit var recycler: RecyclerView

    private fun dp(v: Int) = (resources.displayMetrics.density * v).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val accent = ThemeManager.accent(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = com.myra.assistant.ui.UiKit.screenBg(this@ChatActivity, accent)
            setPadding(0, dp(40), 0, 0)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val back = TextView(this).apply {
            text = "←"; textSize = 24f; setTextColor(accent); setPadding(0, 0, dp(16), 0)
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "Chat with MYRA"; textSize = 18f; setTextColor(0xFFE8E8FF.toInt())
        }
        val clear = TextView(this).apply {
            text = "Clear"; textSize = 13f; setTextColor(0xFF888899.toInt())
            setOnClickListener { ChatStore.clear() }
        }
        bar.addView(back)
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(clear)
        root.addView(bar)

        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ChatActivity).also { it.stackFromEnd = true }
            setPadding(dp(12), dp(4), dp(12), dp(4))
            clipToPadding = false
        }
        adapter = ChatAdapter()
        recycler.adapter = adapter
        root.addView(recycler, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(16))
        }
        val input = EditText(this).apply {
            hint = "Message MYRA..."
            setHintTextColor(0xFF666688.toInt())
            setTextColor(0xFFE8E8FF.toInt())
            setBackgroundResource(com.myra.assistant.R.drawable.bg_input_field)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(false)
        }
        val send = Button(this).apply {
            text = "Send"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        inputRow.addView(send, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(8) })
        root.addView(inputRow)
        setContentView(root)

        fun submit() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            val svc = ForegroundVoiceService.instance
            if (svc == null) {
                if (prefs().getString(Constants.KEY_API_KEY, "").isNullOrBlank()) toast("Add a Gemini API key in Settings", true)
                else toast("MYRA is off. Tap the orb on the home screen to turn her on.", true)
                return
            }
            svc.sendTextToGemini(t)
            input.setText("")
        }
        send.setOnClickListener { submit() }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }

        ChatStore.messages.observe(this) { list ->
            adapter.setAll(list)
            if (list.isNotEmpty()) recycler.scrollToPosition(list.size - 1)
        }
    }
}
