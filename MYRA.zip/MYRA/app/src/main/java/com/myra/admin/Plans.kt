package com.myra.admin

/** Pure premium maths (no Android) so it can be unit-tested. */
object Plans {
    /** Plans used by the app right now: the admin's own list from the database, or the built-in defaults. */
    @Volatile var current: Map<String, Int> = emptyMap()
    fun all(): Map<String, Int> = if (current.isEmpty()) DAYS else current

    /** Turns text typed in the raw-settings editor into a typed value. */
    fun parseValue(raw: String): Any {
        val t = raw.trim()
        if (t == "true") return true
        if (t == "false") return false
        t.toLongOrNull()?.let { return it }
        t.toDoubleOrNull()?.let { return it }
        if (t.startsWith("{")) try { return org.json.JSONObject(t) } catch (_: Exception) {}
        if (t.startsWith("[")) try { return org.json.JSONArray(t) } catch (_: Exception) {}
        return t
    }

    fun validKey(k: String) = k.isNotEmpty() && k.length <= 60 && k.all { it.isLetterOrDigit() || it == '_' }

    /** plan id -> days (-1 = lifetime). Same ids as the MYRA app and the web panel. */
    val DAYS: LinkedHashMap<String, Int> = linkedMapOf(
        "weekly" to 7, "fortnight" to 14, "monthly" to 30, "quarterly" to 90,
        "eightmonth" to 240, "yearly" to 365, "lifetime" to -1
    )

    private const val DAY_MS = 86_400_000L

    /** New expiry time. Adds on top of any time that is still left; lifetime stays lifetime. -1 = never expires. */
    fun until(now: Long, current: Long, days: Int): Long =
        if (days < 0 || current == -1L) -1L else maxOf(now, current) + days * DAY_MS

    fun isActive(until: Long, now: Long): Boolean = until == -1L || until > now

    fun label(until: Long, now: Long): String = when {
        until == -1L -> "Lifetime"
        until > now -> "till " + java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.ENGLISH).format(java.util.Date(until))
        until > 0 -> "expired"
        else -> ""
    }
}
