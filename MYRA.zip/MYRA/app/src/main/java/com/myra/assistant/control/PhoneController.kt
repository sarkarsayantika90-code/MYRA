package com.myra.assistant.control

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.apps.InstalledAppsManager
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.delay

/**
 * "Hands" of MYRA: everything that touches other apps or the system. All targets are found on
 * the CURRENT screen right before acting (no remembered coordinates), then the result is checked.
 */
object PhoneController {
    private const val TAG = "PHONE_CTRL"
    const val NEED_A11Y = "Accessibility MYRA-r sathe connected nai. Settings > Accessibility > MYRA ekbar off kore abar on koro."

    private val svc: AccessibilityHelperService? get() = AccessibilityHelperService.instance

    fun isReady() = svc != null

    fun currentPackage(): String? = svc?.rootInActiveWindow?.packageName?.toString()

    // ───────────────────────── tree helpers ─────────────────────────

    private fun walk(node: AccessibilityNodeInfo?, depth: Int = 0, visit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null || depth > 60) return
        visit(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1, visit)
    }

    private fun findFirst(root: AccessibilityNodeInfo?, cond: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        walk(root) { n -> if (found == null && cond(n)) found = n }
        return found
    }

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val s = svc ?: return emptyList()
        val out = ArrayList<AccessibilityNodeInfo>()
        s.rootInActiveWindow?.let { out.add(it) }
        try {
            for (w in s.windows) w.root?.let { r -> if (out.none { it == r }) out.add(r) }
        } catch (_: Exception) {}
        return out
    }

    private fun labelsOf(n: AccessibilityNodeInfo): List<String> {
        val hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString() else null
        return listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), hint)
            .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    }

    private fun clickNodeOrAncestor(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 7) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    // ───────────────────────── gestures ─────────────────────────

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val s = svc ?: return false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        return s.dispatchGesture(g, null, null)
    }

    private fun tapXY(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    /** direction = way the FINGER moves. */
    fun swipe(direction: String): Boolean {
        val s = svc ?: return false
        val dm = s.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when (direction.lowercase()) {
            "up" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "down" -> { p.moveTo(w / 2, h * 0.30f); p.lineTo(w / 2, h * 0.80f) }
            "left" -> { p.moveTo(w * 0.85f, h / 2); p.lineTo(w * 0.15f, h / 2) }
            "right" -> { p.moveTo(w * 0.15f, h / 2); p.lineTo(w * 0.85f, h / 2) }
            else -> return false
        }
        return gesture(p, 320)
    }

    // ───────────────────────── actions ─────────────────────────

    fun globalAction(key: String): String {
        val s = svc ?: return NEED_A11Y
        val action = when (key.lowercase().replace(" ", "_")) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents", "recent_apps" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications", "notification_panel" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "power_menu" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return "Screenshot Android 9+ e hoy"
            "lock", "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return "Lock Android 9+ e hoy"
            else -> return "Ei key chini na: $key"
        }
        return if (s.performGlobalAction(action)) "done: $key" else "$key kora gelo na"
    }

    fun tapText(text: String): String {
        if (svc == null) return NEED_A11Y
        val q = text.trim().lowercase()
        if (q.isEmpty()) return "Ki tap korbo bolo"

        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        for (root in allRoots()) {
            walk(root) { n ->
                if (!n.isVisibleToUser) return@walk
                var sc = 0
                for (l in labelsOf(n)) {
                    val v = when {
                        l == q -> 100
                        l.startsWith(q) -> 70
                        l.contains(q) && l.length <= q.length * 3 + 12 -> 50
                        else -> 0
                    }
                    if (v > 0) sc = maxOf(sc, v - minOf(l.length / 10, 20))
                }
                if (sc > bestScore) { bestScore = sc; best = n }
            }
        }
        val target = best ?: return "'$text' current screen e khuje pailam na"
        if (clickNodeOrAncestor(target)) return "tapped '$text'"
        val r = Rect()
        target.getBoundsInScreen(r)
        return if (tapXY(r.exactCenterX(), r.exactCenterY())) "tapped '$text'" else "'$text' tap hoilo na"
    }

    /** Tap a node whose resource id contains [fragment] (e.g. "shutter"). */
    fun tapById(fragment: String): Boolean {
        if (svc == null) return false
        for (root in allRoots()) {
            val n = findFirst(root) { it.viewIdResourceName?.lowercase()?.contains(fragment) == true && it.isVisibleToUser }
            if (n != null) {
                if (clickNodeOrAncestor(n)) return true
                val r = Rect(); n.getBoundsInScreen(r)
                if (tapXY(r.exactCenterX(), r.exactCenterY())) return true
            }
        }
        return false
    }

    /** Like [tapText] but waits for slow screens: tries up to 4 times, 600ms apart. */
    suspend fun tapTextWait(text: String): String {
        var last = ""
        repeat(4) {
            last = tapText(text)
            if (last.startsWith("tapped")) return last
            delay(600)
        }
        return last
    }

    suspend fun longPressText(text: String): String {
        val s = svc ?: return NEED_A11Y
        val q = text.trim().lowercase()
        for (root in allRoots()) {
            val n = findFirst(root) { nd -> nd.isVisibleToUser && labelsOf(nd).any { it == q || it.contains(q) } }
            if (n != null) {
                var x: AccessibilityNodeInfo? = n
                var hops = 0
                while (x != null && hops < 6) {
                    if (x.isLongClickable && x.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return "long-pressed '$text'"
                    x = x.parent; hops++
                }
                val r = Rect(); n.getBoundsInScreen(r)
                val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
                if (gesture(p, 700)) return "long-pressed '$text'"
            }
        }
        return "'$text' pailam na"
    }

    private fun scrollNode(forward: Boolean): Boolean {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        for (root in allRoots()) {
            walk(root) { n ->
                if (n.isScrollable && n.isVisibleToUser) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val area = r.width() * r.height()
                    if (area > bestArea) { bestArea = area; best = n }
                }
            }
            if (best != null) break
        }
        val node = best ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    /** "down" = see more content further down the page (like reading on). */
    suspend fun scroll(direction: String, times: Int): String {
        if (svc == null) return NEED_A11Y
        val d = direction.lowercase()
        var ok = false
        repeat(times.coerceIn(1, 10)) {
            ok = when (d) {
                "down" -> scrollNode(true) || swipe("up")
                "up" -> scrollNode(false) || swipe("down")
                "left", "right" -> swipe(d)
                else -> false
            }
            delay(380)
        }
        return if (ok) "scrolled $d" else "scroll kora gelo na"
    }

    suspend fun typeText(text: String, pressEnter: Boolean): String {
        val s = svc ?: return NEED_A11Y
        val root = s.rootInActiveWindow ?: return "Screen porte parlam na"
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null || !target.isEditable) {
            target = findFirst(root) { it.isEditable && it.isVisibleToUser }
        }
        if (target == null) return "Kono text box pailam na, age text box tap koro"
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return "Text likha gelo na"
        if (pressEnter) {
            delay(350)
            var ok = false
            if (Build.VERSION.SDK_INT >= 30) {
                ok = target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
            if (!ok) {
                val r = tapText("search")
                if (!r.startsWith("tapped")) tapText("go")
            }
        }
        return "typed ${text.length} chars" + if (pressEnter) " and pressed enter" else ""
    }

    /** Text summary of the current screen for the model. Passwords are masked. */
    fun readScreen(): String {
        val s = svc ?: return NEED_A11Y
        val root = s.rootInActiveWindow ?: return "Screen ekhon porte parchi na"
        val pkg = root.packageName?.toString() ?: "?"
        val appLabel = try {
            s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val lines = LinkedHashSet<String>()
        walk(root) { n ->
            if (!n.isVisibleToUser) return@walk
            if (n.isPassword) { lines.add("[password field - hidden]"); return@walk }
            val t = n.text?.toString()?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.trim().orEmpty()
            val label = if (t.isNotEmpty()) t else d
            when {
                label.isNotEmpty() -> {
                    val kind = when {
                        n.isEditable -> " (text box)"
                        n.isCheckable -> if (n.isChecked) " (switch ON)" else " (switch OFF)"
                        n.isClickable -> " (button)"
                        else -> ""
                    }
                    lines.add(label.take(140) + kind)
                }
                n.isEditable -> lines.add("(empty text box)")
            }
        }
        if (lines.isEmpty()) return "App: $appLabel. Screen e porar moto text nai (image/video/game hote pare)."
        return ("App: $appLabel\n" + lines.take(70).joinToString("\n") { "- $it" }).take(3500)
    }

    // ───────────────────────── launching apps ─────────────────────────

    fun startAny(context: Context, intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: Context = svc ?: context
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        Logger.e(TAG, "startActivity failed: ${e.message}")
        false
    }

    /**
     * Opens an app and CHECKS that it really came to the foreground. If Android blocks the
     * background start, falls back to a full-screen notification the user can tap.
     */
    suspend fun openApp(context: Context, name: String): String {
        val app = InstalledAppsManager.findApp(context, name) ?: return "App_not_found: '$name' naame kono app nai"
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return "${app.label} open kora jay na"
        startAny(context, intent)
        if (waitForeground(app.packageName)) return "opened ${app.label}"

        // second try after going home (helps when another app is holding focus)
        svc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        delay(500)
        startAny(context, context.packageManager.getLaunchIntentForPackage(app.packageName) ?: intent)
        if (waitForeground(app.packageName)) return "opened ${app.label}"

        notifyToOpen(context, app.label, intent)
        return if (svc == null)
            "${app.label} open command pathiyechi kintu verify korte parlam na (Accessibility off). Notification e tap koro."
        else
            "${app.label} open hoilo na, Android background open block korche. Notification e tap koro."
    }

    private suspend fun waitForeground(pkg: String): Boolean {
        if (svc == null) { delay(900); return false }
        repeat(12) {
            delay(250)
            if (currentPackage() == pkg) return true
        }
        return false
    }

    private fun notifyToOpen(context: Context, label: String, intent: Intent) {
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("myra_launch", "MYRA app launch", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                context, label.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(context, "myra_launch")
                .setSmallIcon(R.drawable.ic_myra_notif)
                .setContentTitle("Open $label")
                .setContentText("Tap to open $label")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(7001, n)
        } catch (e: Exception) {
            Logger.e(TAG, "notifyToOpen failed: ${e.message}")
        }
    }

    /** Search inside an app: direct intent where the app supports it, otherwise type into its search box. */
    suspend fun searchInApp(context: Context, app: String, query: String): String {
        if (query.isBlank()) return "Ki search korbo bolo"
        val a = app.lowercase().trim()
        val q = Uri.encode(query)

        fun view(uri: String, pkg: String?): Boolean {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            if (pkg != null && isInstalled(context, pkg)) i.setPackage(pkg)
            return startAny(context, i)
        }

        val ok = when {
            a.isEmpty() || a in listOf("google", "chrome", "web", "browser", "internet") ->
                view("https://www.google.com/search?q=$q", null)
            "youtube" in a -> view("https://www.youtube.com/results?search_query=$q", "com.google.android.youtube")
            "play" in a && "store" in a -> view("market://search?q=$q", "com.android.vending")
            "map" in a -> view("geo:0,0?q=$q", null)
            "spotify" in a -> view("spotify:search:$q", "com.spotify.music")
            else -> false
        }
        if (ok) return "searched '$query' in ${app.ifBlank { "Google" }}"

        // Generic path: open the app, then use its own search UI.
        val opened = openApp(context, app)
        if (!opened.startsWith("opened")) return opened
        delay(1200)
        var typed = typeText(query, true)
        if (typed.startsWith("Kono text box")) {
            var r = tapText("search")
            if (!r.startsWith("tapped")) r = tapText("find")
            if (!r.startsWith("tapped")) return "${app}-er search box pailam na. screen porbo?"
            delay(700)
            typed = typeText(query, true)
        }
        return typed
    }

    // ───────────────────────── calls ─────────────────────────

    fun answerCall(context: Context): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) return "Answer-call permission dao (Settings > Grant permissions)"
        return try {
            context.getSystemService(TelecomManager::class.java).acceptRingingCall()
            "call receive korlam"
        } catch (e: Exception) {
            val r = tapText("answer")
            if (r.startsWith("tapped")) "call receive korlam" else "Call receive kora gelo na"
        }
    }

    fun endCall(context: Context): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) return "Call-control permission dao (Settings > Grant permissions)"
        return try {
            if (Build.VERSION.SDK_INT >= 28 &&
                context.getSystemService(TelecomManager::class.java).endCall()) "call shesh/reject korlam"
            else {
                val r = tapText("decline").takeIf { it.startsWith("tapped") } ?: tapText("end")
                if (r.startsWith("tapped")) "call shesh/reject korlam" else "Call shesh kora gelo na"
            }
        } catch (e: Exception) {
            "Call shesh kora gelo na"
        }
    }

    // ───────────────────────── settings pages ─────────────────────────

    fun openSettings(context: Context, page: String): String {
        val action = when (page.lowercase().trim()) {
            "wifi", "wi-fi", "internet" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane", "flight" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "data", "mobile data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "notification access" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (startAny(context, Intent(action))) "opened $page settings" else "Settings open hoilo na"
    }

    private fun isInstalled(context: Context, pkg: String) = try {
        context.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }
}
