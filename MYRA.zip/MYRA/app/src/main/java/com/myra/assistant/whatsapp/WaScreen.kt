package com.myra.assistant.whatsapp

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.service.AccessibilityHelperService

/** Fresh-observation helpers for WhatsApp screens. Nothing here caches nodes between calls. */
internal object WaScreen {
    fun root(): AccessibilityNodeInfo? = AccessibilityHelperService.instance?.rootInActiveWindow
    fun pkg(): String? = root()?.packageName?.toString()

    fun walk(node: AccessibilityNodeInfo?, depth: Int = 0, visit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null || depth > 60) return
        visit(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1, visit)
    }

    fun findFirst(root: AccessibilityNodeInfo?, cond: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        walk(root) { n -> if (found == null && cond(n)) found = n }
        return found
    }

    fun findAll(root: AccessibilityNodeInfo?, cond: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walk(root) { n -> if (cond(n)) out.add(n) }
        return out
    }

    private fun idMatches(n: AccessibilityNodeInfo, suffixes: List<String>): Boolean {
        val id = n.viewIdResourceName ?: return false
        return suffixes.any { id.endsWith(it) }
    }

    fun findCompose(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? =
        findFirst(root) { idMatches(it, WhatsAppSelectors.COMPOSE_ID_SUFFIX) && it.isVisibleToUser }
            ?: findFirst(root) { it.isEditable && it.isVisibleToUser }

    fun composeText(root: AccessibilityNodeInfo?): String {
        val c = findCompose(root) ?: return ""
        // A hint-only field reports the hint as text on some builds; treat it as empty.
        if (c.text == null) return ""
        val t = c.text.toString()
        val hint = c.hintText?.toString()
        return if (hint != null && t == hint) "" else t
    }

    /** The Send control: by id, else by SHORT exact description (a long bubble mentioning "send" never matches). */
    fun findSend(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? =
        findFirst(root) { idMatches(it, WhatsAppSelectors.SEND_ID_SUFFIX) && it.isVisibleToUser }
            ?: findFirst(root) { n ->
                val d = n.contentDescription?.toString()?.trim()?.lowercase()
                n.isVisibleToUser && n.isClickable && d != null && d.length <= 12 &&
                    WhatsAppSelectors.SEND_DESCS.any { it == d }
            }

    fun chatTitle(root: AccessibilityNodeInfo?): String? =
        findFirst(root) { idMatches(it, WhatsAppSelectors.CHAT_TITLE_ID_SUFFIX) && !it.text.isNullOrBlank() }
            ?.text?.toString()

    fun signature(root: AccessibilityNodeInfo?): Int {
        if (root == null) return 0
        val sb = StringBuilder(root.packageName?.toString() ?: "")
        walk(root) { n ->
            if (n.isVisibleToUser) {
                n.text?.let { sb.append(it) }
                n.contentDescription?.let { sb.append(it) }
            }
        }
        return sb.toString().hashCode()
    }

    /** Returns a human reason if the screen needs the person (login, verification, permission, PIN...). */
    fun interstitial(root: AccessibilityNodeInfo?): String? {
        if (root == null) return null
        val p = root.packageName?.toString()
        if (p != null && p in WhatsAppSelectors.PERMISSION_PACKAGES) return "permission dialog"
        var hasPassword = false
        val sb = StringBuilder()
        walk(root) { n ->
            if (n.isPassword) hasPassword = true
            n.text?.let { sb.append(it.toString().lowercase()).append('\n') }
        }
        if (hasPassword) return "PIN / password screen"
        val all = sb.toString()
        return WhatsAppSelectors.INTERSTITIAL_MARKERS.firstOrNull { all.contains(it) }
    }

    fun tapNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var hops = 0
        while (x != null && hops < 6) {
            if (x.isClickable && x.isEnabled) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
            hops++
        }
        return false
    }

    fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Delivery state of the newest outgoing bubble whose text equals [message], or null if not visible. */
    fun bubbleStatus(root: AccessibilityNodeInfo?, message: String): String? {
        val bubbles = findAll(root) {
            idMatches(it, WhatsAppSelectors.MESSAGE_TEXT_ID_SUFFIX) && it.text?.toString()?.trim() == message.trim()
        }
        val bubble = bubbles.lastOrNull() ?: return "NO_BUBBLE"
        var scope: AccessibilityNodeInfo? = bubble
        var hops = 0
        while (scope != null && hops < 4) {
            val tick = findFirst(scope) { n ->
                val d = n.contentDescription?.toString()
                d != null && WhatsAppSelectors.TICK_REGEX.containsMatchIn(d)
            }
            if (tick != null) return tick.contentDescription.toString()
            scope = scope.parent
            hops++
        }
        return null
    }

    fun boundsCenterY(n: AccessibilityNodeInfo): Int {
        val r = Rect(); n.getBoundsInScreen(r); return r.centerY()
    }
}
