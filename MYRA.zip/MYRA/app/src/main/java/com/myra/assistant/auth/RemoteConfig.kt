package com.myra.assistant.auth

import android.content.Context
import com.myra.assistant.premium.PremiumPlans
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.prefs
import org.json.JSONObject

/**
 * Settings that live on the server (set from the admin website), so NOTHING sensitive ships inside
 * the APK: Gemini API key, model name, free minutes, maintenance switch, announcement.
 * The key is kept only in encrypted storage on the phone and is fetched after login.
 * Banned or logged-out accounts are refused by the database rules, so they get no key.
 */
object RemoteConfig {
    private const val K_TS = "rc_ts"
    const val OK = 0
    const val DENIED = 1
    const val OFFLINE = 2

    /** Blocking. Call off the main thread. */
    fun refresh(ctx: Context): Int {
        if (!Session.isLoggedIn(ctx)) return DENIED
        return try {
            val raw = FirebaseRest.dbGet(ctx, "appconfig")
            val o = if (raw == "null" || raw.isBlank()) JSONObject() else JSONObject(raw)
            Session.putSecret(ctx, "gemini", o.optString("geminiKey").trim())
            // Admin may keep several keys under secrets/gemini instead - load those too.
            if (o.optString("geminiKey").isBlank()) { try { RemoteKeys.load(ctx) } catch (_: Exception) {} }
            val m = o.optJSONObject("maintenance")
            ctx.prefs().edit()
                .putString("rc_model", o.optString("model").trim())
                .putInt("rc_free", o.optInt("freeMinutes", -1))
                .putBoolean("rc_maint", m?.optBoolean("on", false) ?: false)
                .putString("rc_maint_msg", m?.optString("message").orEmpty())
                .putString("rc_announce", o.optString("announcement").trim())
                .putBoolean("rc_denied", false)
                .putLong(K_TS, System.currentTimeMillis()).apply()
            OK
        } catch (e: FirebaseRest.FirebaseError) {
            if (e.code == "PERMISSION_DENIED") { ctx.prefs().edit().putBoolean("rc_denied", true).apply(); DENIED } else OFFLINE
        } catch (e: Exception) { OFFLINE }
    }

    fun stale(ctx: Context) = System.currentTimeMillis() - ctx.prefs().getLong(K_TS, 0L) > 10 * 60_000L
    fun denied(ctx: Context) = ctx.prefs().getBoolean("rc_denied", false)

    fun geminiKey(ctx: Context): String? = Session.getSecret(ctx, "gemini")?.takeIf { it.isNotBlank() }
    /** Server key first, then the (optional) key typed in Settings. */
    fun anyKey(ctx: Context): String? = geminiKey(ctx) ?: RemoteKeys.current()?.takeIf { it.isNotBlank() } ?: ctx.prefs().getString(Constants.KEY_API_KEY, "")?.takeIf { it.isNotBlank() }
    fun hasKey(ctx: Context) = anyKey(ctx) != null

    fun model(ctx: Context): String {
        val m = ctx.prefs().getString("rc_model", "") ?: ""
        return if (m.isBlank()) Constants.GEMINI_MODEL else if (m.startsWith("models/")) m else "models/$m"
    }

    fun freeMinutes(ctx: Context): Int = ctx.prefs().getInt("rc_free", -1).let { if (it >= 0) it else PremiumPlans.FREE_MINUTES_PER_DAY }

    /** Message to show instead of the app, or null. The admin account is never locked out. */
    fun maintenance(ctx: Context): String? {
        if (Session.isAdmin(ctx)) return null
        if (!ctx.prefs().getBoolean("rc_maint", false)) return null
        return ctx.prefs().getString("rc_maint_msg", "")?.ifBlank { "MYRA is under maintenance. Please try again soon." }
    }

    fun announcement(ctx: Context): String = ctx.prefs().getString("rc_announce", "") ?: ""
}
