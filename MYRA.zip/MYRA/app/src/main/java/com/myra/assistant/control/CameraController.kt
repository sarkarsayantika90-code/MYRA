package com.myra.assistant.control

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

/**
 * Opens the phone's own camera and presses its shutter through Accessibility, then checks the
 * gallery to see whether a new photo really appeared (when the media permission is granted).
 * Only ever runs because the person asked in that moment.
 */
object CameraController {
    private val SHUTTER_HINTS = listOf("shutter", "take photo", "take picture", "capture", "camera button", "photo")
    private val FLIP_HINTS = listOf("switch camera", "flip camera", "front camera", "selfie", "rotate camera", "camera switch")

    private fun canCount(ctx: Context): Boolean {
        val p = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun latestImageId(ctx: Context): Long {
        if (!canCount(ctx)) return -1
        return try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 1"
            )?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
        } catch (e: Exception) { -1 }
    }

    suspend fun takePhoto(ctx: Context, front: Boolean, delaySec: Int): String {
        if (!PhoneController.isReady()) return PhoneController.NEED_A11Y + " (camera shutter dabate lagbe)"
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            return "Camera permission nai (Settings > Grant permissions)"

        val before = latestImageId(ctx)
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        if (!PhoneController.startAny(ctx, intent)) return "Camera open hoilo na"
        delay(1800)

        if (front) {
            val flipped = FLIP_HINTS.any { PhoneController.tapText(it).startsWith("tapped") }
            if (!flipped) return "Camera khulechi kintu front camera switch button pailam na. Photo tulini."
            delay(900)
        }
        if (delaySec > 0) delay(delaySec.coerceAtMost(10) * 1000L)

        // 1) by resource id containing "shutter" (most camera apps), 2) by label
        var pressed = PhoneController.tapById("shutter") || PhoneController.tapById("capture")
        if (!pressed) pressed = SHUTTER_HINTS.any { PhoneController.tapText(it).startsWith("tapped") }
        if (!pressed) return "Camera khulechi kintu shutter button pailam na. 'read screen' diye dekhi?"

        delay(1500)
        val after = latestImageId(ctx)
        return when {
            before >= 0 && after > before -> "photo tola hoyeche, gallery te notun chhobi ashechhe"
            before >= 0 -> "shutter dabiyechi kintu gallery te notun chhobi dekhi ni, ekbar check koro"
            else -> "shutter dabiyechi (gallery permission nai tai verify korte parlam na)"
        }
    }
}
