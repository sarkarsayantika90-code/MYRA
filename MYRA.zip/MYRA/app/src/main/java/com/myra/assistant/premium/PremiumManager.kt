package com.myra.assistant.premium

import android.content.Context
import com.myra.assistant.auth.FirebaseConfig
import com.myra.assistant.auth.FirebaseRest
import com.myra.assistant.auth.Session
import com.myra.assistant.utils.prefs
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Premium state. The SOURCE OF TRUTH is the Realtime Database node users/{uid}/premium, which only
 * the owner (admin) account / the owner's auto-verifier may write (see FIREBASE_SETUP.md rules).
 * This client caches it. NOTE: any client-side check can be bypassed by someone who modifies the APK;
 * for hard protection, enforce in a backend. For a personal app this is the usual trade-off.
 */
object PremiumManager {
    private const val K_UNTIL = "prem_until"      // epoch ms, -1 = lifetime, 0 = none
    private const val K_PLAN = "prem_plan"
    private const val K_DAY = "free_used_day"
    private const val K_SECS = "free_used_secs"

    fun isPremium(ctx: Context): Boolean {
        if (!PremiumPlans.GATING_ENABLED) return true
        if (Session.isAdmin(ctx)) return true
        val until = ctx.prefs().getLong(K_UNTIL, 0L)
        return until == -1L || until > System.currentTimeMillis()
    }

    fun planName(ctx: Context): String {
        if (Session.isAdmin(ctx)) return "Owner"
        val id = ctx.prefs().getString(K_PLAN, "") ?: ""
        return PremiumPlans.byId(id)?.title ?: "Free"
    }

    fun expiryText(ctx: Context): String {
        val until = ctx.prefs().getLong(K_UNTIL, 0L)
        return when {
            Session.isAdmin(ctx) -> "Owner access"
            until == -1L -> "Lifetime"
            until > System.currentTimeMillis() ->
                "Valid till " + SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(until))
            else -> "Free plan"
        }
    }

    /** Blocking. Reads users/{uid}/premium and caches it. Returns true if the call worked. */
    fun refresh(ctx: Context): Boolean {
        val s = Session.get(ctx) ?: return false
        return try {
            val raw = FirebaseRest.dbGet(ctx, "users/${s.uid}/premium")
            val e = ctx.prefs().edit()
            if (raw == "null" || raw.isBlank()) { e.putLong(K_UNTIL, 0L).putString(K_PLAN, "") }
            else {
                val o = JSONObject(raw)
                e.putLong(K_UNTIL, o.optLong("until", 0L)).putString(K_PLAN, o.optString("plan", ""))
            }
            e.apply()
            true
        } catch (e: Exception) { false }
    }

    // ───────────────────────── free daily voice time ─────────────────────────

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun addUsage(ctx: Context, seconds: Int) {
        val p = ctx.prefs()
        val d = today()
        val used = if (p.getString(K_DAY, "") == d) p.getInt(K_SECS, 0) else 0
        p.edit().putString(K_DAY, d).putInt(K_SECS, used + seconds).apply()
    }

    fun usedMinutesToday(ctx: Context): Int {
        val p = ctx.prefs()
        return if (p.getString(K_DAY, "") == today()) p.getInt(K_SECS, 0) / 60 else 0
    }

    fun freeTimeLeft(ctx: Context): Boolean = isPremium(ctx) || usedMinutesToday(ctx) < com.myra.assistant.auth.RemoteConfig.freeMinutes(ctx)

    // ───────────────────────── payments ─────────────────────────

    /** UTR = 12-digit UPI reference. */
    fun validUtr(s: String) = Regex("^\\d{12}$").matches(s.trim())

    /**
     * Records "I paid" for the owner to verify. The UTR is claimed first under utrs/{utr}
     * (write-once), so the same payment can never be used by two accounts.
     */
    fun submitPayment(ctx: Context, plan: PremiumPlans.Plan, utr: String): String {
        val s = Session.get(ctx) ?: return "Age login koro"
        val u = utr.trim()
        if (!validUtr(u)) return "UTR 12 digit er number hote hobe (PhonePe te Transaction ID / UTR)"
        try {
            FirebaseRest.dbPutRaw(ctx, "utrs/$u", "\"${s.uid}\"")
        } catch (e: FirebaseRest.FirebaseError) {
            return if (e.code == "PERMISSION_DENIED") "Ei UTR age use kora hoyeche ba submit kora jay ni. Sothik UTR dao."
            else FirebaseRest.friendly(e.code)
        }
        return try {
            val id = "p" + System.currentTimeMillis()
            FirebaseRest.dbPut(ctx, "payments/${s.uid}/$id", JSONObject()
                .put("email", s.email).put("plan", plan.id).put("amount", plan.price)
                .put("utr", u).put("status", "pending").put("createdAt", System.currentTimeMillis()))
            "OK"
        } catch (e: FirebaseRest.FirebaseError) { FirebaseRest.friendly(e.code) }
    }

    data class Payment(val uid: String, val id: String, val email: String, val plan: String, val amount: Int, val utr: String, val status: String, val at: Long)

    fun myPayments(ctx: Context): List<Payment> {
        val s = Session.get(ctx) ?: return emptyList()
        return try {
            val raw = FirebaseRest.dbGet(ctx, "payments/${s.uid}")
            parsePayments(s.uid, raw)
        } catch (e: Exception) { emptyList() }
    }

    fun parsePayments(uid: String, raw: String): List<Payment> {
        if (raw == "null" || raw.isBlank()) return emptyList()
        val o = JSONObject(raw)
        val out = ArrayList<Payment>()
        for (k in o.keys()) {
            val p = o.optJSONObject(k) ?: continue
            out.add(Payment(uid, k, p.optString("email"), p.optString("plan"), p.optInt("amount"),
                p.optString("utr"), p.optString("status"), p.optLong("createdAt")))
        }
        return out.sortedByDescending { it.at }
    }

    /** ADMIN: every pending payment from every user. */
    fun allPending(ctx: Context): List<Payment> {
        val raw = FirebaseRest.dbGet(ctx, "payments")
        if (raw == "null" || raw.isBlank()) return emptyList()
        val o = JSONObject(raw)
        val out = ArrayList<Payment>()
        for (uid in o.keys()) out.addAll(parsePayments(uid, o.getJSONObject(uid).toString()).filter { it.status == "pending" })
        return out.sortedBy { it.at }
    }

    /** ADMIN: activate premium for a payment (adds to remaining time) and mark it approved. */
    fun approve(ctx: Context, p: Payment, by: String): Boolean {
        val plan = PremiumPlans.byId(p.plan) ?: return false
        return try {
            val now = System.currentTimeMillis()
            val cur = try {
                val raw = FirebaseRest.dbGet(ctx, "users/${p.uid}/premium")
                if (raw == "null") 0L else JSONObject(raw).optLong("until", 0L)
            } catch (e: Exception) { 0L }
            val until = if (plan.days < 0 || cur == -1L) -1L else maxOf(now, cur) + plan.days * 86_400_000L
            FirebaseRest.dbPut(ctx, "users/${p.uid}/premium",
                JSONObject().put("plan", plan.id).put("until", until).put("by", by).put("at", now))
            FirebaseRest.dbPatch(ctx, "payments/${p.uid}/${p.id}", JSONObject().put("status", "approved").put("by", by))
            true
        } catch (e: Exception) { false }
    }

    fun reject(ctx: Context, p: Payment): Boolean = try {
        FirebaseRest.dbPatch(ctx, "payments/${p.uid}/${p.id}", JSONObject().put("status", "rejected")); true
    } catch (e: Exception) { false }
}
