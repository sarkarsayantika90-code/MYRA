package com.myra.assistant.task

import com.myra.assistant.utils.Logger

/**
 * Runs once at app startup (call from Application.onCreate or MainActivity's
 * first launch — deliberately NOT wired into any existing file in Phase 2,
 * per the "don't integrate yet" instruction; hook-up is a later phase).
 *
 * Recovery policy (per approved Phase 1 architecture):
 *  - RUNNING / PLANNING / RETRYING tasks found at startup were interrupted
 *    mid-flight (Activity recreation, app kill, process death). They did NOT
 *    complete, so they are never silently marked COMPLETED or silently
 *    resumed with a fresh action — that would risk duplicate side effects
 *    (e.g. re-sending a message). Instead they're moved to PAUSED with the
 *    last known checkpoint intact, and it's left to the user/executor to
 *    explicitly resume.
 *  - WAITING_FOR_NETWORK tasks are left as-is; TaskScheduler's constraint-based
 *    work will pick them up when connectivity returns.
 *  - Terminal states (COMPLETED/FAILED/CANCELLED) and WAITING_FOR_USER /
 *    WAITING_FOR_PERMISSION are untouched — those are legitimate steady states.
 */
class TaskRecoveryManager(
    private val taskManager: TaskManager,
    private val repository: TaskRepository
) {
    suspend fun recoverInterruptedTasks(): List<LongTask> {
        val interrupted = repository.getInterruptedTasks()
        val recovered = mutableListOf<LongTask>()
        for (task in interrupted) {
            val checkpoint = repository.getLatestCheckpoint(task.taskId)
            Logger.w(
                TAG,
                "Recovering interrupted task ${task.taskId} (was ${task.status}); " +
                    "checkpoint=${checkpoint?.stepIndex ?: "none"}"
            )
            val updated = taskManager.transition(
                task.taskId,
                TaskStatus.PAUSED,
                message = "Recovered after restart from ${task.status}; awaiting explicit resume"
            )
            if (updated != null) recovered.add(updated)
        }
        return recovered
    }

    companion object {
        private const val TAG = "TASK_RECOVERY"
    }
}
