package com.myra.assistant.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import com.myra.assistant.utils.Logger

/**
 * Full-screen, touch-through glow window drawn over every app (needs "Draw over other apps").
 * All methods must be called on the main thread.
 */
class GlowOverlay(context: Context) {
    private val ctx = context.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: GlowView? = null

    fun canShow(): Boolean = Settings.canDrawOverlays(ctx)

    val isShowing: Boolean get() = view != null

    fun show() {
        if (view != null || !canShow()) return
        val v = GlowView(ctx)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            // never takes focus, never takes touches: the app underneath keeps working normally
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            v.alpha = 0f
            wm.addView(v, lp)
            view = v
            v.animate().alpha(1f).setDuration(350).start()
        } catch (e: Exception) {
            Logger.e("GLOW", "cannot show glow: ${e.message}")
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        v.animate().cancel()
        v.animate().alpha(0f).setDuration(300).withEndAction { remove(v) }.start()
    }

    /** Remove right now (service is being destroyed). */
    fun hideNow() {
        val v = view ?: return
        view = null
        v.animate().cancel()
        remove(v)
    }

    fun setState(state: String) { view?.setState(state) }
    fun setLevel(level: Float) { view?.setLevel(level) }

    private fun remove(v: GlowView) {
        try { wm.removeView(v) } catch (_: Exception) {}
    }
}
