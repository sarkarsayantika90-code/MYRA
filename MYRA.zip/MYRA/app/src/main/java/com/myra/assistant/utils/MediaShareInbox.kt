package com.myra.assistant.utils

import android.content.Context
import java.io.File

/**
 * A small, persisted "share inbox" MYRA keeps for media the person
 * explicitly shared TO it (via the system Share sheet -> MYRA), so that a
 * later "post this to Instagram/Facebook" voice command has something to
 * hand off. Modeled on the WhatsApp/Instagram automation safety specs this
 * app follows: the assistant never reaches into the gallery and grabs an
 * arbitrary photo for a social post without the person having explicitly
 * shared it in first — that first share (via ShareInboxReceiverActivity,
 * which shows its own confirmation dialog) is the consent step.
 *
 * Bounded to the last 5 entries, survives process death (SharedPreferences),
 * and entries whose backing file has been deleted are dropped automatically.
 */
object MediaShareInbox {
    private const val PREFS = "myra_share_inbox"
    private const val KEY_ENTRIES = "entries"
    private const val MAX_ENTRIES = 5
    const val MAX_AGE_MS = 30 * 60 * 1000L // 30 minutes, per the automation spec

    data class Entry(val filePath: String, val mimeType: String, val timestamp: Long)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Encoded as simple "path|mime|timestamp" lines — no JSON dependency needed for 5 small rows. */
    private fun encode(e: Entry) = "${e.filePath}|${e.mimeType}|${e.timestamp}"

    private fun decode(line: String): Entry? {
        val parts = line.split("|")
        if (parts.size != 3) return null
        val ts = parts[2].toLongOrNull() ?: return null
        return Entry(parts[0], parts[1], ts)
    }

    fun add(context: Context, filePath: String, mimeType: String) {
        val existing = readAll(context)
        val updated = (listOf(Entry(filePath, mimeType, System.currentTimeMillis())) + existing)
            .distinctBy { it.filePath }
            .take(MAX_ENTRIES)
        prefs(context).edit()
            .putStringSet(KEY_ENTRIES, updated.map { encode(it) }.toSet())
            .apply()
    }

    private fun readAll(context: Context): List<Entry> {
        val raw = prefs(context).getStringSet(KEY_ENTRIES, emptySet()) ?: emptySet()
        return raw.mapNotNull { decode(it) }
            .filter { File(it.filePath).exists() } // drop entries whose file is gone
            .sortedByDescending { it.timestamp }
    }

    /** The most recent shared item, only if within [MAX_AGE_MS] — mirrors the automation spec's "latest/empty" resolver rule. */
    fun latestRecent(context: Context): Entry? {
        val latest = readAll(context).firstOrNull() ?: return null
        return if (System.currentTimeMillis() - latest.timestamp <= MAX_AGE_MS) latest else null
    }
}
