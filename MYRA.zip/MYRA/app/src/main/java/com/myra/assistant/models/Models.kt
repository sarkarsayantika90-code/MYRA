package com.myra.assistant.models

data class VoiceCommand(
    val raw: String,
    val type: CommandType,
    val args: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)

enum class CommandType {
    OPEN_APP, CALL, WHATSAPP_CALL, WHATSAPP_MSG,
    SMS, YOUTUBE_PLAY, SPOTIFY_PLAY,
    FLASHLIGHT_ON, FLASHLIGHT_OFF,
    VOLUME_UP, VOLUME_DOWN,
    SCREEN_ACTION, NAVIGATE, CONVERSATION,
    // Device Tools (PDF §4) + lookup_contact (PDF §2)
    LOOKUP_CONTACT, SET_ALARM, SET_TIMER, GET_BATTERY,
    OPEN_URL, SET_CLIPBOARD, LOCK_DEVICE,
    // Notification Tools (PDF §8) + Media Tools (PDF §3)
    READ_NOTIFICATIONS, CLEAR_NOTIFICATIONS, READ_MISSED_CALLS, MEDIA_CONTROL,
    // Screen understanding + on/off control
    READ_SCREEN, STOP_MYRA,
    // Call Tools (PDF §2)
    ANSWER_CALL, END_CALL,
    // Device Tools extra (PDF §4)
    ANALYZE_STORAGE, CLEAN_STORAGE, SET_VOLUME,
    // Notification Tools extra (PDF §8) — explicit-only, never spoken unprompted
    READ_OTP,
    // Smart / Generative Tools (PDF §6) — on-device only
    SYSTEM_HEALTH,
    // Files & Photos Tools (PDF §5)
    LIST_FILES, SEARCH_FILES, DELETE_FILE, DELETE_PHOTO, ZIP_FOLDER,
    RENAME_FILE, MANAGE_FOLDER, SHARE_FILE, TAKE_PHOTO,
    // Maps & "My World" Tools (PDF §9)
    OPEN_MAP, NAVIGATE_TO, NAVIGATE_TO_PLACE, GET_LOCATION, GET_DISTANCE,
    GET_PARKING_LOCATION, SAVE_PARKING, SEARCH_NEARBY, SET_SMART_MODE,
    // Search, Browser & App-Launch Tools (PDF §11)
    SEARCH_GOOGLE, OPEN_BROWSER, BROWSER_SEARCH,
    // Communication Tools extra (PDF §1)
    OPEN_EMAIL_INBOX, COMPOSE_EMAIL, SEND_EMERGENCY_ALERT,
    // Visual Social Media Agent (Instagram/Facebook PDF) — share-intent based,
    // never auto-publishes (see DynamicDecisionEngine doc comment for scope).
    POST_INSTAGRAM, POST_FACEBOOK,
    UNKNOWN
}

data class AppModel(
    val name: String,
    val packageName: String,
    val label: String
)

data class ScreenNodeModel(
    val text: String?,
    val contentDesc: String?,
    val className: String?,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val bounds: android.graphics.Rect?,
    val viewId: String?
)

data class ActionModel(
    val type: ActionType,
    val target: String = "",
    val value: String = "",
    val x: Int = -1,
    val y: Int = -1
)

enum class ActionType {
    CLICK_TEXT, CLICK_DESC, CLICK_COORDS,
    TYPE_TEXT, SCROLL_DOWN, SCROLL_UP,
    BACK, HOME, RECENT_APPS,
    LAUNCH_APP
}

data class AIStateModel(
    val state: String = "IDLE",
    val statusMessage: String = "SYSTEM READY",
    val isConnected: Boolean = false,
    val isMicActive: Boolean = false,
    val amplitude: Float = 0f
)
