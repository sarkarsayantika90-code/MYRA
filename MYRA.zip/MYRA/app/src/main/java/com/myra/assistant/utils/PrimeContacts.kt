package com.myra.assistant.utils

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * "Prime" contacts: the people MYRA knows best. Unlimited, edited in Personalize > Prime contacts.
 * Stored on-device only. Lookup by name is fuzzy and checked BEFORE the phone's own contact list.
 */
object PrimeContacts {
    data class Contact(val name: String, val number: String)

    fun all(context: Context): List<Contact> {
        val p = context.prefs()
        val out = ArrayList<Contact>()
        try {
            val arr = JSONArray(p.getString(Constants.KEY_PRIME_LIST, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Contact(o.optString("name"), o.optString("number")))
            }
        } catch (_: Exception) {}
        // legacy single prime contact from the old Settings screen
        val ln = p.getString(Constants.KEY_PRIME_NAME, "") ?: ""
        val lnum = p.getString(Constants.KEY_PRIME_NUMBER, "") ?: ""
        if (ln.isNotBlank() && lnum.isNotBlank() && out.none { it.number == lnum }) out.add(Contact(ln, lnum))
        return out
    }

    private fun save(context: Context, list: List<Contact>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("number", it.number)) }
        context.prefs().edit().putString(Constants.KEY_PRIME_LIST, arr.toString()).apply()
    }

    fun add(context: Context, name: String, number: String) {
        if (name.isBlank() || number.isBlank()) return
        val list = all(context).filterNot { it.number == number || it.name.equals(name, true) }.toMutableList()
        list.add(Contact(name.trim(), number.trim()))
        save(context, list)
    }

    fun remove(context: Context, name: String) {
        save(context, all(context).filterNot { it.name.equals(name, true) })
        val p = context.prefs()
        if ((p.getString(Constants.KEY_PRIME_NAME, "") ?: "").equals(name, true)) {
            p.edit().remove(Constants.KEY_PRIME_NAME).remove(Constants.KEY_PRIME_NUMBER).apply()
        }
    }

    fun find(context: Context, query: String): Contact? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        val list = all(context)
        return list.firstOrNull { it.name.lowercase() == q }
            ?: list.firstOrNull { it.name.lowercase().startsWith(q) }
            ?: list.firstOrNull { it.name.lowercase().contains(q) || q.contains(it.name.lowercase()) }
    }
}
