package com.myra.assistant.task

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Update
    suspend fun update(task: TaskEntity)

    @Query("SELECT * FROM tasks WHERE taskId = :taskId")
    suspend fun getById(taskId: String): TaskEntity?

    @Query("SELECT * FROM tasks WHERE taskId = :taskId")
    fun observeById(taskId: String): Flow<TaskEntity?>

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    suspend fun getAll(): List<TaskEntity>

    /**
     * Tasks that were mid-flight when the process died — anything not in a
     * terminal or explicitly-waiting state. Used by TaskRecoveryManager on
     * startup. See Phase 2 requirement #8 (recovery after process restart).
     */
    @Query(
        "SELECT * FROM tasks WHERE status IN ('RUNNING', 'PLANNING', 'RETRYING')"
    )
    suspend fun getInterruptedTasks(): List<TaskEntity>

    @Query("DELETE FROM tasks WHERE taskId = :taskId")
    suspend fun delete(taskId: String)
}

@Dao
interface TaskEventDao {
    @Insert
    suspend fun insert(event: TaskEventEntity)

    @Query("SELECT * FROM task_events WHERE taskId = :taskId ORDER BY timestamp ASC")
    suspend fun getForTask(taskId: String): List<TaskEventEntity>

    @Query("SELECT * FROM task_events WHERE taskId = :taskId ORDER BY timestamp ASC")
    fun observeForTask(taskId: String): Flow<List<TaskEventEntity>>

    @Query("DELETE FROM task_events WHERE taskId = :taskId")
    suspend fun deleteForTask(taskId: String)
}

@Dao
interface TaskCheckpointDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(checkpoint: TaskCheckpointEntity)

    @Query("SELECT * FROM task_checkpoints WHERE taskId = :taskId ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatest(taskId: String): TaskCheckpointEntity?

    @Query("SELECT * FROM task_checkpoints WHERE taskId = :taskId ORDER BY createdAt ASC")
    suspend fun getAllForTask(taskId: String): List<TaskCheckpointEntity>

    @Query("DELETE FROM task_checkpoints WHERE taskId = :taskId")
    suspend fun deleteForTask(taskId: String)
}
