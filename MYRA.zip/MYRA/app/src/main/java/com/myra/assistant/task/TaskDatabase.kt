package com.myra.assistant.task

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Plain SQLite storage for the task system (no Room / no annotation
 * processing, so it can't be broken by kapt/Kotlin version mismatches).
 * Deliberately a separate DB file from any other MYRA storage.
 */
class TaskDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "myra_tasks.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE tasks (
                taskId TEXT PRIMARY KEY NOT NULL,
                userRequest TEXT NOT NULL,
                status TEXT NOT NULL,
                priority INTEGER NOT NULL,
                createdAt INTEGER NOT NULL,
                updatedAt INTEGER NOT NULL,
                currentStep INTEGER NOT NULL,
                totalSteps INTEGER NOT NULL,
                plan TEXT,
                checkpoint TEXT,
                progress INTEGER NOT NULL,
                requiredPermissions TEXT NOT NULL,
                pendingConfirmation TEXT,
                retryCount INTEGER NOT NULL,
                maxRetries INTEGER NOT NULL,
                parentTaskId TEXT,
                childTaskIds TEXT NOT NULL,
                result TEXT,
                error TEXT,
                lastHeartbeat INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE task_events (
                eventId TEXT PRIMARY KEY NOT NULL,
                taskId TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                eventType TEXT NOT NULL,
                stepId TEXT,
                message TEXT,
                progress INTEGER,
                metadata TEXT NOT NULL
            )"""
        )
        db.execSQL("CREATE INDEX idx_events_task ON task_events(taskId, timestamp)")
        db.execSQL(
            """CREATE TABLE task_checkpoints (
                checkpointId TEXT PRIMARY KEY NOT NULL,
                taskId TEXT NOT NULL,
                stepIndex INTEGER NOT NULL,
                stateJson TEXT NOT NULL,
                createdAt INTEGER NOT NULL
            )"""
        )
        db.execSQL("CREATE INDEX idx_checkpoints_task ON task_checkpoints(taskId, createdAt)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v1 only. Future schema changes go here.
    }

    companion object {
        @Volatile private var INSTANCE: TaskDatabase? = null

        fun getInstance(context: Context): TaskDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: TaskDatabase(context).also { INSTANCE = it }
            }
    }
}
