package com.myra.assistant.task

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Standalone database for the task system, deliberately NOT shared with any
 * other MYRA storage (see Phase 1 Memory section: task state is its own
 * concept, separate from conversation history / user memory).
 */
@Database(
    entities = [TaskEntity::class, TaskEventEntity::class, TaskCheckpointEntity::class],
    version = 1,
    exportSchema = true
)
abstract class TaskDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun taskEventDao(): TaskEventDao
    abstract fun taskCheckpointDao(): TaskCheckpointDao

    companion object {
        @Volatile private var INSTANCE: TaskDatabase? = null

        fun getInstance(context: Context): TaskDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TaskDatabase::class.java,
                    "myra_tasks.db"
                ).build().also { INSTANCE = it }
            }
    }
}
