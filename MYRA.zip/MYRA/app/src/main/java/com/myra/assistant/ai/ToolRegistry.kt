package com.myra.assistant.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * HOW TO ADD A NEW MYRA SKILL (takes one block of code, no other file to touch):
 *
 *   ToolRegistry.register(
 *       name = "my_tool",
 *       description = "What it does and WHEN the model should use it.",
 *       params = mapOf("city" to MyraTools.prop("STRING", "City name")),
 *       required = listOf("city")
 *   ) { ctx, args -> "result text MYRA will speak about" }
 *
 * Put it in ExtraTools.registerAll() (or any file called once). If the tool is risky/irreversible,
 * make it two-step like send_sms (draft -> read back -> confirm). To make it Premium-only add its
 * name to PremiumPlans.PREMIUM_TOOLS.
 */
object ToolRegistry {
    class Tool(val decl: JSONObject, val run: suspend (Context, JSONObject) -> String)

    private val tools = LinkedHashMap<String, Tool>()
    @Volatile private var ready = false

    fun register(
        name: String, description: String,
        params: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList(),
        run: suspend (Context, JSONObject) -> String
    ) {
        tools[name] = Tool(MyraTools.fn(name, description, params, required), run)
    }

    private fun ensure() {
        if (ready) return
        synchronized(this) { if (!ready) { ExtraTools.registerAll(); ready = true } }
    }

    fun declarations(): JSONArray { ensure(); return JSONArray().also { a -> tools.values.forEach { a.put(it.decl) } } }

    suspend fun run(ctx: Context, name: String, args: JSONObject): String? {
        ensure()
        return tools[name]?.run?.invoke(ctx, args)
    }
}
