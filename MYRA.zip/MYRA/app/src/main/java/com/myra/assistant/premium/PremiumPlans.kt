package com.myra.assistant.premium

/**
 * Edit prices / days here. days = -1 means lifetime.
 * GATING_ENABLED = false makes every feature free again (plans screen stays).
 */
object PremiumPlans {
    @Volatile var GATING_ENABLED = true            // admin can change these from the website (config/app)
    @Volatile var FREE_MINUTES_PER_DAY = 20

    data class Plan(val id: String, val title: String, val price: Int, val days: Int, val tag: String, val blurb: String)

    private val DEFAULTS = listOf(
        Plan("fortnight", "14 Days", 49, 14, "", "Try everything for two weeks"),
        Plan("monthly", "1 Month", 199, 30, "POPULAR", "Best for everyday use"),
        Plan("quarterly", "3 Months", 499, 90, "", "About ₹166 / month"),
        Plan("eightmonth", "8 Months", 899, 240, "BEST VALUE", "About ₹112 / month"),
        Plan("yearly", "1 Year", 2499, 365, "", "365 days of MYRA"),
        Plan("lifetime", "Lifetime", 8999, -1, "ONE TIME", "Pay once, use forever")
    )

    /** Old plan ids that may still exist in payment records / premium nodes. Not shown in the list. */
    private val LEGACY = listOf(Plan("weekly", "Weekly (old)", 29, 7, "", ""))

    @Volatile var ALL: List<Plan> = DEFAULTS

    fun byId(id: String) = ALL.firstOrNull { it.id == id } ?: LEGACY.firstOrNull { it.id == id }

    val FEATURES: List<String> get() = listOf(
        "Unlimited voice time (free: $FREE_MINUTES_PER_DAY min/day)",
        "WhatsApp read, message & calls",
        "Messages & video/audio calls in any app",
        "Camera: MYRA takes the photo for you",
        "Phone toggles, power off, calendar & more",
        "MYRA starts the chat & cares for you all day",
        "Priority for every new feature"
    )

    /** Tools that need premium (when gating is on). */
    val PREMIUM_TOOLS = setOf(
        "execute_whatsapp_task", "whatsapp_task_control", "app_message", "confirm_app_message", "app_call",
        "take_photo", "toggle_setting", "create_event", "power_off_phone"
    )
}
