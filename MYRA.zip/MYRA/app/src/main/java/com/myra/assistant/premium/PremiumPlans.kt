package com.myra.assistant.premium

/**
 * Edit prices / days here. days = -1 means lifetime.
 * GATING_ENABLED = false makes every feature free again (plans screen stays).
 */
object PremiumPlans {
    const val GATING_ENABLED = true
    const val FREE_MINUTES_PER_DAY = 20

    data class Plan(val id: String, val title: String, val price: Int, val days: Int, val tag: String, val blurb: String)

    val ALL = listOf(
        Plan("weekly", "Weekly", 29, 7, "", "Try everything for a week"),
        Plan("monthly", "Monthly", 99, 30, "POPULAR", "Best for everyday use"),
        Plan("quarterly", "3 Months", 249, 90, "SAVE 16%", "₹83 / month"),
        Plan("yearly", "Yearly", 799, 365, "BEST VALUE", "₹67 / month"),
        Plan("lifetime", "Lifetime", 1499, -1, "ONE TIME", "Pay once, use forever")
    )

    fun byId(id: String) = ALL.firstOrNull { it.id == id }

    val FEATURES = listOf(
        "Unlimited voice time (free: $FREE_MINUTES_PER_DAY min/day)",
        "WhatsApp read, message & calls",
        "Messages & video/audio calls in any app",
        "Camera: MYRA takes the photo for you",
        "Phone toggles, power off, calendar & more",
        "MYRA starts the chat & cares for you all day",
        "Priority for every new feature"
    )

    /** Tools that need premium (when gating is on). */
    val PREMIUM_TOOLS = setOf(
        "execute_whatsapp_task", "whatsapp_task_control", "app_message", "confirm_app_message", "app_call",
        "take_photo", "toggle_setting", "create_event", "power_off_phone"
    )
}
