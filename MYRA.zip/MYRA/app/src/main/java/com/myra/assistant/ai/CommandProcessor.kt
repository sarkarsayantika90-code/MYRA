package com.myra.assistant.ai

import com.myra.assistant.models.CommandType

object CommandProcessor {
    fun process(input: String): String {
        val cmd = IntentAnalyzer.analyze(input)
        return when (cmd.type) {
            CommandType.OPEN_APP -> "OPEN_APP ${cmd.args["app"] ?: ""}"
            CommandType.CALL -> "CALL ${cmd.args["name"] ?: ""}"
            CommandType.WHATSAPP_CALL -> "WHATSAPP_CALL ${cmd.args["name"] ?: ""}"
            CommandType.WHATSAPP_MSG -> "WHATSAPP_MSG ${cmd.args["name"] ?: ""} ${cmd.args["message"] ?: ""}"
            CommandType.YOUTUBE_PLAY -> "YOUTUBE_PLAY ${cmd.args["query"] ?: ""}"
            CommandType.SPOTIFY_PLAY -> "SPOTIFY_PLAY ${cmd.args["query"] ?: ""}"
            CommandType.VOLUME_UP -> "VOLUME_UP"
            CommandType.VOLUME_DOWN -> "VOLUME_DOWN"
            CommandType.FLASHLIGHT_ON -> "FLASHLIGHT_ON"
            CommandType.FLASHLIGHT_OFF -> "FLASHLIGHT_OFF"
            CommandType.SMS -> "SMS ${cmd.args["name"] ?: ""} ${cmd.args["message"] ?: ""}"
            CommandType.LOOKUP_CONTACT -> "LOOKUP_CONTACT ${cmd.args["name"] ?: ""}"
            CommandType.SET_ALARM -> "SET_ALARM ${cmd.args["hour"] ?: ""} ${cmd.args["minute"] ?: "0"} ${cmd.args["label"] ?: ""}"
            CommandType.SET_TIMER -> "SET_TIMER ${cmd.args["minutes"] ?: ""}"
            CommandType.GET_BATTERY -> "GET_BATTERY"
            CommandType.OPEN_URL -> "OPEN_URL ${cmd.args["url"] ?: ""}"
            CommandType.SET_CLIPBOARD -> "SET_CLIPBOARD ${cmd.args["text"] ?: ""}"
            CommandType.LOCK_DEVICE -> "LOCK_DEVICE"
            CommandType.READ_NOTIFICATIONS -> "READ_NOTIFICATIONS"
            CommandType.CLEAR_NOTIFICATIONS -> "CLEAR_NOTIFICATIONS"
            CommandType.READ_MISSED_CALLS -> "READ_MISSED_CALLS"
            CommandType.MEDIA_CONTROL -> "MEDIA_CONTROL ${cmd.args["action"] ?: ""}"
            else -> input
        }
    }
}
