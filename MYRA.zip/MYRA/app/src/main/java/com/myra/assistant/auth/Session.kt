package com.myra.assistant.auth

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the login on-device, encrypted when the phone allows it. */
object Session {
    private fun store(ctx: Context): SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "myra_session", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("myra_session_plain", Context.MODE_PRIVATE)
    }

    data class Info(val email: String, val uid: String, val idToken: String, val refreshToken: String, val expiresAt: Long)

    fun save(ctx: Context, i: Info) {
        store(ctx).edit().putString("email", i.email).putString("uid", i.uid).putString("idToken", i.idToken)
            .putString("refresh", i.refreshToken).putLong("exp", i.expiresAt).apply()
    }

    fun get(ctx: Context): Info? {
        val p = store(ctx)
        val uid = p.getString("uid", null) ?: return null
        val refresh = p.getString("refresh", null) ?: return null
        return Info(p.getString("email", "") ?: "", uid, p.getString("idToken", "") ?: "", refresh, p.getLong("exp", 0))
    }

    fun clear(ctx: Context) { store(ctx).edit().clear().apply() }

    fun putSecret(ctx: Context, k: String, v: String?) {
        val e = store(ctx).edit()
        if (v.isNullOrBlank()) e.remove("s_$k") else e.putString("s_$k", v)
        e.apply()
    }
    fun getSecret(ctx: Context, k: String): String? = store(ctx).getString("s_$k", null)

    fun isLoggedIn(ctx: Context) = get(ctx) != null
    fun email(ctx: Context) = get(ctx)?.email.orEmpty()
    fun isAdmin(ctx: Context) = email(ctx).equals(FirebaseConfig.ADMIN_EMAIL, ignoreCase = true)
}
