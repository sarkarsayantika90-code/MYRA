package com.myra.assistant.control

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.apps.InstalledAppsManager
import com.myra.assistant.whatsapp.ReplyWatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/**
 * Message / call a person inside ANY chat app (Messenger, Telegram, Instagram, Signal, Viber...)
 * by driving its screen the way a person would. This is best-effort: every app's screens differ,
 * so each step is re-read from the live screen and MYRA reports honestly where it got stuck.
 *
 * Messages use the same two-step safety as SMS/WhatsApp: draft -> read back -> his "yes" -> send.
 * One person, one message per confirmation.
 */
object AppAgent {
    private val mutex = Mutex()

    private class Draft(val id: String, val app: String, val pkg: String, val person: String, val text: String, val at: Long)
    @Volatile private var draft: Draft? = null

    private val SEND_LABELS = listOf("send", "send message")
    private val VIDEO_LABELS = listOf("video call", "start video call", "video chat", "video")
    private val AUDIO_LABELS = listOf("voice call", "audio call", "start voice call", "call", "phone call")

    // ───────────────────────── find the person's chat ─────────────────────────

    private suspend fun openChatWith(ctx: Context, appName: String, person: String): Pair<String, String>? {
        val app = InstalledAppsManager.findApp(ctx, appName) ?: return null.also { lastError = "'$appName' app nai" }
        val opened = PhoneController.openApp(ctx, app.label)
        if (!opened.startsWith("opened")) { lastError = opened; return null }
        delay(1400)

        // Search for the person: search icon -> type -> tap the matching result (not the text box).
        var searched = PhoneController.tapText("search").startsWith("tapped") ||
            PhoneController.tapById("search")
        if (!searched) searched = PhoneController.findFirstNode { it.isEditable && it.isVisibleToUser } != null
        delay(600)
        val typed = PhoneController.typeText(person, false)
        if (!typed.startsWith("typed")) { lastError = "Search box pailam na (${app.label})"; return null }
        delay(1300)

        var hit = false
        for (i in 0 until 3) {
            hit = PhoneController.tapText(person, skipEditable = true).startsWith("tapped")
            if (hit) break
            delay(700)
        }
        if (!hit) {
            // try just the first name
            val first = person.trim().split(" ").first()
            hit = first.length >= 2 && PhoneController.tapText(first, skipEditable = true).startsWith("tapped")
        }
        if (!hit) { lastError = "'$person' ke ${app.label}-e khuje pailam na"; return null }
        delay(1200)
        return app.label to app.packageName
    }

    @Volatile private var lastError = ""

    // ───────────────────────── messages ─────────────────────────

    suspend fun prepareMessage(ctx: Context, appName: String, person: String, message: String): String = mutex.withLock {
        if (!PhoneController.isReady()) return "accessibility_not_enabled: ${PhoneController.NEED_A11Y}"
        if (person.isBlank() || message.isBlank()) return "failed: Kake ar ki likhbo bolo"
        val chat = openChatWith(ctx, appName, person) ?: return "failed: $lastError"

        // Chat screen is open: put the text in the compose box (never press Send yet).
        val compose = PhoneController.findFirstNode { it.isEditable && it.isVisibleToUser }
            ?: return "failed: Message likhar box pailam na"
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
        }
        compose.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        if (!compose.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return "failed: Message likhte parlam na"
        delay(400)
        val send = findSend() ?: return "failed: Send button pailam na (ei app e hoyto alada)"
        if (!send.isEnabled) return "failed: Send button active na"

        val d = Draft(UUID.randomUUID().toString().take(6), chat.first, chat.second, person, message.trim(), System.currentTimeMillis())
        draft = d
        "awaiting_confirmation: ${d.app} e ${d.person}-ke message: \"${d.text}\". User ke naam ar exact message poRe shunao, 'pathabo?' jiggesh koro. Sudhu 'haan' shunle confirm_app_message koro. Ekhono pathai ni."
    }

    suspend fun confirmMessage(): String = mutex.withLock {
        val d = draft ?: return "failed: Kono draft nai"
        if (System.currentTimeMillis() - d.at > 3 * 60_000L) { draft = null; return "failed: Draft onek purono, notun kore bolo" }
        when (ReplyWatcher.await(d.at)) {
            ReplyWatcher.Result.YES -> Unit
            ReplyWatcher.Result.NO -> { draft = null; clearCompose(); return "cancelled: User na bolechhe, draft muche dilam" }
            ReplyWatcher.Result.WAITING_READBACK ->
                return "awaiting_confirmation: Age draft ta user ke poRe shunao, uttor er jonno opekkha koro, tarpor abar confirm koro."
            else -> return "awaiting_confirmation: User er spashto 'haan' shuni nai, pathai ni. Abar jiggesh koro."
        }
        if (PhoneController.currentPackage() != d.pkg) return "failed: ${d.app} screen e nai, tai pathai ni. Notun kore bolo."
        val box = PhoneController.findFirstNode { it.isEditable && it.isVisibleToUser }
        if (box?.text?.toString()?.trim() != d.text) return "failed: Compose box er message bodle geche, pathai ni."
        val send = findSend() ?: return "failed: Send button pailam na"
        draft = null
        PhoneController.clickNode(send)
        delay(1200)
        val after = PhoneController.findFirstNode { it.isEditable && it.isVisibleToUser }
        val cleared = after == null || after.text.isNullOrBlank() || after.text.toString() != d.text
        return if (cleared) "submitted_unverified: Send dabiyechi, box khali hoyeche. ${d.person}-ke geche bole mone hocche (tick dekhte pari ni)"
        else "failed: Send hoilo na"
    }

    fun cancelMessage(): String {
        draft = null
        clearCompose()
        return "cancelled: draft muche dilam, kichu pathai ni"
    }

    private fun clearCompose() {
        try {
            val box = PhoneController.findFirstNode { it.isEditable && it.isVisibleToUser } ?: return
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            }
            box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } catch (_: Exception) {}
    }

    private fun findSend(): AccessibilityNodeInfo? = PhoneController.findFirstNode { n ->
        n.isVisibleToUser && (
            (n.viewIdResourceName?.lowercase()?.contains("send") == true) ||
            (n.contentDescription?.toString()?.trim()?.lowercase()?.let { d -> d.length <= 16 && SEND_LABELS.any { it == d } } == true)
        )
    }

    // ───────────────────────── calls ─────────────────────────

    /** Opens the person's chat and taps the call icon. The person asked for exactly this call. */
    suspend fun call(ctx: Context, appName: String, person: String, video: Boolean): String = mutex.withLock {
        if (!PhoneController.isReady()) return "accessibility_not_enabled: ${PhoneController.NEED_A11Y}"
        if (person.isBlank()) return "failed: Kake call korbo?"
        val chat = openChatWith(ctx, appName, person) ?: return "failed: $lastError"
        val tapped = tapCallIcon(video)
        return if (tapped) "ok: ${chat.first} e ${person}-ke ${if (video) "video" else "voice"} call lagachhi"
        else "failed: ${chat.first}-e ${person}-er chat khulechi kintu ${if (video) "video" else "voice"} call button pailam na. Hoyto menu (⋮) er bhitor, ba ei app e call nei."
    }

    suspend fun tapCallIcon(video: Boolean): Boolean {
        val labels = if (video) VIDEO_LABELS else AUDIO_LABELS
        for (attempt in 0 until 2) {
            for (l in labels) {
                val node = PhoneController.findFirstNode { n ->
                    n.isVisibleToUser && n.contentDescription?.toString()?.trim()?.lowercase()?.let { d ->
                        d == l || (d.length <= 24 && d.contains(l) && (video || !d.contains("video")))
                    } == true
                }
                if (node != null && PhoneController.clickNode(node)) { delay(900); return true }
            }
            // Many apps hide calls under the overflow menu.
            if (attempt == 0) {
                if (!PhoneController.tapText("more options").startsWith("tapped")) PhoneController.tapText("more")
                delay(600)
            }
        }
        return false
    }
}
