package com.myra.assistant.voice

import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.util.concurrent.ConcurrentLinkedQueue

class AudioPlayer {
    private val TAG = "PLAYER"
    private val SAMPLE_RATE = Constants.SAMPLE_RATE_OUT

    @Volatile private var audioTrack: AudioTrack? = null
    /** true = play as normal media (needed for Bluetooth headphones that have NO microphone / call profile). */
    @Volatile private var mediaUsage = false
    @Volatile private var preferredOut: AudioDeviceInfo? = null
    private val queue = ConcurrentLinkedQueue<ByteArray>()
    @Volatile private var isPlaying = false
    private var playThread: Thread? = null

    @Volatile private var running = true
    var onPlaybackStarted: (() -> Unit)? = null
    var onPlaybackFinished: (() -> Unit)? = null

    init {
        initTrack()
        startPlayThread()
    }

    private fun initTrack() {
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(if (mediaUsage) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } else {
            @Suppress("DEPRECATION")
            AudioTrack(
                android.media.AudioManager.STREAM_MUSIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 4,
                AudioTrack.MODE_STREAM
            )
        }
        try { audioTrack?.setPreferredDevice(preferredOut) } catch (e: Exception) { Logger.e(TAG, "preferred device: ${e.message}") }
        audioTrack?.play()
    }

    /**
     * Where MYRA's voice should come out. [device] = Bluetooth/wired headset (null = system default),
     * [media] = true for headphones without a call profile (plain A2DP): those only receive "media" audio.
     */
    fun setRoute(device: AudioDeviceInfo?, media: Boolean) {
        val usageChanged = media != mediaUsage
        preferredOut = device
        mediaUsage = media
        if (usageChanged) {
            val old = audioTrack
            audioTrack = null
            initTrack()
            try { old?.stop() } catch (_: Exception) {}
            try { old?.release() } catch (_: Exception) {}
        } else {
            try { audioTrack?.setPreferredDevice(device) } catch (e: Exception) { Logger.e(TAG, "preferred device: ${e.message}") }
        }
    }

    private fun startPlayThread() {
        playThread = Thread {
            var wasPlaying = false
            var emptyStreakMs = 0L
            // How long the queue must stay empty before we believe MYRA has
            // actually finished speaking, rather than the network just being
            // a little slow between chunks. Too short and the mic re-opens
            // mid-sentence and hears MYRA's own voice from the speaker
            // (self-triggering); too long and turn-taking feels sluggish.
            val FINISH_DEBOUNCE_MS = 220L
            val POLL_INTERVAL_MS = 10L

            // release() interrupts this thread while it sleeps. That used to throw an uncaught
            // InterruptedException and crash the whole app every time MYRA was switched off.
            while (running && !Thread.currentThread().isInterrupted) {
                val chunk = queue.poll()
                if (chunk != null) {
                    emptyStreakMs = 0L
                    if (!wasPlaying) {
                        wasPlaying = true
                        VoiceStateManager.setSpeaking()
                        onPlaybackStarted?.invoke()
                    }
                    try {
                        audioTrack?.write(chunk, 0, chunk.size)
                    } catch (e: Exception) {
                        Logger.e(TAG, "Write error: ${e.message}")
                    }
                } else {
                    if (wasPlaying) {
                        emptyStreakMs += POLL_INTERVAL_MS
                        if (emptyStreakMs >= FINISH_DEBOUNCE_MS) {
                            wasPlaying = false
                            emptyStreakMs = 0L
                            onPlaybackFinished?.invoke()
                        }
                    }
                    try {
                        Thread.sleep(POLL_INTERVAL_MS)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }
        }.also {
            it.name = "MYRA_PlayThread"
            it.isDaemon = true
            it.start()
        }
    }

    fun playChunk(data: ByteArray) {
        if (data.isNotEmpty()) queue.offer(data)
    }

    fun clearAndStop() {
        queue.clear()
        VoiceStateManager.setListening()
    }

    /** User started talking over MYRA (barge-in): drop everything queued and flush the device buffer. */
    fun interrupt() {
        queue.clear()
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Logger.e(TAG, "interrupt error: ${e.message}")
        }
    }

    fun release() {
        running = false
        onPlaybackStarted = null
        onPlaybackFinished = null
        playThread?.interrupt()
        queue.clear()
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
    }
}
