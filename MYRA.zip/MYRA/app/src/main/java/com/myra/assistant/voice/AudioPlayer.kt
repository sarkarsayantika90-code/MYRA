package com.myra.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.util.concurrent.ConcurrentLinkedQueue

class AudioPlayer {
    private val TAG = "PLAYER"
    private val SAMPLE_RATE = Constants.SAMPLE_RATE_OUT

    private var audioTrack: AudioTrack? = null
    private val queue = ConcurrentLinkedQueue<ByteArray>()
    @Volatile private var isPlaying = false
    private var playThread: Thread? = null

    var onPlaybackStarted: (() -> Unit)? = null
    var onPlaybackFinished: (() -> Unit)? = null

    init {
        initTrack()
        startPlayThread()
    }

    private fun initTrack() {
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } else {
            @Suppress("DEPRECATION")
            AudioTrack(
                android.media.AudioManager.STREAM_MUSIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 4,
                AudioTrack.MODE_STREAM
            )
        }
        audioTrack?.play()
    }

    private fun startPlayThread() {
        playThread = Thread {
            var wasPlaying = false
            var emptyStreakMs = 0L
            // How long the queue must stay empty before we believe MYRA has
            // actually finished speaking, rather than the network just being
            // a little slow between chunks. Too short and the mic re-opens
            // mid-sentence and hears MYRA's own voice from the speaker
            // (self-triggering); too long and turn-taking feels sluggish.
            val FINISH_DEBOUNCE_MS = 220L
            val POLL_INTERVAL_MS = 10L

            while (!Thread.interrupted()) {
                val chunk = queue.poll()
                if (chunk != null) {
                    emptyStreakMs = 0L
                    if (!wasPlaying) {
                        wasPlaying = true
                        VoiceStateManager.setSpeaking()
                        onPlaybackStarted?.invoke()
                    }
                    try {
                        audioTrack?.write(chunk, 0, chunk.size)
                    } catch (e: Exception) {
                        Logger.e(TAG, "Write error: ${e.message}")
                    }
                } else {
                    if (wasPlaying) {
                        emptyStreakMs += POLL_INTERVAL_MS
                        if (emptyStreakMs >= FINISH_DEBOUNCE_MS) {
                            wasPlaying = false
                            emptyStreakMs = 0L
                            onPlaybackFinished?.invoke()
                        }
                    }
                    Thread.sleep(POLL_INTERVAL_MS)
                }
            }
        }.also {
            it.name = "MYRA_PlayThread"
            it.isDaemon = true
            it.start()
        }
    }

    fun playChunk(data: ByteArray) {
        if (data.isNotEmpty()) queue.offer(data)
    }

    fun clearAndStop() {
        queue.clear()
        VoiceStateManager.setListening()
    }

    /** User started talking over MYRA (barge-in): drop everything queued and flush the device buffer. */
    fun interrupt() {
        queue.clear()
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Logger.e(TAG, "interrupt error: ${e.message}")
        }
    }

    fun release() {
        playThread?.interrupt()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
        queue.clear()
    }
}
