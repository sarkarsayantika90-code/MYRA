package com.myra.admin

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Small programmatic UI kit (dark, red accent - same feel as MYRA). */
object Ui {
    val BG = 0xFF0A0A0F.toInt()
    val CARD = 0xFF15151E.toInt()
    val ACCENT = 0xFFFF2D3D.toInt()
    val TEXT = 0xFFEDEDF5.toInt()
    val DIM = 0xFF8A8AA0.toInt()
    val OK = 0xFF3DDC84.toInt()
    val WARN = 0xFFFFB020.toInt()
    val BAD = 0xFFFF5252.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun lp(c: Context, top: Int = 0, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(c, top) }

    fun rounded(color: Int, radiusDp: Int, c: Context, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(c, radiusDp).toFloat()
        if (stroke != 0) setStroke(dp(c, 1), stroke)
    }

    fun text(c: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun title(c: Context, s: String) = text(c, s, 20f, TEXT, true).apply { setPadding(0, dp(c, 4), 0, dp(c, 8)) }

    fun button(c: Context, label: String, filled: Boolean = false, color: Int = ACCENT, onClick: () -> Unit) = Button(c).apply {
        text = label; isAllCaps = false; textSize = 13f
        setTextColor(if (filled) Color.WHITE else color)
        background = if (filled) rounded(color, 10, c) else rounded(Color.TRANSPARENT, 10, c, color)
        minHeight = 0; minimumHeight = 0
        setPadding(dp(c, 12), dp(c, 9), dp(c, 12), dp(c, 9))
        setOnClickListener { onClick() }
    }

    fun input(c: Context, hint: String, password: Boolean = false, multiline: Boolean = false, number: Boolean = false) = EditText(c).apply {
        this.hint = hint; setHintTextColor(DIM); setTextColor(TEXT); textSize = 15f
        background = rounded(0xFF1E1E2A.toInt(), 10, c)
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        inputType = when {
            password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            number -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> InputType.TYPE_CLASS_TEXT
        }
        if (multiline) { minLines = 3; gravity = Gravity.TOP }
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 14, c)
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
    }

    fun row(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    fun chip(c: Context, s: String, color: Int) = TextView(c).apply {
        text = s; textSize = 11f; setTextColor(color); typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.TRANSPARENT, 20, c, color)
        setPadding(dp(c, 9), dp(c, 3), dp(c, 9), dp(c, 3))
    }

    fun label(c: Context, s: String) = text(c, s, 12f, DIM).apply { setPadding(dp(c, 2), dp(c, 10), 0, dp(c, 4)) }

    fun spacer(c: Context, h: Int = 8): View = View(c).apply { layoutParams = LinearLayout.LayoutParams(1, dp(c, h)) }
}
