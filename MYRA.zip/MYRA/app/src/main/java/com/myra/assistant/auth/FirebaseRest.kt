package com.myra.assistant.auth

import android.content.Context
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Firebase Auth + Realtime Database over REST. All calls are blocking: run them off the main thread. */
object FirebaseRest {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    class FirebaseError(val code: String) : Exception(code)

    fun friendly(code: String): String = friendlyBase(code) + "  [" + code.take(70) + "]"

    private fun friendlyBase(code: String): String = when {
        code.startsWith("CONFIGURATION_NOT_FOUND") -> "Firebase Authentication on kora nai (Console > Authentication > Get started)."
        code.contains("API_KEY") || code.contains("API key") || code.contains("blocked") -> "Firebase API key ei app ke block korche (key restriction check koro)."
        code.startsWith("MISSING_PASSWORD") -> "Password dao."
        code.startsWith("EMAIL_EXISTS") -> "Ei email diye age account khola hoyeche. Login koro."
        code.startsWith("INVALID_LOGIN_CREDENTIALS") || code.startsWith("INVALID_PASSWORD") || code.startsWith("EMAIL_NOT_FOUND") ->
            "Email ba password thik na. Ei email e age account na khule thakle niche 'Create account' dao."
        code.startsWith("WEAK_PASSWORD") -> "Password kom pokkhe 6 okkhor hote hobe."
        code.startsWith("INVALID_EMAIL") -> "Email ta thik moto likho."
        code.startsWith("TOO_MANY_ATTEMPTS") -> "Onek bar try hoyeche, kichukkhon por abar koro."
        code.startsWith("USER_DISABLED") -> "Ei account bondho kora ache."
        code.startsWith("OPERATION_NOT_ALLOWED") -> "Firebase e Email/Password sign-in on kora nai (FIREBASE_SETUP.md dekho)."
        code.startsWith("NETWORK") -> "Internet nai ba server e jachhe na."
        code.startsWith("PERMISSION_DENIED") -> "Permission denied (Firebase rules check koro)."
        else -> "Kichu ekta bhul hoyeche ($code)"
    }

    private fun post(url: String, body: JSONObject): JSONObject {
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(JSON)).build()
        try {
            http.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val o = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                if (!r.isSuccessful) {
                    throw FirebaseError(o.optJSONObject("error")?.optString("message").orEmpty().ifBlank { "HTTP_${r.code}" })
                }
                return o
            }
        } catch (e: FirebaseError) { throw e }
        catch (e: Exception) { throw FirebaseError("NETWORK ${e.message}") }
    }

    private fun toInfo(o: JSONObject, emailFallback: String) = Session.Info(
        email = o.optString("email", emailFallback),
        uid = o.optString("localId"),
        idToken = o.optString("idToken"),
        refreshToken = o.optString("refreshToken"),
        expiresAt = System.currentTimeMillis() + (o.optString("expiresIn", "3600").toLongOrNull() ?: 3600L) * 1000L - 60_000L
    )

    private const val AUTH = "https://identitytoolkit.googleapis.com/v1/accounts"

    fun signIn(ctx: Context, email: String, password: String): Session.Info {
        val o = post("$AUTH:signInWithPassword?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
        return toInfo(o, email).also { Session.save(ctx, it) }
    }

    fun signUp(ctx: Context, email: String, password: String): Session.Info {
        val o = post("$AUTH:signUp?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
        val info = toInfo(o, email)
        Session.save(ctx, info)
        try { sendVerifyEmail(info.idToken) } catch (_: Exception) {}
        return info
    }

    fun sendVerifyEmail(idToken: String) {
        post("$AUTH:sendOobCode?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("requestType", "VERIFY_EMAIL").put("idToken", idToken))
    }

    fun resetPassword(email: String) {
        post("$AUTH:sendOobCode?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("requestType", "PASSWORD_RESET").put("email", email))
    }

    /** Returns a valid ID token, refreshing it if needed. Null = not logged in / refresh failed. */
    fun token(ctx: Context): String? {
        val s = Session.get(ctx) ?: return null
        if (s.idToken.isNotBlank() && System.currentTimeMillis() < s.expiresAt) return s.idToken
        return try {
            val body = FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", s.refreshToken).build()
            val req = Request.Builder().url("https://securetoken.googleapis.com/v1/token?key=${FirebaseConfig.API_KEY}").post(body).build()
            http.newCall(req).execute().use { r ->
                val o = JSONObject(r.body?.string().orEmpty())
                if (!r.isSuccessful) { if (r.code == 400) Session.clear(ctx); return null }
                val id = o.optString("id_token")
                val ns = Session.Info(s.email, s.uid, id, o.optString("refresh_token", s.refreshToken),
                    System.currentTimeMillis() + (o.optString("expires_in", "3600").toLongOrNull() ?: 3600L) * 1000L - 60_000L)
                Session.save(ctx, ns)
                id
            }
        } catch (e: Exception) { null }
    }

    /** Re-issues the ID token now (needed after the user clicks the verification email link). */
    fun forceRefresh(ctx: Context): String? {
        val s = Session.get(ctx) ?: return null
        Session.save(ctx, s.copy(expiresAt = 0L))
        return token(ctx)
    }

    // ───────────────────────── Realtime Database ─────────────────────────

    private fun dbUrl(path: String, token: String) = "${FirebaseConfig.DB_URL}/$path.json?auth=$token"

    private fun dbCall(req: Request): String {
        try {
            http.newCall(req).execute().use { r ->
                val t = r.body?.string().orEmpty()
                if (!r.isSuccessful) throw FirebaseError(if (r.code == 401 || r.code == 403) "PERMISSION_DENIED" else "HTTP_${r.code}")
                return t
            }
        } catch (e: FirebaseError) { throw e }
        catch (e: Exception) { throw FirebaseError("NETWORK ${e.message}") }
    }

    fun dbGet(ctx: Context, path: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).get().build())
    }

    fun dbGetQ(ctx: Context, path: String, query: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url("${FirebaseConfig.DB_URL}/$path.json?auth=$t&$query").get().build())
    }

    /** GET with a query string, e.g. orderBy="$key"&limitToLast=10 (already URL-encoded by caller). */
    fun dbGetQ(ctx: Context, path: String, query: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t) + "&" + query).get().build())
    }

    fun dbPut(ctx: Context, path: String, value: JSONObject): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).put(value.toString().toRequestBody(JSON)).build())
    }

    fun dbPutRaw(ctx: Context, path: String, rawJson: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).put(rawJson.toRequestBody(JSON)).build())
    }

    fun dbPatch(ctx: Context, path: String, value: JSONObject): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).patch(value.toString().toRequestBody(JSON)).build())
    }
}
