package com.myra.assistant.auth

import android.content.Context
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Firebase Auth + Realtime Database over REST. All calls are blocking: run them off the main thread. */
object FirebaseRest {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    class FirebaseError(val code: String) : Exception(code)

    fun friendly(code: String): String = friendlyBase(code) + "  [" + code.take(70) + "]"

    private fun friendlyBase(code: String): String = when {
        code.startsWith("CONFIGURATION_NOT_FOUND") -> "Firebase Authentication is not enabled (Console > Authentication > Get started)."
        code.contains("API_KEY") || code.contains("API key") || code.contains("blocked") -> "The Firebase API key blocks this app (check the key restrictions)."
        code.startsWith("MISSING_PASSWORD") -> "Enter a password."
        code.startsWith("EMAIL_EXISTS") -> "An account with this email already exists. Please log in."
        code.startsWith("INVALID_LOGIN_CREDENTIALS") || code.startsWith("INVALID_PASSWORD") || code.startsWith("EMAIL_NOT_FOUND") ->
            "Wrong email or password. If you signed up with Google, use 'Continue with Google' below. If you have no account yet, tap 'Create account'."
        code.startsWith("CREDENTIAL_TOO_OLD_LOGIN_AGAIN") || code.startsWith("TOKEN_EXPIRED") || code.startsWith("NOT_LOGGED_IN") ->
            "For security, please Log out, log in again, then try again."
        code.startsWith("WEAK_PASSWORD") -> "Password must be at least 6 characters."
        code.startsWith("INVALID_EMAIL") -> "Please enter a valid email."
        code.startsWith("TOO_MANY_ATTEMPTS") -> "Too many attempts, please try again later."
        code.startsWith("USER_DISABLED") -> "This account is disabled."
        code.startsWith("OPERATION_NOT_ALLOWED") -> "This sign-in method (Email/Password or Google) is not enabled in Firebase (Console > Authentication > Sign-in method)."
        code.startsWith("INVALID_IDP_RESPONSE") || code.startsWith("INVALID_CREDENTIAL") -> "Google login did not match Firebase. Check the Web client ID and SHA-1."
        code.startsWith("NETWORK") -> "No internet, or the server is unreachable."
        code.startsWith("PERMISSION_DENIED") -> "Permission denied (check the Firebase rules)."
        else -> "Something went wrong ($code)"
    }

    private fun post(url: String, body: JSONObject): JSONObject {
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(JSON)).build()
        try {
            http.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val o = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                if (!r.isSuccessful) {
                    throw FirebaseError(o.optJSONObject("error")?.optString("message").orEmpty().ifBlank { "HTTP_${r.code}" })
                }
                return o
            }
        } catch (e: FirebaseError) { throw e }
        catch (e: Exception) { throw FirebaseError("NETWORK ${e.message}") }
    }

    private fun toInfo(o: JSONObject, emailFallback: String) = Session.Info(
        email = o.optString("email", emailFallback),
        uid = o.optString("localId"),
        idToken = o.optString("idToken"),
        refreshToken = o.optString("refreshToken"),
        expiresAt = System.currentTimeMillis() + (o.optString("expiresIn", "3600").toLongOrNull() ?: 3600L) * 1000L - 60_000L
    )

    private const val AUTH = "https://identitytoolkit.googleapis.com/v1/accounts"

    fun signIn(ctx: Context, email: String, password: String): Session.Info {
        val o = post("$AUTH:signInWithPassword?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
        return toInfo(o, email).also { Session.save(ctx, it) }
    }

    fun signUp(ctx: Context, email: String, password: String): Session.Info {
        val o = post("$AUTH:signUp?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
        val info = toInfo(o, email)
        Session.save(ctx, info)
        try { sendVerifyEmail(info.idToken) } catch (_: Exception) {}
        return info
    }

    /** Signs in (or creates the account) with a Google ID token. Returns the session and whether the account is new. */
    fun signInWithGoogle(ctx: Context, googleIdToken: String): Pair<Session.Info, Boolean> {
        val o = post("$AUTH:signInWithIdp?key=${FirebaseConfig.API_KEY}",
            JSONObject()
                .put("postBody", "id_token=$googleIdToken&providerId=google.com")
                .put("requestUri", "http://localhost")
                .put("returnIdpCredential", true)
                .put("returnSecureToken", true))
        val info = toInfo(o, "")
        Session.save(ctx, info)
        return Pair(info, o.optBoolean("isNewUser", false))
    }

    /**
     * Which sign-in methods does this email have? e.g. ["google.com"] (Google-only: NO password exists) or ["password"].
     * Empty = unknown (Firebase hides this when "email enumeration protection" is on, or the call failed).
     */
    fun signInMethods(email: String): List<String> = try {
        val o = post("$AUTH:createAuthUri?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("identifier", email).put("continueUri", "http://localhost"))
        val arr = o.optJSONArray("signinMethods") ?: o.optJSONArray("allProviders")
        if (arr == null) emptyList() else (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    } catch (e: Exception) { emptyList() }

    /**
     * Gives the CURRENT (logged-in) account an email+password, in addition to whatever it already has.
     * This is the fix for accounts that were created with "Continue with Google": they have no password,
     * so email+password login always says INVALID_LOGIN_CREDENTIALS until one is set here.
     */
    fun setPassword(ctx: Context, newPassword: String): Session.Info {
        val id = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        val o = post("$AUTH:update?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("idToken", id).put("password", newPassword).put("returnSecureToken", true))
        val old = Session.get(ctx)
        val info = toInfo(o, old?.email.orEmpty())
        // A password-only response can omit the token fields; never overwrite a good session with blanks.
        val safe = if (info.idToken.isBlank() && old != null) old else info
        Session.save(ctx, safe)
        return safe
    }

    fun sendVerifyEmail(idToken: String) {
        post("$AUTH:sendOobCode?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("requestType", "VERIFY_EMAIL").put("idToken", idToken))
    }

    fun resetPassword(email: String) {
        post("$AUTH:sendOobCode?key=${FirebaseConfig.API_KEY}",
            JSONObject().put("requestType", "PASSWORD_RESET").put("email", email))
    }

    /** Returns a valid ID token, refreshing it if needed. Null = not logged in / refresh failed. */
    fun token(ctx: Context): String? {
        val s = Session.get(ctx) ?: return null
        if (s.idToken.isNotBlank() && System.currentTimeMillis() < s.expiresAt) return s.idToken
        return try {
            val body = FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", s.refreshToken).build()
            val req = Request.Builder().url("https://securetoken.googleapis.com/v1/token?key=${FirebaseConfig.API_KEY}").post(body).build()
            http.newCall(req).execute().use { r ->
                val o = JSONObject(r.body?.string().orEmpty())
                if (!r.isSuccessful) { if (r.code == 400) Session.clear(ctx); return null }
                val id = o.optString("id_token")
                val ns = Session.Info(s.email, s.uid, id, o.optString("refresh_token", s.refreshToken),
                    System.currentTimeMillis() + (o.optString("expires_in", "3600").toLongOrNull() ?: 3600L) * 1000L - 60_000L)
                Session.save(ctx, ns)
                id
            }
        } catch (e: Exception) { null }
    }

    /** Re-issues the ID token now (needed after the user clicks the verification email link). */
    fun forceRefresh(ctx: Context): String? {
        val s = Session.get(ctx) ?: return null
        Session.save(ctx, s.copy(expiresAt = 0L))
        return token(ctx)
    }

    // ───────────────────────── Realtime Database ─────────────────────────

    private fun dbUrl(path: String, token: String) = "${FirebaseConfig.DB_URL}/$path.json?auth=$token"

    private fun dbCall(req: Request): String {
        try {
            http.newCall(req).execute().use { r ->
                val t = r.body?.string().orEmpty()
                if (!r.isSuccessful) throw FirebaseError(if (r.code == 401 || r.code == 403) "PERMISSION_DENIED" else "HTTP_${r.code}")
                return t
            }
        } catch (e: FirebaseError) { throw e }
        catch (e: Exception) { throw FirebaseError("NETWORK ${e.message}") }
    }

    fun dbGet(ctx: Context, path: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).get().build())
    }

    /** GET with a query string, e.g. orderBy="$key"&limitToLast=10 (already URL-encoded by caller). */
    fun dbGetQ(ctx: Context, path: String, query: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t) + "&" + query).get().build())
    }

    fun dbPut(ctx: Context, path: String, value: JSONObject): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).put(value.toString().toRequestBody(JSON)).build())
    }

    fun dbPutRaw(ctx: Context, path: String, rawJson: String): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).put(rawJson.toRequestBody(JSON)).build())
    }

    fun dbPatch(ctx: Context, path: String, value: JSONObject): String {
        val t = token(ctx) ?: throw FirebaseError("NOT_LOGGED_IN")
        return dbCall(Request.Builder().url(dbUrl(path, t)).patch(value.toString().toRequestBody(JSON)).build())
    }
}
