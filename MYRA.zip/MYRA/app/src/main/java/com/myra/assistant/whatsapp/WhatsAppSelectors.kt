package com.myra.assistant.whatsapp

/**
 * All WhatsApp-specific knowledge lives here (never in the generic controller or the prompt).
 * IMPORTANT: these are HYPOTHESES from common WhatsApp builds. WhatsApp changes ids between
 * versions, so verify each on the installed version (Debug: run "read_screen" on each screen) and
 * adjust here only on device evidence.
 */
object WhatsAppSelectors {
    const val PKG = "com.whatsapp"
    const val PKG_BUSINESS = "com.whatsapp.w4b"

    val SEND_ID_SUFFIX = listOf(":id/send")
    val SEND_DESCS = listOf("send", "भेजें", "পাঠান")
    val COMPOSE_ID_SUFFIX = listOf(":id/entry")
    val MESSAGE_TEXT_ID_SUFFIX = listOf(":id/message_text")
    val CHAT_TITLE_ID_SUFFIX = listOf(":id/conversation_contact_name", ":id/toolbar_title")
    val MORE_OPTIONS_DESCS = listOf("more options")
    val MUTE_LABELS = listOf("mute notifications", "mute")
    val UNMUTE_LABELS = listOf("unmute notifications", "unmute")
    val MUTE_DURATION_LABELS = listOf("always", "1 year", "8 hours")
    val CONFIRM_DIALOG_LABELS = listOf("ok")
    val SEARCH_DESCS = listOf("search")

    /** Words that mean "a human must handle this screen" (PDF section 11). */
    val INTERSTITIAL_MARKERS = listOf(
        "verify your phone number", "enter your phone number", "enter the 6-digit code", "6-digit code",
        "restore from backup", "restore your chats", "this account may be at risk", "report spam",
        "two-step verification", "enter your pin", "forgot pin", "agree and continue",
        "welcome to whatsapp", "you were logged out", "link a device"
    )
    val PERMISSION_PACKAGES = listOf("com.android.permissioncontroller", "com.google.android.permissioncontroller")

    /** Delivery ticks on an outgoing bubble. Content descriptions expected: Sent / Delivered / Read / Pending. */
    val TICK_REGEX = Regex("(?i)\\b(sent|delivered|read|pending)\\b")
}
