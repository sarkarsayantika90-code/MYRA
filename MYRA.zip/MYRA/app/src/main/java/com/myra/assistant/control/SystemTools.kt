package com.myra.assistant.control

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.utils.PrimeContacts
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Extra everyday tools: volume, brightness, quick toggles, power off, navigation, events, time. */
object SystemTools {

    fun getTime(): String =
        SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())

    fun setVolume(ctx: Context, percent: Int, stream: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val type = when (stream.lowercase()) {
            "ring", "ringtone" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
        return try {
            val max = am.getStreamMaxVolume(type)
            val v = (max * percent.coerceIn(0, 100) / 100f).toInt().coerceIn(0, max)
            am.setStreamVolume(type, v, AudioManager.FLAG_SHOW_UI)
            "volume ${percent.coerceIn(0, 100)}% kore dilam"
        } catch (e: Exception) {
            "Volume bodlano gelo na: ${e.message}"
        }
    }

    fun setBrightness(ctx: Context, percent: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
            return "Brightness bodlate 'Modify system settings' permission lagbe. Settings page khulechi, MYRA ke allow koro."
        }
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * percent.coerceIn(1, 100) / 100f).toInt())
            "brightness ${percent.coerceIn(1, 100)}% kore dilam"
        } catch (e: Exception) {
            "Brightness bodlano gelo na"
        }
    }

    /**
     * Wi-Fi, Bluetooth, Airplane mode, Do not disturb, Auto-rotate, Location, Hotspot...
     * Android does not let apps flip these directly any more, so MYRA opens the quick-settings
     * panel and taps the tile the same way a person would, then closes the panel.
     */
    suspend fun toggleQuickSetting(name: String): String {
        val svc = AccessibilityHelperService.instance ?: return PhoneController.NEED_A11Y
        val alt = when (name.lowercase().trim()) {
            "wifi", "wi-fi", "internet" -> listOf("Internet", "Wi-Fi", "Wi‑Fi", "WLAN")
            "bluetooth" -> listOf("Bluetooth")
            "airplane", "flight", "airplane mode" -> listOf("Airplane mode", "Flight mode", "Airplane")
            "dnd", "do not disturb", "silent" -> listOf("Do Not Disturb", "Do not disturb", "DND")
            "rotate", "auto rotate", "auto-rotate" -> listOf("Auto-rotate", "Auto rotate", "Rotation")
            "location", "gps" -> listOf("Location")
            "hotspot" -> listOf("Hotspot", "Mobile hotspot")
            "data", "mobile data" -> listOf("Mobile data", "Data")
            "battery saver", "power saving" -> listOf("Battery Saver", "Battery saver", "Power saving")
            "torch", "flashlight" -> listOf("Flashlight", "Torch")
            else -> listOf(name)
        }
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        delay(900)
        var result = "'$name' tile pailam na (quick settings e ei tile nai hote pare)"
        for (label in alt) {
            val r = PhoneController.tapText(label)
            if (r.startsWith("tapped")) { result = "$name toggle korlam (ekbar tap)"; break }
        }
        delay(500)
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        delay(200)
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        return result
    }

    /** Opens the power menu and taps Power off / Restart. The model must have asked the user first. */
    suspend fun powerMenu(restart: Boolean): String {
        val svc = AccessibilityHelperService.instance ?: return PhoneController.NEED_A11Y
        if (!svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)) return "Power menu open hoilo na"
        delay(1100)
        val labels = if (restart) listOf("Restart", "Reboot") else listOf("Power off", "Switch off", "Shut down", "Power Off")
        val hit = labels.any { PhoneController.tapText(it).startsWith("tapped") }
        if (!hit) return "Power menu khulechi kintu '${labels.first()}' button pailam na. Tumi nijei dabao."
        delay(900)
        // some phones ask once more
        labels.any { PhoneController.tapText(it).startsWith("tapped") }
        return "${labels.first()} korchi"
    }

    fun navigate(ctx: Context, place: String): String {
        if (place.isBlank()) return "Kothay jabe?"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(place)}"))
        i.setPackage("com.google.android.apps.maps")
        if (PhoneController.startAny(ctx, i)) return "Maps e '$place' er route khulechi"
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(place)}"))
        return if (PhoneController.startAny(ctx, web)) "'$place' map e dekhachhi" else "Map open hoilo na"
    }

    suspend fun createEvent(ctx: Context, title: String, hour: Int, minute: Int, daysFromToday: Int): String {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, daysFromToday.coerceIn(0, 365))
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); set(Calendar.MINUTE, minute.coerceIn(0, 59)); set(Calendar.SECOND, 0)
        }
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + 3600_000L)
        if (!PhoneController.startAny(ctx, i)) return "Calendar open hoilo na"
        delay(1500)
        val saved = PhoneController.isReady() && listOf("Save", "SAVE", "Done").any { PhoneController.tapText(it).startsWith("tapped") }
        return if (saved) "Event '$title' save korlam" else "Calendar khulechi, 'Save' tumi dabao (auto-save korte parlam na)"
    }

    fun addPrimeContact(ctx: Context, name: String, number: String): String {
        val digits = number.filter { it.isDigit() || it == '+' }
        if (name.isBlank() || digits.length < 6) return "Naam ar sothik number lagbe"
        PrimeContacts.add(ctx, name, digits)
        return "'$name' ke prime contact e add korlam"
    }

    fun saveNewContact(ctx: Context, name: String, number: String): String {
        val i = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.NAME, name)
            .putExtra(ContactsContract.Intents.Insert.PHONE, number)
        return if (PhoneController.startAny(ctx, i)) "Notun contact form khulechi, Save dabao" else "Contacts open hoilo na"
    }
}
