package com.myra.assistant.task

import java.util.UUID
import kotlinx.coroutines.flow.Flow

/**
 * Single entry point for creating and controlling LongTasks.
 *
 * Nothing outside this class should write task status directly — always go
 * through transition()/pause()/resume()/etc so the allowed-transition table
 * in TaskStatus is actually enforced, and so every change emits a TaskEvent.
 *
 * IMPORTANT: this class does NOT execute tasks. It has no knowledge of
 * ActionExecutor, ToolRiskPolicy, or any Android action. Phase 2 is
 * infrastructure only — a task executor (Phase 4+, or a simple local one)
 * calls into this to report progress/completion; this class never calls out
 * to perform an action itself. That keeps this class trivially unit-testable
 * and keeps the security boundary (Phase 7) entirely outside it.
 */
class TaskManager(
    private val repository: TaskRepository,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val idGenerator: () -> String = { UUID.randomUUID().toString() }
) {
    fun observeTask(taskId: String): Flow<LongTask?> = repository.observe(taskId)
    fun observeAllTasks(): Flow<List<LongTask>> = repository.observeAll()
    fun observeEvents(taskId: String): Flow<List<TaskEvent>> = repository.observeEvents(taskId)

    suspend fun getTask(taskId: String): LongTask? = repository.get(taskId)
    suspend fun listTasks(): List<LongTask> = repository.getAll()

    suspend fun createTask(
        userRequest: String,
        priority: Int = 0,
        totalSteps: Int = 0,
        requiredPermissions: List<String> = emptyList(),
        parentTaskId: String? = null
    ): LongTask {
        val now = clock()
        val task = LongTask(
            taskId = idGenerator(),
            userRequest = userRequest,
            status = TaskStatus.QUEUED,
            priority = priority,
            createdAt = now,
            updatedAt = now,
            totalSteps = totalSteps,
            requiredPermissions = requiredPermissions,
            parentTaskId = parentTaskId,
            lastHeartbeat = now
        )
        repository.save(task)
        emit(task, TaskEventType.TASK_CREATED, message = "Task created: $userRequest")
        return task
    }

    /** Central, validated status transition. Returns the updated task, or null if rejected. */
    suspend fun transition(
        taskId: String,
        to: TaskStatus,
        message: String? = null,
        mutate: (LongTask) -> LongTask = { it }
    ): LongTask? {
        val current = repository.get(taskId) ?: return null
        val allowed = TaskStatus.ALLOWED_TRANSITIONS[current.status].orEmpty()
        if (to !in allowed) {
            emit(
                current, TaskEventType.TASK_FAILED,
                message = "Rejected illegal transition ${current.status} -> $to"
            )
            return null
        }
        val updated = mutate(current).copy(
            status = to,
            updatedAt = clock(),
            lastHeartbeat = clock()
        )
        repository.save(updated)
        emit(updated, statusToEventType(to), message = message)
        return updated
    }

    suspend fun startPlanning(taskId: String, plan: String, totalSteps: Int): LongTask? {
        val t = transition(taskId, TaskStatus.PLANNING) ?: return null
        val withPlan = t.copy(plan = plan, totalSteps = totalSteps)
        repository.save(withPlan)
        emit(withPlan, TaskEventType.PLAN_CREATED, message = "Plan ready: $totalSteps step(s)")
        return withPlan
    }

    suspend fun beginRunning(taskId: String): LongTask? = transition(taskId, TaskStatus.RUNNING)

    suspend fun reportStepProgress(taskId: String, stepIndex: Int, progress: Int, message: String? = null): LongTask? {
        val current = repository.get(taskId) ?: return null
        val updated = current.copy(
            currentStep = stepIndex,
            progress = progress.coerceIn(0, 100),
            updatedAt = clock(),
            lastHeartbeat = clock()
        )
        repository.save(updated)
        emit(updated, TaskEventType.STEP_PROGRESS, stepId = stepIndex.toString(), message = message, progress = progress)
        return updated
    }

    suspend fun requireConfirmation(taskId: String, reason: String): LongTask? =
        transition(taskId, TaskStatus.WAITING_FOR_USER, message = reason) { it.copy(pendingConfirmation = reason) }

    suspend fun requirePermission(taskId: String, permission: String): LongTask? =
        transition(taskId, TaskStatus.WAITING_FOR_PERMISSION, message = "Needs permission: $permission") {
            it.copy(requiredPermissions = (it.requiredPermissions + permission).distinct())
        }

    /** Approve a pending confirmation and resume execution. */
    suspend fun approveAction(taskId: String): LongTask? =
        transition(taskId, TaskStatus.RUNNING, message = "User approved") { it.copy(pendingConfirmation = null) }

    /** Reject a pending confirmation — task does not resume, caller decides whether to fail/cancel. */
    suspend fun rejectAction(taskId: String, reason: String? = null): LongTask? =
        transition(taskId, TaskStatus.FAILED, message = reason ?: "User rejected required action") {
            it.copy(pendingConfirmation = null, error = reason ?: "User rejected required action")
        }

    suspend fun pause(taskId: String): LongTask? = transition(taskId, TaskStatus.PAUSED, message = "Paused")

    suspend fun resume(taskId: String): LongTask? = transition(taskId, TaskStatus.RUNNING, message = "Resumed")

    suspend fun cancel(taskId: String, reason: String? = null): LongTask? =
        transition(taskId, TaskStatus.CANCELLED, message = reason ?: "Cancelled")

    suspend fun waitForNetwork(taskId: String): LongTask? =
        transition(taskId, TaskStatus.WAITING_FOR_NETWORK, message = "Waiting for network")

    /**
     * Failure + retry handling. Increments retryCount; if maxRetries is
     * exceeded, marks FAILED instead of RETRYING.
     */
    suspend fun reportFailure(taskId: String, error: String): LongTask? {
        val current = repository.get(taskId) ?: return null
        val nextRetryCount = current.retryCount + 1
        return if (nextRetryCount <= current.maxRetries) {
            transition(taskId, TaskStatus.RETRYING, message = "Retry $nextRetryCount/${current.maxRetries}: $error") {
                it.copy(retryCount = nextRetryCount, error = error)
            }
        } else {
            transition(taskId, TaskStatus.FAILED, message = "Max retries exceeded: $error") {
                it.copy(error = error)
            }
        }
    }

    /**
     * Mark a task COMPLETED. `verifiedResult` must come from an actual
     * tool/action outcome, never from raw model text — enforced here by
     * simply requiring a non-blank result. Callers must not fabricate one.
     */
    suspend fun completeTask(taskId: String, verifiedResult: String): LongTask? {
        require(verifiedResult.isNotBlank()) {
            "completeTask requires a verified, non-empty result — model claims of success are not sufficient"
        }
        return transition(taskId, TaskStatus.COMPLETED, message = "Completed") {
            it.copy(result = verifiedResult, progress = 100)
        }
    }

    suspend fun saveCheckpoint(taskId: String, stepIndex: Int, stateJson: String) {
        val checkpoint = TaskCheckpoint(
            checkpointId = idGenerator(),
            taskId = taskId,
            stepIndex = stepIndex,
            stateJson = stateJson,
            createdAt = clock()
        )
        repository.saveCheckpoint(checkpoint)
        val current = repository.get(taskId)
        if (current != null) {
            repository.save(current.copy(checkpoint = stateJson, updatedAt = clock()))
        }
        emit(
            repository.get(taskId) ?: return,
            TaskEventType.CHECKPOINT_SAVED,
            stepId = stepIndex.toString()
        )
    }

    suspend fun getLatestCheckpoint(taskId: String): TaskCheckpoint? = repository.getLatestCheckpoint(taskId)

    private suspend fun emit(
        task: LongTask,
        type: TaskEventType,
        stepId: String? = null,
        message: String? = null,
        progress: Int? = task.progress
    ) {
        repository.appendEvent(
            TaskEvent(
                eventId = idGenerator(),
                taskId = task.taskId,
                timestamp = clock(),
                eventType = type,
                stepId = stepId,
                message = message,
                progress = progress
            )
        )
    }

    private fun statusToEventType(status: TaskStatus): TaskEventType = when (status) {
        TaskStatus.QUEUED -> TaskEventType.TASK_CREATED
        TaskStatus.PLANNING -> TaskEventType.PLAN_CREATED
        TaskStatus.RUNNING -> TaskEventType.STEP_STARTED
        TaskStatus.WAITING_FOR_USER -> TaskEventType.CONFIRMATION_REQUIRED
        TaskStatus.WAITING_FOR_PERMISSION -> TaskEventType.PERMISSION_REQUIRED
        TaskStatus.WAITING_FOR_NETWORK -> TaskEventType.WAITING
        TaskStatus.PAUSED -> TaskEventType.TASK_PAUSED
        TaskStatus.RETRYING -> TaskEventType.RETRYING
        TaskStatus.COMPLETED -> TaskEventType.TASK_COMPLETED
        TaskStatus.FAILED -> TaskEventType.TASK_FAILED
        TaskStatus.CANCELLED -> TaskEventType.TASK_CANCELLED
    }
}
