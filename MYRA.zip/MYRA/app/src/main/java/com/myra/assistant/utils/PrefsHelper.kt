package com.myra.assistant.utils

import android.content.Context

/** Small typed accessors for the newer settings. */
object PrefsHelper {
    const val KEY_NOISE = "noise_level"
    const val KEY_BEDTIME_HOUR = "bedtime_hour"
    const val KEY_NIGHT_OFF_UNTIL = "night_off_until"
    const val KEY_NIGHT_NAG_DAY = "night_nag_day"

    /** 0 off, 1 normal (default), 2 strong */
    fun noiseLevel(ctx: Context): Int = ctx.prefs().getInt(KEY_NOISE, 1).coerceIn(0, 2)
    fun setNoiseLevel(ctx: Context, v: Int) = ctx.prefs().edit().putInt(KEY_NOISE, v.coerceIn(0, 2)).apply()

    /** Hour (0-23) after which MYRA tells him to sleep. Default 0 = midnight. */
    fun bedtimeHour(ctx: Context): Int = ctx.prefs().getInt(KEY_BEDTIME_HOUR, 0).coerceIn(0, 5)
}
