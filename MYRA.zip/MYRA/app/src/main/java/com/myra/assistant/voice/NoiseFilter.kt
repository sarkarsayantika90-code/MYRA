package com.myra.assistant.voice

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Software background-noise reducer for the mic stream (on top of the phone's own noise
 * suppressor). It (1) cuts low rumble below ~80Hz and (2) quietens steady background hiss/hum
 * BETWEEN words with a gentle, smoothed gate that opens instantly when you speak and stays open
 * for a short tail so word endings are never clipped.
 * It cannot remove other people talking or a TV - that sounds like speech.
 * level: 0 = off, 1 = normal, 2 = strong.
 */
class NoiseFilter(private val level: Int) {
    private var prevIn = 0f
    private var prevOut = 0f
    private var floor = 0.01f          // learned background level (0..1)
    private var gain = 1f
    private var hang = 0

    fun process(pcm: ByteArray): ByteArray {
        if (level <= 0 || pcm.size < 4) return pcm
        val n = pcm.size / 2
        val x = FloatArray(n)
        for (i in 0 until n) {
            val lo = pcm[2 * i].toInt() and 0xFF
            val hi = pcm[2 * i + 1].toInt()
            x[i] = ((hi shl 8) or lo).toShort() / 32768f
        }
        // 1) high-pass
        var sum = 0f
        for (i in 0 until n) {
            val y = 0.97f * (prevOut + x[i] - prevIn)
            prevIn = x[i]; prevOut = y
            x[i] = y
            sum += y * y
        }
        val rms = sqrt(sum / n)

        // 2) learn the noise floor: drops fast, rises very slowly (so speech never raises it much)
        floor = if (rms < floor) floor * 0.6f + rms * 0.4f else floor + (rms - floor) * 0.004f
        if (floor < 0.0015f) floor = 0.0015f

        val ratio = if (level >= 2) 3.2f else 2.2f
        val quietGain = if (level >= 2) 0.08f else 0.28f
        val speech = rms > floor * ratio && rms > 0.006f
        if (speech) hang = 9 else if (hang > 0) hang--
        val target = if (speech || hang > 0) 1f else quietGain

        // 3) smooth gain across the chunk (no clicks)
        val step = (target - gain) / n
        val out = ByteArray(pcm.size)
        var g = gain
        for (i in 0 until n) {
            g += step
            var v = (x[i] * g * 32768f).toInt()
            if (v > 32767) v = 32767 else if (v < -32768) v = -32768
            out[2 * i] = (v and 0xFF).toByte()
            out[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        gain = target
        return out
    }
}
