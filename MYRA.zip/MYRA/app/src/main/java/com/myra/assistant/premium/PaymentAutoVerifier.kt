package com.myra.assistant.premium

import android.content.Context
import com.myra.assistant.auth.Session
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * AUTO-VERIFY (runs only on the OWNER's phone, signed in as the admin account).
 *
 * A personal UPI QR has no server callback, so the only independent proof of payment is the
 * owner's own phone: the bank/PhonePe "credited" notification. MYRA's notification listener feeds
 * every such notification here (amount + 12-digit UPI ref, kept in memory only, never logged).
 * Every 30s the owner's phone checks pending payments and approves one ONLY when a credit with the
 * SAME 12-digit UTR and an amount >= the plan price was received. Anything else stays pending for
 * manual approval in Settings > Premium admin.
 * Limits: the owner's phone must be on, online and have MYRA's notification access; if the bank
 * notification hides the UTR the payment is approved manually.
 */
object PaymentAutoVerifier {
    data class Credit(val amount: Double, val refs: Set<String>, val at: Long)

    private val credits = ArrayList<Credit>()
    private var job: Job? = null

    private val CREDIT_WORDS = Regex("(?i)(credited|received|deposit|paid you|sent you|payment from|money received)")
    private val DEBIT_WORDS = Regex("(?i)(debited|you paid|paid to|sent to|withdrawn)")
    private val AMOUNT = Regex("(?i)(?:₹|rs\\.?|inr)\\s?([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
    private val REF = Regex("(?<!\\d)\\d{12}(?!\\d)")

    /** Pure function (unit-tested). Returns null when the text is not an incoming-money message. */
    fun parseCredit(text: String, now: Long = System.currentTimeMillis()): Credit? {
        if (!CREDIT_WORDS.containsMatchIn(text)) return null
        if (DEBIT_WORDS.containsMatchIn(text) && !Regex("(?i)credited").containsMatchIn(text)) return null
        val amount = AMOUNT.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        val refs = REF.findAll(text).map { it.value }.toSet()
        return Credit(amount, refs, now)
    }

    /** True when some credit matches this payment's UTR and covers the price. */
    fun matches(list: List<Credit>, utr: String, price: Int): Boolean =
        list.any { utr in it.refs && it.amount + 0.001 >= price }

    @Synchronized fun onNotificationText(text: String) {
        if (text.length < 10) return
        val c = parseCredit(text) ?: return
        credits.add(c)
        val cutoff = System.currentTimeMillis() - 3 * 86_400_000L
        credits.removeAll { it.at < cutoff }
        while (credits.size > 300) credits.removeAt(0)
    }

    @Synchronized private fun snapshot(): List<Credit> = credits.toList()

    fun start(ctx: Context) {
        if (job?.isActive == true) return
        val app = ctx.applicationContext
        job = CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            while (true) {
                delay(30_000)
                try {
                    if (!Session.isAdmin(app)) continue
                    val have = snapshot()
                    if (have.isEmpty()) continue
                    for (p in PremiumManager.allPending(app)) {
                        val plan = PremiumPlans.byId(p.plan) ?: continue
                        if (matches(have, p.utr, plan.price)) {
                            if (PremiumManager.approve(app, p, "auto")) Logger.d("PAY_AUTO", "approved 1 payment")
                        }
                    }
                } catch (e: Exception) { Logger.e("PAY_AUTO", "loop: ${e.message}") }
            }
        }
    }
}
