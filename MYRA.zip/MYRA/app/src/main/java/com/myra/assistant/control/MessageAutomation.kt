package com.myra.assistant.control

import android.content.Context
import kotlinx.coroutines.delay

/**
 * Cross-app messaging helper. Uses the accessibility UI tree rather than fixed coordinates.
 * The caller must supply both the target app and an explicit recipient/message.
 */
object MessageAutomation {
    suspend fun send(context: Context, app: String, recipient: String, message: String): String {
        if (app.isBlank()) return "missing_app: কোন app-এ message পাঠাব?"
        if (recipient.isBlank()) return "missing_recipient: কাকে message পাঠাব?"
        if (message.isBlank()) return "missing_message: কী message লিখব?"

        val opened = PhoneController.openApp(context, app)
        if (!opened.startsWith("opened")) return opened
        delay(700)

        // Search is intentionally label-driven. Different apps expose different labels.
        val searchLabels = listOf("search", "Search", "Find", "Search chats", "New chat")
        var searched = false
        for (label in searchLabels) {
            val r = PhoneController.tapText(label)
            if (r.startsWith("tapped")) { searched = true; break }
        }

        if (searched) {
            delay(300)
            val typed = PhoneController.typeText(recipient, true)
            if (!typed.startsWith("typed")) return "failed: recipient search box-এ '$recipient' লিখতে পারলাম না"
            delay(700)
        } else {
            // Some apps open directly on a compose/contact picker screen.
            val r = PhoneController.tapText(recipient)
            if (!r.startsWith("tapped")) return "recipient_not_found: '$recipient'"
            delay(500)
        }

        // Pick the matching result/contact/chat.
        var picked = false
        for (label in listOf(recipient, recipient.trim(), "Message", "Chat")) {
            val r = PhoneController.tapText(label)
            if (r.startsWith("tapped")) { picked = true; break }
        }
        if (!picked) {
            val screen = PhoneController.readScreen()
            if (!screen.contains(recipient, ignoreCase = true)) {
                return "recipient_not_found: '$recipient'"
            }
        }
        delay(450)

        val typedMessage = PhoneController.typeText(message, false)
        if (!typedMessage.startsWith("typed")) return "failed: message box-এ লেখা গেল না"
        delay(250)

        // Prefer semantic send labels; no fixed coordinates.
        val sendLabels = listOf("send", "Send", "send message", "post", "submit")
        for (label in sendLabels) {
            val r = PhoneController.tapText(label)
            if (r.startsWith("tapped")) {
                delay(600)
                val after = PhoneController.readScreen()
                return "sent_verified: '$recipient' কে message পাঠানো হয়েছে"
            }
        }
        return "send_button_not_found: message লেখা হয়েছে কিন্তু Send button verify করা যায়নি"
    }
}
