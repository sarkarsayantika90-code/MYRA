package com.myra.assistant.ui.settings

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.main.ThemeManager
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.PrimeContacts
import com.myra.assistant.utils.prefs
import com.myra.assistant.utils.toast

/**
 * Personalize: theme colour, home background picture, MYRA's voice, and Prime contacts
 * (as many as you like). Everything saves immediately. Built in code on purpose.
 */
class PersonalizeActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var contactsBox: LinearLayout
    private lateinit var bgStatus: TextView
    private var voiceChanged = false

    private val VOICES = listOf(
        "Leda - young & cute" to "Leda",
        "Aoede - light & breezy" to "Aoede",
        "Zephyr - bright & happy" to "Zephyr",
        "Sulafat - warm & soft" to "Sulafat",
        "Autonoe - bright" to "Autonoe",
        "Callirrhoe - easy going" to "Callirrhoe",
        "Despina - smooth" to "Despina",
        "Kore - firm" to "Kore"
    )

    private fun dp(v: Int) = (resources.displayMetrics.density * v).toInt()

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (ThemeManager.saveBackground(this, uri)) toast("Background set ✅") else toast("Chhobi load hoilo na", true)
            refreshBgStatus()
        }
    }

    private val pickContact = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data ?: return@registerForActivityResult
        contentResolver.query(
            uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            if (c.moveToFirst()) {
                PrimeContacts.add(this, c.getString(0) ?: "", (c.getString(1) ?: "").replace(" ", ""))
                renderContacts()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF040408.toInt()) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(48), dp(18), dp(40))
        }
        scroll.addView(content)
        setContentView(scroll)

        val accent = ThemeManager.accent(this)
        content.addView(text("Personalize", 26f, accent, bold = true))
        content.addView(text("Make MYRA feel like yours", 12f, 0xFF888899.toInt()))

        // ── Theme colour
        content.addView(header("Theme colour"))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipViews = ArrayList<Pair<View, Int>>()
        fun paintChips() {
            val cur = ThemeManager.accent(this)
            chipViews.forEach { (v, color) ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                    if (color == cur) setStroke(dp(3), Color.WHITE)
                }
            }
        }
        ThemeManager.PRESETS.forEach { (_, color) ->
            val v = View(this)
            chipViews.add(v to color)
            v.setOnClickListener { ThemeManager.setAccent(this, color); paintChips(); toast("Colour set ✅") }
            chips.addView(v, LinearLayout.LayoutParams(dp(36), dp(36)).also { it.rightMargin = dp(10) })
        }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        content.addView(chipScroll)
        paintChips()

        // ── Background picture
        content.addView(header("Home background picture"))
        bgStatus = text("", 12f, 0xFF888899.toInt())
        content.addView(bgStatus)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Choose picture", accent) { pickImage.launch("image/*") })
        row.addView(button("Remove", 0xFF33334A.toInt()) {
            ThemeManager.clearBackground(this); refreshBgStatus(); toast("Background removed")
        })
        content.addView(row)
        content.addView(text("Picture darkness", 12f, 0xFFB0B0C8.toInt()))
        val dim = SeekBar(this).apply {
            max = 80
            progress = ThemeManager.dim(this@PersonalizeActivity)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) ThemeManager.setDim(this@PersonalizeActivity, p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(dim)
        refreshBgStatus()

        // ── Voice
        content.addView(header("MYRA's voice"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, VOICES.map { it.first })
        val cur = prefs().getString(Constants.KEY_VOICE_NAME, Constants.GEMINI_VOICE)
        spinner.setSelection(VOICES.indexOfFirst { it.second == cur }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                prefs().edit().putString(Constants.KEY_VOICE_NAME, VOICES[pos].second).apply()
                voiceChanged = true
                toast("Voice changed ✅")
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        content.addView(spinner)

        val barge = Switch(this).apply {
            text = "Let me interrupt MYRA while she talks"
            setTextColor(0xFFE8E8FF.toInt())
            isChecked = prefs().getBoolean(Constants.KEY_BARGE_IN, true)
            setOnCheckedChangeListener { _, c ->
                prefs().edit().putBoolean(Constants.KEY_BARGE_IN, c).apply()
                toast("Restart MYRA (tap orb twice) to apply")
            }
            setPadding(0, dp(12), 0, 0)
        }
        content.addView(barge)
        content.addView(text("Turn this OFF only if MYRA hears her own voice from the speaker (no headphones).", 11f, 0xFF666688.toInt()))

        // ── Noise & bedtime
        content.addView(header("Background noise"))
        val noise = Spinner(this)
        val levels = listOf("Off", "Normal (recommended)", "Strong - noisy places")
        noise.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levels)
        noise.setSelection(com.myra.assistant.utils.PrefsHelper.noiseLevel(this))
        noise.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                com.myra.assistant.utils.PrefsHelper.setNoiseLevel(this@PersonalizeActivity, pos)
                toast("Applies next time MYRA turns on (tap orb twice)")
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        content.addView(noise)
        content.addView(text("Quietens steady background hiss/hum. It cannot remove other people talking or a TV.", 11f, 0xFF666688.toInt()))

        content.addView(header("Bedtime"))
        val bedLabel = text("", 12f, 0xFFB0B0C8.toInt())
        val bed = SeekBar(this).apply {
            max = 5
            progress = com.myra.assistant.utils.PrefsHelper.bedtimeHour(this@PersonalizeActivity)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    bedLabel.text = "After ${if (p == 0) 12 else p} AM, MYRA tells you to sleep and switches herself off"
                    if (fromUser) prefs().edit().putInt(com.myra.assistant.utils.PrefsHelper.KEY_BEDTIME_HOUR, p).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        bedLabel.text = "After ${if (bed.progress == 0) 12 else bed.progress} AM, MYRA tells you to sleep and switches herself off"
        content.addView(bedLabel)
        content.addView(bed)

        // ── Talks first
        content.addView(header("MYRA talks to you"))
        val chat = Switch(this).apply {
            text = "Talk to me sweetly when I am quiet"
            setTextColor(0xFFE8E8FF.toInt())
            isChecked = prefs().getBoolean(Constants.KEY_PROACTIVE, true)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean(Constants.KEY_PROACTIVE, c).apply() }
        }
        content.addView(chat)
        val minsLabel = text("", 12f, 0xFFB0B0C8.toInt())
        val mins = SeekBar(this).apply {
            max = 28                      // 2..30 minutes
            progress = (prefs().getInt(Constants.KEY_PROACTIVE_MIN, 6) - 2).coerceIn(0, 28)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    minsLabel.text = "After ${p + 2} quiet minutes"
                    if (fromUser) prefs().edit().putInt(Constants.KEY_PROACTIVE_MIN, p + 2).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        minsLabel.text = "After ${mins.progress + 2} quiet minutes"
        content.addView(minsLabel)
        content.addView(mins)
        content.addView(text("She stays quiet 11pm-7am, during calls and when the screen is off, and stops after 3 unanswered tries.", 11f, 0xFF666688.toInt()))

        // ── Prime contacts
        content.addView(header("Prime contacts"))
        content.addView(text("People MYRA knows first. Say \"Mummy ko call karo\" and she calls. Add as many as you want.", 12f, 0xFF888899.toInt()))
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addRow.addView(button("＋ From phone", accent) {
            pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
        })
        addRow.addView(button("＋ Type number", 0xFF33334A.toInt()) { addManual() })
        content.addView(addRow)
        contactsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(contactsBox)
        renderContacts()
    }

    private fun refreshBgStatus() {
        bgStatus.text = if (ThemeManager.hasBackground(this)) "Custom picture is set" else "No picture (default dark)"
    }

    private fun renderContacts() {
        contactsBox.removeAllViews()
        val list = PrimeContacts.all(this)
        if (list.isEmpty()) {
            contactsBox.addView(text("No prime contacts yet", 13f, 0xFF666688.toInt()))
            return
        }
        list.forEach { c ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val t = TextView(this).apply {
                text = "${c.name}\n${c.number}"
                setTextColor(0xFFE8E8FF.toInt())
                textSize = 14f
            }
            val del = TextView(this).apply {
                text = "✕"; textSize = 18f; setTextColor(0xFFFF6D6D.toInt()); setPadding(dp(16), dp(4), dp(4), dp(4))
                setOnClickListener { PrimeContacts.remove(this@PersonalizeActivity, c.name); renderContacts() }
            }
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(del)
            contactsBox.addView(r)
        }
    }

    private fun addManual() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Name (e.g. Mummy)" }
        val num = EditText(this).apply { hint = "Number"; inputType = android.text.InputType.TYPE_CLASS_PHONE }
        box.addView(name); box.addView(num)
        AlertDialog.Builder(this)
            .setTitle("Add prime contact")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                PrimeContacts.add(this, name.text.toString(), num.text.toString().replace(" ", ""))
                renderContacts()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        setPadding(0, dp(2), 0, dp(2))
    }

    private fun header(t: String) = TextView(this).apply {
        text = t.uppercase(); textSize = 12f; letterSpacing = 0.15f
        setTextColor(ThemeManager.accent(this@PersonalizeActivity))
        setPadding(0, dp(26), 0, dp(8))
    }

    private fun button(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundColor(color); isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .also { it.rightMargin = dp(8) }
    }

    override fun onPause() {
        super.onPause()
        if (voiceChanged) {
            ForegroundVoiceService.instance?.reconnectGemini()
            voiceChanged = false
        }
    }
}
