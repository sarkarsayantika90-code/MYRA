package com.myra.assistant.ai

import com.myra.assistant.models.CommandType
import com.myra.assistant.models.VoiceCommand

object IntentAnalyzer {

    private val OPEN_PATTERNS = listOf("open", "kholo", "khol", "launch", "start", "chalo", "chala")
    private val CALL_PATTERNS = listOf("call", "phone", "ring", "dial")
    private val WHATSAPP_CALL = listOf("whatsapp call", "video call")
    private val MSG_PATTERNS = listOf("message", "msg", "send", "bhejo", "likho")
    private val YOUTUBE_PATTERNS = listOf("youtube", "video play", "play on youtube")
    private val SPOTIFY_PATTERNS = listOf("spotify", "play music", "gaana", "song")
    private val VOLUME_UP = listOf("volume up", "louder", "badhao", "tez karo")
    private val VOLUME_DOWN = listOf("volume down", "lower", "kam karo", "dhima karo")
    private val FLASHLIGHT_ON = listOf("flashlight on", "torch on", "light on")
    private val FLASHLIGHT_OFF = listOf("flashlight off", "torch off", "light off")
    private val LOCK_PATTERNS = listOf("lock kar do", "lock the phone", "lock phone", "phone band kar do", "lock kardo")
    private val BATTERY_PATTERNS = listOf("battery kitni", "battery kya", "battery status", "how much battery", "battery percentage")
    private val NOTIF_READ_PATTERNS = listOf("notifications padho", "notification padho", "read notifications", "notifications batao")
    private val NOTIF_CLEAR_PATTERNS = listOf("notifications clear", "clear notifications", "notification hata")
    private val MISSED_CALL_PATTERNS = listOf("missed calls", "missed call batao", "chuti hui call")
    private val MEDIA_NEXT = listOf("agla gaana", "next song", "next track", "skip song")
    private val MEDIA_PREV = listOf("pichla gaana", "previous song", "last song")
    private val MEDIA_PAUSE = listOf("gaana pause", "pause karo", "music pause", "rok do gaana")
    private val READ_SCREEN_PATTERNS = listOf(
        "screen e ki ache", "screen e ki", "screen dekho", "screen porho", "screen padho",
        "what's on my screen", "what is on my screen", "read my screen", "read the screen",
        "screen ta bolo", "ei screen"
    )
    private val STOP_PATTERNS = listOf(
        "myra bondho", "myra bondho koro", "myra off", "band ho jao", "bondho hoye jao",
        "stop myra", "turn off myra", "myra ke off kar do", "chup ho jao", "myra k off koro"
    )

    fun analyze(text: String): VoiceCommand {
        val lower = text.lowercase().trim()

        // Structured command passthrough
        val structured = parseStructured(text)
        if (structured != null) return structured

        // Natural language analysis
        return when {
            // Lock is a safety-critical command (PDF §16: executes instantly,
            // no confirmation) — checked first so it's never shadowed by a
            // looser pattern below.
            LOCK_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.LOCK_DEVICE)

            // Also safety-critical (turns the whole assistant off) — checked
            // early so it's never shadowed by a looser pattern below.
            STOP_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.STOP_MYRA)

            READ_SCREEN_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.READ_SCREEN)

            BATTERY_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.GET_BATTERY)

            NOTIF_READ_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.READ_NOTIFICATIONS)

            NOTIF_CLEAR_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.CLEAR_NOTIFICATIONS)

            MISSED_CALL_PATTERNS.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.READ_MISSED_CALLS)

            MEDIA_NEXT.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.MEDIA_CONTROL, mapOf("action" to "NEXT"))

            MEDIA_PREV.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.MEDIA_CONTROL, mapOf("action" to "PREVIOUS"))

            MEDIA_PAUSE.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.MEDIA_CONTROL, mapOf("action" to "PAUSE"))

            FLASHLIGHT_ON.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.FLASHLIGHT_ON)

            FLASHLIGHT_OFF.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.FLASHLIGHT_OFF)

            VOLUME_UP.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.VOLUME_UP)

            VOLUME_DOWN.any { lower.contains(it) } ->
                VoiceCommand(text, CommandType.VOLUME_DOWN)

            WHATSAPP_CALL.any { lower.contains(it) } -> {
                val name = extractAfter(lower, WHATSAPP_CALL)
                VoiceCommand(text, CommandType.WHATSAPP_CALL, mapOf("name" to name))
            }

            CALL_PATTERNS.any { lower.startsWith(it) || lower.contains(" $it ") } -> {
                val name = extractAfter(lower, CALL_PATTERNS)
                VoiceCommand(text, CommandType.CALL, mapOf("name" to name))
            }

            MSG_PATTERNS.any { lower.contains(it) } -> {
                val parts = lower.split(" to ", " ko ")
                val name = if (parts.size > 1) parts[1].split(" ")[0] else ""
                VoiceCommand(text, CommandType.WHATSAPP_MSG, mapOf("name" to name, "message" to text))
            }

            OPEN_PATTERNS.any { lower.startsWith(it) || lower.contains("$it ") } -> {
                val appName = extractAfter(lower, OPEN_PATTERNS)
                VoiceCommand(text, CommandType.OPEN_APP, mapOf("app" to appName))
            }

            YOUTUBE_PATTERNS.any { lower.contains(it) } -> {
                val song = extractAfter(lower, YOUTUBE_PATTERNS)
                VoiceCommand(text, CommandType.YOUTUBE_PLAY, mapOf("query" to song))
            }

            SPOTIFY_PATTERNS.any { lower.contains(it) } -> {
                val song = extractAfter(lower, SPOTIFY_PATTERNS)
                VoiceCommand(text, CommandType.SPOTIFY_PLAY, mapOf("query" to song))
            }

            else -> VoiceCommand(text, CommandType.CONVERSATION)
        }
    }

    private fun parseStructured(text: String): VoiceCommand? {
        val t = text.trim()
        return when {
            t.startsWith("OPEN_APP", true) -> {
                val app = t.removePrefix("OPEN_APP").removePrefix(":").trim()
                VoiceCommand(t, CommandType.OPEN_APP, mapOf("app" to app))
            }
            t.startsWith("CALL", true) && !t.startsWith("WHATSAPP_CALL", true) -> {
                val name = t.removePrefix("CALL").trim()
                VoiceCommand(t, CommandType.CALL, mapOf("name" to name))
            }
            t.startsWith("WHATSAPP_CALL", true) -> {
                val name = t.removePrefix("WHATSAPP_CALL").trim()
                VoiceCommand(t, CommandType.WHATSAPP_CALL, mapOf("name" to name))
            }
            t.startsWith("WHATSAPP_MSG", true) -> {
                val rest = t.removePrefix("WHATSAPP_MSG").trim()
                val parts = rest.split(" ", limit = 2)
                VoiceCommand(t, CommandType.WHATSAPP_MSG, mapOf(
                    "name" to (parts.getOrNull(0) ?: ""),
                    "message" to (parts.getOrNull(1) ?: "")
                ))
            }
            t.startsWith("YOUTUBE_PLAY", true) -> {
                val q = t.removePrefix("YOUTUBE_PLAY").trim()
                VoiceCommand(t, CommandType.YOUTUBE_PLAY, mapOf("query" to q))
            }
            t.startsWith("SPOTIFY_PLAY", true) -> {
                val q = t.removePrefix("SPOTIFY_PLAY").trim()
                VoiceCommand(t, CommandType.SPOTIFY_PLAY, mapOf("query" to q))
            }
            t.equals("FLASHLIGHT_ON", true) -> VoiceCommand(t, CommandType.FLASHLIGHT_ON)
            t.equals("FLASHLIGHT_OFF", true) -> VoiceCommand(t, CommandType.FLASHLIGHT_OFF)
            t.equals("VOLUME_UP", true) -> VoiceCommand(t, CommandType.VOLUME_UP)
            t.equals("VOLUME_DOWN", true) -> VoiceCommand(t, CommandType.VOLUME_DOWN)
            t.startsWith("SMS", true) -> {
                val rest = t.removePrefix("SMS").trim()
                val parts = rest.split(" ", limit = 2)
                VoiceCommand(t, CommandType.SMS, mapOf(
                    "name" to (parts.getOrNull(0) ?: ""),
                    "message" to (parts.getOrNull(1) ?: "")
                ))
            }
            t.startsWith("LOOKUP_CONTACT", true) -> {
                val name = t.removePrefix("LOOKUP_CONTACT").trim()
                VoiceCommand(t, CommandType.LOOKUP_CONTACT, mapOf("name" to name))
            }
            t.startsWith("SET_ALARM", true) -> {
                // SET_ALARM <hour> <minute> [label...]
                val rest = t.removePrefix("SET_ALARM").trim()
                val parts = rest.split(" ", limit = 3)
                VoiceCommand(t, CommandType.SET_ALARM, mapOf(
                    "hour" to (parts.getOrNull(0) ?: ""),
                    "minute" to (parts.getOrNull(1) ?: "0"),
                    "label" to (parts.getOrNull(2) ?: "")
                ))
            }
            t.startsWith("SET_TIMER", true) -> {
                val minutes = t.removePrefix("SET_TIMER").trim()
                VoiceCommand(t, CommandType.SET_TIMER, mapOf("minutes" to minutes))
            }
            t.equals("GET_BATTERY", true) -> VoiceCommand(t, CommandType.GET_BATTERY)
            t.startsWith("OPEN_URL", true) -> {
                val url = t.removePrefix("OPEN_URL").trim()
                VoiceCommand(t, CommandType.OPEN_URL, mapOf("url" to url))
            }
            t.startsWith("SET_CLIPBOARD", true) -> {
                val text = t.removePrefix("SET_CLIPBOARD").trim()
                VoiceCommand(t, CommandType.SET_CLIPBOARD, mapOf("text" to text))
            }
            t.equals("LOCK_DEVICE", true) -> VoiceCommand(t, CommandType.LOCK_DEVICE)
            t.equals("READ_NOTIFICATIONS", true) -> VoiceCommand(t, CommandType.READ_NOTIFICATIONS)
            t.equals("CLEAR_NOTIFICATIONS", true) -> VoiceCommand(t, CommandType.CLEAR_NOTIFICATIONS)
            t.equals("READ_MISSED_CALLS", true) -> VoiceCommand(t, CommandType.READ_MISSED_CALLS)
            t.startsWith("MEDIA_CONTROL", true) -> {
                val action = t.removePrefix("MEDIA_CONTROL").trim()
                VoiceCommand(t, CommandType.MEDIA_CONTROL, mapOf("action" to action))
            }
            t.equals("READ_SCREEN", true) -> VoiceCommand(t, CommandType.READ_SCREEN)
            t.equals("STOP_MYRA", true) -> VoiceCommand(t, CommandType.STOP_MYRA)
            else -> null
        }
    }

    private fun extractAfter(text: String, patterns: List<String>): String {
        for (p in patterns) {
            val idx = text.indexOf(p)
            if (idx != -1) {
                return text.substring(idx + p.length).trim()
            }
        }
        return ""
    }
}
