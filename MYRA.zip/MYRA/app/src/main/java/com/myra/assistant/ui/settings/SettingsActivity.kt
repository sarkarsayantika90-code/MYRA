package com.myra.assistant.ui.settings

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraDeviceAdminReceiver
import com.myra.assistant.security.SecuritySettingsActivity


class SettingsActivity : AppCompatActivity() {

    // ── Original Views ──────────────────────────────────────────
    private lateinit var apiKeyInput: EditText
    private lateinit var ttsApiKeyInput: EditText
    private lateinit var userNameInput: EditText
    private lateinit var primeNameInput: EditText
    private lateinit var primeNumberInput: EditText
    private lateinit var personalityGroup: RadioGroup
    private lateinit var voiceTypeGroup: RadioGroup
    private lateinit var liveModeSwitch: Switch
    private lateinit var saveBtn: Button
    private lateinit var accessibilityStatus: TextView
    private lateinit var adminStatusText: TextView
    private lateinit var pickContactBtn: ImageButton

    // ── NEW Views ─────────────────────────────────────────────
    private lateinit var callAnnounceSwitch: Switch
    private lateinit var callAnnounceStatusText: TextView
    private lateinit var grantPermissionsBtn: Button
    private lateinit var setDefaultAssistantBtn: Button
    private lateinit var permissionsStatusText: TextView
    private lateinit var heyMyraSwitch: Switch
    private lateinit var heyMyraStatus: TextView
    private var heyMyraBinding = false

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var componentName: ComponentName

    private val contactPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val contactUri = result.data?.data ?: return@registerForActivityResult
            handleContactResult(contactUri)
        }
    }

    // Required permissions list
    private val allPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.CAMERA
    ) + (if (android.os.Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()) +
        (if (android.os.Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT) else emptyArray())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        componentName = ComponentName(this, MyraDeviceAdminReceiver::class.java)

        initViews()
        loadPreferences()
        setupListeners()
        updateStatus()
    }

    private fun initViews() {
        // Original views
        apiKeyInput = findViewById(R.id.apiKeyInput)
        ttsApiKeyInput = findViewById(R.id.ttsApiKeyInput)
        userNameInput = findViewById(R.id.userNameInput)
        primeNameInput = findViewById(R.id.primeNameInput)
        primeNumberInput = findViewById(R.id.primeNumberInput)
        personalityGroup = findViewById(R.id.personalityGroup)
        voiceTypeGroup = findViewById(R.id.voiceTypeGroup)
        liveModeSwitch = findViewById(R.id.liveModeSwitch)
        saveBtn = findViewById(R.id.saveBtn)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)
        adminStatusText = findViewById(R.id.adminStatusText)
        pickContactBtn = findViewById(R.id.pickContactBtn)

        // NEW views — add these to your XML layout
        callAnnounceSwitch = findViewById(R.id.callAnnounceSwitch)
        callAnnounceStatusText = findViewById(R.id.callAnnounceStatusText)
        grantPermissionsBtn = findViewById(R.id.grantPermissionsBtn)
        setDefaultAssistantBtn = findViewById(R.id.setDefaultAssistantBtn)
        permissionsStatusText = findViewById(R.id.permissionsStatusText)
        heyMyraSwitch = findViewById(R.id.heyMyraSwitch)
        heyMyraStatus = findViewById(R.id.heyMyraStatus)
    }

    private fun loadPreferences() {
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        apiKeyInput.setText(prefs.getString("api_key", ""))
        ttsApiKeyInput.setText(prefs.getString("tts_api_key", ""))
        userNameInput.setText(prefs.getString("user_name", ""))
        primeNameInput.setText(prefs.getString("prime_name", ""))
        primeNumberInput.setText(prefs.getString("prime_number", ""))

        when (prefs.getString("personality_mode", "gf")) {
            "gf" -> findViewById<RadioButton>(R.id.gfRadio).isChecked = true
            "professional" -> findViewById<RadioButton>(R.id.proRadio).isChecked = true
            else -> findViewById<RadioButton>(R.id.assistantRadio).isChecked = true
        }

        when (prefs.getString("voice_engine", "system")) {
            "elevenlabs" -> findViewById<RadioButton>(R.id.radioEleven).isChecked = true
            else -> findViewById<RadioButton>(R.id.radioSystem).isChecked = true
        }

        liveModeSwitch.isChecked = prefs.getBoolean("live_mode_enabled", false)

        // Call announce (default ON for better UX)
        val announceEnabled = prefs.getBoolean("call_announce_enabled", true)
        callAnnounceSwitch.isChecked = announceEnabled
        updateCallAnnounceStatus(announceEnabled)
    }

    private fun setupListeners() {
        saveBtn.setOnClickListener { savePreferences() }

        findViewById<View>(R.id.premiumCard).setOnClickListener {
            startActivity(Intent(this, com.myra.assistant.ui.premium.PremiumActivity::class.java))
        }
        findViewById<View>(R.id.accountCard).setOnClickListener {
            val mail = com.myra.assistant.auth.Session.email(this)
            AlertDialog.Builder(this)
                .setTitle("Account")
                .setMessage(if (mail.isBlank()) "Not logged in" else "Logged in as\n$mail")
                .setNeutralButton("Password set koro") { _, _ -> showSetPasswordDialog() }
                .setPositiveButton("Log out") { _, _ ->
                    com.myra.assistant.services.ForegroundVoiceService.stop(this)
                    com.myra.assistant.auth.Session.clear(this)
                    startActivity(Intent(this, com.myra.assistant.ui.auth.LoginActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                }
                .setNegativeButton("Close", null)
                .show()
        }
        findViewById<View>(R.id.personalizeCard).setOnClickListener {
            startActivity(Intent(this, PersonalizeActivity::class.java))
        }
        findViewById<View>(R.id.chatCard).setOnClickListener {
            startActivity(Intent(this, com.myra.assistant.ui.main.ChatActivity::class.java))
        }
        findViewById<View>(R.id.specialAccessCard).setOnClickListener { showSpecialAccess() }
        findViewById<View>(R.id.diagnosticsCard).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("MYRA health check")
                .setMessage(com.myra.assistant.utils.HealthCheck.report(this))
                .setPositiveButton("OK", null)
                .show()
        }

        pickContactBtn.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            contactPickerLauncher.launch(intent)
        }

        // Original cards
        findViewById<View>(R.id.accessibilityCard).setOnClickListener {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<View>(R.id.deviceAdminCard).setOnClickListener {
            if (!devicePolicyManager.isAdminActive(componentName)) {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "MYRA needs admin to control system.")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Admin is already active ✅", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<View>(R.id.securitySettingsCard).setOnClickListener {
            startActivity(Intent(this, SecuritySettingsActivity::class.java))
        }

        // "Hey Myra" in the background: on = one-time voice model download + glow permission; off = MYRA is simply always on.
        heyMyraSwitch.setOnCheckedChangeListener { _, checked ->
            if (heyMyraBinding) return@setOnCheckedChangeListener
            if (checked) com.myra.assistant.voice.HeyMyraSetup.start(this)
            else com.myra.assistant.voice.WakeWordModel.disable(applicationContext)
            refreshHeyMyra()
        }

        // NEW: Call announce switch
        callAnnounceSwitch.setOnCheckedChangeListener { _, isChecked ->
            updateCallAnnounceStatus(isChecked)
        }

        // NEW: Grant permissions button
        grantPermissionsBtn.setOnClickListener {
            checkAndRequestPermissions()
        }

        // NEW: Set default assistant button
        setDefaultAssistantBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                Toast.makeText(this, "MYRA ko Default Assistant chuno 👆", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Settings → Apps → Default Apps → Assistant → MYRA", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * NEW: Check and request all required permissions
     */
    private fun checkAndRequestPermissions() {
        val missing = allPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSIONS_REQUEST_CODE)
        } else {
            Toast.makeText(this, "Sab permissions already granted! ✅", Toast.LENGTH_SHORT).show()
            updatePermissionsStatus()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            val granted = grantResults.count { it == PackageManager.PERMISSION_GRANTED }
            val total = permissions.size

            if (granted == total) {
                Toast.makeText(this, "Sab permissions mil gayi! ✅", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "$granted/$total permissions mili ⚠️", Toast.LENGTH_LONG).show()

                val permanentlyDenied = permissions.filterIndexed { index, _ ->
                    grantResults[index] == PackageManager.PERMISSION_DENIED &&
                    !ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[index])
                }

                if (permanentlyDenied.isNotEmpty()) {
                    AlertDialog.Builder(this)
                        .setTitle("Permissions Required ⚠️")
                        .setMessage("Kuch permissions permanently deny ho gayi hain. Settings se manually enable karo.\n\n" +
                                permanentlyDenied.joinToString("\n") { "• ${it.split('.').last()}" })
                        .setPositiveButton("Open Settings") { _, _ ->
                            try {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", packageName, null)
                                }
                                startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(this, "Settings open nahi ho paya", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            updatePermissionsStatus()
        }
    }

    /** Gives a Google-created account an email+password too, so email login works as well. */
    private fun showSetPasswordDialog() {
        if (!com.myra.assistant.auth.Session.isLoggedIn(this)) return
        val input = EditText(this).apply {
            hint = "Notun password (kom pokkhe 6 okkhor)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Email login er password")
            .setMessage("Ei password diye pore email + password diye-o login korte parbe (Google login-o cholbe).")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pw = input.text.toString()
                if (pw.length < 6) { Toast.makeText(this, "Password kom pokkhe 6 okkhor hote hobe", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                Toast.makeText(this, "Password set hocche...", Toast.LENGTH_SHORT).show()
                Thread {
                    val err = try { com.myra.assistant.auth.FirebaseRest.setPassword(applicationContext, pw); null }
                    catch (ex: com.myra.assistant.auth.FirebaseRest.FirebaseError) { com.myra.assistant.auth.FirebaseRest.friendly(ex.code) }
                    catch (ex: Exception) { "Hoilo na: " + (ex.message ?: "").take(60) }
                    runOnUiThread {
                        Toast.makeText(this, err ?: "Password set hoye geche! Ekhon email + password diye login korte parbe.", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSpecialAccess() {
        val items = arrayOf(
            "Notification access (read notifications / WhatsApp unread)",
            "Draw over other apps (floating orb)",
            "Battery: don't restrict MYRA",
            "Full-screen alerts (open apps from background)",
            "App info (all permissions)"
        )
        AlertDialog.Builder(this).setTitle("Special access").setItems(items) { _, i ->
            try {
                when (i) {
                    0 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    2 -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    3 -> if (android.os.Build.VERSION.SDK_INT >= 34)
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                    else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    else -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Ei page open hoilo na", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    private fun updateCallAnnounceStatus(enabled: Boolean) {
        callAnnounceStatusText.text = if (enabled) {
            "📢 Call aane pe MYRA naam bolegi"
        } else {
            "🔇 Call announce band hai"
        }
        callAnnounceStatusText.setTextColor(
            if (enabled) 0xFF00E676.toInt() else 0xFFFF1744.toInt()
        )
    }

    private fun updatePermissionsStatus() {
        val missing = allPermissions.count {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        permissionsStatusText.text = when {
            missing == 0 -> "✅ All Permissions Granted"
            missing <= 2 -> "⚠️ $missing permissions pending"
            else -> "❌ $missing permissions missing"
        }
        permissionsStatusText.setTextColor(when {
            missing == 0 -> 0xFF00E676.toInt()
            missing <= 2 -> 0xFFFFA726.toInt()
            else -> 0xFFFF1744.toInt()
        })
    }

    private fun refreshHeyMyra() {
        val model = com.myra.assistant.voice.WakeWordModel
        val on = com.myra.assistant.voice.HeyMyraSetup.isOn(this)
        heyMyraBinding = true
        heyMyraSwitch.isChecked = on || model.downloading
        heyMyraBinding = false
        heyMyraStatus.text = when {
            model.downloading -> "Voice model download hocche... ${model.progress.coerceAtLeast(0)}%"
            on && !com.myra.assistant.voice.HeyMyraSetup.overlayGranted(this) ->
                "⚠️ On, kintu glow dekhate 'Special access > Draw over other apps' on koro"
            on -> "✅ On: Hey Myra bolle glow hobe ar MYRA uttor dibe"
            else -> "Off. On korle ekbar ~40MB voice model download hobe"
        }
    }

    private fun handleContactResult(uri: android.net.Uri) {
        val cursor = contentResolver.query(uri, null, null, null, null)
        if (cursor?.moveToFirst() == true) {
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            primeNameInput.setText(cursor.getString(nameIndex))
            primeNumberInput.setText(cursor.getString(numIndex).replace(" ", ""))
        }
        cursor?.close()
    }

    private fun savePreferences() {
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE).edit()

        prefs.putString("api_key", apiKeyInput.text.toString().trim())
        prefs.putString("tts_api_key", ttsApiKeyInput.text.toString().trim())
        prefs.putString("user_name", userNameInput.text.toString().trim())
        prefs.putString("prime_name", primeNameInput.text.toString().trim())
        prefs.putString("prime_number", primeNumberInput.text.toString().trim())

        val personality = when (personalityGroup.checkedRadioButtonId) {
            R.id.gfRadio -> "gf"
            R.id.proRadio -> "professional"
            else -> "assistant"
        }
        prefs.putString("personality_mode", personality)

        val voiceEngine = when (voiceTypeGroup.checkedRadioButtonId) {
            R.id.radioEleven -> "elevenlabs"
            else -> "system"
        }
        prefs.putString("voice_engine", voiceEngine)

        prefs.putBoolean("live_mode_enabled", liveModeSwitch.isChecked)
        prefs.putBoolean("call_announce_enabled", callAnnounceSwitch.isChecked)

        prefs.apply()

        // Without this, name/personality/API-key changes only took effect the
        // NEXT time the voice service was started — MYRA kept using whatever
        // system prompt it built at connect time, which is why a name change
        // here never seemed to "take" while a session was already running.
        com.myra.assistant.services.ForegroundVoiceService.instance?.reconnectGemini()

        Toast.makeText(this, "Settings Saved! MYRA updated. ✅", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun updateStatus() {
        val enabled = AccessibilityHelperService.isEnabled(this)
        val connected = AccessibilityHelperService.isConnected()
        accessibilityStatus.text = when {
            connected -> "✅ Full Control On (connected)"
            enabled -> "⚠️ On but not connected - switch it OFF then ON"
            else -> "❌ Accessibility Off"
        }
        accessibilityStatus.setTextColor(
            when { connected -> 0xFF00E676.toInt(); enabled -> 0xFFFFA726.toInt(); else -> 0xFFFF1744.toInt() }
        )

        val adminActive = devicePolicyManager.isAdminActive(componentName)
        adminStatusText.text = if (adminActive) "✅ Admin Active" else "❌ Admin Inactive"
        adminStatusText.setTextColor(if (adminActive) 0xFF00E676.toInt() else 0xFFFF1744.toInt())

        updatePermissionsStatus()
    }

    override fun onPause() {
        super.onPause()
        com.myra.assistant.voice.WakeWordModel.listener = null
    }

    override fun onResume() {
        super.onResume()
        com.myra.assistant.voice.WakeWordModel.listener = { refreshHeyMyra() }
        refreshHeyMyra()
        try {
            val mail = com.myra.assistant.auth.Session.email(this)
            findViewById<TextView>(R.id.accountCardSub).text = if (mail.isBlank()) "Not logged in" else mail
            findViewById<TextView>(R.id.premiumCardSub).text =
                if (com.myra.assistant.premium.PremiumManager.isPremium(this))
                    "✅ ${com.myra.assistant.premium.PremiumManager.planName(this)} • ${com.myra.assistant.premium.PremiumManager.expiryText(this)}"
                else "Free • tap to see plans"
        } catch (_: Exception) {}
        updateStatus()
    }

    companion object {
        private const val PERMISSIONS_REQUEST_CODE = 200
    }
}