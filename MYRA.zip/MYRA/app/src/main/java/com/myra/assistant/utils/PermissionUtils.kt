package com.myra.assistant.utils

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object PermissionUtils {

    val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.CAMERA
    )

    /** Android 13+ needs this runtime permission for MYRA's notifications (incl. "open app" fallback). */
    val EXTRA_PERMISSIONS: Array<String> = buildList<String> {
        if (android.os.Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.POST_NOTIFICATIONS); add(Manifest.permission.READ_MEDIA_IMAGES) }
        // Android 12+: without "Nearby devices" MYRA cannot use Bluetooth headphones (mic or speaker).
        if (android.os.Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
    }.toTypedArray()

    fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasMicPermission(context: Context) = hasPermission(context, Manifest.permission.RECORD_AUDIO)

    fun getMissingPermissions(context: Context): List<String> =
        (REQUIRED_PERMISSIONS + EXTRA_PERMISSIONS).filter { !hasPermission(context, it) }

    fun requestMissing(activity: Activity, requestCode: Int) {
        val missing = getMissingPermissions(activity)
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(activity, missing.toTypedArray(), requestCode)
        }
    }
}
