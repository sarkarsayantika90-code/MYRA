package com.myra.assistant.ui.main

import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.view.WindowManager
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.security.BiometricManager
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.PermissionUtils
import com.myra.assistant.utils.prefs
import com.myra.assistant.viewmodel.MainViewModel
import com.myra.assistant.voice.VoiceStateManager
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val TAG = "MAIN"
    private val viewModel: MainViewModel by viewModels()

    private lateinit var orbView: OrbAnimationView
    private lateinit var waveformView: WaveformView
    private lateinit var statusText: TextView
    private lateinit var micButton: ImageButton
    private lateinit var chatRecycler: RecyclerView
    private lateinit var chatInput: EditText
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var batteryText: TextView
    private lateinit var ramText: TextView
    private lateinit var timeText: TextView

    private val timeHandler = Handler(Looper.getMainLooper())
    private val timeRunnable = object : Runnable {
        override fun run() {
            updateSystemInfo()
            timeHandler.postDelayed(this, 1000)
        }
    }

    private val responseReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text") ?: return
            addBotMessage(text)
        }
    }

    companion object {
        const val PERM_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)

        initViews()
        updateSystemInfo()
        timeHandler.post(timeRunnable)

        BiometricManager.authenticate(
            this,
            onSuccess = { setupAssistant() },
            onError = { setupAssistant() },
            onFallback = { setupAssistant() }
        )
    }

    private fun setupAssistant() {
        PermissionUtils.requestMissing(this, PERM_CODE)
        observeViewModel()
        observeVoiceState()
        startVoiceService()
        checkAccessibility()
    }

    private fun initViews() {
        orbView     = findViewById(R.id.orbView)
        waveformView = findViewById(R.id.waveformView)
        statusText  = findViewById(R.id.statusText)
        micButton   = findViewById(R.id.micButton)
        chatRecycler = findViewById(R.id.chatRecycler)
        chatInput = findViewById(R.id.chatInput)
        batteryText = findViewById(R.id.batteryText)
        ramText     = findViewById(R.id.ramText)
        timeText    = findViewById(R.id.timeText)

        chatAdapter = ChatAdapter()
        chatRecycler.layoutManager = LinearLayoutManager(this).also { it.stackFromEnd = true }
        chatRecycler.adapter = chatAdapter

        findViewById<ImageButton>(R.id.sendChatBtn).setOnClickListener { sendChatMessage() }
        chatInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND ||
                (event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN)) {
                sendChatMessage()
                true
            } else false
        }

        micButton.setOnClickListener {
            val svc = ForegroundVoiceService.instance
            if (svc != null) {
                val text = "Hey MYRA"
                svc.sendTextToGemini(text)
                addUserMessage(text)
            } else {
                startVoiceService()
            }
        }

        micButton.setOnLongClickListener {
            ForegroundVoiceService.instance?.reconnectGemini()
            addBotMessage("Reconnecting...")
            true
        }

        findViewById<ImageButton>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }


    private fun sendChatMessage() {
        val message = chatInput.text?.toString()?.trim().orEmpty()
        if (message.isEmpty()) return
        val service = ForegroundVoiceService.instance
        if (service == null) {
            addBotMessage("MYRA is offline. Check Settings → API Key, then turn MYRA on.")
            startVoiceService()
            return
        }
        chatInput.text?.clear()
        addUserMessage(message)
        service.sendTextToGemini(message)
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
            ?.hideSoftInputFromWindow(chatInput.windowToken, 0)
    }

    private fun observeVoiceState() {
        VoiceStateManager.state.observe(this) { state ->
            when (state) {
                Constants.STATE_LISTENING -> {
                    orbView.setListening()
                    micButton.setImageResource(R.drawable.ic_mic_on)
                    statusText.setTextColor(0xFF00E5FF.toInt())
                }
                Constants.STATE_THINKING -> {
                    orbView.setThinking()
                    statusText.setTextColor(0xFFD500F9.toInt())
                }
                Constants.STATE_SPEAKING -> {
                    orbView.setSpeaking()
                    micButton.setImageResource(R.drawable.ic_mic_off)
                    statusText.setTextColor(0xFFFF1744.toInt())
                }
                else -> {
                    orbView.setIdle()
                    micButton.setImageResource(R.drawable.ic_mic_off)
                    statusText.setTextColor(0xFFFF1744.toInt())
                }
            }
        }
        VoiceStateManager.amplitude.observe(this) { amp ->
            waveformView.updateAmplitude(amp)
            orbView.setAmplitude(amp)
        }
        VoiceStateManager.statusMessage.observe(this) { msg ->
            statusText.text = msg
        }
    }

    private fun observeViewModel() {
        viewModel.aiResponse.observe(this) { text ->
            if (!text.isNullOrBlank()) addBotMessage(text)
        }
    }

    private fun startVoiceService() {
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isEmpty()) {
            addBotMessage("⚠️ API Key required. Please go to Settings → Enter Gemini API Key.")
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, ForegroundVoiceService::class.java))
        Logger.d(TAG, "Voice service started")
    }

    private fun checkAccessibility() {
        if (!AccessibilityHelperService.isEnabled(this)) {
            addBotMessage("⚠️ Enable Accessibility Service for app control. Settings → Accessibility.")
        }
    }

    fun addUserMessage(text: String) = runOnUiThread {
        chatAdapter.addMessage(ChatMessage(text, true))
        chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
    }

    fun addBotMessage(text: String) = runOnUiThread {
        chatAdapter.addMessage(ChatMessage(text, false))
        chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
    }

    private fun updateSystemInfo() {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        timeText.text = sdf.format(Date())
        val bm = getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        batteryText.text = "${bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0}%"
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ramText.text = "${(mi.totalMem - mi.availMem) / 1048576}MB"
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"), Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"))
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(responseReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        timeHandler.removeCallbacks(timeRunnable)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startVoiceService()
        }
    }
}
