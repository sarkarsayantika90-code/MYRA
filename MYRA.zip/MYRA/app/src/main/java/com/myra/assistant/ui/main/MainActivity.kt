package com.myra.assistant.ui.main

import android.app.ActivityManager
import android.content.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.*
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.security.BiometricManager
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.PermissionUtils
import com.myra.assistant.utils.prefs
import com.myra.assistant.viewmodel.MainViewModel
import com.myra.assistant.voice.VoiceStateManager
import androidx.activity.viewModels
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    private lateinit var orbView: OrbAnimationView
    private lateinit var waveformView: WaveformView
    private lateinit var statusText: TextView
    private lateinit var micButton: ImageButton
    private lateinit var chatRecycler: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var batteryText: TextView
    private lateinit var ramText: TextView
    private lateinit var timeText: TextView
    private lateinit var titleText: TextView
    private lateinit var bgImage: ImageView
    private lateinit var bgDim: android.view.View

    private var assistantReady = false
    private val timeHandler = Handler(Looper.getMainLooper())
    private val timeRunnable = object : Runnable {
        override fun run() { updateSystemInfo(); timeHandler.postDelayed(this, 1000) }
    }

    /** Old broadcast path (kept so older code that sends MYRA_RESPONSE still shows up). */
    private val responseReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.getStringExtra("text")?.let { ChatStore.addBot(it) }
        }
    }

    companion object {
        const val PERM_CODE = 100
        const val KEY_MANUAL_OFF = "myra_manual_off"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!com.myra.assistant.auth.Session.isLoggedIn(this)) {
            startActivity(Intent(this, com.myra.assistant.ui.auth.LoginActivity::class.java))
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)

        initViews()
        applyTheme()
        updateSystemInfo()
        timeHandler.post(timeRunnable)

        BiometricManager.authenticate(
            this,
            onSuccess = { setupAssistant() },
            onError = { setupAssistant() },
            onFallback = { setupAssistant() }
        )
    }

    private fun setupAssistant() {
        if (assistantReady) return
        assistantReady = true
        PermissionUtils.requestMissing(this, PERM_CODE)
        observeVoiceState()
        window.decorView.postDelayed({ if (!isFinishing) maybeAskHeyMyra() }, 3000)
        observeChat()
        // Night switch-off: MYRA put herself to sleep; she stays asleep until 5am unless he taps the orb.
        val nightUntil = prefs().getLong(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_OFF_UNTIL, 0L)
        if (nightUntil != 0L && System.currentTimeMillis() >= nightUntil) {
            prefs().edit().putBoolean(KEY_MANUAL_OFF, false)
                .putLong(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_OFF_UNTIL, 0L).apply()
        }
        if (!prefs().getBoolean(KEY_MANUAL_OFF, false)) startVoiceService(silent = true)
        else {
            VoiceStateManager.setOff()
            if (nightUntil > System.currentTimeMillis()) ChatStore.addBot("MYRA is asleep 😴 Tap the orb to wake her.")
        }
        // refresh premium status in the background
        Thread {
            val app = applicationContext
            com.myra.assistant.auth.UserSync.touch(app)
            com.myra.assistant.auth.RemoteConfig.refresh(app)
            com.myra.assistant.premium.PremiumManager.refresh(app)
            com.myra.assistant.premium.PremiumManager.syncUsage(app)
            try { com.myra.assistant.update.NoticePoller.poll(app) } catch (_: Exception) {}
            runOnUiThread { afterConfig() }
        }.start()
        checkAccessibility()
    }

    private fun initViews() {
        orbView = findViewById(R.id.orbView)
        waveformView = findViewById(R.id.waveformView)
        statusText = findViewById(R.id.statusText)
        micButton = findViewById(R.id.micButton)
        chatRecycler = findViewById(R.id.chatRecycler)
        batteryText = findViewById(R.id.batteryText)
        ramText = findViewById(R.id.ramText)
        timeText = findViewById(R.id.timeText)
        titleText = findViewById(R.id.titleText)
        bgImage = findViewById(R.id.bgImage)
        bgDim = findViewById(R.id.bgDim)

        chatAdapter = ChatAdapter()
        chatRecycler.layoutManager = LinearLayoutManager(this).also { it.stackFromEnd = true }
        chatRecycler.adapter = chatAdapter

        // ONE tap on the glowing orb = MYRA fully OFF; tap again = ON.
        val toggle = { toggleMyra() }
        orbView.setOnClickListener { toggle() }
        // Long-press = fully OFF (also in "Hey Myra" mode, where a normal tap only wakes her / lets her rest).
        orbView.setOnLongClickListener {
            if (ForegroundVoiceService.isRunning) { turnMyraFullyOff(); true } else false
        }
        // MIC button: only mutes / unmutes the microphone. (If MYRA is off, it switches her on; in standby it wakes her.)
        micButton.setOnClickListener {
            val svc = ForegroundVoiceService.instance
            if (!ForegroundVoiceService.isRunning) toggle()
            else if (svc != null && svc.isStandby()) svc.wakeNow()
            else VoiceStateManager.setMicMuted(!VoiceStateManager.micMutedFlag)
            updateMicIcon()
        }

        findViewById<ImageButton>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.chatBtn).setOnClickListener {
            startActivity(Intent(this, ChatActivity::class.java))
        }
    }

    private fun applyTheme() {
        val accent = ThemeManager.accent(this)
        orbView.setAccent(accent)
        titleText.setTextColor(accent)
        titleText.setShadowLayer(22f, 0f, 0f, accent)
        // gradient sweep across the MYRA letters
        titleText.post {
            val w = titleText.paint.measureText(titleText.text.toString())
            titleText.paint.shader = LinearGradient(
                0f, 0f, w, 0f, intArrayOf(accent, Color.WHITE, accent), null, Shader.TileMode.CLAMP
            )
            titleText.invalidate()
        }
        ThemeManager.loadInto(this, bgImage)
        bgDim.alpha = if (ThemeManager.hasBackground(this)) ThemeManager.dim(this) / 100f else 0f
        statusText.setTextColor(accent)
    }

    private fun turnMyraFullyOff() {
        prefs().edit().putBoolean(KEY_MANUAL_OFF, true).apply()
        ForegroundVoiceService.stop(this)
        VoiceStateManager.setOff()
        Toast.makeText(this, "MYRA off", Toast.LENGTH_SHORT).show()
    }

    /** One-time offer: MYRA in the background, woken by "Hey Myra", with the Gemini-style screen glow. */
    private fun maybeAskHeyMyra() {
        val p = prefs()
        if (p.getBoolean(Constants.KEY_WAKE_ASKED, false) || p.getBoolean(Constants.KEY_WAKE_BG, false)) return
        p.edit().putBoolean(Constants.KEY_WAKE_ASKED, true).apply()
        android.app.AlertDialog.Builder(this)
            .setTitle("Turn on \"Hey Myra\"?")
            .setMessage(
                "Just say \"Hey Myra\", even with the app in the background or the phone locked. The screen edge will glow and MYRA will listen and answer. " +
                    "If you stay quiet for a while she goes back to sleep by herself.\n\n" +
                    "• A one-time ~40MB voice model download (Wi-Fi recommended)\n" +
                    "• The microphone stays on, so battery use is a little higher\n" +
                    "• Needs the \"Draw over other apps\" permission for the glow\n\n" +
                    "Tap the orb = wake / sleep. Long-press the orb = fully off."
            )
            .setPositiveButton("Turn on") { _, _ -> com.myra.assistant.voice.HeyMyraSetup.start(this) }
            .setNegativeButton("Later (it stays in Settings)", null)
            .show()
    }

    private fun toggleMyra() {
        val svc = ForegroundVoiceService.instance
        if (ForegroundVoiceService.isRunning && svc != null && svc.wakeModeEnabled()) {
            // "Hey Myra" mode: tap = wake her / let her rest. Long-press = fully off.
            if (svc.isStandby()) svc.wakeNow() else svc.goStandby()
            return
        }
        if (ForegroundVoiceService.isRunning) {
            turnMyraFullyOff()
        } else {
            prefs().edit().putBoolean(KEY_MANUAL_OFF, false).apply()
            startVoiceService(silent = false)
        }
    }

    private fun updateMicIcon() {
        val on = ForegroundVoiceService.isRunning && !VoiceStateManager.micMutedFlag
        micButton.setImageResource(if (on) R.drawable.ic_mic_on else R.drawable.ic_mic_off)
    }

    private fun observeVoiceState() {
        VoiceStateManager.isMicMuted.observe(this) { updateMicIcon() }
        VoiceStateManager.state.observe(this) { state ->
            if (!ForegroundVoiceService.isRunning && VoiceStateManager.serviceOn.value != true) {
                orbView.setIdle(); updateMicIcon(); return@observe
            }
            when (state) {
                Constants.STATE_LISTENING -> { orbView.setListening(); updateMicIcon() }
                Constants.STATE_THINKING -> orbView.setThinking()
                Constants.STATE_SPEAKING -> { orbView.setSpeaking(); updateMicIcon() }
                else -> { orbView.setIdle(); updateMicIcon() }
            }
        }
        VoiceStateManager.serviceOn.observe(this) { on ->
            if (on != true) { orbView.setIdle(); updateMicIcon() }
        }
        VoiceStateManager.amplitude.observe(this) { amp ->
            waveformView.updateAmplitude(amp)
            orbView.setAmplitude(amp)
        }
        VoiceStateManager.statusMessage.observe(this) { statusText.text = it }
    }

    private fun observeChat() {
        ChatStore.messages.observe(this) { list ->
            chatAdapter.setAll(list.takeLast(6))
            if (list.isNotEmpty()) chatRecycler.scrollToPosition(minOf(list.size, 6) - 1)
        }
    }

    private fun startVoiceService(silent: Boolean) {
        if (!com.myra.assistant.auth.RemoteConfig.hasKey(this)) {
            // First run: the key comes from the server. Fetch it, then start once.
            Thread {
                com.myra.assistant.auth.RemoteConfig.refresh(applicationContext)
                runOnUiThread {
                    if (com.myra.assistant.auth.RemoteConfig.hasKey(this)) startVoiceService(silent)
                    else {
                        val why = if (com.myra.assistant.auth.RemoteConfig.denied(this)) "No account access - contact the admin" else "Could not load setup from the server - check your internet"
                        if (!silent) Toast.makeText(this, why, Toast.LENGTH_LONG).show()
                        ChatStore.addBot(why)
                    }
                }
            }.start()
            return
        }
        if (!PermissionUtils.hasMicPermission(this)) {
            PermissionUtils.requestMissing(this, PERM_CODE)
            return
        }
        if (!com.myra.assistant.premium.PremiumManager.freeTimeLeft(this)) {
            ChatStore.addBot("Today's free time is over. Go Premium for unlimited talk time 💕 (Settings > Premium)")
            if (!silent) Toast.makeText(this, "Free time is over - Settings > Premium", Toast.LENGTH_LONG).show()
            return
        }
        if (!ForegroundVoiceService.start(this)) {
            Toast.makeText(this, "MYRA could not start. Please check the microphone permission.", Toast.LENGTH_LONG).show()
        }
    }

    private fun checkAccessibility() {
        if (!AccessibilityHelperService.isEnabled(this)) {
            ChatStore.addBot("To control the phone, turn on Settings > Accessibility > MYRA.")
        }
    }

    private fun updateSystemInfo() {
        timeText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val bm = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        batteryText.text = "${bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0}%"
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ramText.text = "${(mi.totalMem - mi.availMem) / 1048576}MB"
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        com.myra.assistant.update.UpdateManager.reset()
        com.myra.assistant.update.UpdateDialog.checkAndShow(this)
        showPendingCrash()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"), Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"))
        }
    }

    private fun afterConfig() {
        if (isFinishing) return
        com.myra.assistant.auth.RemoteConfig.maintenance(this)?.let { msg ->
            ForegroundVoiceService.stop(this)
            android.app.AlertDialog.Builder(this).setTitle("MYRA").setMessage(msg).setCancelable(false)
                .setPositiveButton("Close") { _, _ -> finishAffinity() }.show()
            return
        }
        val note = com.myra.assistant.auth.RemoteConfig.announcement(this)
        if (note.isNotBlank() && prefs().getInt("announce_seen", 0) != note.hashCode()) {
            prefs().edit().putInt("announce_seen", note.hashCode()).apply()
            ChatStore.addBot("📢 $note")
        }
    }

    private fun showPendingCrash() {
        val crash = com.myra.assistant.utils.CrashReporter.pending(this) ?: return
        com.myra.assistant.utils.CrashReporter.clear(this)
        android.app.AlertDialog.Builder(this)
            .setTitle("MYRA crashed last time")
            .setMessage("Please copy this error and send it to the developer:\n\n" + crash.take(900))
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("MYRA crash", crash))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(responseReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        timeHandler.removeCallbacks(timeRunnable)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE && PermissionUtils.hasMicPermission(this) &&
            !ForegroundVoiceService.isRunning && !prefs().getBoolean(KEY_MANUAL_OFF, false)) {
            startVoiceService(silent = true)
        }
    }
}
