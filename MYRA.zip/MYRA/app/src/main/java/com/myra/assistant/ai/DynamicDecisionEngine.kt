package com.myra.assistant.ai

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.myra.assistant.apps.AppLauncher
import com.myra.assistant.models.CommandType
import com.myra.assistant.models.VoiceCommand
import com.myra.assistant.service.MyraDeviceAdminReceiver
import com.myra.assistant.service.MyraNotificationListenerService
import com.myra.assistant.service.SmartAccessibilityEngine
import com.myra.assistant.accessibility.NodeFinder
import com.myra.assistant.automation.UiTreeSerializer
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.utils.ContactLookup
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.delay
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DynamicDecisionEngine {
    private val TAG = "DECISION"

    suspend fun execute(context: Context, command: VoiceCommand): String {
        Logger.d(TAG, "Executing: ${command.type} - ${command.raw}")

        return when (command.type) {
            CommandType.OPEN_APP -> {
                val app = command.args["app"] ?: ""
                if (AppLauncher.launch(context, app)) "Opening $app"
                else "App not found: $app"
            }

            CommandType.VOLUME_UP -> {
                SmartAccessibilityEngine.execute("VOLUME_UP")
                "Volume badha diya"
            }

            CommandType.VOLUME_DOWN -> {
                SmartAccessibilityEngine.execute("VOLUME_DOWN")
                "Volume kam kiya"
            }

            CommandType.FLASHLIGHT_ON -> {
                toggleFlashlight(context, true)
                "Torch on kar diya"
            }

            CommandType.FLASHLIGHT_OFF -> {
                toggleFlashlight(context, false)
                "Torch off kar diya"
            }

            // Direct, reliable dial — NOT routed through the generic
            // accessibility automation anymore. SmartAutomationAgent can only
            // find-and-click text on a single static screen; it has no idea
            // how to navigate the dialer, which is why CALL never actually
            // worked before. ContactLookup + CallAutomation are the same
            // classes already used elsewhere in the app for direct dialing.
            CommandType.CALL -> {
                val nameOrNumber = command.args["name"]?.trim() ?: ""
                if (nameOrNumber.isBlank()) "Kaake call karna hai, bataiye"
                else {
                    val number = if (nameOrNumber.any { it.isDigit() } && nameOrNumber.length >= 6) {
                        nameOrNumber
                    } else {
                        ContactLookup.findNumber(context, nameOrNumber)
                    }
                    if (number.isNullOrBlank()) "$nameOrNumber ka number nahi mila"
                    else if (com.myra.assistant.automation.CallAutomation.makeCall(context, number)) "Call kar rahi hoon $nameOrNumber ko"
                    else "Call permission nahi hai, Settings mein call permission on karo"
                }
            }

            // WhatsApp automation cannot use ACTION_CALL/ACTION_DIAL — WhatsApp
            // has no public intent for placing a call directly, so we open the
            // chat via the wa.me deep link (this reliably opens WhatsApp on the
            // right contact) and then best-effort auto-tap the "voice call" /
            // "video call" icon via the Accessibility Service. If Accessibility
            // isn't enabled, the chat still opens so the person can tap it
            // themselves.
            CommandType.WHATSAPP_CALL -> whatsAppOpenAndAssist(
                context, command.args["name"] ?: "", message = null,
                assistHints = listOf("voice call", "video call", "call")
            )

            // Deep-link pre-fills the message text reliably. We deliberately
            // never auto-tap Send for a message — sending is irreversible and
            // goes to a real person, so it always waits for the user's own
            // tap. (assistHints unused here for that reason.)
            CommandType.WHATSAPP_MSG -> whatsAppOpenAndAssist(
                context, command.args["name"] ?: "", message = command.args["message"] ?: "",
                assistHints = emptyList()
            )

            CommandType.YOUTUBE_PLAY -> {
                val query = command.args["query"] ?: ""
                SmartAccessibilityEngine.execute("YOUTUBE_PLAY $query")
                "YouTube play kar rahi hoon"
            }

            CommandType.READ_SCREEN -> readScreen(context)

            CommandType.STOP_MYRA -> {
                context.stopService(Intent(context, com.myra.assistant.services.ForegroundVoiceService::class.java))
                "Theek hai, band ho rahi hoon"
            }

            // ---- Device Tools (PDF §4) + lookup_contact (PDF §2) ----

            CommandType.SMS -> sendSms(context, command.args["name"] ?: "", command.args["message"] ?: "")

            CommandType.LOOKUP_CONTACT -> {
                val name = command.args["name"] ?: ""
                val number = ContactLookup.findNumber(context, name)
                if (number != null) "$name ka number hai $number"
                else "$name ka number nahi mila"
            }

            CommandType.SET_ALARM -> setAlarm(
                context,
                command.args["hour"]?.toIntOrNull(),
                command.args["minute"]?.toIntOrNull() ?: 0,
                command.args["label"] ?: ""
            )

            CommandType.SET_TIMER -> setTimer(context, command.args["minutes"]?.toIntOrNull())

            CommandType.GET_BATTERY -> getBatteryStatus(context)

            CommandType.OPEN_URL -> openUrl(context, command.args["url"] ?: "")

            CommandType.SET_CLIPBOARD -> setClipboard(context, command.args["text"] ?: "")

            // Safety-critical: executes instantly, no confirmation (PDF §16).
            CommandType.LOCK_DEVICE -> lockDevice(context)

            // ---- Notification Tools (PDF §8) + Media Tools (PDF §3) ----
            CommandType.READ_NOTIFICATIONS -> readNotifications(context)
            CommandType.CLEAR_NOTIFICATIONS -> clearNotifications(context)
            CommandType.READ_MISSED_CALLS -> readMissedCalls(context)
            CommandType.MEDIA_CONTROL -> mediaControl(context, command.args["action"] ?: "")

            // ---- Call Tools extra (PDF §2) ----
            CommandType.ANSWER_CALL -> answerCall(context)
            CommandType.END_CALL -> endCall(context)

            // ---- Device Tools extra (PDF §4) ----
            CommandType.ANALYZE_STORAGE -> analyzeStorage(context)
            CommandType.CLEAN_STORAGE -> cleanStorage(context)
            CommandType.SET_VOLUME -> setVolumePercent(context, command.args["percent"]?.toIntOrNull())

            // Explicit-only: the general READ_NOTIFICATIONS handler above
            // deliberately filters OTP-looking text out. This is the ONLY
            // path allowed to read one back, and only because the person
            // asked for it directly (PDF §16 safety rule).
            CommandType.READ_OTP -> readOtp(context)

            CommandType.SYSTEM_HEALTH -> systemHealth(context)

            // ---- Files & Photos Tools (PDF §5) ----
            CommandType.LIST_FILES -> listFiles(context)
            CommandType.SEARCH_FILES -> searchFiles(context, command.args["query"] ?: "")
            CommandType.DELETE_FILE -> deleteFile(context, command.args["name"] ?: "")
            CommandType.DELETE_PHOTO -> deletePhoto(context, command.args["count"]?.toIntOrNull() ?: 1)
            CommandType.ZIP_FOLDER -> zipFolder(context, command.args["folder"] ?: "")
            CommandType.RENAME_FILE -> renameFile(context, command.args["name"] ?: "", command.args["newName"] ?: "")
            CommandType.MANAGE_FOLDER -> manageFolder(context, command.args["action"] ?: "", command.args["name"] ?: "")
            CommandType.SHARE_FILE -> shareFile(context, command.args["name"] ?: "", command.args["app"] ?: "")
            CommandType.TAKE_PHOTO -> "Camera se chup-chaap photo lena abhi is version mein nahi bana, camera app khol deti hoon".also {
                try {
                    context.startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { Logger.e(TAG, "Camera open failed: ${e.message}") }
            }

            // ---- Maps & "My World" Tools (PDF §9) ----
            CommandType.OPEN_MAP -> openMap(context)
            CommandType.NAVIGATE_TO -> navigateTo(context, command.args["destination"] ?: "")
            CommandType.NAVIGATE_TO_PLACE -> navigateToSavedPlace(context, command.args["place"] ?: "")
            CommandType.GET_LOCATION -> getLocation(context)
            CommandType.GET_DISTANCE -> getDistanceToSavedPlace(context, command.args["place"] ?: "")
            CommandType.GET_PARKING_LOCATION -> getParkingLocation(context)
            CommandType.SAVE_PARKING -> saveParking(context)
            CommandType.SEARCH_NEARBY -> searchNearby(context, command.args["query"] ?: "")
            CommandType.SET_SMART_MODE -> setSmartMode(context, command.args["mode"] ?: "")

            // ---- Search, Browser & App-Launch Tools (PDF §11) ----
            CommandType.SEARCH_GOOGLE -> searchGoogle(context, command.args["query"] ?: "")
            CommandType.OPEN_BROWSER -> openBrowser(context, command.args["url"] ?: "")
            CommandType.BROWSER_SEARCH -> searchGoogle(context, command.args["query"] ?: "")

            // ---- Communication Tools extra (PDF §1) ----
            CommandType.OPEN_EMAIL_INBOX -> openEmailInbox(context)
            CommandType.COMPOSE_EMAIL -> composeEmail(context, command.args["to"] ?: "", command.args["subject"] ?: "", command.args["body"] ?: "")
            CommandType.SEND_EMERGENCY_ALERT -> sendEmergencyAlert(context, command.args["message"] ?: "")

            // ---- Visual Social Media Agent (Instagram/Facebook) ----
            CommandType.POST_INSTAGRAM -> postToSocialApp(context, "com.instagram.android", "Instagram", command.args["caption"] ?: "")
            CommandType.POST_FACEBOOK -> postToSocialApp(context, "com.facebook.katana", "Facebook", command.args["caption"] ?: "")

            else -> ""
        }
    }

    private fun readNotifications(context: Context): String {
        if (!MyraNotificationListenerService.isEnabled(context)) {
            openNotificationAccessSettings(context)
            return "Notification access on nahi hai. Settings khol diya, MYRA ko allow kar do"
        }
        val items = MyraNotificationListenerService.getRecent(5)
        if (items.isEmpty()) return "Koi naya notification nahi hai"
        // Deliberately skip anything that looks like an OTP: PDF §16 says OTPs
        // are only read on an explicit "OTP batao", never as part of a
        // general notification readout.
        val otpRegex = Regex("\\b\\d{4,8}\\b.*(otp|code|verification)|(otp|code|verification).*\\b\\d{4,8}\\b", RegexOption.IGNORE_CASE)
        val safe = items.filterNot { otpRegex.containsMatchIn("${it.title} ${it.text}") }
        if (safe.isEmpty()) return "Koi naya notification nahi hai"
        return safe.joinToString(". ") { "${it.appLabel}: ${it.title}. ${it.text}".trim() }
    }

    private fun clearNotifications(context: Context): String {
        if (!MyraNotificationListenerService.isEnabled(context)) {
            openNotificationAccessSettings(context)
            return "Notification access on nahi hai. Settings khol diya, MYRA ko allow kar do"
        }
        return if (MyraNotificationListenerService.clearAllNotifications()) "Notifications clear kar diye"
        else "Notification service abhi connected nahi hai, thodi der baad try karo"
    }

    private fun openNotificationAccessSettings(context: Context) {
        try {
            context.startActivity(
                Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Logger.e(TAG, "Could not open notification access settings: ${e.message}")
        }
    }

    private fun readMissedCalls(context: Context): String {
        return try {
            val cursor = context.contentResolver.query(
                android.provider.CallLog.Calls.CONTENT_URI,
                arrayOf(
                    android.provider.CallLog.Calls.CACHED_NAME,
                    android.provider.CallLog.Calls.NUMBER
                ),
                "${android.provider.CallLog.Calls.TYPE} = ?",
                arrayOf(android.provider.CallLog.Calls.MISSED_TYPE.toString()),
                "${android.provider.CallLog.Calls.DATE} DESC"
            ) ?: return "Call log access nahi mila"

            val names = mutableListOf<String>()
            cursor.use {
                val nameIdx = it.getColumnIndex(android.provider.CallLog.Calls.CACHED_NAME)
                val numIdx = it.getColumnIndex(android.provider.CallLog.Calls.NUMBER)
                while (it.moveToNext() && names.size < 5) {
                    val name = if (nameIdx >= 0) it.getString(nameIdx) else null
                    val number = if (numIdx >= 0) it.getString(numIdx) else null
                    names.add(name?.takeIf { n -> n.isNotBlank() } ?: number ?: "Unknown")
                }
            }
            if (names.isEmpty()) "Koi missed call nahi hai"
            else "Missed calls: ${names.joinToString(", ")}"
        } catch (e: SecurityException) {
            "Call log ki permission nahi hai"
        } catch (e: Exception) {
            Logger.e(TAG, "Missed calls read failed: ${e.message}")
            "Missed calls padhne mein error ho gaya"
        }
    }

    private fun mediaControl(context: Context, action: String): String {
        val keyCode = when (action.trim().uppercase()) {
            "PLAY", "PAUSE", "PLAY_PAUSE" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "NEXT" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
            "PREVIOUS", "PREV" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "STOP" -> android.view.KeyEvent.KEYCODE_MEDIA_STOP
            else -> return "Media command samajh nahi aaya"
        }
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
            "Ho gaya"
        } catch (e: Exception) {
            Logger.e(TAG, "Media control failed: ${e.message}")
            "Media control mein error ho gaya"
        }
    }

    private fun sendSms(context: Context, nameOrNumber: String, message: String): String {
        if (message.isBlank()) return "Kya message bhejna hai, bataiye"
        val number = if (nameOrNumber.any { it.isDigit() } && nameOrNumber.length >= 6) {
            nameOrNumber
        } else {
            ContactLookup.findNumber(context, nameOrNumber)
        }
        if (number.isNullOrBlank()) return "$nameOrNumber ka number nahi mila"
        return try {
            @Suppress("DEPRECATION")
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(number, null, message, null, null)
            "SMS bhej diya $nameOrNumber ko"
        } catch (e: Exception) {
            Logger.e(TAG, "SMS send failed: ${e.message}")
            "SMS bhejne mein error ho gaya"
        }
    }

    private fun setAlarm(context: Context, hour: Int?, minute: Int, label: String): String {
        if (hour == null || hour !in 0..23 || minute !in 0..59) return "Alarm ka time samajh nahi aaya"
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Alarm laga diya %02d:%02d baje".format(hour, minute)
        } catch (e: Exception) {
            Logger.e(TAG, "Set alarm failed: ${e.message}")
            "Alarm lagane mein error ho gaya"
        }
    }

    private fun setTimer(context: Context, minutes: Int?): String {
        if (minutes == null || minutes <= 0) return "Timer ka time samajh nahi aaya"
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$minutes minute ka timer laga diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Set timer failed: ${e.message}")
            "Timer lagane mein error ho gaya"
        }
    }

    private fun getBatteryStatus(context: Context): String {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val isCharging = bm.isCharging
            if (isCharging) "Battery $level% hai, charge ho rahi hai"
            else "Battery $level% hai"
        } catch (e: Exception) {
            Logger.e(TAG, "Battery read failed: ${e.message}")
            "Battery status nahi mil paya"
        }
    }

    private fun openUrl(context: Context, url: String): String {
        if (url.isBlank()) return "Konsa website kholna hai, bataiye"
        val fullUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$url khol rahi hoon"
        } catch (e: Exception) {
            Logger.e(TAG, "Open URL failed: ${e.message}")
            "Website kholne mein error ho gaya"
        }
    }

    private fun setClipboard(context: Context, text: String): String {
        if (text.isBlank()) return "Kya copy karna hai, bataiye"
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("MYRA", text))
            "Copy kar liya"
        } catch (e: Exception) {
            Logger.e(TAG, "Clipboard set failed: ${e.message}")
            "Copy karne mein error ho gaya"
        }
    }

    /**
     * Safety-critical, no-confirm command (PDF §16 "Lock command"). Requires
     * MYRA's device-admin to already be active (Settings → Permissions →
     * Device Admin) — if it isn't, we fail loudly rather than silently
     * no-op, since a "lock" that doesn't actually lock is a safety problem.
     */
    private fun lockDevice(context: Context): String {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(context, MyraDeviceAdminReceiver::class.java)
            if (!dpm.isAdminActive(admin)) {
                return "Device admin on nahi hai, pehle Settings mein enable karo"
            }
            dpm.lockNow()
            "Lock kar diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Lock device failed: ${e.message}")
            "Lock karne mein error ho gaya"
        }
    }

    /**
     * Opens a WhatsApp chat via the wa.me deep link (reliable on every
     * WhatsApp variant, no accessibility needed to get this far) and, only
     * for CALL (never for a message send — see the WhatsApp automation
     * safety spec: a message must only ever be sent by the user's own tap,
     * never auto-tapped by the assistant), best-effort auto-taps a
     * voice/video call icon if the Accessibility Service is enabled.
     *
     * For WHATSAPP_MSG this deliberately stops at "pre-filled, waiting for
     * you to tap Send" — never taps Send itself — since that's an
     * irreversible action to a real person and this app has no
     * confirmation-gate/state-machine (WhatsAppTask, TAP_SEND behind a
     * recorded confirm) built yet to do it safely.
     */
    private suspend fun whatsAppOpenAndAssist(
        context: Context,
        nameOrNumber: String,
        message: String?,
        assistHints: List<String>
    ): String {
        if (nameOrNumber.isBlank()) return "Kaake WhatsApp karna hai, bataiye"
        val pm = context.packageManager
        val waInstalled = try {
            pm.getPackageInfo("com.whatsapp", 0) != null
        } catch (e: Exception) {
            false
        }
        if (!waInstalled) return "WhatsApp install nahi hai is phone mein"

        val number = if (nameOrNumber.any { it.isDigit() } && nameOrNumber.length >= 6) {
            nameOrNumber
        } else {
            ContactLookup.findNumber(context, nameOrNumber)
        }
        if (number.isNullOrBlank()) return "$nameOrNumber ka number nahi mila"

        val cleanNumber = number.filter { it.isDigit() || it == '+' }
        val uriStr = if (message != null) {
            "https://wa.me/$cleanNumber?text=${Uri.encode(message)}"
        } else {
            "https://wa.me/$cleanNumber"
        }

        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )

            if (!AccessibilityHelperService.isEnabled(context)) {
                return if (message != null) "$nameOrNumber ka chat khol diya, message likha hai, ab khud Send dabao"
                else "$nameOrNumber ka WhatsApp chat khol diya, call button khud dabao (Accessibility on nahi hai)"
            }

            // Give WhatsApp's own transition time to actually load the chat
            // before we go looking for anything in it (freshness matters —
            // acting on a stale/previous screen is exactly the bug class this
            // feature has to avoid).
            delay(1800)

            if (message != null) {
                // Never auto-tap Send — pre-fill only, by design (see doc comment above).
                "$nameOrNumber ko message ready kar diya, ab Send button khud dabao"
            } else {
                val root = AccessibilityHelperService.getFreshRoot()
                var tapped = false
                for (hint in assistHints) {
                    val node = NodeFinder.findClickable(root, hint)
                    if (node != null) {
                        tapped = node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                        if (tapped) break
                    }
                }
                if (tapped) "$nameOrNumber ko WhatsApp call laga rahi hoon"
                else "$nameOrNumber ka chat khol diya, call button khud dabao, mujhe nahi mila"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "WhatsApp automation failed: ${e.message}")
            "WhatsApp kholne mein error ho gaya"
        }
    }

    /**
     * Captures the current on-screen accessibility tree and hands a compact
     * summary back to Gemini (via ForegroundVoiceService.describeScreenToUser)
     * so MYRA can describe what's on screen by voice, reusing the existing
     * audio pipeline rather than building a separate local TTS/description path.
     */
    private fun readScreen(context: Context): String {
        if (!AccessibilityHelperService.isEnabled(context)) {
            return "Screen dekhne ke liye Accessibility Service on nahi hai, Settings mein enable karo"
        }
        val root = AccessibilityHelperService.getFreshRoot()
            ?: return "Abhi screen padh nahi paa rahi, dobara try karo"

        val elements = UiTreeSerializer.findClickableElements(root)
            .mapNotNull { node ->
                val label = (node.text?.toString()?.takeIf { it.isNotBlank() }
                    ?: node.contentDescription?.toString())?.trim()
                label?.takeIf { it.isNotBlank() }
            }
            .distinct()
            .take(25)

        if (elements.isEmpty()) return "Screen mein padhne layak kuch nahi mila"

        val summary = elements.joinToString(", ")
        com.myra.assistant.services.ForegroundVoiceService.instance?.describeScreenToUser(summary)
        // The actual spoken description comes back asynchronously through
        // Gemini's own audio/text reply, so we return blank here to avoid a
        // duplicate/competing broadcast.
        return ""
    }

    // =====================================================================
    // Call Tools extra (PDF §2) — answer_call / end_call
    // =====================================================================

    /**
     * Answers the currently ringing call from the main voice pipeline (as
     * opposed to the dedicated incoming-call popup in CallAssistantActivity,
     * which already handles this when it launches). Kept as a plain
     * TelecomManager call — no accessibility fallback here since, unlike a
     * WhatsApp screen, there's no reliable generic "Answer" button to find
     * outside that dedicated UI.
     */
    private fun answerCall(context: Context): String {
        return try {
            if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ANSWER_PHONE_CALLS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                return "Call answer karne ki permission nahi hai, Settings mein do"
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val telecom = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                @Suppress("DEPRECATION")
                telecom.acceptRingingCall()
                "Call utha rahi hoon"
            } else {
                "Ye Android version call answer support nahi karta"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Answer call failed: ${e.message}")
            "Call answer karne mein error ho gaya"
        }
    }

    /**
     * Ends/rejects a call. Per the WhatsApp/call automation safety spec this
     * app follows: never hang up on ambiguous input. The ONLY thing enforced
     * here in code is that a call is actually ringing/active (TelephonyManager
     * state) before acting — the "was a clear reject word spoken in the last
     * ~20s" judgment is the system prompt's job (SAFETY RULES), since that's
     * about interpreting what the person said, which happens before this
     * command token is ever produced.
     */
    private fun endCall(context: Context): String {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            val state = tm.callState
            if (state == TelephonyManager.CALL_STATE_IDLE) {
                return "Abhi koi call chal hi nahi rahi"
            }
            if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ANSWER_PHONE_CALLS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                return "Call kaatne ki permission nahi hai, Settings mein do"
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val telecom = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                @Suppress("DEPRECATION")
                telecom.endCall()
                "Call kaat diya"
            } else {
                "Ye Android version se call kaatna support nahi karta"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "End call failed: ${e.message}")
            "Call kaatne mein error ho gaya"
        }
    }

    // =====================================================================
    // Device Tools extra (PDF §4) — storage, volume, OTP
    // =====================================================================

    private fun analyzeStorage(context: Context): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = total - free
            fun gb(b: Long) = "%.1f".format(b / 1024.0 / 1024.0 / 1024.0)
            val cacheDir = context.cacheDir
            val cacheSize = cacheDir?.walkTopDown()?.sumOf { if (it.isFile) it.length() else 0L } ?: 0L
            "Storage mein $${gb(used)} GB use ho raha hai, ${gb(free)} GB free hai. Cache/temp files $${gb(cacheSize)} GB ke around hain."
                .replace("$", "")
        } catch (e: Exception) {
            Logger.e(TAG, "Analyze storage failed: ${e.message}")
            "Storage check nahi ho paya"
        }
    }

    /** Clears only MYRA's own cache/temp files — never touches other apps' data or user files. */
    private fun cleanStorage(context: Context): String {
        return try {
            var deleted = 0
            context.cacheDir?.walkBottomUp()?.forEach { f ->
                if (f.isFile && f.delete()) deleted++
            }
            context.externalCacheDir?.walkBottomUp()?.forEach { f ->
                if (f.isFile && f.delete()) deleted++
            }
            "MYRA ka cache clean kar diya, $deleted files hataye"
        } catch (e: Exception) {
            Logger.e(TAG, "Clean storage failed: ${e.message}")
            "Storage clean karne mein error ho gaya"
        }
    }

    private fun setVolumePercent(context: Context, percent: Int?): String {
        if (percent == null || percent !in 0..100) return "Volume kitna % karna hai, clearly bolo"
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            val target = (max * percent / 100.0).toInt().coerceIn(0, max)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, target, 0)
            "Volume $percent% kar diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Set volume failed: ${e.message}")
            "Volume set karne mein error ho gaya"
        }
    }

    /**
     * Explicit-only OTP readout (PDF §16 safety rule + §8). Unlike
     * readNotifications() above — which deliberately filters OTP-looking text
     * OUT — this is the one path allowed to surface it, and only because the
     * person asked for it directly this turn.
     */
    private fun readOtp(context: Context): String {
        if (!MyraNotificationListenerService.isEnabled(context)) {
            openNotificationAccessSettings(context)
            return "Notification access on nahi hai. Settings khol diya, MYRA ko allow kar do"
        }
        val otpRegex = Regex("\\b\\d{4,8}\\b")
        val hintRegex = Regex("otp|verification|code", RegexOption.IGNORE_CASE)
        val items = MyraNotificationListenerService.getRecent(10)
        val match = items.firstOrNull { hintRegex.containsMatchIn("${it.title} ${it.text}") }
        val code = match?.let { otpRegex.find("${it.title} ${it.text}")?.value }
        return if (code != null) "OTP hai $code" else "Koi recent OTP nahi mila"
    }

    // =====================================================================
    // Smart / Generative Tools (PDF §6) — on-device only. generate_project,
    // generate_image and deep_research need a paid backend (OpenAI/Tavily
    // etc.) that this app has no API key or Connectors screen for yet — not
    // implemented here, flagged to the user separately instead of faked.
    // =====================================================================

    private fun systemHealth(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val usedRamPct = (100 - (memInfo.availMem * 100 / memInfo.totalMem)).toInt()

            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

            val parts = mutableListOf("RAM $usedRamPct% use ho raha hai", "battery $battery%")
            if (memInfo.lowMemory) parts.add("phone low memory mein hai, kuch apps band karo")
            "Phone health: ${parts.joinToString(", ")}."
        } catch (e: Exception) {
            Logger.e(TAG, "System health check failed: ${e.message}")
            "Phone health check nahi ho paya"
        }
    }

    // =====================================================================
    // Files & Photos Tools (PDF §5)
    //
    // Scoped deliberately to MYRA's own app-storage workspace
    // (getExternalFilesDir()/MyraFiles), NOT the whole device's storage.
    // Android 10+ (scoped storage) does not allow one app broad read/write
    // access to arbitrary files elsewhere without MANAGE_EXTERNAL_STORAGE, a
    // special Play-Store-gated permission this app does not request — so
    // "manage any file anywhere" is out of scope, but MYRA's own workspace
    // (where files shared TO it, or created BY it, would live) works fully.
    // =====================================================================

    private fun workspaceDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "MyraFiles")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun listFiles(context: Context): String {
        val files = workspaceDir(context).listFiles()?.filter { it.isFile } ?: emptyList()
        if (files.isEmpty()) return "MYRA ke workspace mein koi file nahi hai"
        return "Files: ${files.joinToString(", ") { it.name }}"
    }

    private fun searchFiles(context: Context, query: String): String {
        if (query.isBlank()) return "Kya dhundna hai, bataiye"
        val matches = workspaceDir(context).listFiles()
            ?.filter { it.isFile && it.name.contains(query, ignoreCase = true) }
            ?: emptyList()
        return if (matches.isEmpty()) "\"$query\" naam ki koi file nahi mili"
        else "Mili: ${matches.joinToString(", ") { it.name }}"
    }

    private fun deleteFile(context: Context, name: String): String {
        if (name.isBlank()) return "Kaunsi file delete karni hai, bataiye"
        val file = File(workspaceDir(context), name)
        return if (!file.exists()) "\"$name\" file nahi mili"
        else if (file.delete()) "\"$name\" delete kar diya"
        else "\"$name\" delete nahi ho payi"
    }

    /**
     * Deletes the most recent photo(s) from the device gallery. On Android
     * 10+, deleting media another app created (or that the system owns)
     * generally requires a user-confirmed system dialog
     * (MediaStore.createDeleteRequest), which needs an Activity to launch and
     * receive the result — not available from this background command
     * pipeline. We delete what we can (rows this app can directly remove)
     * and report honestly rather than claiming success.
     */
    private fun deletePhoto(context: Context, count: Int): String {
        val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        if (!hasPermission) return "Photos dekhne ki permission nahi hai, Settings mein do"

        return try {
            val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
            val cursor = context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )
            var deleted = 0
            var failed = 0
            cursor?.use {
                val idIdx = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (it.moveToNext() && (deleted + failed) < count) {
                    val id = it.getLong(idIdx)
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        if (context.contentResolver.delete(uri, null, null) > 0) deleted++ else failed++
                    } catch (e: SecurityException) {
                        failed++ // needs a user-confirmed system dialog we can't launch from here
                    }
                }
            }
            when {
                deleted > 0 && failed == 0 -> "$deleted photo delete kar diya"
                deleted > 0 -> "$deleted photo delete hui, $failed ke liye phone khud confirmation maangega (Gallery app se delete karo)"
                else -> "Photo delete nahi ho payi, ho sakta hai phone confirmation maang raha ho — Gallery app se try karo"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Delete photo failed: ${e.message}")
            "Photo delete karne mein error ho gaya"
        }
    }

    private fun zipFolder(context: Context, folderName: String): String {
        if (folderName.isBlank()) return "Kaunsa folder zip karna hai, bataiye"
        val src = File(workspaceDir(context), folderName)
        if (!src.exists() || !src.isDirectory) return "\"$folderName\" folder nahi mila"
        val zipFile = File(workspaceDir(context), "$folderName.zip")
        return try {
            ZipOutputStream(zipFile.outputStream()).use { zos ->
                src.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entryName = file.relativeTo(src).path
                    zos.putNextEntry(ZipEntry(entryName))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            "\"$folderName.zip\" ban gaya"
        } catch (e: Exception) {
            Logger.e(TAG, "Zip folder failed: ${e.message}")
            "Zip karne mein error ho gaya"
        }
    }

    private fun renameFile(context: Context, name: String, newName: String): String {
        if (name.isBlank() || newName.isBlank()) return "Kaunsi file aur naya naam kya, dono bataiye"
        val src = File(workspaceDir(context), name)
        if (!src.exists()) return "\"$name\" file nahi mili"
        val dst = File(workspaceDir(context), newName)
        return if (src.renameTo(dst)) "\"$name\" ka naam \"$newName\" kar diya"
        else "Naam change nahi ho paya"
    }

    private fun manageFolder(context: Context, action: String, name: String): String {
        if (name.isBlank()) return "Kaunsa folder, bataiye"
        val dir = File(workspaceDir(context), name)
        return when (action.trim().lowercase()) {
            "create", "banao", "banaye" -> if (dir.mkdirs()) "\"$name\" folder ban gaya" else "Folder pehle se hai ya ban nahi paya"
            "delete", "hatao" -> if (dir.deleteRecursively()) "\"$name\" folder delete kar diya" else "\"$name\" folder nahi mila"
            "list" -> {
                val items = dir.listFiles()?.map { it.name } ?: emptyList()
                if (items.isEmpty()) "\"$name\" khaali hai" else "\"$name\" mein: ${items.joinToString(", ")}"
            }
            else -> "Folder ke saath kya karna hai (create/delete/list) clearly bolo"
        }
    }

    private fun shareFile(context: Context, name: String, appHint: String): String {
        if (name.isBlank()) return "Kaunsi file share karni hai, bataiye"
        val file = File(workspaceDir(context), name)
        if (!file.exists()) return "\"$name\" file nahi mili"
        return try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = context.contentResolver.getType(uri) ?: "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (appHint.isNotBlank()) {
                    val pkg = when {
                        appHint.contains("whatsapp", true) -> "com.whatsapp"
                        appHint.contains("telegram", true) -> "org.telegram.messenger"
                        appHint.contains("gmail", true) -> "com.google.android.gm"
                        else -> null
                    }
                    if (pkg != null) setPackage(pkg)
                }
            }
            context.startActivity(if (intent.`package` != null) intent else Intent.createChooser(intent, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "\"$name\" share kar rahi hoon"
        } catch (e: Exception) {
            Logger.e(TAG, "Share file failed: ${e.message}")
            "Share karne mein error ho gaya"
        }
    }

    // =====================================================================
    // Maps & "My World" Tools (PDF §9)
    //
    // Uses plain geo:/google.navigation: intents (no Maps SDK/API key needed)
    // and Android's own LocationManager (no play-services-location dependency
    // — adding a new Gradle dependency here would be riskier to get right
    // blind than reusing what's already on the classpath). Saved
    // parking/home/office places live in SharedPrefs.
    // =====================================================================

    private fun hasLocationPermission(context: Context): Boolean =
        ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Best last-known fix from whichever provider has one — no active GPS session (keeps this instant, no callback plumbing needed for a voice command). */
    private fun lastKnownLocation(context: Context): Location? {
        if (!hasLocationPermission(context)) return null
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.getProviders(true)
                .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (e: SecurityException) { null } }
                .maxByOrNull { it.time }
        } catch (e: Exception) {
            Logger.e(TAG, "Location fetch failed: ${e.message}")
            null
        }
    }

    private fun openMap(context: Context): String {
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Map khol diya"
        } catch (e: Exception) {
            "Maps app nahi mila"
        }
    }

    private fun navigateTo(context: Context, destination: String): String {
        if (destination.isBlank()) return "Kahan jaana hai, bataiye"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(destination)}"))
                    .setPackage("com.google.android.apps.maps")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "$destination ka rasta dikha rahi hoon"
        } catch (e: Exception) {
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(destination)}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "$destination dikha rahi hoon"
            } catch (e2: Exception) {
                "Maps app nahi mila"
            }
        }
    }

    private fun savedPlacePrefs(context: Context) = context.getSharedPreferences("myra_places", Context.MODE_PRIVATE)

    private fun navigateToSavedPlace(context: Context, place: String): String {
        val key = place.trim().lowercase()
        val saved = savedPlacePrefs(context).getString("place_$key", null)
            ?: return "\"$place\" save nahi kiya hua, pehle address batao"
        return navigateTo(context, saved)
    }

    private fun getLocation(context: Context): String {
        if (!hasLocationPermission(context)) return "Location permission nahi hai, Settings mein do"
        val loc = lastKnownLocation(context) ?: return "Abhi location nahi mil paayi, GPS on karke try karo"
        return "Aap yahan hain: %.5f, %.5f".format(loc.latitude, loc.longitude)
    }

    private fun getDistanceToSavedPlace(context: Context, place: String): String {
        if (!hasLocationPermission(context)) return "Location permission nahi hai, Settings mein do"
        val key = place.trim().lowercase()
        val savedLatLng = savedPlacePrefs(context).getString("latlng_$key", null)
            ?: return "\"$place\" ki saved location nahi mili"
        val loc = lastKnownLocation(context) ?: return "Abhi current location nahi mil paayi"
        return try {
            val parts = savedLatLng.split(",")
            val target = Location("saved").apply {
                latitude = parts[0].toDouble()
                longitude = parts[1].toDouble()
            }
            val km = loc.distanceTo(target) / 1000.0
            "$place %.1f km door hai".format(km)
        } catch (e: Exception) {
            "\"$place\" ki distance calculate nahi ho payi"
        }
    }

    private fun getParkingLocation(context: Context): String {
        val saved = savedPlacePrefs(context).getString("parking_latlng", null)
            ?: return "Koi parking location save nahi hai"
        return try {
            val parts = saved.split(",")
            "Aapki gaadi yahan park hai: ${parts[0]}, ${parts[1]}"
        } catch (e: Exception) {
            "Parking location padhne mein error ho gaya"
        }
    }

    private fun saveParking(context: Context): String {
        if (!hasLocationPermission(context)) return "Location permission nahi hai, Settings mein do"
        val loc = lastKnownLocation(context) ?: return "Abhi location nahi mil payi, GPS on karke try karo"
        savedPlacePrefs(context).edit()
            .putString("parking_latlng", "${loc.latitude},${loc.longitude}")
            .apply()
        return "Parking location save kar li"
    }

    private fun searchNearby(context: Context, query: String): String {
        if (query.isBlank()) return "Kya dhundna hai (ATM, hospital, etc), bataiye"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(query)}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Aas-paas $query dhoondh rahi hoon"
        } catch (e: Exception) {
            "Maps app nahi mila"
        }
    }

    /**
     * Smart modes (Driving/Sleep/Work/Game) are recorded as a simple prefs
     * flag other parts of the app (e.g. notification filtering) can read
     * later — this does not yet change ringer/DND behavior on its own, since
     * that needs Notification-Policy-Access, a separate special permission
     * not wired up in this pass.
     */
    private fun setSmartMode(context: Context, mode: String): String {
        val normalized = mode.trim().lowercase()
        if (normalized !in setOf("driving", "sleep", "work", "game", "off")) {
            return "Kaunsa mode (driving/sleep/work/game), clearly bolo"
        }
        context.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE).edit()
            .putString("smart_mode", normalized)
            .apply()
        return if (normalized == "off") "Smart mode off kar diya" else "$normalized mode on kar diya"
    }

    // =====================================================================
    // Search, Browser & App-Launch Tools (PDF §11)
    // =====================================================================

    private fun searchGoogle(context: Context, query: String): String {
        if (query.isBlank()) return "Kya search karna hai, bataiye"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, query)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "\"$query\" search kar rahi hoon"
        } catch (e: Exception) {
            openBrowser(context, "https://www.google.com/search?q=${Uri.encode(query)}")
        }
    }

    private fun openBrowser(context: Context, url: String): String {
        val target = if (url.isBlank()) "https://www.google.com"
        else if (url.startsWith("http://") || url.startsWith("https://")) url
        else "https://$url"
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Browser khol diya"
        } catch (e: Exception) {
            "Browser nahi mila"
        }
    }

    // =====================================================================
    // Communication Tools extra (PDF §1) — email + emergency SOS
    // =====================================================================

    private fun openEmailInbox(context: Context): String {
        return try {
            val gmail = context.packageManager.getLaunchIntentForPackage("com.google.android.gm")
            if (gmail != null) {
                context.startActivity(gmail.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Inbox khol diya"
            } else {
                context.startActivity(Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_EMAIL)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                "Email app khol diya"
            }
        } catch (e: Exception) {
            "Email app nahi mila"
        }
    }

    private fun composeEmail(context: Context, to: String, subject: String, body: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Email ready kar diya, ab aap khud Send dabao"
        } catch (e: Exception) {
            "Email app nahi mila"
        }
    }

    /**
     * Sends an SOS SMS (with location if available) to the saved prime/
     * trusted contact. This is the one place an SMS goes out without a
     * separate per-message confirmation, because the PDF explicitly scopes
     * this to genuine emergencies ("SOS", "main khatre mein hoon") — the
     * system prompt is responsible for only emitting this token when the
     * person's words actually mean that, not for casual use.
     */
    private fun sendEmergencyAlert(context: Context, message: String): String {
        val prefs = context.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val primeNumber = prefs.getString("prime_number", "")?.trim() ?: ""
        if (primeNumber.isBlank()) return "Koi emergency contact save nahi hai, pehle Settings mein Prime Contact set karo"

        val loc = lastKnownLocation(context)
        val locationText = if (loc != null) " Location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}" else ""
        val body = "EMERGENCY: ${message.ifBlank { "Madad chahiye" }}.$locationText"

        return try {
            @Suppress("DEPRECATION")
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(primeNumber, null, body, null, null)
            "Emergency alert bhej diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Emergency alert failed: ${e.message}")
            "Emergency alert bhejne mein error ho gaya"
        }
    }

    // =====================================================================
    // Visual Social Media Agent (Instagram/Facebook PDF) — SCOPED DOWN.
    //
    // The source spec asks for a full closed-loop UI-automation agent
    // (screen observer, target resolver, state machine, real-device-verified
    // selectors) that auto-navigates to the Share/Post button and stops only
    // for a confirmation tap before publishing. That cannot be built
    // honestly here: Instagram/Facebook's exact button ids/labels drift by
    // version and the spec itself says every selector must be verified on a
    // real device before trusting it — something not possible from this
    // environment (no device, no compiler).
    //
    // What IS built, safely: MYRA resolves the most recently shared-to-MYRA
    // photo/video (via ShareInboxReceiverActivity — the person had to
    // explicitly share it in first, exactly like the spec's media handoff
    // rule) and hands it to Instagram/Facebook's own share flow via an
    // explicit ACTION_SEND intent, filtering out known-dangerous share
    // targets (DM/group/message) by component class name the same way the
    // spec's Lesson 6 describes. It never taps anything inside those apps —
    // captioning and the final Post/Share tap are always the person's own,
    // which trivially satisfies "never auto-publish" because there is no
    // publish code path here at all.
    // =====================================================================

    private fun postToSocialApp(context: Context, packageName: String, platformLabel: String, caption: String): String {
        val installed = try {
            context.packageManager.getPackageInfo(packageName, 0) != null
        } catch (e: Exception) {
            false
        }
        if (!installed) return "$platformLabel install nahi hai is phone mein"

        val media = com.myra.assistant.utils.MediaShareInbox.latestRecent(context)
            ?: return "Pehle Gallery se photo/video 'Share -> MYRA' karo, tabhi $platformLabel par post kar paungi"

        val file = File(media.filePath)
        if (!file.exists()) return "Shared media nahi mila, phirse share karo"

        return try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

            // Lesson 6 from the spec: pick a share target by component class
            // name, hard-excluding anything that looks like a direct
            // message/group/profile-picture target, rather than trusting
            // localized labels or falling back to a generic chooser.
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = media.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                if (caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val dangerousHints = listOf("direct", "group", "profile", "message", "chat", "inbox", "messenger")
            val candidates = context.packageManager.queryIntentActivities(sendIntent, 0)
                .filter { it.activityInfo.packageName == packageName }
                .filterNot { info -> dangerousHints.any { info.activityInfo.name.lowercase().contains(it) } }

            val chosen = candidates.firstOrNull()
                ?: return "$platformLabel mein safe share target nahi mila"

            sendIntent.setClassName(chosen.activityInfo.packageName, chosen.activityInfo.name)
            context.startActivity(sendIntent)

            "$platformLabel khol diya, photo ready hai — caption check karke aap khud Post/Share dabao"
        } catch (e: Exception) {
            Logger.e(TAG, "$platformLabel post failed: ${e.message}")
            "$platformLabel kholne mein error ho gaya"
        }
    }

    private fun toggleFlashlight(context: Context, on: Boolean) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                cm.setTorchMode(cameraId, on)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Flashlight error: ${e.message}")
        }
    }
}
