package com.myra.assistant.ai

import android.app.AlarmManager
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.telephony.SmsManager
import com.myra.assistant.apps.AppLauncher
import com.myra.assistant.models.CommandType
import com.myra.assistant.models.VoiceCommand
import com.myra.assistant.service.MyraDeviceAdminReceiver
import com.myra.assistant.service.MyraNotificationListenerService
import com.myra.assistant.service.SmartAccessibilityEngine
import com.myra.assistant.utils.ContactLookup
import com.myra.assistant.utils.Logger

object DynamicDecisionEngine {
    private val TAG = "DECISION"

    suspend fun execute(context: Context, command: VoiceCommand): String {
        Logger.d(TAG, "Executing: ${command.type} - ${command.raw}")

        return when (command.type) {
            CommandType.OPEN_APP -> {
                val app = command.args["app"] ?: ""
                if (AppLauncher.launch(context, app)) "Opening $app"
                else "App not found: $app"
            }

            CommandType.VOLUME_UP -> {
                SmartAccessibilityEngine.execute("VOLUME_UP")
                "Volume badha diya"
            }

            CommandType.VOLUME_DOWN -> {
                SmartAccessibilityEngine.execute("VOLUME_DOWN")
                "Volume kam kiya"
            }

            CommandType.FLASHLIGHT_ON -> {
                toggleFlashlight(context, true)
                "Torch on kar diya"
            }

            CommandType.FLASHLIGHT_OFF -> {
                toggleFlashlight(context, false)
                "Torch off kar diya"
            }

            CommandType.WHATSAPP_CALL -> {
                SmartAccessibilityEngine.execute("WHATSAPP_CALL ${command.args["name"] ?: ""}")
                "WhatsApp call kar rahi hoon"
            }

            CommandType.WHATSAPP_MSG -> {
                val name = command.args["name"] ?: ""
                val msg = command.args["message"] ?: ""
                SmartAccessibilityEngine.execute("WHATSAPP_MSG $name $msg")
                "Message bhej rahi hoon"
            }

            CommandType.YOUTUBE_PLAY -> {
                val query = command.args["query"] ?: ""
                SmartAccessibilityEngine.execute("YOUTUBE_PLAY $query")
                "YouTube play kar rahi hoon"
            }

            CommandType.CALL -> {
                SmartAccessibilityEngine.execute("CALL ${command.args["name"] ?: ""}")
                "Call kar rahi hoon"
            }

            // ---- Device Tools (PDF §4) + lookup_contact (PDF §2) ----

            CommandType.SMS -> sendSms(context, command.args["name"] ?: "", command.args["message"] ?: "")

            CommandType.LOOKUP_CONTACT -> {
                val name = command.args["name"] ?: ""
                val number = ContactLookup.findNumber(context, name)
                if (number != null) "$name ka number hai $number"
                else "$name ka number nahi mila"
            }

            CommandType.SET_ALARM -> setAlarm(
                context,
                command.args["hour"]?.toIntOrNull(),
                command.args["minute"]?.toIntOrNull() ?: 0,
                command.args["label"] ?: ""
            )

            CommandType.SET_TIMER -> setTimer(context, command.args["minutes"]?.toIntOrNull())

            CommandType.GET_BATTERY -> getBatteryStatus(context)

            CommandType.OPEN_URL -> openUrl(context, command.args["url"] ?: "")

            CommandType.SET_CLIPBOARD -> setClipboard(context, command.args["text"] ?: "")

            // Safety-critical: executes instantly, no confirmation (PDF §16).
            CommandType.LOCK_DEVICE -> lockDevice(context)

            // ---- Notification Tools (PDF §8) + Media Tools (PDF §3) ----
            CommandType.READ_NOTIFICATIONS -> readNotifications(context)
            CommandType.CLEAR_NOTIFICATIONS -> clearNotifications(context)
            CommandType.READ_MISSED_CALLS -> readMissedCalls(context)
            CommandType.MEDIA_CONTROL -> mediaControl(context, command.args["action"] ?: "")

            else -> ""
        }
    }

    private fun readNotifications(context: Context): String {
        if (!MyraNotificationListenerService.isEnabled(context)) {
            openNotificationAccessSettings(context)
            return "Notification access on nahi hai. Settings khol diya, MYRA ko allow kar do"
        }
        val items = MyraNotificationListenerService.getRecent(5)
        if (items.isEmpty()) return "Koi naya notification nahi hai"
        // Deliberately skip anything that looks like an OTP: PDF §16 says OTPs
        // are only read on an explicit "OTP batao", never as part of a
        // general notification readout.
        val otpRegex = Regex("\\b\\d{4,8}\\b.*(otp|code|verification)|(otp|code|verification).*\\b\\d{4,8}\\b", RegexOption.IGNORE_CASE)
        val safe = items.filterNot { otpRegex.containsMatchIn("${it.title} ${it.text}") }
        if (safe.isEmpty()) return "Koi naya notification nahi hai"
        return safe.joinToString(". ") { "${it.appLabel}: ${it.title}. ${it.text}".trim() }
    }

    private fun clearNotifications(context: Context): String {
        if (!MyraNotificationListenerService.isEnabled(context)) {
            openNotificationAccessSettings(context)
            return "Notification access on nahi hai. Settings khol diya, MYRA ko allow kar do"
        }
        return if (MyraNotificationListenerService.clearAllNotifications()) "Notifications clear kar diye"
        else "Notification service abhi connected nahi hai, thodi der baad try karo"
    }

    private fun openNotificationAccessSettings(context: Context) {
        try {
            context.startActivity(
                Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Logger.e(TAG, "Could not open notification access settings: ${e.message}")
        }
    }

    private fun readMissedCalls(context: Context): String {
        return try {
            val cursor = context.contentResolver.query(
                android.provider.CallLog.Calls.CONTENT_URI,
                arrayOf(
                    android.provider.CallLog.Calls.CACHED_NAME,
                    android.provider.CallLog.Calls.NUMBER
                ),
                "${android.provider.CallLog.Calls.TYPE} = ?",
                arrayOf(android.provider.CallLog.Calls.MISSED_TYPE.toString()),
                "${android.provider.CallLog.Calls.DATE} DESC"
            ) ?: return "Call log access nahi mila"

            val names = mutableListOf<String>()
            cursor.use {
                val nameIdx = it.getColumnIndex(android.provider.CallLog.Calls.CACHED_NAME)
                val numIdx = it.getColumnIndex(android.provider.CallLog.Calls.NUMBER)
                while (it.moveToNext() && names.size < 5) {
                    val name = if (nameIdx >= 0) it.getString(nameIdx) else null
                    val number = if (numIdx >= 0) it.getString(numIdx) else null
                    names.add(name?.takeIf { n -> n.isNotBlank() } ?: number ?: "Unknown")
                }
            }
            if (names.isEmpty()) "Koi missed call nahi hai"
            else "Missed calls: ${names.joinToString(", ")}"
        } catch (e: SecurityException) {
            "Call log ki permission nahi hai"
        } catch (e: Exception) {
            Logger.e(TAG, "Missed calls read failed: ${e.message}")
            "Missed calls padhne mein error ho gaya"
        }
    }

    private fun mediaControl(context: Context, action: String): String {
        val keyCode = when (action.trim().uppercase()) {
            "PLAY", "PAUSE", "PLAY_PAUSE" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "NEXT" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
            "PREVIOUS", "PREV" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "STOP" -> android.view.KeyEvent.KEYCODE_MEDIA_STOP
            else -> return "Media command samajh nahi aaya"
        }
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
            "Ho gaya"
        } catch (e: Exception) {
            Logger.e(TAG, "Media control failed: ${e.message}")
            "Media control mein error ho gaya"
        }
    }

    private fun sendSms(context: Context, nameOrNumber: String, message: String): String {
        if (message.isBlank()) return "Kya message bhejna hai, bataiye"
        val number = if (nameOrNumber.any { it.isDigit() } && nameOrNumber.length >= 6) {
            nameOrNumber
        } else {
            ContactLookup.findNumber(context, nameOrNumber)
        }
        if (number.isNullOrBlank()) return "$nameOrNumber ka number nahi mila"
        return try {
            @Suppress("DEPRECATION")
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(number, null, message, null, null)
            "SMS bhej diya $nameOrNumber ko"
        } catch (e: Exception) {
            Logger.e(TAG, "SMS send failed: ${e.message}")
            "SMS bhejne mein error ho gaya"
        }
    }

    private fun setAlarm(context: Context, hour: Int?, minute: Int, label: String): String {
        if (hour == null || hour !in 0..23 || minute !in 0..59) return "Alarm ka time samajh nahi aaya"
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Alarm laga diya %02d:%02d baje".format(hour, minute)
        } catch (e: Exception) {
            Logger.e(TAG, "Set alarm failed: ${e.message}")
            "Alarm lagane mein error ho gaya"
        }
    }

    private fun setTimer(context: Context, minutes: Int?): String {
        if (minutes == null || minutes <= 0) return "Timer ka time samajh nahi aaya"
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$minutes minute ka timer laga diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Set timer failed: ${e.message}")
            "Timer lagane mein error ho gaya"
        }
    }

    private fun getBatteryStatus(context: Context): String {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val isCharging = bm.isCharging
            if (isCharging) "Battery $level% hai, charge ho rahi hai"
            else "Battery $level% hai"
        } catch (e: Exception) {
            Logger.e(TAG, "Battery read failed: ${e.message}")
            "Battery status nahi mil paya"
        }
    }

    private fun openUrl(context: Context, url: String): String {
        if (url.isBlank()) return "Konsa website kholna hai, bataiye"
        val fullUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$url khol rahi hoon"
        } catch (e: Exception) {
            Logger.e(TAG, "Open URL failed: ${e.message}")
            "Website kholne mein error ho gaya"
        }
    }

    private fun setClipboard(context: Context, text: String): String {
        if (text.isBlank()) return "Kya copy karna hai, bataiye"
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("MYRA", text))
            "Copy kar liya"
        } catch (e: Exception) {
            Logger.e(TAG, "Clipboard set failed: ${e.message}")
            "Copy karne mein error ho gaya"
        }
    }

    /**
     * Safety-critical, no-confirm command (PDF §16 "Lock command"). Requires
     * MYRA's device-admin to already be active (Settings → Permissions →
     * Device Admin) — if it isn't, we fail loudly rather than silently
     * no-op, since a "lock" that doesn't actually lock is a safety problem.
     */
    private fun lockDevice(context: Context): String {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(context, MyraDeviceAdminReceiver::class.java)
            if (!dpm.isAdminActive(admin)) {
                return "Device admin on nahi hai, pehle Settings mein enable karo"
            }
            dpm.lockNow()
            "Lock kar diya"
        } catch (e: Exception) {
            Logger.e(TAG, "Lock device failed: ${e.message}")
            "Lock karne mein error ho gaya"
        }
    }

    private fun toggleFlashlight(context: Context, on: Boolean) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                cm.setTorchMode(cameraId, on)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Flashlight error: ${e.message}")
        }
    }
}
