package com.myra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AccessibilityHelperService : AccessibilityService() {

    companion object {
        private const val TAG = "MYRA_ACCESS"

        var instance: AccessibilityHelperService? = null
        var currentRoot: AccessibilityNodeInfo? = null

        fun isEnabled(context: Context): Boolean {
            if (instance != null) return true   // really bound = enabled, whatever the settings string says
            val expectedComponentName =
                ComponentName(
                    context,
                    AccessibilityHelperService::class.java
                )

            val enabledServicesSetting =
                Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false

            val colonSplitter =
                TextUtils.SimpleStringSplitter(':')

            colonSplitter.setString(enabledServicesSetting)

            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()

                val enabledService =
                    ComponentName.unflattenFromString(
                        componentNameString
                    )

                if (enabledService == expectedComponentName) {
                    return true
                }
            }

            return false
        }

        /** True only when Android has really bound the service (not just "listed as enabled"). */
        fun isConnected(): Boolean = instance != null

        fun getFreshRoot(): AccessibilityNodeInfo? {
            return instance?.rootInActiveWindow ?: currentRoot
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        instance = this
        SmartAccessibilityEngine.service = this

        // IMPORTANT: modify the config Android already loaded from accessibility_service_config.xml.
        // The old code assigned a brand-new AccessibilityServiceInfo(), which REPLACED the XML and
        // silently lost canRetrieveWindowContent / canPerformGestures - so MYRA could not read the
        // screen or tap, even though Accessibility looked "on".
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            info.notificationTimeout = 50
            serviceInfo = info
        } catch (e: Exception) {
            Log.e(TAG, "serviceInfo update failed: ${e.message}")
        }

        currentRoot = rootInActiveWindow

        Log.d(TAG, "==============================")
        Log.d(TAG, "MYRA ACCESSIBILITY CONNECTED")
        Log.d(TAG, "==============================")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            currentRoot = rootInActiveWindow
        }
        com.myra.assistant.accessibility.AccessibilityEventManager.onEvent(event)
    }

    override fun onInterrupt() {
        Log.d(TAG, "SERVICE INTERRUPTED")
    }

    override fun onDestroy() {
        super.onDestroy()

        instance = null
        currentRoot = null
        SmartAccessibilityEngine.service = null

        Log.d(TAG, "SERVICE DESTROYED")
    }
}