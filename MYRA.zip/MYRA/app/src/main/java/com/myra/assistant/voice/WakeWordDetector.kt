package com.myra.assistant.voice

import android.content.Context
import com.myra.assistant.utils.Logger
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Listens for "Hey Myra" on-device (Vosk), fed with the same 16 kHz mic chunks the voice service already records,
 * so there is only ONE microphone stream. Nothing here is sent to the internet.
 *
 * Recognition runs on its own thread; [feed] never blocks the mic thread (if the recognizer falls behind,
 * the oldest-unprocessed audio is simply dropped).
 */
class WakeWordDetector(
    private val ctx: Context,
    private val onWake: () -> Unit,
    private val onError: (String) -> Unit
) {
    private val TAG = "WAKE"
    private val queue = LinkedBlockingQueue<ByteArray>(150)   // ~6 s of audio
    @Volatile private var running = false
    @Volatile private var resetRequested = false
    @Volatile private var cooldownUntil = 0L
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var model: Model? = null
            var rec: Recognizer? = null
            try {
                model = Model(WakeWordModel.dir(ctx).absolutePath)
                rec = Recognizer(model, 16000.0f, WakeWordMatcher.grammar)
                Logger.d(TAG, "wake engine ready")
                var lastPartial = ""
                while (running && !Thread.currentThread().isInterrupted) {
                    val data = queue.poll(250, TimeUnit.MILLISECONDS) ?: continue
                    if (resetRequested) { resetRequested = false; rec.reset(); lastPartial = "" }
                    val text = if (rec.acceptWaveForm(data, data.size)) {
                        lastPartial = ""
                        JSONObject(rec.getResult()).optString("text")
                    } else {
                        // Partial results fire the moment "hey myra" has been heard - no waiting for a pause.
                        val p = JSONObject(rec.getPartialResult()).optString("partial")
                        if (p == lastPartial) "" else { lastPartial = p; p }
                    }
                    if (text.isNotEmpty() && WakeWordMatcher.matches(text) && System.currentTimeMillis() >= cooldownUntil) {
                        cooldownUntil = System.currentTimeMillis() + 2500
                        Logger.d(TAG, "wake word heard: \"$text\"")
                        rec.reset()
                        lastPartial = ""
                        queue.clear()
                        onWake()
                    }
                }
            } catch (e: InterruptedException) {
                // stopped
            } catch (e: Throwable) {
                // Throwable on purpose: a missing native library is an Error, not an Exception.
                Logger.e(TAG, "wake engine failed: ${e.message}", e)
                if (running) onError(e.message ?: e.javaClass.simpleName)
            } finally {
                try { rec?.close() } catch (_: Throwable) {}
                try { model?.close() } catch (_: Throwable) {}
            }
        }.also {
            it.name = "MYRA_WakeThread"
            it.isDaemon = true
            it.start()
        }
    }

    /** Mic chunk (16 kHz mono PCM16). Cheap and non-blocking. */
    fun feed(chunk: ByteArray) {
        if (running) queue.offer(chunk)
    }

    /** Forget half-heard words (call when going back to standby). */
    fun reset() {
        queue.clear()
        resetRequested = true
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        queue.clear()
    }
}
