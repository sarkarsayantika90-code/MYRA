package com.myra.admin

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Defaults ship in the app, but all three can be changed in Settings - so the app never needs a rebuild. */
object Config {
    private const val DEF_API_KEY = "AIzaSyDeRgRglK6lyAtcpJBdZD5l-hoGfMnm4xs"
    private const val DEF_DB = "https://sayantika-afefe-default-rtdb.firebaseio.com"
    private const val DEF_ADMIN = "anikmondal71001@gmail.com"

    @Volatile var apiKey = DEF_API_KEY
    @Volatile var db = DEF_DB
    @Volatile var admin = DEF_ADMIN

    private fun p(ctx: Context) = ctx.getSharedPreferences("admin_cfg", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val pr = p(ctx)
        apiKey = pr.getString("apiKey", null)?.takeIf { it.isNotBlank() } ?: DEF_API_KEY
        db = pr.getString("db", null)?.takeIf { it.isNotBlank() } ?: DEF_DB
        admin = pr.getString("admin", null)?.takeIf { it.isNotBlank() } ?: DEF_ADMIN
    }

    fun save(ctx: Context, key: String, dbUrl: String, adminEmail: String) {
        p(ctx).edit().putString("apiKey", key.trim()).putString("db", dbUrl.trim().trimEnd('/')).putString("admin", adminEmail.trim().lowercase()).apply()
        load(ctx)
    }

    fun resetDefaults(ctx: Context) { p(ctx).edit().clear().apply(); load(ctx) }
}

class HttpError(val code: Int, val body: String) : Exception("HTTP $code $body")

object Http {
    fun request(method: String, url: String, body: String?, contentType: String = "application/json"): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 25000
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }
}

/** Firebase email/password session for the admin account. Stored on this phone only. */
object Auth {
    private fun p(ctx: Context) = ctx.getSharedPreferences("admin_session", Context.MODE_PRIVATE)

    fun email(ctx: Context): String = p(ctx).getString("email", "") ?: ""
    fun isLoggedIn(ctx: Context) = !p(ctx).getString("refresh", null).isNullOrBlank() && email(ctx).equals(Config.admin, true)

    /** Blocking. Throws an Exception with a readable message. */
    fun signIn(ctx: Context, email: String, password: String) {
        if (!email.equals(Config.admin, true)) throw Exception("This app is only for ${Config.admin}")
        val body = JSONObject().put("email", email).put("password", password).put("returnSecureToken", true).toString()
        val j = try {
            JSONObject(Http.request("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${Config.apiKey}", body))
        } catch (e: HttpError) { throw Exception(friendly(e.body)) }
        save(ctx, email, j.getString("idToken"), j.getString("refreshToken"), j.optString("expiresIn", "3600").toLongOrNull() ?: 3600L)
    }

    private fun save(ctx: Context, email: String, id: String, refresh: String, expiresIn: Long) {
        p(ctx).edit().putString("email", email).putString("id", id).putString("refresh", refresh)
            .putLong("exp", System.currentTimeMillis() + expiresIn * 1000 - 60_000).apply()
    }

    fun friendly(raw: String): String {
        val m = try { JSONObject(raw).getJSONObject("error").getString("message") } catch (_: Exception) { raw }
        return when {
            m.contains("INVALID_LOGIN") || m.contains("INVALID_PASSWORD") ->
                "Wrong password, or this account has no password yet (it was made with Google). Open MYRA > Settings > Account and set a password first."
            m.contains("EMAIL_NOT_FOUND") -> "No account with this email."
            m.contains("TOO_MANY") -> "Too many attempts. Wait a few minutes."
            m.contains("USER_DISABLED") -> "This account is disabled."
            else -> m.take(160)
        }
    }

    /** Blocking. A valid ID token, refreshed when needed. */
    @Synchronized
    fun token(ctx: Context): String {
        val pr = p(ctx)
        val id = pr.getString("id", null)
        if (id != null && System.currentTimeMillis() < pr.getLong("exp", 0L)) return id
        val refresh = pr.getString("refresh", null) ?: throw Exception("Please log in again")
        val j = try {
            JSONObject(Http.request("POST", "https://securetoken.googleapis.com/v1/token?key=${Config.apiKey}",
                "grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(refresh, "UTF-8"), "application/x-www-form-urlencoded"))
        } catch (e: HttpError) { logout(ctx); throw Exception("Session expired - log in again") }
        save(ctx, email(ctx), j.getString("id_token"), j.getString("refresh_token"), j.optString("expires_in", "3600").toLongOrNull() ?: 3600L)
        return j.getString("id_token")
    }

    fun logout(ctx: Context) { p(ctx).edit().clear().apply() }
}

/** Realtime Database over REST. All calls are blocking - run them off the main thread. */
object Db {
    private fun url(ctx: Context, path: String, query: String = ""): String =
        "${Config.db}/$path.json?auth=${Auth.token(ctx)}" + if (query.isEmpty()) "" else "&$query"

    private fun call(method: String, ctx: Context, path: String, body: String? = null, query: String = ""): String = try {
        Http.request(method, url(ctx, path, query), body)
    } catch (e: HttpError) {
        throw Exception(if (e.code == 401 || e.code == 403) "Permission denied. Is the admin email verified, and are the database rules published?" else "Server error ${e.code}")
    }

    fun getObject(ctx: Context, path: String, query: String = ""): JSONObject {
        val raw = call("GET", ctx, path, null, query).trim()
        return if (raw == "null" || raw.isEmpty() || !raw.startsWith("{")) JSONObject() else JSONObject(raw)
    }

    /** Only the child names of a node ({"uid": true}) - cheap even for thousands of users. */
    fun keys(ctx: Context, path: String): Set<String> = getObject(ctx, path, "shallow=true").keys().asSequence().toSet()

    fun put(ctx: Context, path: String, value: Any?) { call("PUT", ctx, path, toJson(value)) }
    fun delete(ctx: Context, path: String) { call("DELETE", ctx, path) }

    fun toJson(v: Any?): String = when (v) {
        null -> "null"
        is String -> JSONObject.quote(v)
        is Boolean, is Int, is Long, is Double -> v.toString()
        else -> v.toString()      // JSONObject / JSONArray
    }

    fun audit(ctx: Context, action: String, target: String = "") {
        try {
            put(ctx, "audit/${System.currentTimeMillis()}",
                JSONObject().put("by", Auth.email(ctx)).put("action", action).put("target", target).put("at", System.currentTimeMillis()))
        } catch (_: Exception) {}
    }

    /** Silent command or visible message for one user (or everyone when uid == null). */
    fun notice(ctx: Context, uid: String?, title: String, body: String, action: String = "") {
        val now = System.currentTimeMillis()
        val o = JSONObject().put("title", title).put("body", body).put("at", now)
        if (action.isNotEmpty()) o.put("action", action)
        put(ctx, (if (uid == null) "notices/all/" else "notices/users/$uid/") + now, o)
    }
}

data class UserRow(
    val uid: String, val email: String, val device: String, val ver: String,
    val lastSeen: Long, val createdAt: Long, val plan: String, val premiumUntil: Long, val hasPremium: Boolean
) {
    fun premiumActive(now: Long) = hasPremium && Plans.isActive(premiumUntil, now)
}

object Models {
    fun users(o: JSONObject): List<UserRow> {
        val out = ArrayList<UserRow>()
        for (uid in o.keys()) {
            val u = o.optJSONObject(uid) ?: continue
            val pr = u.optJSONObject("profile")
            val pm = u.optJSONObject("premium")
            out.add(UserRow(
                uid, pr?.optString("email").orEmpty(), pr?.optString("device").orEmpty(), pr?.optString("ver").orEmpty(),
                pr?.optLong("lastSeen", 0L) ?: 0L, pr?.optLong("createdAt", 0L) ?: 0L,
                pm?.optString("plan").orEmpty(), pm?.optLong("until", 0L) ?: 0L, pm != null
            ))
        }
        return out
    }
}
