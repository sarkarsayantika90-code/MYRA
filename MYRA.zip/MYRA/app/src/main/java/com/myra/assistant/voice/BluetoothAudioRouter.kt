package com.myra.assistant.voice

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.Logger

/**
 * Sends MYRA's voice call audio (mic AND speaker) to the right place:
 *   Bluetooth headset  >  wired headset  >  phone speaker.
 *
 * Why this exists: the old code did `isSpeakerphoneOn = true` and never touched Bluetooth, so with
 * Bluetooth headphones connected MYRA kept using the phone mic + loudspeaker (headphones stayed silent).
 *
 *  - Android 12+ (API 31): setCommunicationDevice() / clearCommunicationDevice(); needs BLUETOOTH_CONNECT.
 *  - Android 8-11: startBluetoothSco() + isBluetoothScoOn.
 *
 * [onRouteChanged] runs on the main thread once the route has settled; the owner should restart the
 * recorder there (an AudioRecord that was opened before the Bluetooth link came up keeps the phone mic).
 */
class BluetoothAudioRouter(
    private val ctx: Context,
    private val onRouteChanged: () -> Unit
) {
    private val TAG = "BT_ROUTE"
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())

    /** Device the recorder / player should prefer. null = system default. */
    @Volatile var inputDevice: AudioDeviceInfo? = null
        private set
    @Volatile var outputDevice: AudioDeviceInfo? = null
        private set
    @Volatile var usingBluetooth = false
        private set
    /**
     * Bluetooth headphones are connected but have no usable microphone/call profile (plain A2DP): MYRA's voice goes to
     * them as normal media audio and her ears stay on the phone mic. The owner must NOT use MODE_IN_COMMUNICATION then.
     */
    @Volatile var a2dpOnly = false
        private set
    /** A Bluetooth headset is connected but BLUETOOTH_CONNECT was not granted, so MYRA cannot use it. */
    @Volatile var needsPermission = false
        private set

    private var started = false
    private var scoOn = false
    private var lastSignature = ""

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            if (addedDevices.any { isRoutable(it) }) scheduleApply()
        }
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            if (removedDevices.any { isRoutable(it) }) scheduleApply()
        }
    }

    /** Android 8-11 only: tells us when the SCO (Bluetooth call audio) link is really up. */
    private val scoReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val st = intent?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1) ?: return
            if (st == AudioManager.SCO_AUDIO_STATE_CONNECTED && usingBluetooth) main.post { onRouteChanged() }
        }
    }

    private val applyRunnable = Runnable { applyRoute() }

    fun start() {
        if (started) return
        started = true
        try { am.registerAudioDeviceCallback(deviceCallback, main) } catch (e: Exception) { Logger.e(TAG, "callback: ${e.message}") }
        if (Build.VERSION.SDK_INT < 31) {
            try {
                ContextCompat.registerReceiver(
                    ctx, scoReceiver, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED),
                    ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (e: Exception) { Logger.e(TAG, "sco receiver: ${e.message}") }
        }
        applyRoute()
    }

    fun stop() {
        if (!started) return
        started = false
        main.removeCallbacks(applyRunnable)
        try { am.unregisterAudioDeviceCallback(deviceCallback) } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT < 31) {
            try { ctx.unregisterReceiver(scoReceiver) } catch (_: Exception) {}
            releaseSco()
        } else {
            try { am.clearCommunicationDevice() } catch (_: Exception) {}
        }
        inputDevice = null
        outputDevice = null
        usingBluetooth = false
        a2dpOnly = false
        lastSignature = ""
    }

    /** Call again after the user grants BLUETOOTH_CONNECT. */
    fun refresh() { if (started) scheduleApply() }

    // Android fires several add/remove events for ONE headset, so wait a moment and apply once.
    private fun scheduleApply() {
        main.removeCallbacks(applyRunnable)
        main.postDelayed(applyRunnable, 400)
    }

    private fun hasBtPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun isBt(d: AudioDeviceInfo) =
        d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)

    private fun isWired(d: AudioDeviceInfo) =
        d.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            d.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            d.type == AudioDeviceInfo.TYPE_USB_HEADSET

    private fun isRoutable(d: AudioDeviceInfo) = isBt(d) || isWired(d) || d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP

    @Suppress("DEPRECATION")
    private fun applyRoute() {
        if (!started) return
        try {
            val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val permOk = hasBtPermission()
            val btSeen = outs.any { isBt(it) || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
            val btIn = if (permOk) ins.firstOrNull { isBt(it) } else null
            val btOut = if (permOk) outs.firstOrNull { isBt(it) } else null
            val wiredOut = outs.firstOrNull { isWired(it) }
            val wiredIn = ins.firstOrNull { isWired(it) && it.type != AudioDeviceInfo.TYPE_WIRED_HEADPHONES }
            val a2dpOut = outs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
            // Need BOTH directions for a Bluetooth call route (mic + speaker over SCO / LE).
            val useBt = btIn != null && btOut != null
            // Headphones with no mic path (or no permission to use it): still play MYRA's voice in them as media audio.
            val useA2dp = !useBt && wiredOut == null && a2dpOut != null

            needsPermission = btSeen && !permOk
            if (needsPermission) Logger.e(TAG, "Bluetooth headset connected but BLUETOOTH_CONNECT not granted")

            if (useBt) {
                if (Build.VERSION.SDK_INT >= 31) {
                    val dev = am.availableCommunicationDevices.firstOrNull { isBt(it) }
                    val ok = dev != null && am.setCommunicationDevice(dev)
                    Logger.d(TAG, "setCommunicationDevice(bt) = $ok")
                } else {
                    am.isSpeakerphoneOn = false
                    if (!scoOn) {
                        am.startBluetoothSco()
                        am.isBluetoothScoOn = true
                        scoOn = true
                    }
                }
                inputDevice = btIn
                outputDevice = btOut
            } else {
                if (Build.VERSION.SDK_INT >= 31) {
                    am.clearCommunicationDevice()
                    if (!useA2dp) {
                        val avail = am.availableCommunicationDevices
                        val dev = avail.firstOrNull { isWired(it) } ?: avail.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                        if (dev != null) am.setCommunicationDevice(dev)
                    }
                } else {
                    releaseSco()
                    am.isSpeakerphoneOn = wiredOut == null && !useA2dp
                }
                inputDevice = wiredIn
                outputDevice = if (useA2dp) a2dpOut else wiredOut
            }
            usingBluetooth = useBt
            a2dpOnly = useA2dp

            val sig = "$useBt|$useA2dp|${btIn?.id}|${btOut?.id}|${wiredOut?.id}|${wiredIn?.id}|${a2dpOut?.id}"
            if (sig != lastSignature) {
                lastSignature = sig
                Logger.d(TAG, "route -> ${if (useBt) "BLUETOOTH" else if (useA2dp) "BLUETOOTH-MEDIA" else if (wiredOut != null) "WIRED" else "SPEAKER"}")
                // SCO on Android 8-11 needs a moment; the receiver above fires again when it is really up.
                main.postDelayed({ if (started) onRouteChanged() }, if (useBt && Build.VERSION.SDK_INT < 31) 1500L else 350L)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "route failed: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun releaseSco() {
        if (!scoOn) return
        try { am.isBluetoothScoOn = false } catch (_: Exception) {}
        try { am.stopBluetoothSco() } catch (_: Exception) {}
        scoOn = false
    }
}
