package com.myra.assistant.whatsapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.myra.assistant.control.PhoneController
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraNotificationListenerService
import com.myra.assistant.utils.ContactLookup
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/**
 * WhatsApp assistant (implements the "WhatsApp Assistant Automation" spec).
 *
 * Hard limits, enforced in code AND in the system prompt:
 *  - one message, one contact, one explicit "yes" each time; no bulk/broadcast/auto-reply
 *  - never taps Send unless [WhatsAppTask.canTapSend] (task confirmed) AND the person's own words
 *    after the read-back are an affirmative ([ConfirmGate])
 *  - "sent" is only reported when a delivery tick is seen on the actual bubble
 *  - never logs message bodies, numbers or notification text - only action names and status codes
 */
object WhatsAppAgent {
    private const val TAG = "WA_AGENT"
    private val mutex = Mutex()
    @Volatile private var task: WhatsAppTask? = null

    private fun waPackage(ctx: Context): String? = listOf(WhatsAppSelectors.PKG, WhatsAppSelectors.PKG_BUSINESS)
        .firstOrNull { p -> try { ctx.packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false } }

    private fun res(code: String, text: String) = "$code: $text"

    // ───────────────────────── entry points (LLM tools) ─────────────────────────

    suspend fun run(ctx: Context, action: String, contact: String?, message: String?, count: Int): String =
        mutex.withLock {
            Logger.d(TAG, "action=$action")
            when (action.lowercase()) {
                "read_unread" -> readUnread(ctx, contact)
                "send_message" -> prepareSend(ctx, contact.orEmpty(), message.orEmpty())
                "read_chat" -> readChat(ctx, contact.orEmpty(), count.coerceIn(1, 10))
                "mark_read" -> markRead(ctx, contact.orEmpty())
                "mute_chat" -> muteChat(ctx, contact.orEmpty(), true)
                "unmute_chat" -> muteChat(ctx, contact.orEmpty(), false)
                "search_chat" -> searchChat(ctx, contact.orEmpty())
                else -> res(WaCode.UNSUPPORTED_ACTION, "'$action' support kori na. Ami sudhu read, ekta message (confirm shoho), mute/unmute, mark read, search kori.")
            }
        }

    suspend fun control(ctx: Context, command: String, taskId: String?): String = mutex.withLock {
        val t = task
        when (command.lowercase()) {
            "status" -> t?.let { res(it.status.name.lowercase(), "task ${it.taskId}") } ?: res(WaCode.OK, "kono active WhatsApp task nai")
            "confirm" -> confirmAndSend(ctx, t, taskId)
            "reject", "cancel" -> discard(t, command.lowercase() == "reject")
            "resume" -> res(WaCode.OK, "resume: notun kore screen dekhe abar shuru korbo. Task-ta abar bolo.")
            else -> res(WaCode.UNSUPPORTED_ACTION, "unknown command $command")
        }
    }

    // ───────────────────────── reading ─────────────────────────

    private fun readUnread(ctx: Context, contact: String?): String {
        if (!MyraNotificationListenerService.isEnabled(ctx)) {
            return res(WaCode.USER_ACTION_REQUIRED, "Notification access on nai. Settings > Notification access > MYRA allow koro.")
        }
        val list = WhatsAppNotificationStore.all()
        if (list.isEmpty()) return res(WaCode.OK, "Kono unread WhatsApp message nai (ba notification cleared).")
        if (!contact.isNullOrBlank()) {
            val u = WhatsAppNotificationStore.forChat(contact)
                ?: return res(WaCode.OK, "$contact theke kono unread nai")
            return if (u.previews.isEmpty())
                res(WaCode.OK, "${u.chat} theke ${u.count}ta notun message, kintu preview off. Chat khule porbo?")
            else res(WaCode.OK, "${u.chat}: " + u.previews.joinToString(" | "))
        }
        val total = WhatsAppNotificationStore.totalUnread()
        val lines = list.take(8).joinToString("; ") { u ->
            if (u.previews.isEmpty()) "${u.chat} (${u.count}, preview off)"
            else "${u.chat} (${u.count}): ${u.previews.last()}"
        }
        return res(WaCode.OK, "$total unread. $lines")
    }

    private suspend fun readChat(ctx: Context, contact: String, count: Int): String {
        val pkg = precheck(ctx) ?: return preFail
        val target = resolve(ctx, contact) ?: return preFail
        openChat(ctx, pkg, target.second, null, target.first)?.let { return it }
        val root = WaScreen.root() ?: return res(WaCode.FAILED, "screen porte parlam na")
        val texts = WaScreen.findAll(root) { n ->
            n.isVisibleToUser && (n.viewIdResourceName?.endsWith(":id/message_text") == true) && !n.text.isNullOrBlank()
        }.map { it.text.toString().trim() }
        if (texts.isEmpty()) {
            return res(WaCode.UNSUPPORTED_ACTION,
                "Chat khulechi kintu message list detect korte parlam na (WhatsApp version alada hote pare, ba media/disappearing chat). 'read_screen' diye dekhi?")
        }
        val last = texts.takeLast(count)
        return res(WaCode.OK, "${target.first}-er last ${last.size} message: " + last.joinToString(" | "))
    }

    private suspend fun markRead(ctx: Context, contact: String): String {
        val pkg = precheck(ctx) ?: return preFail
        val target = resolve(ctx, contact) ?: return preFail
        openChat(ctx, pkg, target.second, null, target.first)?.let { return it }
        return res(WaCode.OK, "${target.first}-er chat kholechi, ebar read mark hoye geche")
    }

    private suspend fun searchChat(ctx: Context, query: String): String {
        val pkg = precheck(ctx) ?: return preFail
        if (query.isBlank()) return res(WaCode.FAILED, "Ki search korbo?")
        PhoneController.startAny(ctx, ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return res(WaCode.FAILED, "WhatsApp open hoilo na"))
        delay(1500)
        waitInterstitial()?.let { return it }
        val tapped = PhoneController.tapText("search")
        if (!tapped.startsWith("tapped")) return res(WaCode.UNSUPPORTED_ACTION, "Search icon pailam na")
        delay(600)
        val typed = PhoneController.typeText(query, false)
        return if (typed.startsWith("typed")) res(WaCode.OK, "'$query' search kore dekhachi") else res(WaCode.FAILED, typed)
    }

    private suspend fun muteChat(ctx: Context, contact: String, mute: Boolean): String {
        val pkg = precheck(ctx) ?: return preFail
        val target = resolve(ctx, contact) ?: return preFail
        openChat(ctx, pkg, target.second, null, target.first)?.let { return it }
        if (!PhoneController.tapText(WhatsAppSelectors.MORE_OPTIONS_DESCS.first()).startsWith("tapped"))
            return res(WaCode.UNSUPPORTED_ACTION, "More options menu pailam na")
        delay(500)
        val labels = if (mute) WhatsAppSelectors.MUTE_LABELS else WhatsAppSelectors.UNMUTE_LABELS
        val hit = labels.any { PhoneController.tapText(it).startsWith("tapped") }
        if (!hit) {
            PhoneController.globalAction("back")
            return res(WaCode.UNSUPPORTED_ACTION, if (mute) "Mute option pailam na (already muted hote pare)" else "Unmute option pailam na (mute kora nai hote pare)")
        }
        if (mute) {
            delay(500)
            WhatsAppSelectors.MUTE_DURATION_LABELS.any { PhoneController.tapText(it).startsWith("tapped") }
            delay(300)
            PhoneController.tapText("ok")
        }
        delay(600)
        return res(WaCode.SUBMITTED_UNVERIFIED, "${target.first} ke ${if (mute) "mute" else "unmute"} korar chesta korlam")
    }

    // ───────────────────────── sending (confirmation gated) ─────────────────────────

    private suspend fun prepareSend(ctx: Context, contact: String, message: String): String {
        task?.let {
            if (it.status == WaStatus.AWAITING_CONFIRMATION && System.currentTimeMillis() - it.draftAt < WhatsAppTask.DRAFT_TTL_MS)
                return res(WaCode.BUSY, "Ekta draft (${it.resolvedName}-ke) ekhono confirm hoy nai. Age oita confirm ba reject koro.")
        }
        if (message.isBlank()) return res(WaCode.FAILED, "Ki message likhbo bolo")
        val pkg = precheck(ctx) ?: return preFail
        val target = resolve(ctx, contact) ?: return preFail

        val t = WhatsAppTask(UUID.randomUUID().toString().take(8), "send_message", contact, target.first, target.second, message)
        task = t
        t.status = WaStatus.OPENING

        openChat(ctx, pkg, target.second, message, target.first)?.let { task = null; return it }

        // Closed loop: make sure the draft in the compose box is EXACTLY the approved text.
        var root = WaScreen.root()
        if (WaScreen.composeText(root).trim() != message.trim()) {
            val field = WaScreen.findCompose(root)
            if (field == null || !WaScreen.setText(field, message)) { task = null; return res(WaCode.FAILED, "Message likhte parlam na") }
            delay(400)
            root = WaScreen.root()
            if (WaScreen.composeText(root).trim() != message.trim()) { task = null; return res(WaCode.FAILED, "Compose box e message thik moto boshlo na") }
        }
        val send = WaScreen.findSend(root)
        if (send == null || !send.isEnabled) { task = null; return res(WaCode.FAILED, "Send button pailam na") }

        t.markAwaiting()
        Logger.d(TAG, "draft ready len=${message.length}")
        return res(
            WaCode.AWAITING_CONFIRMATION,
            "task ${t.taskId}. Draft ready: to ${t.resolvedName}, message: \"$message\". " +
                "Ei exact message ar naam user ke poRe shunao, tarpor sudhu user 'haan/yes' bolle whatsapp_task_control confirm koro."
        )
    }

    private suspend fun confirmAndSend(ctx: Context, t: WhatsAppTask?, taskId: String?): String {
        if (t == null) return res(WaCode.FAILED, "Kono draft nai")
        if (t.status != WaStatus.AWAITING_CONFIRMATION) return res(WaCode.FAILED, "Ei task ekhon confirm korar obostha e nai (${t.status.name.lowercase()})")

        // Second lock: the PERSON's own words AFTER the read-back must be a clear yes.
        var ok = false
        var readbackDone = false
        for (i in 0 until 10) {
            val said = UtteranceLog.sinceReadback(t.draftAt)
            if (said != null) {
                readbackDone = true
                if (ConfirmGate.isAffirmative(said)) { ok = true; break }
                if (ConfirmGate.isNegative(said)) break
            }
            delay(300)
        }
        if (!ok) {
            return res(WaCode.AWAITING_CONFIRMATION,
                if (readbackDone) "User er spashto 'haan/yes' shuni nai, tai pathai ni. Abar jiggesh koro: \"${t.resolvedName}-ke pathabo?\" Draft ekhono ache."
                else "Age draft ta user ke poRe shunao ar user er uttor er jonno opekkha koro. Tarpor abar confirm koro. Ekhono pathai ni.")
        }
        if (!t.confirm(taskId ?: t.taskId)) {
            return res(WaCode.FAILED, "Confirm hoilo na (task id mile ni ba draft onek purono). Notun kore shuru koro.")
        }

        val pkg = waPackage(ctx) ?: return res(WaCode.APP_NOT_INSTALLED, "WhatsApp nai")
        t.status = WaStatus.SENDING
        return tapSend(t, pkg)
    }

    private suspend fun tapSend(t: WhatsAppTask, pkg: String): String {
        // Defense in depth: the send step itself refuses unless THIS task was confirmed.
        if (!t.canTapSend()) return res(WaCode.FAILED, "Internal: confirm chara send hobe na")

        var root = WaScreen.root()
        if (root == null || root.packageName?.toString() != pkg) return res(WaCode.USER_ACTION_REQUIRED, "WhatsApp screen ar samne nai. Pathai ni.")
        WaScreen.interstitial(root)?.let { return res(WaCode.USER_ACTION_REQUIRED, it) }
        if (WaScreen.composeText(root).trim() != t.message.trim()) {
            return res(WaCode.FAILED, "Compose box er message bodle geche, tai pathai ni. Notun kore draft koro.")
        }
        var send = WaScreen.findSend(root)
        if (send == null || !send.isEnabled) return res(WaCode.FAILED, "Send button pailam na")

        val before = WaScreen.signature(root)
        WaScreen.tapNode(send)          // tapped exactly once...
        delay(900)

        root = WaScreen.root()
        // ...and re-tapped at most once, only if the screen provably did not react.
        if (WaScreen.signature(root) == before && WaScreen.composeText(root).trim() == t.message.trim() && t.retryCount < t.maxRetries) {
            t.retryCount++
            send = WaScreen.findSend(root)
            if (send != null && send.isEnabled) { WaScreen.tapNode(send); delay(900) }
        }

        // Verify from the UI, not from assumption.
        var tick: String? = null
        for (i in 0 until 8) {
            root = WaScreen.root()
            val st = WaScreen.bubbleStatus(root, t.message)
            if (st != null && st != "NO_BUBBLE") { tick = st; break }
            delay(400)
        }
        val stillInBox = WaScreen.composeText(WaScreen.root()).trim() == t.message.trim()
        t.status = WaStatus.DONE
        task = null
        return when {
            tick != null -> res(WaCode.SENT, "${t.resolvedName}-ke message pathano hoyeche ($tick)")
            !stillInBox -> res(WaCode.SUBMITTED_UNVERIFIED, "Send dabiyechi, compose box khali hoyeche, kintu tick dekhte pai ni. Nishchit noi.")
            else -> { t.status = WaStatus.FAILED; res(WaCode.FAILED, "Send hoilo na") }
        }
    }

    private fun discard(t: WhatsAppTask?, rejected: Boolean): String {
        if (t == null) return res(WaCode.OK, "kono draft nai")
        t.status = if (rejected) WaStatus.REJECTED else WaStatus.CANCELLED
        // Do not leave a stale draft sitting in WhatsApp.
        try {
            val root = WaScreen.root()
            if (root?.packageName?.toString()?.startsWith("com.whatsapp") == true) {
                WaScreen.findCompose(root)?.let { WaScreen.setText(it, "") }
            }
        } catch (_: Exception) {}
        task = null
        return res(if (rejected) WaCode.REJECTED else WaCode.CANCELLED, "draft muche dilam, kichu pathai ni")
    }

    // ───────────────────────── shared steps ─────────────────────────

    private var preFail: String = ""

    private fun precheck(ctx: Context): String? {
        val pkg = waPackage(ctx)
        if (pkg == null) { preFail = res(WaCode.APP_NOT_INSTALLED, "WhatsApp install kora nai"); return null }
        if (!AccessibilityHelperService.isEnabled(ctx) || AccessibilityHelperService.instance == null) {
            preFail = res(WaCode.ACCESSIBILITY_NOT_ENABLED, "Accessibility on koro (Settings > Accessibility > MYRA)"); return null
        }
        return pkg
    }

    /** Returns (displayName, number) or null with [preFail] set. Never guesses between two people. */
    private fun resolve(ctx: Context, query: String): Pair<String, String>? {
        if (query.isBlank()) { preFail = res(WaCode.CONTACT_NOT_FOUND, "Kake bolbo? Naam bolo"); return null }
        if (query.count { it.isDigit() } >= 8) return query to query
        val matches = ContactLookup.findAll(ctx, query)
        if (matches.isEmpty()) { preFail = res(WaCode.CONTACT_NOT_FOUND, "'$query' naame kono contact pai ni"); return null }
        val exact = matches.filter { it.first.equals(query.trim(), true) }
        val pick = if (exact.size == 1) exact else matches
        val distinctPeople = pick.map { it.first.lowercase() }.distinct()
        if (distinctPeople.size > 1) {
            preFail = res(WaCode.CONTACT_AMBIGUOUS, "Ekadhik contact: " + pick.take(5).joinToString(", ") { it.first } + ". Kon ta?")
            return null
        }
        return pick.first()
    }

    private suspend fun waitInterstitial(): String? {
        val why = WaScreen.interstitial(WaScreen.root()) ?: return null
        return res(WaCode.USER_ACTION_REQUIRED, "WhatsApp e $why dekhachhe. Tumi nijei sheta koro, 'done' bolle ami abar shuru korbo.")
    }

    /**
     * Opens a chat via WhatsApp's own deep link and WAITS for a genuinely new screen for that
     * chat (window/content signature + chat title), so we never read or type into the previous chat.
     */
    private suspend fun openChat(ctx: Context, pkg: String, number: String, prefill: String?, displayName: String): String? {
        val before = WaScreen.signature(WaScreen.root())
        val beforePkg = WaScreen.pkg()
        val digits = number.filter { it.isDigit() }
        val uri = "https://wa.me/$digits" + (if (prefill != null) "?text=${Uri.encode(prefill)}" else "")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(pkg)
        if (!PhoneController.startAny(ctx, i)) return res(WaCode.FAILED, "WhatsApp chat open hoilo na")

        val firstName = displayName.trim().split(" ").firstOrNull()?.lowercase().orEmpty()
        val tail = digits.takeLast(8)
        var waited = 0
        while (waited < 8000) {
            delay(300); waited += 300
            val root = WaScreen.root() ?: continue
            val p = root.packageName?.toString()
            if (p != pkg) {
                if (p != null && p in WhatsAppSelectors.PERMISSION_PACKAGES) return waitInterstitial() ?: res(WaCode.USER_ACTION_REQUIRED, "permission dialog")
                continue
            }
            waitInterstitial()?.let { return it }
            if (WaScreen.findCompose(root) == null) continue
            val changed = WaScreen.signature(root) != before || beforePkg != pkg
            val title = WaScreen.chatTitle(root)?.lowercase()
            val titleOk = title == null ||
                (firstName.isNotEmpty() && title.contains(firstName)) ||
                title.filter { it.isDigit() }.endsWith(tail)
            if ((changed || waited >= 2400) && titleOk) { delay(350); return null }
        }
        return res(WaCode.FAILED, "Sothik chat khulte parlam na (onno chat khola thakte pare). Kichu pathai ni.")
    }
}
