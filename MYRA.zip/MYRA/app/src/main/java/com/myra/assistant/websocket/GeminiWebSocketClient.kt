package com.myra.assistant.websocket

import android.util.Base64
import android.util.Log
import com.myra.assistant.utils.Constants
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini Live (BidiGenerateContent) client.
 *
 * What changed vs. the old version (these were the reasons MYRA was slow / deaf / never opened apps):
 *  - Real FUNCTION CALLING (toolCall / toolResponse). Before, the model was told to "reply with a
 *    command line" but a native-audio model only returns audio, so no command ever arrived.
 *  - Audio goes out as realtimeInput.audio (mediaChunks is deprecated and adds latency/failures).
 *  - Server-side voice activity detection with fast end-of-speech + barge-in (interruptions).
 *  - Input/output transcription so the chat screen shows what was said.
 *  - Sliding-window context compression so long sessions do not die after a few minutes.
 *  - Events from an old socket are ignored, so a reconnect can never double-fire.
 */
class GeminiWebSocketClient(
    private val apiKey: String,
    private val systemPrompt: String,
    private val voiceName: String,
    private val model: String,
    private val tools: JSONArray,
    /** 0 = full, 1 = without thinking/compression, 2 = minimal. Steps down automatically if the server rejects a setup. */
    private val level: Int,
    /** Handle from the previous session: lets Gemini continue the same conversation after a reconnect. */
    val resumeHandle: String?,
    private val listener: Listener
) {
    interface Listener {
        fun onConnected()
        fun onAudio(pcm: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onInterrupted()
        fun onTurnComplete()
        fun onClosed(reason: String)
        /** Server sent a new resumption handle - keep the newest one. */
        fun onResumeHandle(handle: String)
        /** Server says this connection will close soon - reconnect now, quietly. */
        fun onGoAway()
    }

    private val TAG = "GEMINI_WS"
    @Volatile private var webSocket: WebSocket? = null
    @Volatile private var ready = false
    @Volatile private var closedByUs = false
    /** true once the server accepted the setup at least once on THIS client. */
    @Volatile var everReady = false
        private set

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun connect() {
        ready = false
        closedByUs = false
        val url = "${Constants.GEMINI_WS_BASE}?key=$apiKey"
        val request = Request.Builder().url(url).build()
        var self: WebSocket? = null
        self = client.newWebSocket(request, object : WebSocketListener() {
            private fun stale() = self !== webSocket && webSocket != null

            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "socket open")
                sendSetup(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                if (stale()) return
                handle(text)
            }

            override fun onMessage(ws: WebSocket, bytes: ByteString) {
                if (stale()) return
                handle(bytes.utf8())
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                if (stale()) return
                ready = false
                Log.e(TAG, "failure: ${t.message} ${response?.code}")
                if (!closedByUs) listener.onClosed("failure: ${t.message ?: response?.code}")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                if (stale()) return
                ready = false
                Log.d(TAG, "closed $code $reason")
                if (!closedByUs) listener.onClosed("closed $code $reason")
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                ws.close(1000, null)
            }
        })
        webSocket = self
    }

    private fun sendSetup(ws: WebSocket) {
        val full = level <= 1
        val tuned = level == 0
        val setup = JSONObject().apply {
            put("model", model)
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName))
                    })
                })
                // Thinking adds seconds of delay before every spoken answer. Off = much faster replies.
                if (tuned) put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            val toolList = JSONArray()
            toolList.put(JSONObject().put("functionDeclarations", tools))
            if (full && Constants.ENABLE_WEB_SEARCH) toolList.put(JSONObject().put("googleSearch", JSONObject()))
            put("tools", toolList)
            if (full) {
                put("realtimeInputConfig", JSONObject().apply {
                    put("automaticActivityDetection", JSONObject().apply {
                        put("disabled", false)
                        put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")
                        put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                        put("prefixPaddingMs", 30)
                        put("silenceDurationMs", 280)
                    })
                    put("activityHandling", "START_OF_ACTIVITY_INTERRUPTS")
                })
                put("inputAudioTranscription", JSONObject())
                put("outputAudioTranscription", JSONObject())
                if (tuned) put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
                put("sessionResumption", JSONObject().apply {
                    if (!resumeHandle.isNullOrBlank()) put("handle", resumeHandle)
                })
            }
        }
        ws.send(JSONObject().put("setup", setup).toString())
    }

    private fun handle(json: String) {
        try {
            val obj = JSONObject(json)

            if (obj.has("setupComplete")) {
                ready = true
                everReady = true
                listener.onConnected()
                return
            }

            obj.optJSONObject("sessionResumptionUpdate")?.let { u ->
                val h = u.optString("newHandle")
                if (u.optBoolean("resumable", true) && h.isNotEmpty()) listener.onResumeHandle(h)
                return
            }
            if (obj.has("goAway")) { listener.onGoAway(); return }

            obj.optJSONObject("toolCall")?.let { tc ->
                val calls = tc.optJSONArray("functionCalls") ?: return@let
                for (i in 0 until calls.length()) {
                    val c = calls.getJSONObject(i)
                    listener.onToolCall(
                        c.optString("id"),
                        c.optString("name"),
                        c.optJSONObject("args") ?: JSONObject()
                    )
                }
                return
            }

            val sc = obj.optJSONObject("serverContent") ?: return

            if (sc.optBoolean("interrupted", false)) listener.onInterrupted()

            sc.optJSONObject("inputTranscription")?.optString("text")?.let {
                if (it.isNotEmpty()) listener.onInputTranscript(it)
            }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let {
                if (it.isNotEmpty()) listener.onOutputTranscript(it)
            }

            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                    val data = inline.optString("data")
                    if (data.isNotEmpty()) listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                }
            }

            if (sc.optBoolean("turnComplete", false)) listener.onTurnComplete()
        } catch (e: Exception) {
            Log.e(TAG, "parse error: ${e.message}")
        }
    }

    /** [force] = skip the "uplink is slow" drop (used once to send the audio recorded while the socket was opening). */
    fun sendAudioChunk(pcm: ByteArray, force: Boolean = false) {
        if (!ready) return
        // If the uplink is slow, old audio piles up and MYRA answers seconds late. Drop instead.
        if (!force && (webSocket?.queueSize() ?: 0L) > 48_000L) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject().apply {
            put("data", Base64.encodeToString(pcm, Base64.NO_WRAP))
            put("mimeType", "audio/pcm;rate=16000")
        }))
        webSocket?.send(msg.toString())
    }

    /** Typed message from the chat screen. */
    fun sendText(text: String) {
        if (!ready) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("text", text))
        webSocket?.send(msg.toString())
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        val fr = JSONObject().apply {
            put("id", id)
            put("name", name)
            put("response", JSONObject().put("result", result))
        }
        val msg = JSONObject().put(
            "toolResponse",
            JSONObject().put("functionResponses", JSONArray().put(fr))
        )
        webSocket?.send(msg.toString())
    }

    fun disconnect() {
        closedByUs = true
        ready = false
        try { webSocket?.close(1000, "bye") } catch (_: Exception) {}
        webSocket = null
    }

    fun isReady() = ready

    companion object {
        /**
         * Did the SERVER refuse our setup (so a simpler setup is worth trying)? A network failure, timeout or a bad key is
         * not the setup's fault - stepping down on those made replies randomly slower (no "thinking off", no fast speech
         * detection) until the service was restarted. [reason] is what onClosed/onFailure reported.
         */
        fun looksLikeSetupRejection(reason: String): Boolean {
            val r = reason.lowercase()
            if (!r.startsWith("closed ")) return false               // "failure: ..." = network, not the setup
            if (listOf("api key", "api_key", "quota", "billing", "permission", "expired", "rate limit", "exhausted").any { it in r }) return false
            return r.startsWith("closed 1007") || r.startsWith("closed 1008") ||
                listOf("invalid", "unknown name", "not supported", "not implemented", "unsupported").any { it in r }
        }
    }
}
