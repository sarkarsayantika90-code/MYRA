package com.myra.admin

/** Every tool MYRA can use, so the admin can switch single ones off. (stop_myra can never be switched off.) */
object ToolNames {
    val GROUPS: LinkedHashMap<String, List<String>> = linkedMapOf(
        "Phone control" to listOf("open_app", "search_in_app", "open_url", "read_screen", "tap_text", "long_press_text", "scroll", "type_text", "press_key", "open_settings", "wait", "toggle_setting", "navigate_to"),
        "Calls & messages" to listOf("call_contact", "answer_call", "end_call", "send_sms", "confirm_sms", "cancel_sms", "execute_whatsapp_task", "whatsapp_task_control", "app_message", "confirm_app_message", "cancel_app_message", "app_call", "read_notifications", "clear_notifications", "read_missed_calls"),
        "Contacts" to listOf("list_prime_contacts", "add_prime_contact", "save_new_contact"),
        "Device" to listOf("take_photo", "media_control", "flashlight", "change_volume", "set_volume", "set_brightness", "get_battery", "set_clipboard", "lock_phone", "power_off_phone", "self_check", "play_video"),
        "Time & planning" to listOf("get_time", "set_alarm", "set_timer", "create_event", "daily_briefing", "stopwatch"),
        "Notes & to-dos" to listOf("save_note", "read_notes", "delete_note", "clear_notes", "add_todo", "list_todos", "complete_todo", "get_clipboard", "generate_password"),
        "Maths & dates" to listOf("calculate", "convert_units", "percentage_calc", "split_bill", "emi_calculator", "bmi_calculator", "age_calculator", "days_between", "add_to_date", "day_of_week", "world_time"),
        "Fun & utilities" to listOf("random_number", "flip_coin", "roll_dice", "pick_random", "device_info", "storage_info", "network_status", "share_text", "map_search", "web_search", "dial_number")
    )
}
