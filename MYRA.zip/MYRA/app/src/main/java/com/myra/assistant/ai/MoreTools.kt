package com.myra.assistant.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.myra.assistant.utils.prefs
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/** 30 extra everyday tools. Nothing here needs a new permission and nothing here is destructive without an explicit confirm. */
object MoreTools {
    private const val TODOS = "myra_todos_json"
    private const val STOPWATCH = "myra_stopwatch_start"
    private val rnd = SecureRandom()

    fun registerAll() {
        fun p(t: String, d: String) = MyraTools.prop(t, d)

        // ── maths & conversion ──
        ToolRegistry.register("calculate",
            "Exact calculator. ALWAYS use it for arithmetic instead of mental maths. Supports + - * / % ^ ( ) sqrt abs sin cos tan ln log pi.",
            mapOf("expression" to p("STRING", "e.g. 12.5*(3+4)")), listOf("expression")) { _, a ->
            try { "Result: " + QuickMath.fmt(QuickMath.eval(a.optString("expression"))) }
            catch (e: Exception) { "Could not calculate: ${e.message}. Ask the user to repeat the numbers." }
        }
        ToolRegistry.register("convert_units",
            "Convert between units: length, weight, volume, speed, temperature (C/F/K), data size, time, area.",
            mapOf("value" to p("NUMBER", "Amount"), "from_unit" to p("STRING", "e.g. km, lb, celsius"), "to_unit" to p("STRING", "e.g. mile, kg, fahrenheit")),
            listOf("value", "from_unit", "to_unit")) { _, a ->
            val v = num(a, "value") ?: return@register "Which number should I convert?"
            QuickMath.convert(v, a.optString("from_unit"), a.optString("to_unit"))
                ?: "I can't convert ${a.optString("from_unit")} to ${a.optString("to_unit")} - they may be different kinds of units."
        }
        ToolRegistry.register("percentage_calc",
            "Percentage maths. mode: 'of' (X% of Y), 'change' (percent change from X to Y), 'increase' (Y increased by X%), 'discount' (Y reduced by X%).",
            mapOf("mode" to p("STRING", "of | change | increase | discount"), "x" to p("NUMBER", "First number"), "y" to p("NUMBER", "Second number")),
            listOf("mode", "x", "y")) { _, a ->
            val x = num(a, "x"); val y = num(a, "y")
            if (x == null || y == null) return@register "I need two numbers."
            when (a.optString("mode").lowercase()) {
                "of" -> "${QuickMath.fmt(x)}% of ${QuickMath.fmt(y)} = ${QuickMath.fmt(y * x / 100)}"
                "change" -> if (x == 0.0) "Can't compute a change from zero." else "Change from ${QuickMath.fmt(x)} to ${QuickMath.fmt(y)} = ${QuickMath.fmt((y - x) / x * 100)}%"
                "increase" -> "${QuickMath.fmt(y)} increased by ${QuickMath.fmt(x)}% = ${QuickMath.fmt(y * (1 + x / 100))}"
                "discount" -> "${QuickMath.fmt(y)} after ${QuickMath.fmt(x)}% off = ${QuickMath.fmt(y * (1 - x / 100))} (saves ${QuickMath.fmt(y * x / 100)})"
                else -> "Mode must be of, change, increase or discount."
            }
        }
        ToolRegistry.register("split_bill",
            "Split a bill between people with an optional tip percentage.",
            mapOf("amount" to p("NUMBER", "Bill total"), "people" to p("NUMBER", "Number of people"), "tip_percent" to p("NUMBER", "Tip % (optional)")),
            listOf("amount", "people")) { _, a ->
            val amt = num(a, "amount"); val n = num(a, "people")?.toInt()
            if (amt == null || n == null || n < 1) return@register "I need the bill amount and how many people."
            val tip = num(a, "tip_percent") ?: 0.0
            val total = amt * (1 + tip / 100)
            "Total ${QuickMath.fmt(total)}, each person pays ${QuickMath.fmt(total / n)}"
        }
        ToolRegistry.register("emi_calculator",
            "Loan EMI calculator: monthly instalment, total payment and total interest.",
            mapOf("principal" to p("NUMBER", "Loan amount"), "annual_rate_percent" to p("NUMBER", "Yearly interest rate in %"),
                "years" to p("NUMBER", "Loan term in years (or use months)"), "months" to p("NUMBER", "Loan term in months")),
            listOf("principal", "annual_rate_percent")) { _, a ->
            val pr = num(a, "principal"); val rate = num(a, "annual_rate_percent")
            val months = num(a, "months")?.toInt() ?: num(a, "years")?.let { (it * 12).toInt() }
            if (pr == null || rate == null || months == null || months <= 0) return@register "I need the amount, interest rate and the term."
            val e = QuickMath.emi(pr, rate, months)
            "EMI ${QuickMath.fmt(e)} per month for $months months. Total payment ${QuickMath.fmt(e * months)}, interest ${QuickMath.fmt(e * months - pr)}"
        }
        ToolRegistry.register("bmi_calculator",
            "BMI from weight and height, with the standard category.",
            mapOf("weight_kg" to p("NUMBER", "Weight in kg"), "height_cm" to p("NUMBER", "Height in cm")), listOf("weight_kg", "height_cm")) { _, a ->
            val w = num(a, "weight_kg"); val h = num(a, "height_cm")
            if (w == null || h == null || w <= 0 || h <= 0) return@register "I need weight in kg and height in cm."
            val b = QuickMath.bmi(w, h)
            "BMI ${"%.1f".format(Locale.ENGLISH, b)} - ${QuickMath.bmiCategory(b)}. This is only a general guide, not medical advice."
        }

        // ── dates & time ──
        ToolRegistry.register("age_calculator",
            "Exact age (years, months, days) from a date of birth.",
            mapOf("date_of_birth" to p("STRING", "Date like 2001-07-15 or 15-07-2001")), listOf("date_of_birth")) { _, a ->
            val d = parseDate(a.optString("date_of_birth")) ?: return@register "I couldn't read that date. Ask for day, month and year."
            val now = LocalDate.now()
            if (d.isAfter(now)) return@register "That date is in the future."
            val per = java.time.Period.between(d, now)
            "${per.years} years, ${per.months} months, ${per.days} days old (${ChronoUnit.DAYS.between(d, now)} days in total)"
        }
        ToolRegistry.register("days_between",
            "Number of days between two dates. If to_date is empty it counts to today - use it for 'how many days until / since'.",
            mapOf("from_date" to p("STRING", "Start date (or 'today')"), "to_date" to p("STRING", "End date (optional)")), listOf("from_date")) { _, a ->
            val f = parseDate(a.optString("from_date")) ?: return@register "I couldn't read the date."
            val t = if (a.optString("to_date").isBlank()) LocalDate.now() else parseDate(a.optString("to_date")) ?: return@register "I couldn't read the second date."
            val n = ChronoUnit.DAYS.between(f, t)
            "$n days (${n / 7} weeks and ${n % 7} days) from ${f} to ${t}"
        }
        ToolRegistry.register("add_to_date",
            "Date after adding (or subtracting, negative) some days to a date. Default start = today.",
            mapOf("days" to p("NUMBER", "Days to add, negative to go back"), "date" to p("STRING", "Start date (optional)")), listOf("days")) { _, a ->
            val n = num(a, "days")?.toLong() ?: return@register "How many days?"
            val d = if (a.optString("date").isBlank()) LocalDate.now() else parseDate(a.optString("date")) ?: return@register "I couldn't read the date."
            val r = d.plusDays(n)
            "${r.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH))}"
        }
        ToolRegistry.register("day_of_week",
            "Which weekday a given date falls on.",
            mapOf("date" to p("STRING", "Date")), listOf("date")) { _, a ->
            val d = parseDate(a.optString("date")) ?: return@register "I couldn't read the date."
            d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH))
        }
        ToolRegistry.register("world_time",
            "Current time in another city or country (e.g. London, New York, Dubai, Tokyo, Dhaka).",
            mapOf("place" to p("STRING", "City or country")), listOf("place")) { _, a ->
            val z = zoneFor(a.optString("place")) ?: return@register "I don't know that city's time zone. Try a bigger nearby city."
            val t = ZonedDateTime.now(z)
            "In ${a.optString("place")} it is ${t.format(DateTimeFormatter.ofPattern("hh:mm a, EEEE d MMMM", Locale.ENGLISH))} (${z.getDisplayName(TextStyle.FULL, Locale.ENGLISH)})"
        }
        ToolRegistry.register("stopwatch",
            "Simple stopwatch. action: start | check | stop.",
            mapOf("action" to p("STRING", "start | check | stop")), listOf("action")) { ctx, a ->
            val pr = ctx.prefs()
            val start = pr.getLong(STOPWATCH, 0L)
            when (a.optString("action").lowercase()) {
                "start" -> { pr.edit().putLong(STOPWATCH, System.currentTimeMillis()).apply(); "Stopwatch started" }
                "check" -> if (start == 0L) "The stopwatch isn't running." else "Running: ${span(System.currentTimeMillis() - start)}"
                "stop" -> if (start == 0L) "The stopwatch isn't running." else {
                    pr.edit().remove(STOPWATCH).apply(); "Stopped at ${span(System.currentTimeMillis() - start)}"
                }
                else -> "Say start, check or stop."
            }
        }

        // ── randomness ──
        ToolRegistry.register("random_number",
            "A random whole number between min and max (inclusive). Default 1 to 100.",
            mapOf("min" to p("NUMBER", "Lowest"), "max" to p("NUMBER", "Highest"))) { _, a ->
            val lo = num(a, "min")?.toLong() ?: 1L; val hi = num(a, "max")?.toLong() ?: 100L
            if (hi < lo) return@register "Max must be bigger than min."
            val span = hi - lo + 1
            (lo + (rnd.nextLong() and Long.MAX_VALUE) % span).toString()
        }
        ToolRegistry.register("flip_coin", "Flip a coin: heads or tails.") { _, _ -> if (rnd.nextBoolean()) "Heads" else "Tails" }
        ToolRegistry.register("roll_dice",
            "Roll one or more dice.",
            mapOf("sides" to p("NUMBER", "Sides per die, default 6"), "count" to p("NUMBER", "How many dice, default 1, max 20"))) { _, a ->
            val sides = (num(a, "sides")?.toInt() ?: 6).coerceIn(2, 1000)
            val count = (num(a, "count")?.toInt() ?: 1).coerceIn(1, 20)
            val rolls = List(count) { rnd.nextInt(sides) + 1 }
            if (count == 1) "Rolled ${rolls[0]}" else "Rolled ${rolls.joinToString(", ")} - total ${rolls.sum()}"
        }
        ToolRegistry.register("pick_random",
            "Pick one option at random from a list (to settle a choice).",
            mapOf("options" to p("STRING", "Options separated by commas")), listOf("options")) { _, a ->
            val opts = a.optString("options").split(",", " or ", "|").map { it.trim() }.filter { it.isNotEmpty() }
            if (opts.size < 2) "Give me at least two options." else "I pick: ${opts[rnd.nextInt(opts.size)]}"
        }
        ToolRegistry.register("generate_password",
            "Create a strong random password and copy it to the clipboard. NEVER read the password aloud - just tell the user it is on the clipboard.",
            mapOf("length" to p("NUMBER", "Length 8-64, default 16"))) { ctx, a ->
            val n = (num(a, "length")?.toInt() ?: 16).coerceIn(8, 64)
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?"
            val pw = String(CharArray(n) { chars[rnd.nextInt(chars.length)] })
            try {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("password", pw))
                "A $n-character password is copied to the clipboard. It is not shown or spoken - the user can paste it where needed."
            } catch (e: Exception) { "Could not reach the clipboard." }
        }

        // ── clipboard, notes, to-dos ──
        ToolRegistry.register("get_clipboard", "Read the text currently on the clipboard.") { ctx, _ ->
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
                if (t.isNullOrBlank()) "The clipboard is empty, or Android blocks reading it while the app is in the background. Ask the user to open MYRA and try again."
                else "Clipboard: " + t.take(500)
            } catch (e: Exception) { "Could not read the clipboard." }
        }
        ToolRegistry.register("delete_note",
            "Delete ONE saved note. number = 1 for the latest note, 2 for the one before... or give a word it contains.",
            mapOf("number" to p("NUMBER", "1 = latest"), "contains" to p("STRING", "Word inside the note"))) { ctx, a ->
            val arr = try { JSONArray(ctx.prefs().getString(ExtraTools.NOTES, "[]")) } catch (_: Exception) { JSONArray() }
            if (arr.length() == 0) return@register "There are no notes."
            val idx: Int = when {
                a.optString("contains").isNotBlank() -> (arr.length() - 1 downTo 0).firstOrNull { arr.getJSONObject(it).optString("t").contains(a.optString("contains"), true) } ?: -1
                else -> arr.length() - (num(a, "number")?.toInt() ?: 1)
            }
            if (idx < 0 || idx >= arr.length()) return@register "I couldn't find that note."
            val gone = arr.getJSONObject(idx).optString("t")
            val out = JSONArray(); for (i in 0 until arr.length()) if (i != idx) out.put(arr.get(i))
            ctx.prefs().edit().putString(ExtraTools.NOTES, out.toString()).apply()
            "Deleted the note: ${gone.take(80)}"
        }
        ToolRegistry.register("clear_notes",
            "Delete ALL saved notes. Irreversible: first ask 'Delete all your notes?', and call with confirm=true only after a clear yes.",
            mapOf("confirm" to p("BOOLEAN", "true only after the user clearly said yes"))) { ctx, a ->
            if (!a.optBoolean("confirm", false)) "Not deleted. Ask the user to confirm first."
            else { ctx.prefs().edit().putString(ExtraTools.NOTES, "[]").apply(); "All notes deleted" }
        }
        ToolRegistry.register("add_todo",
            "Add an item to the user's to-do list.",
            mapOf("task" to p("STRING", "The task")), listOf("task")) { ctx, a ->
            val t = a.optString("task").trim()
            if (t.isEmpty()) return@register "What is the task?"
            val arr = loadTodos(ctx); arr.put(JSONObject().put("t", t.take(200)).put("done", false))
            ctx.prefs().edit().putString(TODOS, arr.toString()).apply()
            "Added to your to-do list: $t"
        }
        ToolRegistry.register("list_todos", "Read the pending items on the user's to-do list.") { ctx, _ ->
            val arr = loadTodos(ctx)
            val open = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { !it.optBoolean("done") }
            if (open.isEmpty()) "Your to-do list is empty." else open.mapIndexed { i, o -> "${i + 1}. ${o.optString("t")}" }.joinToString("; ")
        }
        ToolRegistry.register("complete_todo",
            "Mark a to-do done. Give its number from list_todos, or a word it contains.",
            mapOf("number" to p("NUMBER", "Position in the pending list"), "contains" to p("STRING", "Word inside the task"))) { ctx, a ->
            val arr = loadTodos(ctx)
            val openIdx = (0 until arr.length()).filter { !arr.getJSONObject(it).optBoolean("done") }
            val pick: Int? = if (a.optString("contains").isNotBlank())
                openIdx.firstOrNull { arr.getJSONObject(it).optString("t").contains(a.optString("contains"), true) }
            else num(a, "number")?.toInt()?.let { openIdx.getOrNull(it - 1) }
            if (pick == null) return@register "I couldn't find that task."
            val o = arr.getJSONObject(pick); o.put("done", true)
            ctx.prefs().edit().putString(TODOS, arr.toString()).apply()
            "Marked done: ${o.optString("t")}"
        }

        // ── device info ──
        ToolRegistry.register("device_info", "Phone model, brand and Android version.") { _, _ ->
            "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}"
        }
        ToolRegistry.register("storage_info", "How much phone storage is free.") { _, _ ->
            try {
                val st = StatFs(Environment.getDataDirectory().path)
                val gb = 1024.0 * 1024.0 * 1024.0
                "%.1f GB free of %.1f GB".format(Locale.ENGLISH, st.availableBytes / gb, st.totalBytes / gb)
            } catch (e: Exception) { "Could not read storage." }
        }
        ToolRegistry.register("network_status", "Is the phone online, and on Wi-Fi or mobile data.") { ctx, _ ->
            try {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                when {
                    caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "No internet connection."
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Online via Wi-Fi."
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Online via mobile data."
                    else -> "Online."
                }
            } catch (e: Exception) { "Could not check the network." }
        }

        // ── open things (no extra permission; the user still sees the screen) ──
        ToolRegistry.register("share_text",
            "Open the Android share sheet with some text so the user can pick an app to send it with. Does NOT send anything by itself.",
            mapOf("text" to p("STRING", "Text to share")), listOf("text")) { ctx, a ->
            val t = a.optString("text")
            if (t.isBlank()) return@register "What should I share?"
            launch(ctx, Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }, "Share with"), "Share sheet opened")
        }
        ToolRegistry.register("map_search",
            "Show a place or 'restaurants near me' style search in the maps app.",
            mapOf("query" to p("STRING", "Place or search")), listOf("query")) { ctx, a ->
            val q = a.optString("query")
            if (q.isBlank()) return@register "Which place?"
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))), "Opened maps for $q")
        }
        ToolRegistry.register("web_search",
            "Open a Google search for the user in the browser. For quick factual answers just answer or use search grounding instead.",
            mapOf("query" to p("STRING", "What to search")), listOf("query")) { ctx, a ->
            val q = a.optString("query")
            if (q.isBlank()) return@register "What should I search?"
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), "Searching for $q")
        }
        ToolRegistry.register("dial_number",
            "Open the phone dialer with a number typed in. It does NOT place the call - the user presses call. (Use call_contact to call a saved contact.)",
            mapOf("number" to p("STRING", "Phone number")), listOf("number")) { ctx, a ->
            val n = a.optString("number").filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
            if (n.length < 3) return@register "I didn't get a valid number."
            launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))), "Dialer opened with the number ready")
        }
    }

    // ───────────── helpers ─────────────

    private fun num(a: JSONObject, key: String): Double? =
        if (!a.has(key) || a.isNull(key)) null else a.opt(key)?.toString()?.trim()?.replace(",", "")?.toDoubleOrNull()

    private fun launch(ctx: Context, i: Intent, ok: String): String = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok
    } catch (e: Exception) { "Couldn't open that on this phone." }

    private fun loadTodos(ctx: Context): JSONArray =
        try { JSONArray(ctx.prefs().getString(TODOS, "[]")) } catch (_: Exception) { JSONArray() }

    private fun span(ms: Long): String {
        val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return buildString {
            if (h > 0) append("$h hours ")
            if (m > 0 || h > 0) append("$m minutes ")
            append("$sec seconds")
        }
    }

    private val dateFormats = listOf("yyyy-M-d", "d-M-yyyy", "d/M/yyyy", "d MMMM yyyy", "MMMM d yyyy", "MMMM d, yyyy", "d MMM yyyy", "MMM d yyyy")

    fun parseDate(raw: String): LocalDate? {
        val s = raw.trim().replace(Regex("(?<=\\d)(st|nd|rd|th)\\b"), "")
        when (s.lowercase()) {
            "", "today" -> return LocalDate.now()
            "tomorrow" -> return LocalDate.now().plusDays(1)
            "yesterday" -> return LocalDate.now().minusDays(1)
        }
        for (f in dateFormats) {
            try { return LocalDate.parse(s, DateTimeFormatter.ofPattern(f, Locale.ENGLISH)) } catch (_: Exception) {}
        }
        return null
    }

    private val zoneAlias = mapOf(
        "india" to "Asia/Kolkata", "delhi" to "Asia/Kolkata", "mumbai" to "Asia/Kolkata", "kolkata" to "Asia/Kolkata",
        "bangladesh" to "Asia/Dhaka", "dhaka" to "Asia/Dhaka", "pakistan" to "Asia/Karachi", "nepal" to "Asia/Kathmandu",
        "usa" to "America/New_York", "us" to "America/New_York", "new york" to "America/New_York", "washington" to "America/New_York",
        "california" to "America/Los_Angeles", "san francisco" to "America/Los_Angeles", "los angeles" to "America/Los_Angeles",
        "chicago" to "America/Chicago", "texas" to "America/Chicago", "toronto" to "America/Toronto", "canada" to "America/Toronto",
        "uk" to "Europe/London", "england" to "Europe/London", "london" to "Europe/London",
        "uae" to "Asia/Dubai", "dubai" to "Asia/Dubai", "saudi" to "Asia/Riyadh", "qatar" to "Asia/Qatar",
        "japan" to "Asia/Tokyo", "tokyo" to "Asia/Tokyo", "china" to "Asia/Shanghai", "beijing" to "Asia/Shanghai",
        "korea" to "Asia/Seoul", "singapore" to "Asia/Singapore", "malaysia" to "Asia/Kuala_Lumpur",
        "germany" to "Europe/Berlin", "france" to "Europe/Paris", "italy" to "Europe/Rome", "spain" to "Europe/Madrid",
        "russia" to "Europe/Moscow", "australia" to "Australia/Sydney", "new zealand" to "Pacific/Auckland",
        "brazil" to "America/Sao_Paulo", "egypt" to "Africa/Cairo", "south africa" to "Africa/Johannesburg"
    )

    fun zoneFor(place: String): ZoneId? {
        val q = place.trim().lowercase()
        if (q.isEmpty()) return null
        zoneAlias[q]?.let { return ZoneId.of(it) }
        val key = q.replace(' ', '_')
        ZoneId.getAvailableZoneIds().firstOrNull { it.lowercase().endsWith("/$key") }?.let { return ZoneId.of(it) }
        return null
    }
}
