package com.myra.assistant.auth

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Shows the Google account picker and returns a Google ID token (then exchanged with Firebase). */
object GoogleSignIn {
    fun configured(): Boolean = FirebaseConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()

    /** Throws androidx.credentials.exceptions.GetCredentialException when cancelled / no account / bad setup. */
    suspend fun getIdToken(activity: Activity): String {
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(FirebaseConfig.GOOGLE_WEB_CLIENT_ID)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(activity).getCredential(activity, request)
        val cred = result.credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return GoogleIdTokenCredential.createFrom(cred.data).idToken
        }
        throw IllegalStateException("Google account paoa jay ni")
    }
}
