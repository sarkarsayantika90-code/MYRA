package com.myra.assistant.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.View
import com.myra.assistant.utils.Constants
import kotlin.math.PI
import kotlin.math.sin

/**
 * Soft rainbow light that runs around the screen edge while MYRA is awake (like Gemini Live).
 *  listening: slow breathing glow   thinking: faster, brighter swirl   speaking: pulses with her voice.
 * Pure canvas drawing (gradients, no blur) so it stays smooth on weak phones.
 */
class GlowView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val colors = intArrayOf(
        0xFF4285F4.toInt(),   // blue
        0xFF9B72F3.toInt(),   // purple
        0xFFFF6BA6.toInt(),   // pink
        0xFFFFA24C.toInt(),   // orange
        0xFF34D6C0.toInt(),   // teal
        0xFF4285F4.toInt()    // back to blue so the sweep is seamless
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var shaderW = 0
    private var shaderH = 0

    @Volatile private var state = Constants.STATE_LISTENING
    private var level = 0f            // smoothed voice level 0..1
    @Volatile private var targetLevel = 0f
    private var lastFrame = SystemClock.uptimeMillis()
    private var angle = 0f

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        isClickable = false
        isFocusable = false
    }

    fun setState(s: String) { state = s }
    fun setLevel(v: Float) { targetLevel = v.coerceIn(0f, 1f) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        if (shader == null || shaderW != w || shaderH != h) {
            shader = SweepGradient(w / 2f, h / 2f, colors, null)
            shaderW = w; shaderH = h
        }

        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame).coerceIn(1L, 64L)
        lastFrame = now
        level += (targetLevel - level) * 0.25f

        val t = now / 1000f
        val (spinSeconds, base) = when (state) {
            Constants.STATE_THINKING -> 2.6f to 0.85f
            Constants.STATE_SPEAKING -> 4.0f to (0.70f + 0.45f * level)
            else -> 6.5f to (0.50f + 0.12f * sin(t * 2f * PI.toFloat() / 3.2f))   // listening: breathe every ~3 s
        }
        angle = (angle + 360f * dt / (spinSeconds * 1000f)) % 360f

        matrix.setRotate(angle, w / 2f, h / 2f)
        shader!!.setLocalMatrix(matrix)
        paint.shader = shader

        val widthBoost = 1f + (if (state == Constants.STATE_SPEAKING) level * 0.6f else 0f)
        val radius = 38f * density
        // Wide + faint underneath, thin + bright on top = a glow that fades inwards.
        val widths = floatArrayOf(46f, 30f, 17f, 7f)
        val alphas = floatArrayOf(0.10f, 0.18f, 0.34f, 0.95f)
        for (i in widths.indices) {
            val sw = widths[i] * density * widthBoost
            paint.strokeWidth = sw
            paint.alpha = (255f * (alphas[i] * base).coerceIn(0f, 1f)).toInt()
            rect.set(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f)
            canvas.drawRoundRect(rect, radius, radius, paint)
        }
        postInvalidateOnAnimation()
    }

    @Suppress("unused")
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
}
