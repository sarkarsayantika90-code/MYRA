package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.control.AppAgent
import com.myra.assistant.control.PhoneController
import com.myra.assistant.utils.prefs
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Newer skills, registered through ToolRegistry. Add future skills here. */
object ExtraTools {
    internal const val NOTES = "myra_notes_json"

    fun registerAll() {
        fun p(t: String, d: String) = MyraTools.prop(t, d)

        ToolRegistry.register("play_video",
            "Find a video on YouTube and start playing the first matching result.",
            mapOf("query" to p("STRING", "What to watch")), listOf("query")) { ctx, a -> playVideo(ctx, a.optString("query")) }

        ToolRegistry.register("app_message",
            "STEP 1 of 2. Write a message to ONE person inside ANY chat app (Messenger, Telegram, Instagram, Signal...). Creates a draft only and returns awaiting_confirmation. Ask who/what first if missing. Not for WhatsApp (use execute_whatsapp_task) or SMS (use send_sms).",
            mapOf("app_name" to p("STRING", "Chat app name"), "person" to p("STRING", "Who to message"),
                "message" to p("STRING", "Final message text you wrote")), listOf("app_name", "person", "message")) { ctx, a ->
            AppAgent.prepareMessage(ctx, a.optString("app_name"), a.optString("person"), a.optString("message"))
        }
        ToolRegistry.register("confirm_app_message",
            "STEP 2 of 2: send the drafted in-app message. ONLY after you read recipient + exact text aloud and the user clearly said yes.") { _, _ ->
            AppAgent.confirmMessage()
        }
        ToolRegistry.register("cancel_app_message", "Discard the pending in-app message draft.") { _, _ -> AppAgent.cancelMessage() }

        ToolRegistry.register("app_call",
            "Place a voice or VIDEO call to ONE person inside any calling-capable app (Messenger, Telegram, Instagram, Signal, Google Meet/Duo...). For WhatsApp you may use execute_whatsapp_task video_call / voice_call.",
            mapOf("app_name" to p("STRING", "App"), "person" to p("STRING", "Who to call"),
                "video" to p("BOOLEAN", "true = video call, false = voice call")), listOf("app_name", "person")) { ctx, a ->
            AppAgent.call(ctx, a.optString("app_name"), a.optString("person"), a.optBoolean("video", false))
        }

        ToolRegistry.register("daily_briefing",
            "A quick briefing for the user: current date/time and part of the day, battery, and his latest saved notes. Use when he asks for his briefing, " +
                "'what's my day', 'catch me up', or as a helpful start of the day. After speaking it, offer to also read notifications or missed calls " +
                "(tools read_notifications / read_missed_calls) - call those only if he says yes.") { ctx, _ -> dailyBriefing(ctx) }

        ToolRegistry.register("save_note",
            "Remember something for the user (where he kept something, a to-do, an idea, a number).",
            mapOf("text" to p("STRING", "What to remember")), listOf("text")) { ctx, a -> saveNote(ctx, a.optString("text")) }

        MoreTools.registerAll()

        ToolRegistry.register("read_notes",
            "Read back the user's saved notes. Optional filter word.",
            mapOf("filter" to p("STRING", "Word to look for"))) { ctx, a -> readNotes(ctx, a.optString("filter")) }
    }

    private fun dailyBriefing(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        val level = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val charging = bm?.isCharging == true
        val notes = readNotes(ctx, "")
        return buildString {
            append(com.myra.assistant.utils.DayPart.describe()).append('\n')
            append("Battery: ").append(if (level >= 0) "$level%" else "unknown").append(if (charging) " (charging)" else "").append('\n')
            append("Latest notes: ").append(notes)
        }
    }

    private suspend fun playVideo(ctx: Context, query: String): String {
        if (query.isBlank()) return "What should I watch?"
        val r = PhoneController.searchInApp(ctx, "YouTube", query)
        if (r.contains("pailam na") || r.startsWith("App_not_found")) return r
        // YouTube result rows carry a description that ends with "play video".
        for (i in 0 until 6) {
            delay(900)
            if (PhoneController.tapContains("play video")) { delay(800); return "YouTube e '$query' chalu korlam" }
        }
        return "YouTube e '$query' search korechi kintu pratham video tap korte parlam na. Screen dekhe bolo konta chalabo."
    }

    private fun saveNote(ctx: Context, text: String): String {
        if (text.isBlank()) return "What should I remember?"
        val arr = try { JSONArray(ctx.prefs().getString(NOTES, "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("t", text.trim().take(400)).put("at", System.currentTimeMillis()))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 60) until arr.length()) trimmed.put(arr.get(i))
        ctx.prefs().edit().putString(NOTES, trimmed.toString()).apply()
        return "Saved to notes"
    }

    private fun readNotes(ctx: Context, filter: String): String {
        val arr = try { JSONArray(ctx.prefs().getString(NOTES, "[]")) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<String>()
        for (i in arr.length() - 1 downTo 0) {
            val t = arr.getJSONObject(i).optString("t")
            if (filter.isBlank() || t.contains(filter, ignoreCase = true)) out.add(t)
            if (out.size >= 8) break
        }
        return if (out.isEmpty()) "No notes yet" else out.joinToString(" | ")
    }
}
