package com.myra.assistant.task

enum class TaskEventType {
    TASK_CREATED,
    PLAN_CREATED,
    STEP_STARTED,
    STEP_PROGRESS,
    ACTION_REQUESTED,
    CONFIRMATION_REQUIRED,
    PERMISSION_REQUIRED,
    ACTION_COMPLETED,
    CHECKPOINT_SAVED,
    WAITING,
    RETRYING,
    TASK_PAUSED,
    TASK_RESUMED,
    TASK_CANCELLED,
    TASK_COMPLETED,
    TASK_FAILED
}

/**
 * One entry in a task's event stream. Persisted via [TaskEventDao] so the
 * history survives process death, and exposed live via
 * TaskRepository.observeEvents() for UI / voice progress updates.
 *
 * Kept intentionally lightweight — this is NOT where large tool output goes;
 * put that in TaskCheckpoint or LongTask.result instead. `message` should be
 * short enough to be safe to speak aloud (see Phase 6 voice guidance: don't
 * speak every internal event).
 */
data class TaskEvent(
    val eventId: String,
    val taskId: String,
    val timestamp: Long,
    val eventType: TaskEventType,
    val stepId: String? = null,
    val message: String? = null,
    val progress: Int? = null,
    val metadata: Map<String, String> = emptyMap()
)
