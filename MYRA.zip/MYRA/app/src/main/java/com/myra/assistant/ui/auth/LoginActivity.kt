package com.myra.assistant.ui.auth

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.auth.FirebaseRest
import com.myra.assistant.ui.UiKit
import com.myra.assistant.ui.UiKit.dp
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.ui.main.OrbAnimationView
import com.myra.assistant.ui.main.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Login / Sign-up / Forgot password. Session is kept, so this only shows once per device. */
class LoginActivity : AppCompatActivity() {
    private var signUpMode = false
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var main: Button
    private lateinit var switchMode: TextView
    private lateinit var subtitleView: TextView
    private lateinit var msg: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val accent = ThemeManager.accent(this)

        val scroll = ScrollView(this).apply { background = UiKit.screenBg(this@LoginActivity, accent); isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(this@LoginActivity, 26), dp(this@LoginActivity, 50), dp(this@LoginActivity, 26), dp(this@LoginActivity, 30))
        }
        scroll.addView(col)

        val orb = OrbAnimationView(this).also { it.setAccent(accent); it.setListening() }
        col.addView(orb, LinearLayout.LayoutParams(dp(this, 190), dp(this, 190)))

        col.addView(UiKit.label(this, "MYRA", 34f, accent, true, true).apply {
            letterSpacing = 0.3f; setShadowLayer(22f, 0f, 0f, accent)
        })
        subtitleView = UiKit.label(this, "Welcome back, sona", 15f, UiKit.DIM, false, true)
        col.addView(subtitleView)

        email = UiKit.input(this, "Email", email = true)
        pass = UiKit.input(this, "Password", password = true)
        col.addView(email, UiKit.lp(top = 26, c = this))
        col.addView(pass, UiKit.lp(top = 12, c = this))

        main = UiKit.button(this, "Login", accent) { submit() }
        col.addView(main, UiKit.lp(top = 18, c = this))

        progress = ProgressBar(this).apply { visibility = android.view.View.GONE }
        col.addView(progress, UiKit.lp(w = dp(this, 28), h = dp(this, 28), top = 10, c = this))

        msg = UiKit.label(this, "", 13f, 0xFFFF8A80.toInt(), false, true)
        col.addView(msg, UiKit.lp(top = 8, c = this))

        switchMode = UiKit.label(this, "New here? Create account", 14f, accent, true, true).apply {
            setPadding(0, dp(this@LoginActivity, 14), 0, dp(this@LoginActivity, 14))
            setOnClickListener { toggleMode() }
        }
        col.addView(switchMode)

        col.addView(UiKit.label(this, "Forgot password?", 13f, UiKit.DIM, false, true).apply {
            setOnClickListener { forgot() }
        })
        setContentView(scroll)
    }

    private fun toggleMode() {
        signUpMode = !signUpMode
        main.text = if (signUpMode) "Create account" else "Login"
        switchMode.text = if (signUpMode) "Already have an account? Login" else "New here? Create account"
        subtitleView.text = if (signUpMode) "Join MYRA - she is waiting for you" else "Welcome back, sona"
        msg.text = ""
    }

    private fun busy(b: Boolean) {
        progress.visibility = if (b) android.view.View.VISIBLE else android.view.View.GONE
        main.isEnabled = !b
    }

    private fun submit() {
        val e = email.text.toString().trim().lowercase()
        val p = pass.text.toString()
        if (e.isEmpty() || p.isEmpty()) { msg.text = "Email ar password dao"; return }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) { msg.text = "Email ta thik moto likho (jemon name@gmail.com)"; return }
        busy(true); msg.setTextColor(0xFFFF8A80.toInt()); msg.text = ""
        lifecycleScope.launch {
            var cfg = -1
            val err = withContext(Dispatchers.IO) {
                try {
                    if (signUpMode) FirebaseRest.signUp(this@LoginActivity, e, p) else FirebaseRest.signIn(this@LoginActivity, e, p)
                    com.myra.assistant.auth.UserSync.touch(this@LoginActivity, signUpMode)
                    cfg = com.myra.assistant.auth.RemoteConfig.refresh(this@LoginActivity)
                    null
                } catch (ex: FirebaseRest.FirebaseError) {
                    // Sign-up with an email that already exists -> just sign in instead.
                    if (signUpMode && ex.code.startsWith("EMAIL_EXISTS")) {
                        try {
                            FirebaseRest.signIn(this@LoginActivity, e, p)
                            com.myra.assistant.auth.UserSync.touch(this@LoginActivity, false)
                            cfg = com.myra.assistant.auth.RemoteConfig.refresh(this@LoginActivity)
                            null
                        } catch (ex2: FirebaseRest.FirebaseError) { "Ei email e age account ache, kintu password mille ni. 'Forgot password' dao.  [" + ex2.code.take(50) + "]" }
                    } else FirebaseRest.friendly(ex.code)
                } catch (ex: Exception) {
                    "Login hoilo na: " + (ex.message ?: ex.javaClass.simpleName).take(80)
                }
            }
            busy(false)
            if (err != null) { msg.text = err; return@launch }
            if (cfg == com.myra.assistant.auth.RemoteConfig.DENIED)
                Toast.makeText(this@LoginActivity, "Login hoyeche, kintu server setup access pai ni. Admin ke Firebase rules publish korte bolo.", Toast.LENGTH_LONG).show()
            if (signUpMode) Toast.makeText(this@LoginActivity, "Account hoye geche! Verify email pathiyechi (spam-o dekho).", Toast.LENGTH_LONG).show()
            startActivity(Intent(this@LoginActivity, MainActivity::class.java))
            finish()
        }
    }

    private fun forgot() {
        val e = email.text.toString().trim()
        if (e.isEmpty()) { msg.text = "Age email likho, tarpor 'Forgot password' dao"; return }
        busy(true)
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try { FirebaseRest.resetPassword(e); null } catch (ex: FirebaseRest.FirebaseError) { FirebaseRest.friendly(ex.code) }
            }
            busy(false)
            msg.setTextColor(if (err == null) 0xFF69F0AE.toInt() else 0xFFFF8A80.toInt())
            msg.text = err ?: "Password reset email pathiyechi"
        }
    }
}
