package com.myra.assistant.ui.auth

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.auth.FirebaseRest
import com.myra.assistant.auth.GoogleSignIn
import com.myra.assistant.auth.RemoteConfig
import com.myra.assistant.auth.UserSync
import com.myra.assistant.ui.UiKit
import com.myra.assistant.ui.UiKit.dp
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.ui.main.OrbAnimationView
import com.myra.assistant.ui.main.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Login / Sign-up / Google login / Forgot password. Session is kept, so this only shows once per device. */
class LoginActivity : AppCompatActivity() {
    private var signUpMode = false
    private var passVisible = false
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var main: Button
    private lateinit var googleBtn: Button
    private lateinit var switchMode: TextView
    private lateinit var forgotView: TextView
    private lateinit var showPass: TextView
    private lateinit var subtitleView: TextView
    private lateinit var msg: TextView
    private lateinit var progress: ProgressBar

    private val red = 0xFFFF8A80.toInt()
    private val green = 0xFF69F0AE.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val accent = ThemeManager.accent(this)

        val scroll = ScrollView(this).apply { background = UiKit.screenBg(this@LoginActivity, accent); isFillViewport = true }
        // Keep the form clear of the status bar, navigation bar and keyboard (Android 15 draws edge-to-edge).
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(this@LoginActivity, 26), dp(this@LoginActivity, 24), dp(this@LoginActivity, 26), dp(this@LoginActivity, 30))
        }
        scroll.addView(col)

        val orb = OrbAnimationView(this).also { it.setAccent(accent); it.setListening() }
        col.addView(orb, LinearLayout.LayoutParams(dp(this, 170), dp(this, 170)))

        col.addView(UiKit.label(this, "MYRA", 34f, accent, true, true).apply {
            letterSpacing = 0.3f; setShadowLayer(22f, 0f, 0f, accent)
        })
        subtitleView = UiKit.label(this, "Welcome back", 15f, UiKit.DIM, false, true)
        col.addView(subtitleView)

        email = UiKit.input(this, "Email", email = true).apply { imeOptions = EditorInfo.IME_ACTION_NEXT }
        pass = UiKit.input(this, "Password", password = true).apply {
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
            }
        }
        col.addView(email, UiKit.lp(top = 24, c = this))
        col.addView(pass, UiKit.lp(top = 12, c = this))

        showPass = UiKit.label(this, "Show password", 12f, UiKit.DIM).apply {
            gravity = Gravity.END
            setPadding(dp(this@LoginActivity, 8), dp(this@LoginActivity, 8), dp(this@LoginActivity, 4), dp(this@LoginActivity, 4))
            setOnClickListener { togglePass() }
        }
        col.addView(showPass, UiKit.lp(c = this))

        main = UiKit.button(this, "Login", accent) { submit() }
        col.addView(main, UiKit.lp(top = 6, c = this))

        // Forgot password: a proper tappable row right under the Login button.
        forgotView = UiKit.label(this, "Forgot password?", 14f, accent, true, true).apply {
            setPadding(dp(this@LoginActivity, 12), dp(this@LoginActivity, 14), dp(this@LoginActivity, 12), dp(this@LoginActivity, 10))
            setOnClickListener { forgot() }
        }
        col.addView(forgotView)

        progress = ProgressBar(this).apply { visibility = View.GONE }
        col.addView(progress, UiKit.lp(w = dp(this, 28), h = dp(this, 28), top = 4, c = this))

        msg = UiKit.label(this, "", 13f, red, false, true)
        col.addView(msg, UiKit.lp(top = 4, c = this))

        col.addView(UiKit.label(this, "— or —", 12f, UiKit.DIM, false, true), UiKit.lp(top = 10, c = this))
        googleBtn = UiKit.button(this, "G   Continue with Google", accent, filled = false) { googleLogin() }
        col.addView(googleBtn, UiKit.lp(top = 8, c = this))

        switchMode = UiKit.label(this, "New here? Create account", 14f, accent, true, true).apply {
            setPadding(0, dp(this@LoginActivity, 18), 0, dp(this@LoginActivity, 14))
            setOnClickListener { toggleMode() }
        }
        col.addView(switchMode)
        setContentView(scroll)
    }

    private fun togglePass() {
        passVisible = !passVisible
        val sel = pass.selectionEnd
        pass.inputType = if (passVisible) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pass.setSelection(sel.coerceIn(0, pass.text.length))
        showPass.text = if (passVisible) "Hide password" else "Show password"
    }

    private fun toggleMode() {
        signUpMode = !signUpMode
        main.text = if (signUpMode) "Create account" else "Login"
        switchMode.text = if (signUpMode) "Already have an account? Login" else "New here? Create account"
        subtitleView.text = if (signUpMode) "Join MYRA - your personal voice assistant" else "Welcome back"
        forgotView.visibility = if (signUpMode) View.GONE else View.VISIBLE
        msg.text = ""
    }

    private fun busy(b: Boolean) {
        progress.visibility = if (b) View.VISIBLE else View.GONE
        main.isEnabled = !b
        googleBtn.isEnabled = !b
        forgotView.isEnabled = !b
        switchMode.isEnabled = !b
    }

    private fun showError(t: String) { msg.setTextColor(red); msg.text = t }

    private fun validEmail(e: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()

    private fun submit() {
        val e = email.text.toString().trim().lowercase()
        val p = pass.text.toString()
        if (e.isEmpty() || p.isEmpty()) { showError("Enter your email and password"); return }
        if (!validEmail(e)) { showError("Enter a valid email (e.g. name@gmail.com)"); return }
        if (signUpMode && p.length < 6) { showError("Password must be at least 6 characters"); return }
        busy(true); msg.text = ""
        lifecycleScope.launch {
            var cfg = -1
            val err = withContext(Dispatchers.IO) {
                try {
                    if (signUpMode) FirebaseRest.signUp(this@LoginActivity, e, p) else FirebaseRest.signIn(this@LoginActivity, e, p)
                    UserSync.touch(this@LoginActivity, signUpMode)
                    cfg = RemoteConfig.refresh(this@LoginActivity)
                    null
                } catch (ex: FirebaseRest.FirebaseError) {
                    // Sign-up with an email that already exists -> just sign in instead.
                    if (signUpMode && ex.code.startsWith("EMAIL_EXISTS")) {
                        try {
                            FirebaseRest.signIn(this@LoginActivity, e, p)
                            UserSync.touch(this@LoginActivity, false)
                            cfg = RemoteConfig.refresh(this@LoginActivity)
                            null
                        } catch (ex2: FirebaseRest.FirebaseError) {
                            if (isBadCredentials(ex2.code)) badCredentialsMessage(e)
                            else FirebaseRest.friendly(ex2.code)
                        }
                    } else if (!signUpMode && isBadCredentials(ex.code)) badCredentialsMessage(e)
                    else FirebaseRest.friendly(ex.code)
                } catch (ex: Exception) {
                    "Login failed: " + (ex.message ?: ex.javaClass.simpleName).take(80)
                }
            }
            busy(false)
            if (err != null) { showError(err); return@launch }
            if (signUpMode) Toast.makeText(this@LoginActivity, "Account created! We sent a verification email (check spam too).", Toast.LENGTH_LONG).show()
            goHome(cfg)
        }
    }

    private fun isBadCredentials(code: String) =
        code.startsWith("INVALID_LOGIN_CREDENTIALS") || code.startsWith("INVALID_PASSWORD") || code.startsWith("EMAIL_NOT_FOUND")

    /**
     * Wrong email/password. The most common real reason: the account was made with "Continue with Google", so it
     * has NO password at all. Ask Firebase which sign-in methods exist and say exactly what to do. Runs off the main thread.
     */
    private fun badCredentialsMessage(email: String): String {
        val methods = FirebaseRest.signInMethods(email)
        return when {
            "google.com" in methods && "password" !in methods ->
                "This email was registered with Google, so it has no password.\n" +
                    "Tap 'Continue with Google' below. After logging in, go to Settings > Account > 'Set password' to also log in with email + password."
            methods.isEmpty() ->
                "Wrong email or password.\nIf you signed up with 'Continue with Google', use that button again " +
                    "(Google accounts have no password). New here? Tap 'Create account'. [INVALID_LOGIN_CREDENTIALS]"
            else -> "Wrong password. Use 'Forgot password?' to reset it. [INVALID_LOGIN_CREDENTIALS]"
        }
    }

    private fun googleLogin() {
        if (!GoogleSignIn.configured()) {
            showError("Google login is not set up yet (Web client ID needed). Please log in with email."); return
        }
        busy(true); msg.text = ""
        lifecycleScope.launch {
            var cfg = -1
            var err: String? = null
            try {
                val idToken = GoogleSignIn.getIdToken(this@LoginActivity)
                err = withContext(Dispatchers.IO) {
                    try {
                        val (_, isNew) = FirebaseRest.signInWithGoogle(this@LoginActivity, idToken)
                        UserSync.touch(this@LoginActivity, isNew)
                        cfg = RemoteConfig.refresh(this@LoginActivity)
                        null
                    } catch (ex: FirebaseRest.FirebaseError) {
                        FirebaseRest.friendly(ex.code)
                    } catch (ex: Exception) {
                        "Google login failed: " + (ex.message ?: ex.javaClass.simpleName).take(80)
                    }
                }
            } catch (ex: GetCredentialCancellationException) {
                err = "Google login was cancelled"
            } catch (ex: NoCredentialException) {
                err = googleHelp(ex)
            } catch (ex: GetCredentialException) {
                err = googleHelp(ex)
            } catch (ex: Exception) {
                err = "Google login failed: " + (ex.message ?: ex.javaClass.simpleName).take(80)
            }
            busy(false)
            if (err != null) { showError(err); return@launch }
            goHome(cfg)
        }
    }

    /**
     * "No credentials" is ALSO what Google returns when this app is not registered in Firebase with its
     * SHA-1 - so it does not always mean the phone has no Google account. Show the exact values to register.
     */
    private fun googleHelp(ex: Exception): String {
        val sha = com.myra.assistant.utils.AppSignature.sha1(this)
        msg.setOnClickListener {
            val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("SHA-1", sha))
            Toast.makeText(this, "SHA-1 copied", Toast.LENGTH_SHORT).show()
        }
        return "Google login failed. This error also appears when the app is not registered in Firebase with its SHA-1, even if the phone has a Google account.\n" +
            "Firebase > Project settings > Add Android app:\nPackage: $packageName\nSHA-1: $sha\n" +
            "(tap this text to copy the SHA-1). Authentication > Google must be enabled.\n" +
            "[" + ex.javaClass.simpleName + ": " + (ex.message ?: "").take(60) + "]"
    }

    private fun goHome(cfg: Int) {
        if (cfg == RemoteConfig.DENIED)
            Toast.makeText(this, "Logged in, but server setup could not be loaded. Ask the admin to publish the Firebase rules.", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun forgot() {
        val e = email.text.toString().trim().lowercase()
        if (e.isEmpty()) { showError("Enter your email above first, then tap 'Forgot password'"); return }
        if (!validEmail(e)) { showError("Enter a valid email (e.g. name@gmail.com)"); return }
        busy(true); msg.text = ""
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try { FirebaseRest.resetPassword(e); null } catch (ex: FirebaseRest.FirebaseError) {
                    if (ex.code.startsWith("EMAIL_NOT_FOUND")) "No account exists for this email. Tap 'Create account'."
                    else FirebaseRest.friendly(ex.code)
                } catch (ex: Exception) { "Could not send the reset email: " + (ex.message ?: "").take(60) }
            }
            busy(false)
            if (err == null) { msg.setTextColor(green); msg.text = "We sent a password reset email. Check your inbox and spam, then tap the link to choose a new password." }
            else showError(err)
        }
    }
}
