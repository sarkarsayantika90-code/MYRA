package com.myra.assistant.whatsapp

import android.app.Notification
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import java.util.concurrent.ConcurrentHashMap

/**
 * Read-only unread tracker built from WhatsApp's OWN notifications (PDF section 5A). Never opens
 * WhatsApp, never touches Accessibility. Kept in memory only and never logged: message text is
 * held just long enough to be read back to the person when they ask.
 */
object WhatsAppNotificationStore {
    data class Unread(val key: String, val chat: String, val count: Int, val previews: List<String>, val at: Long)

    private val map = ConcurrentHashMap<String, Unread>()
    private val COLLAPSED = Regex("^\\d+\\s+new\\s+messages?.*", RegexOption.IGNORE_CASE)

    fun isWhatsApp(pkg: String) = pkg == WhatsAppSelectors.PKG || pkg == WhatsAppSelectors.PKG_BUSINESS

    fun onPosted(sbn: StatusBarNotification) {
        if (!isWhatsApp(sbn.packageName)) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return // "N messages from M chats" summary
        val extras = n.extras
        val chat = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        if (chat.isBlank()) return

        val previews = ArrayList<String>()
        try {
            val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
            style?.messages?.forEach { m ->
                val t = m.text?.toString()?.trim().orEmpty()
                if (t.isNotEmpty()) previews.add(t)
            }
        } catch (_: Exception) {}
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        var count = previews.size
        if (previews.isEmpty() && text.isNotEmpty()) {
            if (COLLAPSED.matches(text)) {
                count = Regex("^\\d+").find(text)?.value?.toIntOrNull() ?: 1
            } else {
                previews.add(text); count = 1
            }
        }
        if (count == 0) count = 1
        map[sbn.key] = Unread(sbn.key, chat, count, previews.takeLast(5), sbn.postTime)
    }

    fun onRemoved(sbn: StatusBarNotification) {
        if (isWhatsApp(sbn.packageName)) map.remove(sbn.key)
    }

    fun clearAll() = map.clear()

    fun all(): List<Unread> = map.values.sortedByDescending { it.at }

    fun totalUnread(): Int = all().sumOf { it.count }

    fun forChat(query: String): Unread? {
        val q = query.trim().lowercase()
        return all().firstOrNull { it.chat.lowercase().contains(q) }
    }
}
