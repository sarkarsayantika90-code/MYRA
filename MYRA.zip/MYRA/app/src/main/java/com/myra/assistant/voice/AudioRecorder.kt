package com.myra.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Logger

class AudioRecorder(
    private val context: Context,
    private val onChunk: (ByteArray) -> Unit
) {
    private val TAG = "RECORDER"
    private val SAMPLE_RATE = 16000
    private val CHUNK_SIZE = 640   // 20ms at 16kHz mono 16-bit (smaller chunks = she hears you sooner)

    private var audioRecord: AudioRecord? = null
    private var recordThread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var isRecording = false
    /** Bumped on every start/stop so a thread from an older start can never keep feeding chunks. */
    @Volatile private var generation = 0
    /** The caller wants the mic open (survives a mic that died by itself, e.g. another app grabbed it). */
    @Volatile private var wanted = false

    /** Bluetooth / wired mic to record from. null = the phone's own mic. Changed via [reroute]. */
    @Volatile private var preferred: AudioDeviceInfo? = null

    /**
     * false (default) = keep sending mic audio while MYRA speaks so the user can interrupt her
     * (Gemini does barge-in). The hardware echo canceller handles her own voice. Set true only
     * for phones with a bad echo canceller and no headphones.
     */
    @Volatile var gateWhileSpeaking = false

    @Synchronized
    fun start() {
        wanted = true
        if (isRecording) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Logger.e(TAG, "RECORD_AUDIO permission not granted")
            return
        }

        val bufferSize = AudioUtils.getMinBufferSize(SAMPLE_RATE)

        try {
            var ar = build(MediaRecorder.AudioSource.VOICE_COMMUNICATION, bufferSize)
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                // A few phones refuse the call-tuned source; the plain mic always works.
                try { ar.release() } catch (_: Exception) {}
                ar = build(MediaRecorder.AudioSource.MIC, bufferSize)
            }
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                try { ar.release() } catch (_: Exception) {}
                Logger.e(TAG, "AudioRecord not initialized (mic busy?)")
                scheduleRetry()
                return
            }
            audioRecord = ar
            try { preferred?.let { ar.setPreferredDevice(it) } } catch (e: Exception) { Logger.e(TAG, "preferred device: ${e.message}") }

            EchoCancellationManager.attach(ar.audioSessionId)
            val noise = NoiseFilter(com.myra.assistant.utils.PrefsHelper.noiseLevel(context))
            ar.startRecording()
            isRecording = true
            val myGen = ++generation

            recordThread = Thread {
                val buffer = ByteArray(CHUNK_SIZE)
                while (isRecording && generation == myGen && !Thread.currentThread().isInterrupted) {
                    val read = try { ar.read(buffer, 0, buffer.size) } catch (e: Exception) { -1 }
                    if (read > 0) {
                        if (!(gateWhileSpeaking && VoiceStateManager.isAiSpeaking())) {
                            try { onChunk(noise.process(buffer.copyOf(read))) } catch (e: Exception) { Logger.e(TAG, "chunk: ${e.message}") }
                        }
                    } else if (read < 0) {
                        // ERROR_DEAD_OBJECT etc. If we did not stop on purpose, reopen the mic.
                        if (generation == myGen && wanted) {
                            Logger.e(TAG, "read error $read - reopening mic")
                            isRecording = false
                            scheduleRetry()
                        }
                        break
                    }
                }
            }.also {
                it.name = "MYRA_RecordThread"
                it.isDaemon = true
                it.start()
            }

            Logger.d(TAG, "Recording started")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to start recording: ${e.message}")
            releaseNow()
            scheduleRetry()
        }
    }

    private fun build(source: Int, bufferSize: Int) = AudioRecord(
        source, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
    )

    private fun scheduleRetry() {
        if (!wanted) return
        main.postDelayed({
            if (wanted && !isRecording) {
                releaseNow()
                start()
            }
        }, 800)
    }

    /**
     * Switch to another microphone (Bluetooth headset / wired / phone) - reopens the mic only if the device really changed.
     * An AudioRecord that was opened before the Bluetooth link came up keeps using the phone mic, so a reopen is required.
     */
    fun reroute(device: AudioDeviceInfo?) {
        val changed = (device?.id ?: -1) != (preferred?.id ?: -1)
        preferred = device
        if (!changed || !wanted) return
        Logger.d(TAG, "mic route changed -> reopen")
        releaseNow()
        start()
    }

    @Synchronized
    private fun releaseNow() {
        isRecording = false
        generation++
        recordThread?.interrupt()
        recordThread = null
        val ar = audioRecord
        audioRecord = null
        try { ar?.stop() } catch (_: Exception) {}
        try { ar?.release() } catch (_: Exception) {}
        try { EchoCancellationManager.release() } catch (_: Exception) {}
    }

    fun stop() {
        wanted = false
        main.removeCallbacksAndMessages(null)
        releaseNow()
        Logger.d(TAG, "Recording stopped")
    }

    fun isActive() = isRecording
}
