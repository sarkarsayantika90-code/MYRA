package com.myra.assistant.ui.main

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.MediaShareInbox
import java.io.File

/**
 * Handles the system Share sheet target "Share -> MYRA" for a single
 * image/video. Per the social-media-automation safety spec: an intent from
 * another app must NEVER silently put media into MYRA's posting inbox — the
 * person must explicitly confirm it here first. This activity does nothing
 * but show that confirmation and, on yes, copy the media into MYRA's own
 * app-private storage (so it survives the source app closing).
 *
 * This is a transparent, no-UI-of-its-own activity: it shows one dialog and
 * finishes immediately either way.
 */
class ShareInboxReceiverActivity : Activity() {

    private val TAG = "SHARE_INBOX"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sourceUri: Uri? = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        val mimeType = intent?.type ?: ""

        if (sourceUri == null || (!mimeType.startsWith("image/") && !mimeType.startsWith("video/"))) {
            finish()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("MYRA")
            .setMessage("Ye photo/video MYRA ko de dun? Baad mein 'Instagram/Facebook par post karo' bolke use kar paoge.")
            .setPositiveButton("Haan") { _, _ -> acceptMedia(sourceUri, mimeType) }
            .setNegativeButton("Nahi") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun acceptMedia(sourceUri: Uri, mimeType: String) {
        try {
            val inboxDir = File(filesDir, "MyraShareInbox").apply { if (!exists()) mkdirs() }
            val ext = if (mimeType.startsWith("video/")) "mp4" else "jpg"
            val destFile = File(inboxDir, "shared_${System.currentTimeMillis()}.$ext")

            contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }

            if (destFile.exists() && destFile.length() > 0) {
                MediaShareInbox.add(this, destFile.absolutePath, mimeType)
                Toast.makeText(this, "MYRA ko de diya ✅", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Media copy nahi ho paya", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Share accept failed: ${e.message}")
            Toast.makeText(this, "Kuch error ho gaya", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }
}
