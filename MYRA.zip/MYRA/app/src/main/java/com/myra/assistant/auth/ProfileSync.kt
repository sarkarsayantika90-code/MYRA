package com.myra.assistant.auth

import android.content.Context
import com.myra.assistant.update.UpdateManager
import com.myra.assistant.utils.prefs
import org.json.JSONObject

/** Tells the admin site this install exists: email, version, device, last seen. No messages, no contacts, no screen data. */
object ProfileSync {
    fun sync(ctx: Context, force: Boolean = false) {
        val p = ctx.prefs()
        val now = System.currentTimeMillis()
        if (!force && now - p.getLong("profile_at", 0L) < 5 * 60_000L) return
        val s = Session.get(ctx) ?: return
        if (p.getLong("first_seen", 0L) == 0L) p.edit().putLong("first_seen", now).apply()
        try {
            FirebaseRest.dbPatch(ctx, "users/${s.uid}/profile", JSONObject()
                .put("email", s.email)
                .put("createdAt", p.getLong("first_seen", now))
                .put("lastSeen", now)
                .put("ver", UpdateManager.installedName(ctx))
                .put("code", UpdateManager.installedCode(ctx))
                .put("device", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}".take(40))
                .put("os", android.os.Build.VERSION.SDK_INT))
            p.edit().putLong("profile_at", now).apply()
        } catch (_: Exception) {}
    }
}
