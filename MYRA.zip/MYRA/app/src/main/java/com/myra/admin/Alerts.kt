package com.myra.admin

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Alert(val at: Long, val kind: String, val title: String, val text: String)

/** Alerts inbox kept on this phone (newest 150). */
object AlertStore {
    private fun p(ctx: Context) = ctx.getSharedPreferences("admin_alerts", Context.MODE_PRIVATE)

    @Synchronized fun add(ctx: Context, kind: String, title: String, text: String, unread: Boolean = true) {
        val arr = try { JSONArray(p(ctx).getString("list", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("at", System.currentTimeMillis()).put("kind", kind).put("title", title).put("text", text))
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 150) until arr.length()) out.put(arr.get(i))
        p(ctx).edit().putString("list", out.toString())
            .putInt("unread", p(ctx).getInt("unread", 0) + if (unread) 1 else 0).apply()
    }

    @Synchronized fun all(ctx: Context): List<Alert> {
        val arr = try { JSONArray(p(ctx).getString("list", "[]")) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<Alert>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Alert(o.optLong("at"), o.optString("kind"), o.optString("title"), o.optString("text")))
        }
        return out
    }

    fun unread(ctx: Context) = p(ctx).getInt("unread", 0)
    fun markRead(ctx: Context) { p(ctx).edit().putInt("unread", 0).apply() }
    @Synchronized fun clear(ctx: Context) { p(ctx).edit().remove("list").putInt("unread", 0).apply() }
}

object Notifier {
    private const val CH = "admin_alerts"

    fun canPost(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun post(ctx: Context, id: Int, title: String, text: String, tab: String) {
        if (!canPost(ctx)) return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Admin alerts", NotificationManager.IMPORTANCE_HIGH))
            val open = Intent(ctx, SplashActivity::class.java).putExtra("tab", tab).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(id, android.app.Notification.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Exception) {}
    }
}

/** Looks for new pending payments and new users. The first run only remembers what already exists. */
object Watcher {
    private fun p(ctx: Context) = ctx.getSharedPreferences("admin_watch", Context.MODE_PRIVATE)
    private fun rid() = Math.abs((System.nanoTime() % 900).toInt())

    fun wantsPay(ctx: Context) = p(ctx).getBoolean("alert_pay", true)
    fun wantsUsers(ctx: Context) = p(ctx).getBoolean("alert_user", true)
    fun setWants(ctx: Context, pay: Boolean, users: Boolean) { p(ctx).edit().putBoolean("alert_pay", pay).putBoolean("alert_user", users).apply() }
    fun intervalMinutes(ctx: Context) = p(ctx).getInt("interval", 15)
    fun setInterval(ctx: Context, m: Int) { p(ctx).edit().putInt("interval", m).apply() }

    /** Blocking. Returns how many new things were found. */
    @Synchronized
    fun check(ctx: Context): Int {
        if (!Auth.isLoggedIn(ctx)) return 0
        var found = 0
        val pr = p(ctx)

        if (wantsPay(ctx)) {
            val pay = Db.getObject(ctx, "payments")
            val pending = LinkedHashMap<String, String>()
            for (uid in pay.keys()) {
                val per = pay.optJSONObject(uid) ?: continue
                for (id in per.keys()) {
                    val o = per.optJSONObject(id) ?: continue
                    if (o.optString("status") == "pending")
                        pending["$uid/$id"] = "${o.optString("email").ifBlank { uid }}: ${o.optString("plan")} - Rs ${o.optString("amount")} (UTR ${o.optString("utr")})"
                }
            }
            val seen = pr.getStringSet("seen_pay", null)
            if (seen != null) {
                val fresh = pending.filterKeys { it !in seen }
                for ((_, d) in fresh.entries.take(5)) {
                    AlertStore.add(ctx, "pay", "New payment to approve", d)
                    Notifier.post(ctx, 2000 + rid(), "New payment to approve", d, "pay")
                }
                if (fresh.size > 5) AlertStore.add(ctx, "pay", "More payments waiting", "${fresh.size - 5} more pending payments")
                found += fresh.size
            }
            pr.edit().putStringSet("seen_pay", HashSet(pending.keys)).apply()
        }

        if (wantsUsers(ctx)) {
            val uids = Db.keys(ctx, "users")
            val seen = pr.getStringSet("seen_users", null)
            if (seen != null) {
                val fresh = uids.filter { it !in seen }
                for (uid in fresh.take(5)) {
                    val email = try { Db.getObject(ctx, "users/$uid/profile").optString("email") } catch (_: Exception) { "" }
                    val who = email.ifBlank { "a new user" }
                    AlertStore.add(ctx, "user", "New user joined", who)
                    Notifier.post(ctx, 3000 + rid(), "New user joined", who, "users")
                }
                if (fresh.size > 5) AlertStore.add(ctx, "user", "More new users", "${fresh.size - 5} more users joined")
                found += fresh.size
            }
            pr.edit().putStringSet("seen_users", HashSet(uids)).apply()
        }
        return found
    }

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<CheckWorker>(maxOf(15, intervalMinutes(ctx)).toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("admin_watch", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(ctx: Context) { WorkManager.getInstance(ctx).cancelUniqueWork("admin_watch") }
}

class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Watcher.check(applicationContext) } catch (_: Exception) {}
        return Result.success()
    }
}
