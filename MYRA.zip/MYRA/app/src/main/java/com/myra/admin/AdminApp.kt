package com.myra.admin

import android.app.Application

class AdminApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Config.load(this)
    }
}
