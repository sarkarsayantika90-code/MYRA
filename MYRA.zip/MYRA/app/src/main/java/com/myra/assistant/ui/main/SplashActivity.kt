package com.myra.assistant.ui.main

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Loading screen: glowing orb that breathes, MYRA letters fading in, a little line of text.
 * Built in code (no new XML ids) so it can never break the resource build.
 */
class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val accent = ThemeManager.accent(this)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF040408.toInt()) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val orb = OrbAnimationView(this).also { it.setAccent(accent); it.setListening() }
        val d = (resources.displayMetrics.density * 260).toInt()
        col.addView(orb, LinearLayout.LayoutParams(d, d))

        val title = TextView(this).apply {
            text = "MYRA"
            setTextColor(accent)
            textSize = 34f
            letterSpacing = 0.4f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            setShadowLayer(24f, 0f, 0f, accent)
            alpha = 0f
        }
        col.addView(title)

        val sub = TextView(this).apply {
            text = "waking up for you..."
            setTextColor(0xFFB0B0C8.toInt())
            textSize = 12f
            letterSpacing = 0.15f
            alpha = 0f
            setPadding(0, (resources.displayMetrics.density * 10).toInt(), 0, 0)
        }
        col.addView(sub)

        setContentView(root)

        val fadeTitle = ObjectAnimator.ofFloat(title, View.ALPHA, 0f, 1f).apply { duration = 900; interpolator = DecelerateInterpolator() }
        val slideTitle = ObjectAnimator.ofFloat(title, View.TRANSLATION_Y, 40f, 0f).apply { duration = 900 }
        val fadeSub = ObjectAnimator.ofFloat(sub, View.ALPHA, 0f, 0.9f).apply { duration = 700; startDelay = 500 }
        AnimatorSet().apply { playTogether(fadeTitle, slideTitle, fadeSub); start() }

        ValueAnimator.ofFloat(0.94f, 1.06f).apply {
            duration = 1100; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { orb.scaleX = it.animatedValue as Float; orb.scaleY = it.animatedValue as Float }
            start()
        }

        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2300)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
