package com.myra.assistant.ui.main

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.apps.InstalledAppsManager
import com.myra.assistant.auth.Session
import com.myra.assistant.ui.auth.LoginActivity
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Loading screen: drifting star particles, a glowing orb with ripple rings, MYRA letters that
 * appear one by one, a smooth progress bar and changing status lines. While it plays, the app list
 * is loaded in the background so the home screen is ready instantly.
 */
class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        val accent = ThemeManager.accent(this)
        val view = SplashView(this, accent)
        setContentView(view)

        // warm things up while the animation plays
        Thread { try { InstalledAppsManager.getAllApps(applicationContext) } catch (_: Exception) {} }.start()

        handler.postDelayed({
            val next = if (Session.isLoggedIn(this)) MainActivity::class.java else LoginActivity::class.java
            startActivity(Intent(this, next))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, SplashView.TOTAL_MS)
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private class SplashView(ctx: Context, private val accent: Int) : View(ctx) {
        companion object { const val TOTAL_MS = 3200L }

        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stars = List(70) { Star(Random.nextFloat(), Random.nextFloat(), 0.4f + Random.nextFloat() * 1.8f, 0.02f + Random.nextFloat() * 0.06f, Random.nextFloat()) }
        private class Star(var x: Float, var y: Float, val r: Float, val speed: Float, val phase: Float)
        private var t = 0f            // 0..1 overall progress
        private var clock = 0f        // seconds
        private val lines = listOf("waking up for you...", "tuning my voice...", "checking your phone...", "almost ready, sona...")

        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = TOTAL_MS; interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; clock = t * TOTAL_MS / 1000f; invalidate() }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

        private fun ease(x: Float) = 1f - (1f - x) * (1f - x)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val d = resources.displayMetrics.density
            c.drawColor(0xFF040408.toInt())

            // soft colour wash
            p.shader = RadialGradient(w * 0.2f, h * 0.15f, w, intArrayOf(withA(accent, 70), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = RadialGradient(w * 0.9f, h * 0.9f, w, intArrayOf(withA(0xFF7C4DFF.toInt(), 70), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // stars drifting up
            for (s in stars) {
                s.y -= s.speed * 0.016f
                if (s.y < 0f) { s.y = 1f; s.x = Random.nextFloat() }
                val tw = 0.4f + 0.6f * (0.5f + 0.5f * sin(clock * 2f + s.phase * 6f))
                p.color = withA(Color.WHITE, (tw * 170).toInt())
                c.drawCircle(s.x * w, s.y * h, s.r * d, p)
            }

            val cx = w / 2f; val cy = h * 0.40f
            val base = min(w, h) * 0.20f
            val appear = ease((t / 0.25f).coerceIn(0f, 1f))
            val breathe = 1f + 0.05f * sin(clock * 3.2f)
            val r = base * appear * breathe

            // ripple rings
            for (i in 0 until 3) {
                val ph = ((clock * 0.7f) + i / 3f) % 1f
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d
                p.color = withA(accent, ((1f - ph) * 120 * appear).toInt())
                c.drawCircle(cx, cy, r * (1f + ph * 1.1f), p)
            }
            p.style = Paint.Style.FILL

            // glow + orb
            p.shader = RadialGradient(cx, cy, r * 2.4f, intArrayOf(withA(accent, 150), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 2.4f, p)
            p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.2f,
                intArrayOf(Color.WHITE, accent, shade(accent, 0.35f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
            p.shader = null

            // orbiting spark
            val a = clock * 2.4f
            p.color = Color.WHITE
            c.drawCircle(cx + cos(a) * r * 1.5f, cy + sin(a) * r * 1.5f, 3.5f * d, p)

            // MYRA letters, one by one
            val word = "MYRA"
            p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            p.textSize = 40f * d
            p.letterSpacing = 0.25f
            val total = p.measureText(word)
            var x = cx - total / 2f
            val ty = cy + base * 2.2f + 50f * d
            for (i in word.indices) {
                val a0 = 0.22f + i * 0.07f
                val k = ease(((t - a0) / 0.12f).coerceIn(0f, 1f))
                val ch = word[i].toString()
                val cw = p.measureText(ch)
                p.color = withA(accent, (255 * k).toInt())
                p.setShadowLayer(22f * d * k, 0f, 0f, accent)
                c.drawText(ch, x, ty + (1f - k) * 24f * d, p)
                x += cw
            }
            p.clearShadowLayer(); p.letterSpacing = 0f

            // status line
            val idx = min((t * lines.size).toInt(), lines.size - 1)
            p.typeface = Typeface.DEFAULT; p.textSize = 13f * d; p.color = 0xFFB0B0C8.toInt()
            val line = lines[idx]
            c.drawText(line, cx - p.measureText(line) / 2f, ty + 40f * d, p)

            // progress bar
            val bw = w * 0.5f; val bh = 4f * d; val by = h * 0.86f
            p.color = 0x22FFFFFF
            c.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + bh, bh, bh, p)
            p.shader = LinearGradient(cx - bw / 2, 0f, cx + bw / 2, 0f, intArrayOf(accent, Color.WHITE), null, Shader.TileMode.CLAMP)
            c.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * t, by + bh, bh, bh, p)
            p.shader = null
        }

        private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
        private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())
    }
}
