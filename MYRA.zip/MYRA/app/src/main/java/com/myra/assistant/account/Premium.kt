package com.myra.assistant.account

import android.content.Context
import com.myra.assistant.utils.Logger
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Plans, premium state and the free-tier limits. Edit the prices/days here. */
object Premium {
    data class Plan(val id: String, val title: String, val price: Int, val days: Int, val tag: String = "")

    val PLANS = listOf(
        Plan("weekly", "Weekly", 29, 7),
        Plan("monthly", "Monthly", 99, 30, "POPULAR"),
        Plan("quarterly", "3 Months", 249, 90, "SAVE 16%"),
        Plan("yearly", "Yearly", 799, 365, "BEST VALUE"),
        Plan("lifetime", "Lifetime", 1999, 36500, "FOREVER")
    )

    /** These need premium. Everything else works on the free plan within the daily limit. */
    private val PREMIUM_ONLY = setOf(
        "execute_whatsapp_task", "whatsapp_task_control", "app_message", "confirm_app_message",
        "app_call", "take_photo"
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("myra_premium", Context.MODE_PRIVATE)
    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun until(ctx: Context): Long = sp(ctx).getLong("until", 0L)
    fun planName(ctx: Context): String = sp(ctx).getString("plan", "") ?: ""

    fun isPremium(ctx: Context): Boolean {
        if (AccountConfig.OWNER_EMAIL.isNotEmpty() && Cloud.email(ctx).equals(AccountConfig.OWNER_EMAIL, true)) return true
        if (Cloud.isOwner(ctx)) return true
        return until(ctx) > System.currentTimeMillis()
    }

    fun describe(ctx: Context): String {
        if (!isPremium(ctx)) return "Free plan - ${usedToday(ctx)}/${AccountConfig.FREE_ACTIONS_PER_DAY} actions used today"
        if (Cloud.isOwner(ctx)) return "Premium - owner"
        val u = until(ctx)
        return if (u > System.currentTimeMillis() + 3000L * 86400_000L) "Premium - lifetime"
        else "Premium until " + SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(u))
    }

    fun usedToday(ctx: Context): Int = sp(ctx).getInt("used_${today()}", 0)

    /** null = allowed. Otherwise the sentence the assistant should say to the user. */
    fun gate(ctx: Context, tool: String): String? {
        if (isPremium(ctx)) return null
        if (tool in PREMIUM_ONLY)
            return "premium_required: Ei feature ta MYRA Premium e ache. User ke sweetly bolo Settings > Premium theke nite parbe."
        val n = usedToday(ctx)
        if (n >= AccountConfig.FREE_ACTIONS_PER_DAY)
            return "premium_required: Aajker free ${AccountConfig.FREE_ACTIONS_PER_DAY} ta action shesh. Premium nile unlimited. User ke sweetly bolo."
        sp(ctx).edit().putInt("used_${today()}", n + 1).apply()
        return null
    }

    /** Reads premium/{uid} from the database and caches it. */
    suspend fun refresh(ctx: Context): Boolean {
        if (!Cloud.isLoggedIn(ctx)) return false
        val r = Cloud.get(ctx, "premium/${Cloud.uid(ctx)}")
        if (!r.ok) return false
        return try {
            if (r.body == "null" || r.body.isBlank()) {
                sp(ctx).edit().putLong("until", 0L).putString("plan", "").apply()
            } else {
                val j = JSONObject(r.body)
                sp(ctx).edit().putLong("until", j.optLong("until", 0L)).putString("plan", j.optString("plan")).apply()
            }
            true
        } catch (e: Exception) { Logger.e("PREMIUM", "parse: ${e.message}"); false }
    }

    fun planById(id: String) = PLANS.firstOrNull { it.id == id }
}
