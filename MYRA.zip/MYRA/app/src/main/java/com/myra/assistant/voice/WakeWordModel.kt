package com.myra.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * The offline speech model used only to hear "Hey Myra" (Vosk small Indian-English, ~36 MB).
 * It is downloaded once, on the phone, when the user switches "Hey Myra" on - it is NOT inside the APK.
 */
object WakeWordModel {
    private const val TAG = "WAKE_MODEL"
    const val NAME = "vosk-model-small-en-in-0.4"
    private const val URL = "https://alphacephei.com/vosk/models/$NAME.zip"

    @Volatile var downloading = false
        private set
    /** 0..100 while downloading, -1 otherwise. */
    @Volatile var progress = -1
        private set
    @Volatile var lastError: String? = null
        private set
    /** Settings screen sets this to show progress; it must clear it in onDestroy. Called on the main thread. */
    @Volatile var listener: ((Int) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    private fun root(ctx: Context) = File(ctx.filesDir, "wake")
    fun dir(ctx: Context) = File(root(ctx), NAME)
    private fun marker(ctx: Context) = File(dir(ctx), ".ready")

    fun isReady(ctx: Context) = marker(ctx).exists() && File(dir(ctx), "conf").isDirectory

    private fun publish(p: Int) {
        progress = p
        main.post { listener?.invoke(p) }
    }

    /**
     * Downloads + unpacks the model on a background thread. When it succeeds "Hey Myra" is switched on and the
     * running voice service is told, so it works right away. Safe to call twice.
     */
    fun downloadAndEnable(ctx: Context) {
        val app = ctx.applicationContext
        if (downloading) return
        if (isReady(app)) { enable(app); return }
        downloading = true
        lastError = null
        publish(0)
        Thread {
            var ok = false
            try {
                download(app)
                ok = isReady(app)
                if (!ok) lastError = "Could not unpack the voice model"
            } catch (e: Exception) {
                Logger.e(TAG, "download failed: ${e.message}")
                lastError = "Download failed: " + (e.message ?: e.javaClass.simpleName).take(60)
            }
            downloading = false
            publish(if (ok) 100 else -1)
            main.post {
                if (ok) { enable(app); Toast.makeText(app, "Hey Myra is on!", Toast.LENGTH_LONG).show() }
                else Toast.makeText(app, lastError ?: "Hey Myra model download failed", Toast.LENGTH_LONG).show()
            }
        }.also { it.name = "MYRA_WakeModelDownload"; it.isDaemon = true; it.start() }
    }

    fun enable(app: Context) {
        app.prefs().edit().putBoolean(Constants.KEY_WAKE_BG, true).apply()
        ForegroundVoiceService.instance?.onWakeSettingChanged()
    }

    fun disable(app: Context) {
        app.prefs().edit().putBoolean(Constants.KEY_WAKE_BG, false).apply()
        ForegroundVoiceService.instance?.onWakeSettingChanged()
    }

    private fun download(app: Context) {
        val rootDir = root(app).also { it.mkdirs() }
        val zip = File(rootDir, "$NAME.zip.part")
        val http = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
        http.newCall(Request.Builder().url(URL).build()).execute().use { r ->
            if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
            val body = r.body ?: throw IllegalStateException("empty response")
            val total = body.contentLength()
            body.byteStream().use { input ->
                FileOutputStream(zip).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastPct = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            // download = 0..90%, unpack = 90..100%
                            val pct = (done * 90 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; publish(pct) }
                        }
                    }
                }
            }
        }
        publish(90)
        dir(app).deleteRecursively()
        unzip(zip, rootDir)
        zip.delete()
        // Archives contain a single top-level folder named like the model.
        if (File(dir(app), "conf").isDirectory) marker(app).writeText("ok")
    }

    private fun unzip(zip: File, dest: File) {
        val destCanon = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val target = File(dest, e.name)
                // zip-slip guard: never write outside the model folder
                if (!target.canonicalPath.startsWith(destCanon)) throw SecurityException("bad zip entry")
                if (e.isDirectory) { target.mkdirs(); continue }
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { out -> zin.copyTo(out) }
            }
        }
    }
}
