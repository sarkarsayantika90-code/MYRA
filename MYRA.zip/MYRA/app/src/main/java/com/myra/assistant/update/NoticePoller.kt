package com.myra.assistant.update

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.myra.assistant.R
import com.myra.assistant.auth.FirebaseRest
import com.myra.assistant.auth.Session
import com.myra.assistant.ui.main.ChatStore
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.prefs
import org.json.JSONObject

/**
 * Messages sent from the admin website (notices/all and notices/users/{uid}).
 * No Google push service is needed: the app checks every ~15 min in the background (WorkManager)
 * and every minute while MYRA is on. A brand-new install starts from "now" so old messages never flood.
 */
object NoticePoller {
    private const val CH = "myra_notices"

    private fun parse(raw: String): List<Triple<Long, String, String>> {
        if (raw == "null" || raw.isBlank()) return emptyList()
        val o = JSONObject(raw)
        val out = ArrayList<Triple<Long, String, String>>()
        for (k in o.keys()) {
            val n = o.optJSONObject(k) ?: continue
            val at = k.toLongOrNull() ?: n.optLong("at")
            out.add(Triple(at, n.optString("title"), n.optString("body")))
        }
        return out
    }

    /** Blocking. Returns how many new messages were shown. */
    fun poll(ctx: Context): Int {
        val extra = try { BroadcastPoller.check(ctx) } catch (_: Exception) { 0 }
        return pollNotices(ctx) + extra
    }

    private fun pollNotices(ctx: Context): Int {
        val s = Session.get(ctx) ?: return 0
        val last = ctx.prefs().getLong("notice_last", 0L)
        val q = "orderBy=%22%24key%22&limitToLast=10"
        val all = try { parse(FirebaseRest.dbGetQ(ctx, "notices/all", q)) } catch (_: Exception) { emptyList() }
        val mine = try { parse(FirebaseRest.dbGetQ(ctx, "notices/users/${s.uid}", q)) } catch (_: Exception) { emptyList() }
        val items = (all + mine).sortedBy { it.first }
        if (last == 0L) {      // first run on this install: start from now
            ctx.prefs().edit().putLong("notice_last", maxOf(System.currentTimeMillis(), items.maxOfOrNull { it.first } ?: 0L)).apply()
            return 0
        }
        val fresh = items.filter { it.first > last }
        if (fresh.isEmpty()) return 0
        ctx.prefs().edit().putLong("notice_last", fresh.maxOf { it.first }).apply()
        fresh.takeLast(3).forEach { show(ctx, it.second, it.third) }
        return fresh.size
    }

    private fun show(ctx: Context, title: String, body: String) {
        ChatStore.addBot("📢 ${title.ifBlank { "MYRA" }}: $body")
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Messages from MYRA", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify((System.currentTimeMillis() % 100000).toInt() + 8000, NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_myra_notif).setContentTitle(title.ifBlank { "MYRA" }).setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_HIGH).build())
        } catch (_: Exception) {}
    }
}

class NoticeWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        try { NoticePoller.poll(applicationContext) } catch (_: Exception) {}
        return Result.success()
    }
}
