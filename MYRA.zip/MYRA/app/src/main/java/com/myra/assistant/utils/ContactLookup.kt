package com.myra.assistant.utils

import android.content.Context
import android.provider.ContactsContract

/**
 * Resolves a spoken contact name to a phone number. Shared by CALL, SMS, and
 * the lookup_contact tool so we don't duplicate the ContactsContract query
 * logic in three places.
 */
object ContactLookup {
    /** All distinct phone contacts matching [name] (distinct by last 8 digits). Used to detect ambiguity. */
    fun findAll(context: Context, name: String): List<Pair<String, String>> {
        if (name.isBlank()) return emptyList()
        val out = LinkedHashMap<String, Pair<String, String>>()
        PrimeContacts.find(context, name)?.let { out[it.number.filter(Char::isDigit).takeLast(8)] = it.name to it.number }
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${name.trim()}%"),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = num.filter(Char::isDigit).takeLast(8)
                    if (key.isNotEmpty() && !out.containsKey(key)) out[key] = n to num
                }
            }
        } catch (_: Exception) {}
        return out.values.toList()
    }

    fun findNumber(context: Context, name: String): String? {
        if (name.isBlank()) return null
        PrimeContacts.find(context, name)?.let { return it.number }
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${name.trim()}%"),
            null
        ) ?: return null

        cursor.use {
            if (it.moveToFirst()) {
                val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (numberIdx >= 0) return it.getString(numberIdx)
            }
        }
        return null
    }
}
