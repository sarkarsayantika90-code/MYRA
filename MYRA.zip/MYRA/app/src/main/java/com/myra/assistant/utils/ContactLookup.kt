package com.myra.assistant.utils

import android.content.Context
import android.provider.ContactsContract

/**
 * Resolves a spoken contact name to a phone number. Shared by CALL, SMS, and
 * the lookup_contact tool so we don't duplicate the ContactsContract query
 * logic in three places.
 */
object ContactLookup {
    fun findNumber(context: Context, name: String): String? {
        if (name.isBlank()) return null
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${name.trim()}%"),
            null
        ) ?: return null

        cursor.use {
            if (it.moveToFirst()) {
                val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (numberIdx >= 0) return it.getString(numberIdx)
            }
        }
        return null
    }
}
