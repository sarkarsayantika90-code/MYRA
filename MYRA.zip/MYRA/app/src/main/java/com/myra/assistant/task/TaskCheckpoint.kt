package com.myra.assistant.task

/**
 * A saved resumption point for a task. `stateJson` is opaque to the task
 * system on purpose — the task-type-specific executor decides what it needs
 * to resume (e.g. "which of the 10 sources have been read so far"), the
 * infrastructure here just persists and retrieves it.
 */
data class TaskCheckpoint(
    val checkpointId: String,
    val taskId: String,
    val stepIndex: Int,
    val stateJson: String,
    val createdAt: Long
)
