package com.myra.assistant.ui.main

import androidx.lifecycle.MutableLiveData

/**
 * One shared conversation for the home screen and the Chat screen. The voice service streams
 * speech transcripts into it (what you said / what MYRA said) and typed messages go through it too.
 */
object ChatStore {
    val messages = MutableLiveData<List<ChatMessage>>(emptyList())
    private val list = ArrayList<ChatMessage>()
    private var streamingUser = false
    private var streamingBot = false

    @Synchronized private fun publish() {
        while (list.size > 200) list.removeAt(0)
        messages.postValue(list.toList())
    }

    @Synchronized fun addUser(text: String) {
        if (text.isBlank()) return
        streamingUser = false; streamingBot = false
        list.add(ChatMessage(text.trim(), true)); publish()
    }

    @Synchronized fun addBot(text: String) {
        if (text.isBlank()) return
        streamingUser = false; streamingBot = false
        list.add(ChatMessage(text.trim(), false)); publish()
    }

    /** Small "what I am doing" line, shown as a MYRA bubble. */
    @Synchronized fun addAction(text: String) {
        streamingBot = false
        list.add(ChatMessage("▸ $text", false)); publish()
    }

    @Synchronized fun appendUser(fragment: String) {
        if (!streamingUser || list.isEmpty() || !list.last().isUser) {
            streamingBot = false
            list.add(ChatMessage(fragment.trimStart(), true))
            streamingUser = true
        } else {
            val last = list.removeAt(list.size - 1)
            list.add(last.copy(text = last.text + fragment))
        }
        publish()
    }

    @Synchronized fun appendBot(fragment: String) {
        if (!streamingBot || list.isEmpty() || list.last().isUser) {
            streamingUser = false
            list.add(ChatMessage(fragment.trimStart(), false))
            streamingBot = true
        } else {
            val last = list.removeAt(list.size - 1)
            list.add(last.copy(text = last.text + fragment))
        }
        publish()
    }

    @Synchronized fun endTurn() { streamingUser = false; streamingBot = false }

    @Synchronized fun clear() { list.clear(); streamingUser = false; streamingBot = false; publish() }
}
