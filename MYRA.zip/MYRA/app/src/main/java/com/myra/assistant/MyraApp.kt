package com.myra.assistant

import android.app.Application
import com.myra.assistant.utils.CrashReporter

class MyraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
    }
}
