package com.myra.assistant

import android.app.Application
import com.myra.assistant.utils.CrashReporter

class MyraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
        try {
            val req = androidx.work.PeriodicWorkRequestBuilder<com.myra.assistant.update.NoticeWorker>(15, java.util.concurrent.TimeUnit.MINUTES)
                .setConstraints(androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()).build()
            androidx.work.WorkManager.getInstance(this)
                .enqueueUniquePeriodicWork("myra_notices", androidx.work.ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {}
    }
}
