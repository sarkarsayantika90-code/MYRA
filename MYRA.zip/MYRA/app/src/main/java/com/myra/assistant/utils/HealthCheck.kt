package com.myra.assistant.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraNotificationListenerService
import com.myra.assistant.services.ForegroundVoiceService

/**
 * MYRA's self-check. Finds what is broken and says exactly how to fix it. The voice model can also
 * call it (tool "self_check") when the user says "kichu kaj korche na" - it tells the user the fix.
 */
object HealthCheck {
    fun report(ctx: Context): String {
        val lines = ArrayList<String>()
        fun ok(b: Boolean, good: String, bad: String) = lines.add(if (b) "✅ $good" else "❌ $bad")

        ok(com.myra.assistant.auth.RemoteConfig.hasKey(ctx),
            "Gemini key available (from server)", if (com.myra.assistant.auth.RemoteConfig.denied(ctx)) "Account blocked or not logged in -> contact the admin" else "No Gemini key -> check your internet (the key comes from the admin panel)")
        ok(has(ctx, Manifest.permission.RECORD_AUDIO), "Mic permission ok", "No microphone permission -> Grant permissions")
        ok(online(ctx), "Internet connected", "No internet -> turn on Wi-Fi/data")
        val lvl = ctx.prefs().getInt("setup_level", 0)
        val lastErr = ctx.prefs().getString("last_close_reason", "") ?: ""
        lines.add(if (lvl == 0) "✅ Voice mode: fast (full)" else "⚠️ Voice mode: safe-mode $lvl (server rejected a fast setting${if (lastErr.isNotBlank()) ": $lastErr" else ""})")
        ok(ForegroundVoiceService.isRunning, "MYRA is on", "MYRA is off -> tap the orb on the home screen")
        val enabled = AccessibilityHelperService.isEnabled(ctx)
        val connected = AccessibilityHelperService.isConnected()
        when {
            connected -> lines.add("✅ Accessibility connected (screen dekha, tap, scroll kaj korbe)")
            enabled -> lines.add("❌ Accessibility shows on but is not connected -> switch MYRA OFF and ON again. If that fails: App info > ⋮ > 'Allow restricted settings', then turn it on again.")
            else -> lines.add("❌ Accessibility off -> Settings > Accessibility > MYRA, turn it on. If you cannot: App info > ⋮ > 'Allow restricted settings'.")
        }
        ok(MyraNotificationListenerService.isEnabled(ctx), "Notification access on",
            "Notification access off -> needed to read WhatsApp unread / notifications")
        ok(has(ctx, Manifest.permission.CALL_PHONE), "Call permission ok", "No call permission")
        ok(has(ctx, Manifest.permission.ANSWER_PHONE_CALLS), "Call answer/end permission ok", "No call answer/end permission")
        ok(has(ctx, Manifest.permission.READ_CONTACTS), "Contacts permission ok", "No contacts permission")
        ok(has(ctx, Manifest.permission.SEND_SMS), "SMS permission ok", "No SMS permission")
        ok(Settings.canDrawOverlays(ctx), "Draw-over-apps ok", "Draw-over-apps off (optional)")
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        ok(pm.isIgnoringBatteryOptimizations(ctx.packageName), "No battery restriction",
            "Battery optimization is on -> MYRA may stop in the background; turn it off in Special access")
        ok(PrimeContacts.all(ctx).isNotEmpty(), "Prime contact set", "No prime contact (optional) -> Personalize")
        return lines.joinToString("\n")
    }

    fun problemsOnly(ctx: Context): String =
        report(ctx).lines().filter { it.startsWith("❌") }.joinToString("\n").ifBlank { "Everything looks good" }

    private fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
