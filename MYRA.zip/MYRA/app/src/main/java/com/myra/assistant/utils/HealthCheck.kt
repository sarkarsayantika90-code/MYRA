package com.myra.assistant.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraNotificationListenerService
import com.myra.assistant.services.ForegroundVoiceService

/**
 * MYRA's self-check. Finds what is broken and says exactly how to fix it. The voice model can also
 * call it (tool "self_check") when the user says "kichu kaj korche na" - it tells the user the fix.
 */
object HealthCheck {
    fun report(ctx: Context): String {
        val lines = ArrayList<String>()
        fun ok(b: Boolean, good: String, bad: String) = lines.add(if (b) "✅ $good" else "❌ $bad")

        ok(!ctx.prefs().getString(Constants.KEY_API_KEY, "").isNullOrBlank(),
            "Gemini API key ache", "Gemini API key nai -> Settings e dao")
        ok(has(ctx, Manifest.permission.RECORD_AUDIO), "Mic permission ok", "Mic permission nai -> Grant permissions")
        ok(online(ctx), "Internet ache", "Internet nai -> Wi-Fi/data on koro")
        ok(ForegroundVoiceService.isRunning, "MYRA on ache", "MYRA off -> home e orb tap koro")
        val enabled = AccessibilityHelperService.isEnabled(ctx)
        val connected = AccessibilityHelperService.isConnected()
        when {
            connected -> lines.add("✅ Accessibility connected (screen dekha, tap, scroll kaj korbe)")
            enabled -> lines.add("❌ Accessibility on dekhachhe kintu connect hoyni -> MYRA ekbar OFF kore abar ON koro. Ta-o na hole App info > ⋮ > 'Allow restricted settings' dao, tarpor abar on koro.")
            else -> lines.add("❌ Accessibility off -> Settings > Accessibility > MYRA on koro. Jodi on kora jay na: App info > ⋮ > 'Allow restricted settings'.")
        }
        ok(MyraNotificationListenerService.isEnabled(ctx), "Notification access on",
            "Notification access off -> WhatsApp unread/notification poRte lagbe")
        ok(has(ctx, Manifest.permission.CALL_PHONE), "Call permission ok", "Call permission nai")
        ok(has(ctx, Manifest.permission.ANSWER_PHONE_CALLS), "Call answer/end permission ok", "Call answer/end permission nai")
        ok(has(ctx, Manifest.permission.READ_CONTACTS), "Contacts permission ok", "Contacts permission nai")
        ok(has(ctx, Manifest.permission.SEND_SMS), "SMS permission ok", "SMS permission nai")
        ok(Settings.canDrawOverlays(ctx), "Draw-over-apps ok", "Draw-over-apps off (optional)")
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        ok(pm.isIgnoringBatteryOptimizations(ctx.packageName), "Battery restriction nai",
            "Battery optimization on -> MYRA background e bondho hoye jete pare, Special access e off koro")
        ok(PrimeContacts.all(ctx).isNotEmpty(), "Prime contact ache", "Prime contact nai (optional) -> Personalize")
        return lines.joinToString("\n")
    }

    fun problemsOnly(ctx: Context): String =
        report(ctx).lines().filter { it.startsWith("❌") }.joinToString("\n").ifBlank { "Sob thik ache" }

    private fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
