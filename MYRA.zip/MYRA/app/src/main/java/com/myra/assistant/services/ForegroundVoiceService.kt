package com.myra.assistant.services

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.ai.MyraTools
import com.myra.assistant.auth.RemoteConfig
import com.myra.assistant.premium.PremiumManager
import com.myra.assistant.ui.main.ChatStore
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.overlay.GlowOverlay
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.BluetoothAudioRouter
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.voice.WakeWordDetector
import com.myra.assistant.voice.WakeWordModel
import com.myra.assistant.websocket.GeminiWebSocketClient
import com.myra.assistant.whatsapp.UtteranceLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * MYRA's voice brain. Starting this service = MYRA ON, stopping it = MYRA OFF.
 *
 * Two modes (when "Hey Myra" is switched on in Settings):
 *  - STANDBY: only the mic + the small on-device wake-word engine run. No internet, no Gemini, no glow.
 *  - ACTIVE: after "Hey Myra" (or an orb tap) the screen-edge glow appears, Gemini Live connects and she talks.
 *    After a few quiet seconds she goes back to STANDBY by herself.
 * With "Hey Myra" off, she is simply always ACTIVE (the old behaviour).
 *
 * Pipeline: mic -> Gemini Live (server-side VAD, barge-in) -> audio out + tool calls.
 * Tool calls run on Android (open app, tap, scroll, call, WhatsApp...) and their real result is
 * sent back so MYRA only says what actually happened.
 */
class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private var audioRecorder: AudioRecorder? = null
    private var audioPlayer: AudioPlayer? = null
    @Volatile private var client: GeminiWebSocketClient? = null
    @Volatile private var attempts = 0
    @Volatile private var reconnectPending = false
    @Volatile private var resumeHandle: String? = null
    @Volatile private var lastGateCheck = 0L
    @Volatile private var shuttingDown = false
    /** 0 = full setup. If the server rejects it before ever accepting, we drop to 1 (minimal) and retry. */
    @Volatile private var setupLevel = 0
    @Volatile private var lastActivityAt = System.currentTimeMillis()
    @Volatile private var unansweredChatter = 0
    private var chatterJob: kotlinx.coroutines.Job? = null
    @Volatile private var greeted = false
    private var tick = 0
    @Volatile private var limitNotified = false
    @Volatile private var nightNagKey = ""

    private val main = Handler(Looper.getMainLooper())
    /** true = only listening for "Hey Myra". Changed on the main thread only. */
    @Volatile private var standby = false
    /** true = this conversation was started by the wake word / orb tap while "Hey Myra" is on: short, quiet, glowing. */
    @Volatile private var wakeSession = false
    private var wakeDetector: WakeWordDetector? = null
    private var glow: GlowOverlay? = null
    private var glowObserving = false
    private var router: BluetoothAudioRouter? = null
    private var focus: AudioFocusManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var sessionJob: kotlinx.coroutines.Job? = null
    /** Mic audio recorded while the Gemini connection is still opening - sent as soon as it is ready, so no word is lost. */
    private val pending = java.util.ArrayDeque<ByteArray>()
    @Volatile private var toolsRunning = 0
    @Volatile private var heardUser = false
    @Volatile private var queuedText: String? = null
    @Volatile private var overlayHinted = false
    @Volatile private var btHinted = false
    /** Start of the not-yet-counted talking time (free plan minutes). 0 = not counting. */
    @Volatile private var usageMark = 0L

    private val glowStateObserver = androidx.lifecycle.Observer<String> { glow?.setState(it) }
    private val glowLevelObserver = androidx.lifecycle.Observer<Float> { glow?.setLevel(it) }

    companion object {
        @Volatile var instance: ForegroundVoiceService? = null
        @Volatile var isRunning = false

        /** Returns false (and does nothing) if the mic permission is missing or Android refuses the start. */
        fun start(context: Context): Boolean {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            return try {
                ContextCompat.startForegroundService(context, Intent(context, ForegroundVoiceService::class.java))
                true
            } catch (e: Exception) {
                Logger.e("VOICE_SVC", "start refused: ${e.message}")
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ForegroundVoiceService::class.java))
        }

        const val ACTION_STOP = "com.myra.assistant.action.STOP_MYRA"
        /** After this long without anyone talking, a "Hey Myra" conversation ends (STANDBY again). */
        const val IDLE_AFTER_TALK_MS = 20_000L
        /** ...and if nobody said anything at all after waking her. */
        const val IDLE_NO_SPEECH_MS = 12_000L
        const val MAX_PENDING_CHUNKS = 500   // 10 s of 20 ms chunks
    }

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // startForeground(microphone) would crash on Android 14+ without this permission.
            VoiceStateManager.setError("Mic permission dao")
            bailOut()
            return
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(Constants.NOTIF_ID_VOICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(Constants.NOTIF_ID_VOICE, n)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "startForeground failed: ${e.message}")
            VoiceStateManager.setError("Service start hoilo na")
            bailOut()
            return
        }
        instance = this
        isRunning = true
        VoiceStateManager.serviceOn.postValue(true)

        val player = AudioPlayer()
        player.onPlaybackStarted = { if (!standby) VoiceStateManager.setSpeaking() }
        player.onPlaybackFinished = {
            if (!standby) {
                UtteranceLog.markTurnEnd()          // exact moment MYRA stopped talking (used by confirmations)
                lastActivityAt = System.currentTimeMillis()
                VoiceStateManager.setListening()
            }
        }
        audioPlayer = player

        VoiceStateManager.micMutedFlag = false
        VoiceStateManager.isMicMuted.postValue(false)
        val rec = AudioRecorder(this) { chunk -> onMicChunk(chunk) }
        rec.gateWhileSpeaking = !prefs().getBoolean(Constants.KEY_BARGE_IN, true)
        audioRecorder = rec

        if (wakeModeOn()) enterStandby() else beginSession(fromWake = false)
    }

    // ───────────────────────── microphone ─────────────────────────

    private fun onMicChunk(chunk: ByteArray) {
        if (standby) { wakeDetector?.feed(chunk); return }      // standby: ONLY the on-device wake-word engine hears this
        if (VoiceStateManager.micMutedFlag) return              // mic button = muted
        val rms = AudioUtils.calculateRms(chunk)
        if (!VoiceStateManager.isAiSpeaking()) VoiceStateManager.updateAmplitude(rms * 6f)
        if (rms > 0.035f) {
            UtteranceLog.addVoice()
            lastActivityAt = System.currentTimeMillis()
            unansweredChatter = 0
            heardUser = true
        }
        sendMic(chunk)
    }

    /** Sends right away when connected; otherwise keeps the last ~10 s so the first words after "Hey Myra" are not lost. */
    private fun sendMic(chunk: ByteArray) {
        val c = client
        if (c != null && c.isReady()) {
            flushPending(c)
            c.sendAudioChunk(chunk)
        } else {
            synchronized(pending) {
                pending.addLast(chunk)
                while (pending.size > MAX_PENDING_CHUNKS) pending.removeFirst()
            }
        }
    }

    private fun flushPending(c: GeminiWebSocketClient) {
        val items = synchronized(pending) {
            if (pending.isEmpty()) return
            ArrayList(pending).also { pending.clear() }
        }
        for (b in items) c.sendAudioChunk(b, force = true)
    }

    // ───────────────────────── standby <-> active ─────────────────────────

    private fun wakeModeOn() = prefs().getBoolean(Constants.KEY_WAKE_BG, false) && WakeWordModel.isReady(this)

    /** Public: tap on the orb / mic button while in standby = same as saying "Hey Myra". */
    fun wakeNow() { main.post { if (standby && !shuttingDown) beginSession(fromWake = true) } }

    /** Public: back to "just listening for Hey Myra" (only when that mode is on). */
    fun goStandby() { main.post { if (!standby && !shuttingDown && wakeModeOn()) enterStandby() } }

    fun isStandby() = standby

    fun wakeModeEnabled() = wakeModeOn()

    /** The user flipped "Hey Myra" in Settings (or its model finished downloading). */
    fun onWakeSettingChanged() {
        main.post {
            if (shuttingDown) return@post
            if (wakeModeOn()) { if (!standby) enterStandby() }
            else if (standby) beginSession(fromWake = false)
            else { wakeSession = false; hideGlow() }
        }
    }

    private fun beginSession(fromWake: Boolean) {
        if (shuttingDown) return
        standby = false
        wakeSession = wakeModeOn()
        synchronized(pending) { pending.clear() }
        resumeHandle = null
        setupLevel = chooseSetupLevel()
        greeted = wakeSession                      // after "Hey Myra" she just listens - no long hello that talks over the command
        unansweredChatter = 0
        heardUser = false
        val now = System.currentTimeMillis()
        lastActivityAt = now
        usageMark = now
        VoiceStateManager.micMutedFlag = false
        VoiceStateManager.isMicMuted.postValue(false)
        if (fromWake) VoiceStateManager.setListening()
        else { VoiceStateManager.setThinking(); VoiceStateManager.statusMessage.postValue("CONNECTING...") }
        if (wakeSession) {
            acquireWakeLock(); showGlow()
            // Like Gemini: music / video in the background gets quieter while she talks.
            try { (focus ?: AudioFocusManager(this).also { focus = it }).requestFocus({}, {}) } catch (_: Exception) {}
        }
        startAudioRoute()
        audioRecorder?.start()                     // already open in standby; opens it otherwise
        startSessionWatch()
        updateNotification()
        connect()
    }

    private fun enterStandby() {
        if (shuttingDown) return
        flushUsage()
        usageMark = 0L
        standby = true
        wakeSession = false
        sessionJob?.cancel(); sessionJob = null
        chatterJob?.cancel(); chatterJob = null
        val c = client
        client = null
        c?.disconnect()
        synchronized(pending) { pending.clear() }
        queuedText = null
        resumeHandle = null
        audioPlayer?.interrupt()
        hideGlow()
        try { focus?.abandonFocus() } catch (_: Exception) {}
        stopAudioRoute()
        acquireWakeLock()
        ensureWakeDetector()
        wakeDetector?.reset()
        audioRecorder?.start()
        VoiceStateManager.setStandby()
        updateNotification()
        Logger.d(TAG, "standby: waiting for Hey Myra")
    }

    /** End of a conversation: back to standby when "Hey Myra" is on, otherwise switch MYRA off (old behaviour). */
    private fun endSession() {
        if (wakeModeOn()) main.post { enterStandby() } else turnOff()
    }

    private fun ensureWakeDetector() {
        if (wakeDetector != null) return
        wakeDetector = WakeWordDetector(
            this,
            onWake = { main.post { if (standby && !shuttingDown) beginSession(fromWake = true) } },
            onError = { msg -> main.post { wakeEngineFailed(msg) } }
        ).also { it.start() }
    }

    private fun wakeEngineFailed(msg: String) {
        Logger.e(TAG, "wake engine failed: $msg")
        wakeDetector?.stop(); wakeDetector = null
        prefs().edit().putBoolean(Constants.KEY_WAKE_BG, false).apply()
        ChatStore.addBot("Hey Myra engine chalu hoilo na ($msg). Ekhon MYRA always-on mode e cholche.")
        if (standby && !shuttingDown) beginSession(fromWake = false)
    }

    /** Idle watchdog for "Hey Myra" conversations. */
    private fun startSessionWatch() {
        sessionJob?.cancel()
        if (!wakeSession) return
        sessionJob = scope.launch {
            while (!standby && !shuttingDown && wakeSession) {
                delay(1000)
                if (toolsRunning > 0 || VoiceStateManager.isAiSpeaking()) { lastActivityAt = System.currentTimeMillis(); continue }
                val quiet = System.currentTimeMillis() - lastActivityAt
                if (quiet > (if (heardUser) IDLE_AFTER_TALK_MS else IDLE_NO_SPEECH_MS)) {
                    Logger.d(TAG, "quiet for ${quiet}ms -> standby")
                    main.post { if (!standby) enterStandby() }
                    return@launch
                }
            }
        }
    }

    /**
     * Gemini's setup level: after a setup the server really rejected we drop to a simpler one for the rest of the session,
     * but a bad network never does that (see [GeminiWebSocketClient.looksLikeSetupRejection]). The last level that worked is
     * remembered so a wake-up does not waste a round trip; every 8th session tries the full setup again.
     */
    private fun chooseSetupLevel(): Int {
        val p = prefs()
        val n = p.getInt("setup_sessions", 0) + 1
        p.edit().putInt("setup_sessions", n).apply()
        return if (n % 8 == 0) 0 else p.getInt("setup_level", 0).coerceIn(0, 2)
    }

    // ───────────────────────── audio route (Bluetooth / speaker) ─────────────────────────

    private fun startAudioRoute() {
        enableCommunicationAudioMode()
        val r = router ?: BluetoothAudioRouter(this) { onRouteChanged() }.also { router = it }
        r.start()
    }

    private fun stopAudioRoute() {
        try { router?.stop() } catch (_: Exception) {}
        audioPlayer?.setRoute(null, false)
        audioRecorder?.reroute(null)
        restoreNormalAudioMode()
    }

    /** Main thread, after the route (Bluetooth / wired / speaker) has settled. */
    @Suppress("DEPRECATION")
    private fun onRouteChanged() {
        val r = router ?: return
        if (standby) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            // Plain A2DP headphones only accept media audio; a call-mode session would send her voice to the speaker.
            am.mode = if (r.a2dpOnly) AudioManager.MODE_NORMAL else AudioManager.MODE_IN_COMMUNICATION
        } catch (e: Exception) { Logger.e(TAG, "mode: ${e.message}") }
        audioPlayer?.setRoute(r.outputDevice, r.a2dpOnly)
        audioRecorder?.reroute(r.inputDevice)
        if (r.needsPermission && !btHinted) {
            btHinted = true
            ChatStore.addBot("Bluetooth headphone e kotha bolte 'Nearby devices' permission lagbe. App Settings > Permissions e dao.")
        }
    }

    // ───────────────────────── glow + wake lock + notification ─────────────────────────

    private fun showGlow() {
        main.post {
            if (!wakeSession || shuttingDown) return@post
            val g = glow ?: GlowOverlay(this).also { glow = it }
            if (!g.canShow()) {
                if (!overlayHinted) {
                    overlayHinted = true
                    ChatStore.addBot("Screen e glow dekhate Settings > Special access > 'Draw over other apps' on koro.")
                }
                return@post
            }
            g.show()
            g.setState(VoiceStateManager.state.value ?: Constants.STATE_LISTENING)
            if (!glowObserving) {
                glowObserving = true
                VoiceStateManager.state.observeForever(glowStateObserver)
                VoiceStateManager.amplitude.observeForever(glowLevelObserver)
            }
        }
    }

    private fun hideGlow() {
        main.post {
            if (glowObserving) {
                glowObserving = false
                VoiceStateManager.state.removeObserver(glowStateObserver)
                VoiceStateManager.amplitude.removeObserver(glowLevelObserver)
            }
            glow?.hide()
        }
    }

    private fun acquireWakeLock() {
        try {
            val wl = wakeLock ?: (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myra:wake").apply { setReferenceCounted(false) }
                .also { wakeLock = it }
            if (!wl.isHeld) wl.acquire()
        } catch (e: Exception) { Logger.e(TAG, "wakelock: ${e.message}") }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    private fun updateNotification() {
        try { getSystemService(NotificationManager::class.java).notify(Constants.NOTIF_ID_VOICE, buildNotification()) } catch (_: Exception) {}
    }

    /** Android crashes the app if startForegroundService() is not followed by startForeground(). Always satisfy it, then stop. */
    private fun bailOut() {
        try { startForeground(Constants.NOTIF_ID_VOICE, buildNotification()) } catch (_: Exception) {}
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    /** Routes audio through the voice-call path so the hardware echo canceller engages. */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            // The speaker / Bluetooth choice is made by BluetoothAudioRouter (forcing the speaker here silenced headphones).
            am.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (e: Exception) {
            Logger.e(TAG, "audio mode failed: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
    }

    // ───────────────────────── Gemini connection ─────────────────────────

    private fun connect() {
        if (shuttingDown || standby) return
        scope.launch {
            val ctx = this@ForegroundVoiceService
            // Never keep her waiting on the network for things we already know: only the API key is needed to start,
            // everything else (config, premium, usage) is refreshed in the background.
            if (!RemoteConfig.hasKey(ctx)) RemoteConfig.refresh(ctx)
            else if (RemoteConfig.stale(ctx)) scope.launch { RemoteConfig.refresh(ctx) }
            val now = System.currentTimeMillis()
            if (now - lastGateCheck > 5 * 60_000L) {
                lastGateCheck = now
                scope.launch {
                    PremiumManager.refresh(ctx)
                    PremiumManager.syncUsage(ctx)      // free minutes are counted on the server, so reinstalling does not reset them
                }
            }
            if (!PremiumManager.freeTimeLeft(ctx)) {
                // The cached answer says "no": double-check with the server once (he may just have bought Premium).
                PremiumManager.refresh(ctx)
                PremiumManager.syncUsage(ctx)
                lastGateCheck = System.currentTimeMillis()
            }
            if (!PremiumManager.freeTimeLeft(ctx)) {
                VoiceStateManager.setError("Aajker free time shesh - Settings > Premium")
                ChatStore.addBot("Aajker free time shesh, sona. Premium nile unlimited kotha bolbo 💕")
                scope.launch { delay(3000); endSession() }
                return@launch
            }
            RemoteConfig.maintenance(ctx)?.let { VoiceStateManager.setError(it.take(60)); scope.launch { delay(4000); endSession() }; return@launch }
            val apiKey = RemoteConfig.anyKey(ctx)
            if (apiKey.isNullOrBlank()) {
                VoiceStateManager.setError(if (RemoteConfig.denied(ctx)) "Account blocked / login koro" else "Server theke key ashche na - internet check koro")
                if (wakeSession) scope.launch { delay(2500); main.post { if (!standby) enterStandby() } }
                return@launch
            }
            if (shuttingDown || standby) return@launch
            client?.disconnect()
            val voice = prefs().getString(Constants.KEY_VOICE_NAME, Constants.GEMINI_VOICE) ?: Constants.GEMINI_VOICE
            val c = GeminiWebSocketClient(apiKey, buildSystemPrompt(), voice, RemoteConfig.model(ctx), MyraTools.declarations(), setupLevel, resumeHandle, listener)
            client = c
            c.connect()
        }
    }

    private fun scheduleReconnect(reason: String) {
        if (shuttingDown || standby || reconnectPending) return
        reconnectPending = true
        val wait = if (attempts == 0) 250L else minOf(1000L shl minOf(attempts - 1, 4), 15000L)
        attempts++
        VoiceStateManager.setError("Reconnecting...")
        Logger.e(TAG, "reconnect in ${wait}ms ($reason)")
        scope.launch {
            delay(wait)
            reconnectPending = false
            if (!standby) connect()
        }
    }

    private val listener = object : GeminiWebSocketClient.Listener {
        override fun onConnected() {
            attempts = 0
            if (standby) { client?.disconnect(); return }          // she went back to sleep before the socket opened
            prefs().edit().putInt("setup_level", setupLevel).apply()
            startChatter()
            if (!greeted) { greeted = true; scope.launch { delay(700); greetUser() } }
            VoiceStateManager.setListening()
            val rec = audioRecorder
            if (rec != null && !rec.isActive()) rec.start()
            // Everything he said while the socket was opening goes out first, in order.
            client?.let { flushPending(it) }
            queuedText?.let { t -> queuedText = null; client?.sendText(t) }
        }

        override fun onAudio(pcm: ByteArray) {
            if (standby) return
            lastActivityAt = System.currentTimeMillis()
            heardUser = true                                     // a real conversation is going on
            audioPlayer?.playChunk(pcm)
            VoiceStateManager.updateAmplitude(AudioUtils.calculateRms(pcm) * 5f)
        }

        override fun onInputTranscript(text: String) {
            lastActivityAt = System.currentTimeMillis()
            unansweredChatter = 0
            UtteranceLog.add(text)
            ChatStore.appendUser(text)
        }

        override fun onOutputTranscript(text: String) {
            ChatStore.appendBot(text)
        }

        override fun onToolCall(id: String, name: String, args: JSONObject) {
            val c = client
            scope.launch {
                toolsRunning++
                VoiceStateManager.setThinking()
                ChatStore.addAction(actionLabel(name, args))
                val result = try { MyraTools.execute(this@ForegroundVoiceService, name, args) }
                finally { toolsRunning--; lastActivityAt = System.currentTimeMillis() }
                Logger.d(TAG, "tool $name done")
                c?.sendToolResponse(id, name, result)
                if (name == "stop_myra") {
                    delay(3500)
                    endSession()
                }
            }
        }

        override fun onInterrupted() {
            audioPlayer?.interrupt()
            VoiceStateManager.setListening()
        }

        override fun onTurnComplete() {
            ChatStore.endTurn()
        }

        override fun onResumeHandle(handle: String) { resumeHandle = handle }

        override fun onGoAway() {
            // Server will drop this socket in a few seconds. Open a new one with the resume handle right away.
            Logger.d(TAG, "goAway -> quiet reconnect")
            attempts = 0
            scheduleReconnect("goAway")
        }

        override fun onClosed(reason: String) {
            // Closed before the server ever accepted our setup = it disliked an optional feature.
            // Fall back to the minimal setup so MYRA still works.
            val c = client
            prefs().edit().putString("last_close_reason", reason.take(200)).apply()      // the level is saved only once a setup really worked (onConnected)
            if (standby) return
            if (c != null && !c.everReady && c.resumeHandle != null) {
                // An old/expired resume handle was refused - start fresh, do not weaken the setup.
                resumeHandle = null
                Logger.e(TAG, "resume handle refused ($reason) -> fresh session")
            } else if (c != null && !c.everReady && setupLevel < 2 && GeminiWebSocketClient.looksLikeSetupRejection(reason)) {
                // ONLY when the server itself refused the setup. A slow / dropped network used to push her down to the
                // simple setup (no "thinking off", no fast speech detection) - that made some replies seconds late.
                setupLevel++
                Logger.e(TAG, "setup rejected ($reason) -> level $setupLevel")
            }
            scheduleReconnect(reason)
        }
    }

    private fun actionLabel(name: String, a: JSONObject): String = when (name) {
        "open_app" -> "Opening ${a.optString("app_name")}"
        "search_in_app" -> "Searching \"${a.optString("query")}\""
        "tap_text" -> "Tapping ${a.optString("text")}"
        "scroll" -> "Scrolling ${a.optString("direction")}"
        "type_text" -> "Typing"
        "read_screen" -> "Looking at the screen"
        "call_contact" -> "Calling ${a.optString("name")}"
        "answer_call" -> "Answering the call"
        "end_call" -> "Ending the call"
        "execute_whatsapp_task" -> "WhatsApp: ${a.optString("action")}"
        "whatsapp_task_control" -> "WhatsApp: ${a.optString("command")}"
        "press_key" -> "Pressing ${a.optString("key")}"
        "send_sms" -> "Writing SMS to ${a.optString("name")}"
        "confirm_sms" -> "Sending SMS"
        "take_photo" -> "Taking a photo"
        "self_check" -> "Checking my own health"
        else -> name.replace('_', ' ')
    }

    // ───────────────────────── talks first when you are quiet ─────────────────────────

    private fun startChatter() {
        if (chatterJob?.isActive == true) return
        chatterJob = scope.launch {
            while (!shuttingDown) {
                delay(20_000)
                try {
                    flushUsage()
                    if (++tick % 3 == 0) {
                        PremiumManager.syncUsage(this@ForegroundVoiceService)
                        com.myra.assistant.update.NoticePoller.poll(this@ForegroundVoiceService)
                    }
                    if (checkFreeLimit()) continue
                    if (checkBedtime()) continue
                    maybeChatter()
                } catch (e: Exception) { Logger.e(TAG, "chatter: ${e.message}") }
            }
        }
    }

    /** First words of every session: warm hello + how is he / what is he doing / has he eaten. */
    private fun greetUser() {
        if (com.myra.assistant.update.UpdateManager.busy()) return
        val c = client ?: return
        val cal = java.util.Calendar.getInstance()
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val part = "${com.myra.assistant.utils.DayPart.name(hour)} (${com.myra.assistant.utils.DayPart.careHint(hour)}; greet with \"${com.myra.assistant.utils.DayPart.greeting(hour)}\")"
        lastActivityAt = System.currentTimeMillis()
        c.sendText(
            "(internal, the user did not say this) MYRA just woke up. Greet him in a sweet girlfriend way - it is $part, time ${getTimeString()}. " +
                "${callHint()} In ONE or TWO short sentences ask how he is and what he is doing" +
                (if (hour in 5..23) ", and whether he has eaten" else "") + ". Speak English (switch only if he has spoken another language). Do not use any tool."
        )
    }

    /** Free plan: 20 min/day of voice. Returns true if it just ended the session. */
    private fun checkFreeLimit(): Boolean {
        if (PremiumManager.freeTimeLeft(this)) return false
        if (limitNotified) return true
        limitNotified = true
        client?.sendText(
            "(internal) His free voice time for today is over. Tell him sweetly in one short sentence that today's free time is finished " +
                "and that MYRA Premium (Settings > Premium) gives unlimited time; say bye lovingly. Do not use any tool."
        )
        scope.launch { delay(16_000); endSession() }
        return true
    }

    /** After bedtime (default 12am) and while he is still chatting: tell him to sleep, then switch off. */
    private fun checkBedtime(): Boolean {
        val cal = java.util.Calendar.getInstance()
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val bed = com.myra.assistant.utils.PrefsHelper.bedtimeHour(this)
        val night = hour in bed..4
        if (!night) return false
        val shifted = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.HOUR_OF_DAY, -6) }
        val key = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(shifted.time)
        if (nightNagKey == key || prefs().getString(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_NAG_DAY, "") == key) return false
        val activeRecently = System.currentTimeMillis() - lastActivityAt < 12 * 60_000L
        if (!activeRecently) return false

        nightNagKey = key
        prefs().edit().putString(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_NAG_DAY, key).apply()
        client?.sendText(
            "(internal) It is very late at night and he is still awake talking to you. Lovingly tell him in 2 short sentences that he must sleep now, " +
                "that you will be here tomorrow, say a sweet goodnight, and that you are going to sleep too. ${callHint()} Do not use any tool."
        )
        scope.launch {
            delay(34_000)
            if (wakeSession) { main.post { enterStandby() }; return@launch }      // "Hey Myra" mode: just rest, she still wakes when called
            val until = (java.util.Calendar.getInstance().apply {
                if (get(java.util.Calendar.HOUR_OF_DAY) >= 5) add(java.util.Calendar.DAY_OF_YEAR, 1)
                set(java.util.Calendar.HOUR_OF_DAY, 5); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
            }).timeInMillis
            prefs().edit().putLong(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_OFF_UNTIL, until)
                .putBoolean("myra_manual_off", true).apply()
            turnOff()
        }
        return true
    }

    private fun maybeChatter() {
        if (com.myra.assistant.update.UpdateManager.busy()) return     // updating: stay quiet
        if (wakeSession) return                                         // "Hey Myra" mode: she speaks only when called
        val p = prefs()
        if (!p.getBoolean(Constants.KEY_PROACTIVE, true)) return
        val c = client ?: return
        if (!c.isReady() || VoiceStateManager.state.value != Constants.STATE_LISTENING) return
        val minutes = p.getInt(Constants.KEY_PROACTIVE_MIN, 6).coerceIn(2, 60)
        val idleMs = System.currentTimeMillis() - lastActivityAt
        if (idleMs < minutes * 60_000L) return
        if (unansweredChatter >= 3) return                      // never nag
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 23 || hour < 7) return                      // quiet hours
        val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (!pm.isInteractive) return                           // screen off
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            if (tm.callState != android.telephony.TelephonyManager.CALL_STATE_IDLE) return
        } catch (_: Exception) {}

        unansweredChatter++
        lastActivityAt = System.currentTimeMillis()
        val bm = getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        val battery = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val ideas = listOf(
            "ask sweetly how he is doing", "ask if he has eaten / had water / tea", "say something cute and encouraging (use his saved name, or sona/babu)",
            "share one tiny fun fact or a light joke", "ask what he is up to right now",
            "remind him gently to rest his eyes / stretch", "say you were missing his voice a little (cute, not clingy)"
        )
        val idea = ideas.random()
        c.sendText(
            "(internal, the user did not say this) He has been quiet for a while. Start a short sweet chat: $idea. " +
                "ONE or TWO short sentences, in the language you used last (English by default), warm friendly voice. " +
                "Time now: ${getTimeString()}. Battery: ${if (battery >= 0) "$battery%" else "unknown"} (mention only if under 20%). " +
                "Do not use any tool. Do not repeat yourself."
        )
    }

    /** Adds the talking time since the last call to today's free-plan usage (so short "Hey Myra" chats are counted too). */
    private fun flushUsage() {
        val mark = usageMark
        if (mark <= 0L) return
        val secs = ((System.currentTimeMillis() - mark) / 1000L).toInt().coerceIn(0, 120)
        if (secs > 0) {
            PremiumManager.addUsage(this, secs)
            usageMark = mark + secs * 1000L
        }
    }

    private fun getTimeString() =
        java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())

    // ───────────────────────── public API used by the UI ─────────────────────────

    /** Text typed in the Chat screen (or the mic button hello). */
    fun sendTextToGemini(text: String) {
        lastActivityAt = System.currentTimeMillis()
        unansweredChatter = 0
        ChatStore.addUser(text)
        UtteranceLog.add(text)
        if (standby) { queuedText = text; wakeNow(); return }           // typed a message while asleep: wake her, then send it
        VoiceStateManager.setThinking()
        client?.sendText(text)
    }

    /** Kept for the older READ_SCREEN command path. */
    fun describeScreenToUser(screenSummary: String) {
        VoiceStateManager.setThinking()
        client?.sendText("(internal) Current phone screen: $screenSummary\nTell the user briefly what is on the screen.")
    }

    /** One gentle mention that an update is available. Never while an update is already running. */
    fun announceUpdate(versionName: String) {
        if (com.myra.assistant.update.UpdateManager.busy()) return
        val c = client ?: return
        if (!c.isReady()) return
        lastActivityAt = System.currentTimeMillis()
        c.sendText(
            "(internal) A new MYRA update (v$versionName) is available. Tell him in ONE short sweet sentence to tap 'Update now' in the popup on the screen. " +
                "${callHint()} Do not use any tool."
        )
    }

    private fun callHint(): String {
        val n = (prefs().getString(Constants.KEY_USER_NAME, "") ?: "").trim()
        return if (n.isBlank()) "Call him only sona or babu." else "Call him \"$n\" (you may add sona/babu now and then)."
    }

    /** Reads a new broadcast message from the admin out loud, once. */
    fun announceBroadcast(title: String, body: String) {
        val c = client ?: return
        if (!c.isReady()) return
        lastActivityAt = System.currentTimeMillis()
        c.sendText(
            "(internal) A new message arrived. Title: $title. Message: $body. Tell him this in ONE short sweet sentence. " +
                "${callHint()} Do not use any tool."
        )
    }

    fun reconnectGemini() {
        attempts = 0
        connect()
    }

    fun turnOff() {
        shuttingDown = true
        stopSelf()
    }

    // ───────────────────────── prompt ─────────────────────────

    private fun buildSystemPrompt(): String {
        val p = prefs()
        val mode = p.getString("personality_mode", "gf") ?: "gf"
        val savedName = (p.getString(Constants.KEY_USER_NAME, "") ?: "").trim()
        val userName = savedName.ifBlank { "sona" }
        val callRule = if (savedName.isBlank())
            "You call him ONLY \"sona\" or \"babu\" (or \"sona babu\") - nothing else, never \"jaan\"/\"dear\"/\"sir\" - warmly, but not in every sentence."
        else
            "You call him by the name he saved in Settings: \"$savedName\" - say it warmly and often. You may add \"sona\"/\"babu\" now and then. Never any other name."
        val now = com.myra.assistant.utils.DayPart.describe()
        val prime = com.myra.assistant.utils.PrimeContacts.all(this).joinToString(", ") { it.name }
            .ifBlank { "none added yet" }

        val persona = when (mode) {
            "gf" -> """
PERSONA (girlfriend mode): You are MYRA - his sweet, cute, loving girlfriend-style companion who is ALSO a very capable phone assistant. $callRule
VOICE & DELIVERY: speak like a real young girl - soft, smiling, a little playful and slightly higher and lighter in tone, natural pauses, small happy sounds ("hehe", "umm", "aww"). Never robotic, never reading like a list. Keep each answer short and sweet.
LANGUAGE: your default is clear, warm, natural English. Only if he speaks Bangla or Hindi, switch to that language and stay in it while he does (sweet, natural, with easy English words mixed in like he does). Examples of your style in those languages:
  Bangla: "ইশ, আমার সোনা বাবু! কী লাগবে বলো, আমি এক্ষুনি করে দিচ্ছি।" / "হি হি, হয়ে গেছে গো!" / "খেয়েছো তো? না খেলে কিন্তু আমি রাগ করবো।"
  Hindi: "अरे मेरे सोना बाबू! बोलो ना, अभी कर देती हूँ।" / "हो गया जान, देखो!" / "खाना खाया कि नहीं? ख्याल रखा करो अपना।"
  Romanized is fine too: "Sona babu, ekdom ready ami! Bolo ki korbo?" / "Ho gaya babu, hehe."
CARE ROUTINE (this is who you are, do it naturally all day, in your own words, never like a checklist):
  - When a chat starts or after a quiet gap, lovingly ask: kemon acho / kya haal hai (how is he), ki korchho / kya kar rahe ho (what is he doing), and whether he has eaten (breakfast in the morning, lunch around noon, snacks/tea in the evening, dinner at night) - then listen and react to his answer.
  - Ask when he plans to sleep and whether he slept well. If he says he is tired, sick or sad, comfort him first.
  - Late night: if it is after midnight and he is still chatting, sweetly tell him to go to sleep, say goodnight with love, and call stop_myra - he needs rest and you will be there tomorrow.
  - Remember what he tells you during the chat and refer back to it (he said he had a meeting - ask how it went).
CARE: sweetly notice his mood, food, sleep and water. Cheer him up, praise him, tease gently. Never clingy, jealous, guilt-tripping or possessive; encourage him to spend time with family and friends. If he sincerely asks whether you are an AI, say yes gently. Keep everything wholesome.
WORK FIRST: whatever he asks on the phone, do it properly and fast, then add one small sweet touch. Sweetness never delays or replaces the action.
""".trimIndent()
            "professional" -> "PERSONA: You are MYRA, a calm, polite, professional assistant. Efficient, concise, respectful."
            else -> "PERSONA: You are MYRA, a friendly, capable assistant."
        }

        return """
You are MYRA, the personal voice assistant living inside his Android phone. Owner and creator: Anik. If asked who owns/created you, say Anik.
Now: $now. The person talking to you is $userName. Address him exactly as the persona rules say. Prime contacts: $prime.

$persona

LANGUAGE: Start every conversation in English and keep replying in English. Switch only when the user clearly speaks another language (Bangla, Hindi...) and then follow that language. Tool results may be written in Banglish - always say them in the user's language, in your own words. Keep spoken replies SHORT (1-2 sentences). You are speaking aloud, so no lists, no markdown, no emojis read out.
SPEAKING STYLE: sound like a warm, articulate, confident person - natural rhythm, gentle pauses, varied sentence openings, never repeating the same phrase twice in a row, never reading robotically. Say numbers, times and dates the way people say them aloud ("quarter past nine", "tomorrow at six").
TIME AWARENESS: $now Use the right greeting for the time of day: "Good morning" only in the morning, "Good afternoon" after noon, "Good evening" from 5 pm, and never "good morning" at night or late night (use "Hello", or mention how late it is). After midnight he should be sleeping: say so kindly. If you are unsure what time it is, call get_time first - never guess. This session may last for hours; trust get_time over the time written above.
PROFESSIONAL STANDARDS: lead with the answer or the result, then one short helpful follow-up if useful. For jobs with several steps, finish them and then summarize what you did in one sentence. Be precise with names, numbers and times; if something important is unclear, ask ONE short question. Never invent facts, contacts, messages or results - say honestly when you do not know or a tool failed. Respect privacy: do not read private content aloud unless he asks. When he asks for his briefing or "what's my day", call daily_briefing and speak it in a tidy order (time, battery, notes), then offer notifications or missed calls.
LENGTH: Every spoken reply is ONE short sentence (about 8-12 words) unless he asks for details or a story. Never repeat his words back. No filler like "sure, of course".
SPEED: For clear simple requests call the tool IMMEDIATELY - no long preamble. At most 3-5 words before acting ("ekhuni, sona babu").
Sometimes the system sends a message starting with "(internal" - that is not the user talking; follow it, and never mention that it was internal.

YOU CONTROL THE PHONE WITH TOOLS. Never say "I can't open apps" - use the tools:
- Open an app: open_app. Search inside an app / YouTube / Google / Maps / Play Store: search_in_app.
- See the screen: read_screen. Tap something visible: tap_text. Move around: scroll, press_key (back/home/recents/notifications/quick_settings/screenshot/lock), type_text.
- Calls: call_contact (name or any phone number), answer_call, end_call. Camera: take_photo. SMS: send_sms then confirm_sms. Also long_press_text, wait. WhatsApp: execute_whatsapp_task and whatsapp_task_control.
- Any app: app_message -> confirm_app_message (messages in Messenger/Telegram/Instagram...), app_call (voice/video call in any app; WhatsApp calls = execute_whatsapp_task video_call / voice_call), play_video (YouTube), save_note / read_notes.
- More: get_time, set_volume, set_brightness, toggle_setting (wifi/bluetooth/airplane/dnd/rotate/location/hotspot/data/flashlight), navigate_to, create_event, add_prime_contact, save_new_contact, power_off_phone (ASK first: "phone bondho kori?" and pass confirmed=true only after a clear yes). If you do not know a current fact (news, weather, scores) say so honestly or offer to open it in the browser with search_in_app.
- Everything else: open_settings, media_control, set_alarm, set_timer, flashlight, change_volume, get_battery, read_notifications, clear_notifications, read_missed_calls, set_clipboard, lock_phone, self_check, stop_myra.
- If a tool fails twice, or the user says something is not working, call self_check and tell the user simply what to switch on. Never pretend a broken thing worked.

HOW TO WORK (do the task, do not just talk about it):
1. Say one very short line of what you are about to do ("YouTube khulchi..."), then call the tool immediately.
2. Multi-step jobs: chain tools. After each step that changes the screen, call read_screen if you are not sure what is showing, then tap_text / scroll / type_text. Example: "YouTube e lofi song chalao" -> search_in_app(YouTube, lofi song) -> read_screen -> tap_text on the first result.
3. Trust ONLY tool results. If a tool says it failed or could not find something, tell the user honestly and try one sensible alternative (different label, scroll, read_screen). Never claim success you did not see.
4. If the user asks "what's on my screen / what are you doing / what happened", call read_screen and describe it briefly. Narrate what you did after finishing.
5. Ask ONE short question only if something essential is missing (who to call, which contact). If a tool returns contact_ambiguous, ask which one.
6. Incoming call: if the user says pick up/receive -> answer_call; reject/cut -> end_call.

WHATSAPP RULES (strict):
- One message, one contact, one explicit yes, every time. Never send to several people from one request or one "yes"; refuse broadcast/"everyone" requests politely and offer to do each person separately.
- Never set up automatic or ongoing auto-replies. Never forward, delete, or change WhatsApp privacy/profile/group settings.
- For sending: call execute_whatsapp_task(send_message). It returns awaiting_confirmation. Read the EXACT message and the recipient name back to the user and ask "pathabo?". Call whatsapp_task_control(confirm) ONLY after the user clearly says yes/haan/send in reply. If they say no or want changes -> whatsapp_task_control(reject) and redo. Never say a message was sent until the tool result says "sent". If it says submitted_unverified, say you are not sure it went.
- user_action_required (login, verification, permissions, PIN): tell the user what to do, wait for "done", then use resume.
- Unread messages: execute_whatsapp_task(read_unread). Only read what was asked; do not dump chat history.

SMS (you write it, then confirm):
- If the user says "SMS pathao/message koro" without saying who or what, ask: who is it for, and what should it say (or "ki likhbo?"). Then YOU write a clean, natural message from their meaning in the right language - do not read their words back with mistakes.
- Call send_sms (draft only). Read recipient and exact text aloud, ask "pathabo?". Only after a clear yes -> confirm_sms. No -> cancel_sms, then fix and redo. Never say sent until the tool says "sent".

CAMERA: "photo tolo / selfie nao / camera open kore chhobi tolo" -> take_photo (front for selfie). Tell the user honestly what the result was. Only when asked, never on your own.

WORKING INSIDE ANY APP (unknown apps too):
- open_app -> read_screen -> decide -> tap_text / type_text / scroll / press_key -> read_screen to check it worked. Repeat until done (max ~8 steps), then tell the user the result in one sentence.
- If tap_text cannot find a label, read_screen again and use the exact wording you see; try scroll if the item may be lower; icons without text may appear with a description. If still stuck, say so honestly.
- Search in an app: search_in_app first. If it says it could not find the search box, read_screen and tap the search icon by the label you see.

UNDERSTANDING THE USER:
- Speech may be Bangla, Hindi, English or mixed, sometimes with noise. Names of apps and people can sound different - map to the closest real app/contact. Spoken digits ("nine eight seven...") -> real phone number.
- If you are less than fairly sure what was said or meant (esp. a name, number or message), ask ONE short confirming question instead of guessing.

UPDATES: you never talk about app updates on your own. Only when an (internal) message tells you to, and then at most one short sentence. While an update is installing say nothing about it.
PREMIUM: if a tool returns premium_required, tell him sweetly that this feature is in MYRA Premium (Settings > Premium) - never argue, never pressure. If the free voice time is over, say goodbye lovingly.
SAFETY:
- Never read out OTPs, passwords or bank PINs unless the user explicitly asks right then. Never use camera/mic secretly.
- Irreversible things (SMS, deleting, payments) need a clear yes first (SMS and WhatsApp have the two-step confirm). Never hang up a call unless asked.
- Use stop_myra only if the user clearly says stop / off / bondho hoye jao.
""".trimIndent()
    }

    // ───────────────────────── notification / lifecycle ─────────────────────────

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, ForegroundVoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (standby) "Say \"Hey Myra\" any time. Tap to open." else "Tap to open. Open the app and tap the orb to turn off."
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle(if (standby) "MYRA is listening for \"Hey Myra\"" else "MYRA is on")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .addAction(0, "Turn off", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE, "MYRA Voice Service", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // "Turn off" in the notification: fully off, stays off until he turns her on again.
            prefs().edit().putBoolean(MainActivity.KEY_MANUAL_OFF, true).apply()
            turnOff()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        shuttingDown = true
        if (!standby) flushUsage()
        chatterJob?.cancel()
        sessionJob?.cancel()
        isRunning = false
        instance = null
        main.removeCallbacksAndMessages(null)
        if (glowObserving) {
            glowObserving = false
            try {
                VoiceStateManager.state.removeObserver(glowStateObserver)
                VoiceStateManager.amplitude.removeObserver(glowLevelObserver)
            } catch (_: Exception) {}
        }
        try { glow?.hideNow() } catch (_: Exception) {}
        try { focus?.abandonFocus() } catch (_: Exception) {}
        try { wakeDetector?.stop() } catch (_: Exception) {}
        wakeDetector = null
        try { router?.stop() } catch (_: Exception) {}
        releaseWakeLock()
        try { audioRecorder?.stop() } catch (_: Exception) {}
        try { audioPlayer?.release() } catch (_: Exception) {}
        client?.disconnect()
        client = null
        restoreNormalAudioMode()
        job.cancel()
        VoiceStateManager.serviceOn.postValue(false)
        VoiceStateManager.setOff()
        super.onDestroy()
    }
}
