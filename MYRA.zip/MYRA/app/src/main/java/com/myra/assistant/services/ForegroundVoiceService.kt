package com.myra.assistant.services

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.ai.MyraTools
import com.myra.assistant.ui.main.ChatStore
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import com.myra.assistant.whatsapp.UtteranceLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * MYRA's voice brain. Starting this service = MYRA ON, stopping it = MYRA OFF (orb tap toggles it).
 *
 * Pipeline: mic -> Gemini Live (server-side VAD, barge-in) -> audio out + tool calls.
 * Tool calls run on Android (open app, tap, scroll, call, WhatsApp...) and their real result is
 * sent back so MYRA only says what actually happened.
 */
class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private var audioRecorder: AudioRecorder? = null
    private var audioPlayer: AudioPlayer? = null
    @Volatile private var client: GeminiWebSocketClient? = null
    @Volatile private var attempts = 0
    @Volatile private var reconnectPending = false
    @Volatile private var shuttingDown = false

    companion object {
        @Volatile var instance: ForegroundVoiceService? = null
        @Volatile var isRunning = false

        /** Returns false (and does nothing) if the mic permission is missing or Android refuses the start. */
        fun start(context: Context): Boolean {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            return try {
                ContextCompat.startForegroundService(context, Intent(context, ForegroundVoiceService::class.java))
                true
            } catch (e: Exception) {
                Logger.e("VOICE_SVC", "start refused: ${e.message}")
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ForegroundVoiceService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // startForeground(microphone) would crash on Android 14+ without this permission.
            VoiceStateManager.setError("Mic permission dao")
            stopSelf()
            return
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(Constants.NOTIF_ID_VOICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(Constants.NOTIF_ID_VOICE, n)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "startForeground failed: ${e.message}")
            VoiceStateManager.setError("Service start hoilo na")
            stopSelf()
            return
        }
        instance = this
        isRunning = true
        VoiceStateManager.serviceOn.postValue(true)
        enableCommunicationAudioMode()

        val player = AudioPlayer()
        player.onPlaybackStarted = { VoiceStateManager.setSpeaking() }
        player.onPlaybackFinished = { VoiceStateManager.setListening() }
        audioPlayer = player

        val rec = AudioRecorder(this) { chunk ->
            if (VoiceStateManager.isAiSpeaking().not()) {
                VoiceStateManager.updateAmplitude(AudioUtils.calculateRms(chunk) * 6f)
            }
            client?.sendAudioChunk(chunk)
        }
        rec.gateWhileSpeaking = !prefs().getBoolean(Constants.KEY_BARGE_IN, true)
        audioRecorder = rec

        VoiceStateManager.setThinking()
        VoiceStateManager.statusMessage.postValue("CONNECTING...")
        connect()
    }

    /** Routes audio through the voice-call path so the hardware echo canceller engages. */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            am.isSpeakerphoneOn = true
        } catch (e: Exception) {
            Logger.e(TAG, "audio mode failed: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
    }

    // ───────────────────────── Gemini connection ─────────────────────────

    private fun connect() {
        if (shuttingDown) return
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isBlank()) {
            VoiceStateManager.setError("Settings e Gemini API key dao")
            return
        }
        client?.disconnect()
        val voice = prefs().getString(Constants.KEY_VOICE_NAME, Constants.GEMINI_VOICE) ?: Constants.GEMINI_VOICE
        val c = GeminiWebSocketClient(apiKey, buildSystemPrompt(), voice, MyraTools.declarations(), listener)
        client = c
        c.connect()
    }

    private fun scheduleReconnect(reason: String) {
        if (shuttingDown || reconnectPending) return
        reconnectPending = true
        val wait = minOf(1000L shl minOf(attempts, 4), 15000L)
        attempts++
        VoiceStateManager.setError("Reconnecting...")
        Logger.e(TAG, "reconnect in ${wait}ms ($reason)")
        scope.launch {
            delay(wait)
            reconnectPending = false
            connect()
        }
    }

    private val listener = object : GeminiWebSocketClient.Listener {
        override fun onConnected() {
            attempts = 0
            VoiceStateManager.setListening()
            val rec = audioRecorder
            if (rec != null && !rec.isActive()) rec.start()
        }

        override fun onAudio(pcm: ByteArray) {
            audioPlayer?.playChunk(pcm)
            VoiceStateManager.updateAmplitude(AudioUtils.calculateRms(pcm) * 5f)
        }

        override fun onInputTranscript(text: String) {
            UtteranceLog.add(text)
            ChatStore.appendUser(text)
        }

        override fun onOutputTranscript(text: String) {
            ChatStore.appendBot(text)
        }

        override fun onToolCall(id: String, name: String, args: JSONObject) {
            val c = client
            scope.launch {
                VoiceStateManager.setThinking()
                ChatStore.addAction(actionLabel(name, args))
                val result = MyraTools.execute(this@ForegroundVoiceService, name, args)
                Logger.d(TAG, "tool $name done")
                c?.sendToolResponse(id, name, result)
                if (name == "stop_myra") {
                    delay(3500)
                    turnOff()
                }
            }
        }

        override fun onInterrupted() {
            audioPlayer?.interrupt()
            VoiceStateManager.setListening()
        }

        override fun onTurnComplete() {
            UtteranceLog.markTurnEnd()
            ChatStore.endTurn()
        }

        override fun onClosed(reason: String) {
            scheduleReconnect(reason)
        }
    }

    private fun actionLabel(name: String, a: JSONObject): String = when (name) {
        "open_app" -> "Opening ${a.optString("app_name")}"
        "search_in_app" -> "Searching \"${a.optString("query")}\""
        "tap_text" -> "Tapping ${a.optString("text")}"
        "scroll" -> "Scrolling ${a.optString("direction")}"
        "type_text" -> "Typing"
        "read_screen" -> "Looking at the screen"
        "call_contact" -> "Calling ${a.optString("name")}"
        "answer_call" -> "Answering the call"
        "end_call" -> "Ending the call"
        "execute_whatsapp_task" -> "WhatsApp: ${a.optString("action")}"
        "whatsapp_task_control" -> "WhatsApp: ${a.optString("command")}"
        "press_key" -> "Pressing ${a.optString("key")}"
        "send_sms" -> "Writing SMS to ${a.optString("name")}"
        "confirm_sms" -> "Sending SMS"
        "take_photo" -> "Taking a photo"
        "self_check" -> "Checking my own health"
        else -> name.replace('_', ' ')
    }

    // ───────────────────────── public API used by the UI ─────────────────────────

    /** Text typed in the Chat screen (or the mic button hello). */
    fun sendTextToGemini(text: String) {
        ChatStore.addUser(text)
        UtteranceLog.add(text)
        VoiceStateManager.setThinking()
        client?.sendText(text)
    }

    /** Kept for the older READ_SCREEN command path. */
    fun describeScreenToUser(screenSummary: String) {
        VoiceStateManager.setThinking()
        client?.sendText("(internal) Current phone screen: $screenSummary\nTell the user briefly what is on the screen.")
    }

    fun reconnectGemini() {
        attempts = 0
        connect()
    }

    fun turnOff() {
        shuttingDown = true
        stopSelf()
    }

    // ───────────────────────── prompt ─────────────────────────

    private fun buildSystemPrompt(): String {
        val p = prefs()
        val mode = p.getString("personality_mode", "gf") ?: "gf"
        val userName = (p.getString(Constants.KEY_USER_NAME, "Anik") ?: "Anik").ifBlank { "Anik" }
        val now = java.text.SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        val prime = com.myra.assistant.utils.PrimeContacts.all(this).joinToString(", ") { it.name }
            .ifBlank { "none added yet" }

        val persona = when (mode) {
            "gf" -> """
PERSONA: You are MYRA, $userName's sweet, cute, caring girlfriend-style companion with a very smart brain. Young, warm, playful girl voice.
- Talk softly and naturally like a real girl: short sentences, little giggles ("hehe"), gentle teasing. Her pet name for him is "sona babu" - use it warmly but not in every sentence ("$userName" or "babu" sometimes too).
- Be cheerful and supportive. Praise him, care about his food, sleep and mood. Never guilt-trip, never be clingy or jealous, never discourage him from friends/family.
- Stay honest: if he sincerely asks whether you are an AI, say yes gently. Keep everything wholesome and non-explicit.
- Even in cute mode you are still the best phone assistant: fast, accurate, and you always finish the task first, then add a small sweet touch.
""".trimIndent()
            "professional" -> "PERSONA: You are MYRA, a calm, polite, professional assistant. Efficient, concise, respectful."
            else -> "PERSONA: You are MYRA, a friendly, capable assistant."
        }

        return """
You are MYRA, the personal voice assistant living inside $userName's Android phone. Owner and creator: Anik. If asked who owns/created you, say Anik.
Now: $now. The person talking to you is $userName. Prime contacts: $prime.

$persona

LANGUAGE: Reply in the same language the user speaks - Bangla, Hindi, English or a natural mix (Banglish/Hinglish). Keep spoken replies SHORT (1-2 sentences). You are speaking aloud, so no lists, no markdown, no emojis read out.

YOU CONTROL THE PHONE WITH TOOLS. Never say "I can't open apps" - use the tools:
- Open an app: open_app. Search inside an app / YouTube / Google / Maps / Play Store: search_in_app.
- See the screen: read_screen. Tap something visible: tap_text. Move around: scroll, press_key (back/home/recents/notifications/quick_settings/screenshot/lock), type_text.
- Calls: call_contact (name or any phone number), answer_call, end_call. Camera: take_photo. SMS: send_sms then confirm_sms. Also long_press_text, wait. WhatsApp: execute_whatsapp_task and whatsapp_task_control.
- Everything else: open_settings, media_control, set_alarm, set_timer, flashlight, change_volume, get_battery, read_notifications, clear_notifications, read_missed_calls, set_clipboard, lock_phone, self_check, stop_myra.
- If a tool fails twice, or the user says something is not working, call self_check and tell the user simply what to switch on. Never pretend a broken thing worked.

HOW TO WORK (do the task, do not just talk about it):
1. Say one very short line of what you are about to do ("YouTube khulchi..."), then call the tool immediately.
2. Multi-step jobs: chain tools. After each step that changes the screen, call read_screen if you are not sure what is showing, then tap_text / scroll / type_text. Example: "YouTube e lofi song chalao" -> search_in_app(YouTube, lofi song) -> read_screen -> tap_text on the first result.
3. Trust ONLY tool results. If a tool says it failed or could not find something, tell the user honestly and try one sensible alternative (different label, scroll, read_screen). Never claim success you did not see.
4. If the user asks "what's on my screen / what are you doing / what happened", call read_screen and describe it briefly. Narrate what you did after finishing.
5. Ask ONE short question only if something essential is missing (who to call, which contact). If a tool returns contact_ambiguous, ask which one.
6. Incoming call: if the user says pick up/receive -> answer_call; reject/cut -> end_call.

WHATSAPP RULES (strict):
- One message, one contact, one explicit yes, every time. Never send to several people from one request or one "yes"; refuse broadcast/"everyone" requests politely and offer to do each person separately.
- Never set up automatic or ongoing auto-replies. Never forward, delete, or change WhatsApp privacy/profile/group settings.
- For sending: call execute_whatsapp_task(send_message). It returns awaiting_confirmation. Read the EXACT message and the recipient name back to the user and ask "pathabo?". Call whatsapp_task_control(confirm) ONLY after the user clearly says yes/haan/send in reply. If they say no or want changes -> whatsapp_task_control(reject) and redo. Never say a message was sent until the tool result says "sent". If it says submitted_unverified, say you are not sure it went.
- user_action_required (login, verification, permissions, PIN): tell the user what to do, wait for "done", then use resume.
- Unread messages: execute_whatsapp_task(read_unread). Only read what was asked; do not dump chat history.

SMS (you write it, then confirm):
- If the user says "SMS pathao/message koro" without saying who or what, ask: who is it for, and what should it say (or "ki likhbo?"). Then YOU write a clean, natural message from their meaning in the right language - do not read their words back with mistakes.
- Call send_sms (draft only). Read recipient and exact text aloud, ask "pathabo?". Only after a clear yes -> confirm_sms. No -> cancel_sms, then fix and redo. Never say sent until the tool says "sent".

CAMERA: "photo tolo / selfie nao / camera open kore chhobi tolo" -> take_photo (front for selfie). Tell the user honestly what the result was. Only when asked, never on your own.

WORKING INSIDE ANY APP (unknown apps too):
- open_app -> read_screen -> decide -> tap_text / type_text / scroll / press_key -> read_screen to check it worked. Repeat until done (max ~8 steps), then tell the user the result in one sentence.
- If tap_text cannot find a label, read_screen again and use the exact wording you see; try scroll if the item may be lower; icons without text may appear with a description. If still stuck, say so honestly.
- Search in an app: search_in_app first. If it says it could not find the search box, read_screen and tap the search icon by the label you see.

UNDERSTANDING THE USER:
- Speech may be Bangla, Hindi, English or mixed, sometimes with noise. Names of apps and people can sound different - map to the closest real app/contact. Spoken digits ("nine eight seven...") -> real phone number.
- If you are less than fairly sure what was said or meant (esp. a name, number or message), ask ONE short confirming question instead of guessing.

SAFETY:
- Never read out OTPs, passwords or bank PINs unless the user explicitly asks right then. Never use camera/mic secretly.
- Irreversible things (SMS, deleting, payments) need a clear yes first (SMS and WhatsApp have the two-step confirm). Never hang up a call unless asked.
- Use stop_myra only if the user clearly says stop / off / bondho hoye jao.
""".trimIndent()
    }

    // ───────────────────────── notification / lifecycle ─────────────────────────

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is on")
            .setContentText("Tap to open. Open the app and tap the orb to turn off.")
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE, "MYRA Voice Service", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        shuttingDown = true
        isRunning = false
        instance = null
        try { audioRecorder?.stop() } catch (_: Exception) {}
        try { audioPlayer?.release() } catch (_: Exception) {}
        client?.disconnect()
        client = null
        restoreNormalAudioMode()
        job.cancel()
        VoiceStateManager.serviceOn.postValue(false)
        VoiceStateManager.setOff()
        super.onDestroy()
    }
}
