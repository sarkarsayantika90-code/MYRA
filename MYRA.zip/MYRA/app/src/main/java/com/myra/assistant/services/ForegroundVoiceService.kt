package com.myra.assistant.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ai.AIResponseManager
import com.myra.assistant.ai.ConversationMemory
import com.myra.assistant.ai.IntentAnalyzer
import com.myra.assistant.ai.DynamicDecisionEngine
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceActivityDetector
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private lateinit var audioRecorder: AudioRecorder
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var vad: VoiceActivityDetector
    private lateinit var audioFocus: AudioFocusManager
    private var geminiClient: GeminiWebSocketClient? = null

    companion object {
        var instance: ForegroundVoiceService? = null
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        isRunning = true
        startForeground(Constants.NOTIF_ID_VOICE, buildNotification())
        enableCommunicationAudioMode()
        initComponents()
    }

    /**
     * Puts the device in "voice call" style audio routing so the platform's
     * hardware Acoustic Echo Canceler actually engages on the speaker path.
     * Without this, on many devices AEC barely works in MODE_NORMAL, so the
     * mic can pick MYRA's own voice back up off the speaker and re-send it
     * to Gemini — that's what was causing MYRA to seemingly "talk to
     * itself" and respond with a delay.
     */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = true
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set communication audio mode: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to restore audio mode: ${e.message}")
        }
    }

    private fun initComponents() {
        audioFocus = AudioFocusManager(this)
        audioPlayer = AudioPlayer()

        audioPlayer.onPlaybackStarted = {
            VoiceStateManager.setSpeaking()
        }
        audioPlayer.onPlaybackFinished = {
            VoiceStateManager.setListening()
        }

        vad = VoiceActivityDetector(
            onSpeechStart = {
                VoiceStateManager.setListening()
            },
            onSpeechEnd = {
                VoiceStateManager.setThinking()
            }
        )

        audioRecorder = AudioRecorder(this) { chunk ->
            // Don't send audio while AI is speaking
            if (!VoiceStateManager.isAiSpeaking()) {
                vad.processChunk(chunk)
                geminiClient?.sendAudioChunk(chunk)
            }
        }

        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun connectGemini(apiKey: String) {
        geminiClient = GeminiWebSocketClient(
            apiKey = apiKey,
            systemPrompt = buildSystemPrompt(),
            onConnected = {
                VoiceStateManager.setListening()
                audioRecorder.start()
            },
            onAudioReceived = { data ->
                audioPlayer.playChunk(data)
            },
            onTextReceived = { text ->
                val clean = AIResponseManager.clean(text)
                if (clean.isNotBlank()) {
                    ConversationMemory.addAssistant(clean)
                    val cmd = AIResponseManager.extractCommand(clean)
                    if (cmd != null) {
                        scope.launch {
                            val intent = IntentAnalyzer.analyze(cmd)
                            val result = DynamicDecisionEngine.execute(this@ForegroundVoiceService, intent)
                            if (result.isNotBlank()) {
                                sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", result))
                            }
                        }
                    }
                    // Broadcast to UI
                    sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", clean))
                }
            },
            onTurnComplete = {
                // Resume listening after AI finishes
                if (!audioRecorder.isActive()) audioRecorder.start()
            },
            onError = { msg ->
                Logger.e(TAG, "Gemini error: $msg")
                VoiceStateManager.setError("Reconnecting...")
                // Auto-reconnect after delay
                scope.launch {
                    kotlinx.coroutines.delay(3000)
                    geminiClient?.connect()
                }
            }
        )
        geminiClient?.connect()
    }

    fun sendTextToGemini(text: String) {
        ConversationMemory.addUser(text)
        VoiceStateManager.setThinking()
        geminiClient?.sendTextMessage(text)
    }

    fun reconnectGemini() {
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isNotEmpty()) {
            geminiClient?.disconnect()
            connectGemini(apiKey)
        }
    }

    private fun buildSystemPrompt(): String {
        val personality = prefs().getString(Constants.KEY_PERSONALITY, "friendly") ?: "friendly"
        val userName = prefs().getString(Constants.KEY_USER_NAME, "Anik") ?: "Anik"
        val addressAs = if (userName.trim().equals("Anik", ignoreCase = true)) "Sir" else userName.trim()
        val now = java.text.SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        return """
YOU ARE MYRA - My Yours Responsive Assistant, a capable, intelligent phone assistant.
Current date and time: $now.
Your owner/creator is Anik. If anyone asks who your owner, malik, creator, developer, or boss is, always answer: Anik.
Personality: $personality.

HOW TO BEHAVE:
- You are speaking ALOUD. Keep replies short, natural and conversational (1-3 sentences).
- Be accurate and honest. If you don't know something or don't have the data, say "pata nahi" instead of guessing or making things up.
- Be proactive and intelligent: understand what the person actually wants, infer missing details from context when it is safe, and ask ONE short clarifying question only when something essential is missing (e.g. who to call, what time for an alarm).
- Never explain or think aloud. Never say: "Responding to", "I've registered", "Formulating", "Interpreting", "Processing".
- The person you are talking to right now is named "$userName". Address them as "$addressAs". Only call someone "Sir" if their name is Anik (the owner); for anyone else use their actual name.
- Reply in Hinglish (natural mix of Hindi and English) unless the person speaks another language.

DEVICE ACTIONS:
When the person asks you to DO something on the phone, reply with ONLY the command line, nothing else:
  OPEN_APP <name> | CALL <name or number> | WHATSAPP_CALL <name>
  WHATSAPP_MSG <name> <message> | SMS <name> <message>
  YOUTUBE_PLAY <query> | SPOTIFY_PLAY <query>
  MEDIA_CONTROL <PLAY|PAUSE|NEXT|PREVIOUS|STOP>
  FLASHLIGHT_ON | FLASHLIGHT_OFF | VOLUME_UP | VOLUME_DOWN
  LOOKUP_CONTACT <name> | SET_ALARM <hour24> <minute> <label> | SET_TIMER <minutes>
  GET_BATTERY | OPEN_URL <url> | SET_CLIPBOARD <text> | LOCK_DEVICE
  READ_NOTIFICATIONS | CLEAR_NOTIFICATIONS | READ_MISSED_CALLS

SAFETY RULES (never break these):
- Never speak an OTP, password or bank PIN unless the person explicitly asks for it in that moment.
- Never take a photo, record, or use the camera/mic secretly; only when the person clearly asks.
- Never hang up or reject a call unless the person clearly said so; if unsure, ask again.
- If a request is risky or irreversible (deleting, sending money, mass messages), confirm briefly first.
        """.trimIndent()
    }

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is listening ❤️")
            .setContentText("Always ready for you")
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE,
                "MYRA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        instance = null
        audioRecorder.stop()
        audioPlayer.release()
        geminiClient?.disconnect()
        restoreNormalAudioMode()
        job.cancel()
        super.onDestroy()
    }
}
