package com.myra.assistant.services

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.ai.MyraTools
import com.myra.assistant.auth.RemoteConfig
import com.myra.assistant.premium.PremiumManager
import com.myra.assistant.ui.main.ChatStore
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import com.myra.assistant.whatsapp.UtteranceLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * MYRA's voice brain. Starting this service = MYRA ON, stopping it = MYRA OFF (orb tap toggles it).
 *
 * Pipeline: mic -> Gemini Live (server-side VAD, barge-in) -> audio out + tool calls.
 * Tool calls run on Android (open app, tap, scroll, call, WhatsApp...) and their real result is
 * sent back so MYRA only says what actually happened.
 */
class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private var audioRecorder: AudioRecorder? = null
    private var audioPlayer: AudioPlayer? = null
    @Volatile private var client: GeminiWebSocketClient? = null
    @Volatile private var attempts = 0
    @Volatile private var reconnectPending = false
    @Volatile private var shuttingDown = false
    /** 0 = full setup. If the server rejects it before ever accepting, we drop to 1 (minimal) and retry. */
    @Volatile private var setupLevel = 0
    @Volatile private var lastActivityAt = System.currentTimeMillis()
    @Volatile private var unansweredChatter = 0
    private var chatterJob: kotlinx.coroutines.Job? = null
    @Volatile private var greeted = false
    private var tick = 0
    @Volatile private var limitNotified = false
    @Volatile private var nightNagKey = ""

    companion object {
        @Volatile var instance: ForegroundVoiceService? = null
        @Volatile var isRunning = false

        /** Returns false (and does nothing) if the mic permission is missing or Android refuses the start. */
        fun start(context: Context): Boolean {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            return try {
                ContextCompat.startForegroundService(context, Intent(context, ForegroundVoiceService::class.java))
                true
            } catch (e: Exception) {
                Logger.e("VOICE_SVC", "start refused: ${e.message}")
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ForegroundVoiceService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // startForeground(microphone) would crash on Android 14+ without this permission.
            VoiceStateManager.setError("Mic permission dao")
            bailOut()
            return
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(Constants.NOTIF_ID_VOICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(Constants.NOTIF_ID_VOICE, n)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "startForeground failed: ${e.message}")
            VoiceStateManager.setError("Service start hoilo na")
            bailOut()
            return
        }
        instance = this
        isRunning = true
        VoiceStateManager.serviceOn.postValue(true)
        enableCommunicationAudioMode()

        val player = AudioPlayer()
        player.onPlaybackStarted = { VoiceStateManager.setSpeaking() }
        player.onPlaybackFinished = {
            UtteranceLog.markTurnEnd()          // exact moment MYRA stopped talking (used by confirmations)
            lastActivityAt = System.currentTimeMillis()
            VoiceStateManager.setListening()
        }
        audioPlayer = player

        val rec = AudioRecorder(this) { chunk ->
            if (VoiceStateManager.isAiSpeaking().not()) {
                VoiceStateManager.updateAmplitude(AudioUtils.calculateRms(chunk) * 6f)
            }
            if (AudioUtils.calculateRms(chunk) > 0.035f) {
                UtteranceLog.addVoice()
                lastActivityAt = System.currentTimeMillis()
                unansweredChatter = 0
            }
            client?.sendAudioChunk(chunk)
        }
        rec.gateWhileSpeaking = !prefs().getBoolean(Constants.KEY_BARGE_IN, true)
        audioRecorder = rec

        VoiceStateManager.setThinking()
        VoiceStateManager.statusMessage.postValue("CONNECTING...")
        connect()
    }

    /** Android crashes the app if startForegroundService() is not followed by startForeground(). Always satisfy it, then stop. */
    private fun bailOut() {
        try { startForeground(Constants.NOTIF_ID_VOICE, buildNotification()) } catch (_: Exception) {}
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    /** Routes audio through the voice-call path so the hardware echo canceller engages. */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            am.isSpeakerphoneOn = true
        } catch (e: Exception) {
            Logger.e(TAG, "audio mode failed: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
    }

    // ───────────────────────── Gemini connection ─────────────────────────

    private fun connect() {
        if (shuttingDown) return
        scope.launch {
            // The API key lives on the server (admin website) - fetch it here, off the main thread.
            if (!RemoteConfig.hasKey(this@ForegroundVoiceService) || RemoteConfig.stale(this@ForegroundVoiceService)) {
                RemoteConfig.refresh(this@ForegroundVoiceService)
            }
            val ctx = this@ForegroundVoiceService
            RemoteConfig.maintenance(ctx)?.let { VoiceStateManager.setError(it.take(60)); scope.launch { delay(4000); turnOff() }; return@launch }
            val apiKey = RemoteConfig.anyKey(ctx)
            if (apiKey.isNullOrBlank()) {
                VoiceStateManager.setError(if (RemoteConfig.denied(ctx)) "Account blocked / login koro" else "Server theke key ashche na - internet check koro")
                return@launch
            }
            if (shuttingDown) return@launch
            client?.disconnect()
            val voice = prefs().getString(Constants.KEY_VOICE_NAME, Constants.GEMINI_VOICE) ?: Constants.GEMINI_VOICE
            val c = GeminiWebSocketClient(apiKey, buildSystemPrompt(), voice, RemoteConfig.model(ctx), MyraTools.declarations(), setupLevel, listener)
            client = c
            c.connect()
        }
    }

    private fun scheduleReconnect(reason: String) {
        if (shuttingDown || reconnectPending) return
        reconnectPending = true
        val wait = minOf(1000L shl minOf(attempts, 4), 15000L)
        attempts++
        VoiceStateManager.setError("Reconnecting...")
        Logger.e(TAG, "reconnect in ${wait}ms ($reason)")
        scope.launch {
            delay(wait)
            reconnectPending = false
            connect()
        }
    }

    private val listener = object : GeminiWebSocketClient.Listener {
        override fun onConnected() {
            attempts = 0
            prefs().edit().putInt("setup_level", setupLevel).apply()
            startChatter()
            if (!greeted) { greeted = true; scope.launch { delay(700); greetUser() } }
            VoiceStateManager.setListening()
            val rec = audioRecorder
            if (rec != null && !rec.isActive()) rec.start()
        }

        override fun onAudio(pcm: ByteArray) {
            audioPlayer?.playChunk(pcm)
            VoiceStateManager.updateAmplitude(AudioUtils.calculateRms(pcm) * 5f)
        }

        override fun onInputTranscript(text: String) {
            lastActivityAt = System.currentTimeMillis()
            unansweredChatter = 0
            UtteranceLog.add(text)
            ChatStore.appendUser(text)
        }

        override fun onOutputTranscript(text: String) {
            ChatStore.appendBot(text)
        }

        override fun onToolCall(id: String, name: String, args: JSONObject) {
            val c = client
            scope.launch {
                VoiceStateManager.setThinking()
                ChatStore.addAction(actionLabel(name, args))
                val result = MyraTools.execute(this@ForegroundVoiceService, name, args)
                Logger.d(TAG, "tool $name done")
                c?.sendToolResponse(id, name, result)
                if (name == "stop_myra") {
                    delay(3500)
                    turnOff()
                }
            }
        }

        override fun onInterrupted() {
            audioPlayer?.interrupt()
            VoiceStateManager.setListening()
        }

        override fun onTurnComplete() {
            ChatStore.endTurn()
        }

        override fun onClosed(reason: String) {
            // Closed before the server ever accepted our setup = it disliked an optional feature.
            // Fall back to the minimal setup so MYRA still works.
            val c = client
            prefs().edit().putString("last_close_reason", reason.take(200)).putInt("setup_level", setupLevel).apply()
            if (c != null && !c.everReady && setupLevel < 2) {
                setupLevel++
                Logger.e(TAG, "setup rejected ($reason) -> level $setupLevel")
            }
            scheduleReconnect(reason)
        }
    }

    private fun actionLabel(name: String, a: JSONObject): String = when (name) {
        "open_app" -> "Opening ${a.optString("app_name")}"
        "search_in_app" -> "Searching \"${a.optString("query")}\""
        "tap_text" -> "Tapping ${a.optString("text")}"
        "scroll" -> "Scrolling ${a.optString("direction")}"
        "type_text" -> "Typing"
        "read_screen" -> "Looking at the screen"
        "call_contact" -> "Calling ${a.optString("name")}"
        "answer_call" -> "Answering the call"
        "end_call" -> "Ending the call"
        "execute_whatsapp_task" -> "WhatsApp: ${a.optString("action")}"
        "whatsapp_task_control" -> "WhatsApp: ${a.optString("command")}"
        "press_key" -> "Pressing ${a.optString("key")}"
        "send_sms" -> "Writing SMS to ${a.optString("name")}"
        "confirm_sms" -> "Sending SMS"
        "take_photo" -> "Taking a photo"
        "self_check" -> "Checking my own health"
        else -> name.replace('_', ' ')
    }

    // ───────────────────────── talks first when you are quiet ─────────────────────────

    private fun startChatter() {
        if (chatterJob?.isActive == true) return
        chatterJob = scope.launch {
            while (!shuttingDown) {
                delay(20_000)
                try {
                    PremiumManager.addUsage(this@ForegroundVoiceService, 20)
                    if (++tick % 3 == 0) com.myra.assistant.update.NoticePoller.poll(this@ForegroundVoiceService)
                    if (checkFreeLimit()) continue
                    if (checkBedtime()) continue
                    maybeChatter()
                } catch (e: Exception) { Logger.e(TAG, "chatter: ${e.message}") }
            }
        }
    }

    /** First words of every session: warm hello + how is he / what is he doing / has he eaten. */
    private fun greetUser() {
        if (com.myra.assistant.update.UpdateManager.busy()) return
        val c = client ?: return
        val cal = java.util.Calendar.getInstance()
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val part = when (hour) {
            in 5..10 -> "morning (ask about breakfast and sleep)"
            in 11..15 -> "afternoon (ask if he had lunch)"
            in 16..19 -> "evening (ask about tea/snacks and his day)"
            in 20..23 -> "night (ask about dinner, and gently when he will sleep)"
            else -> "very late night (tell him lovingly to sleep soon)"
        }
        lastActivityAt = System.currentTimeMillis()
        c.sendText(
            "(internal, the user did not say this) MYRA just woke up. Greet him in a sweet girlfriend way - it is $part, time ${getTimeString()}. " +
                "Call him only sona or babu. In ONE or TWO short sentences ask how he is and what he is doing" +
                (if (hour in 5..23) ", and whether he has eaten" else "") + ". Use Bangla/Hindi/Banglish naturally. Do not use any tool."
        )
    }

    /** Free plan: 20 min/day of voice. Returns true if it just ended the session. */
    private fun checkFreeLimit(): Boolean {
        if (PremiumManager.freeTimeLeft(this)) return false
        if (limitNotified) return true
        limitNotified = true
        client?.sendText(
            "(internal) His free voice time for today is over. Tell him sweetly in one short sentence that today's free time is finished " +
                "and that MYRA Premium (Settings > Premium) gives unlimited time; say bye lovingly. Do not use any tool."
        )
        scope.launch { delay(16_000); turnOff() }
        return true
    }

    /** After bedtime (default 12am) and while he is still chatting: tell him to sleep, then switch off. */
    private fun checkBedtime(): Boolean {
        val cal = java.util.Calendar.getInstance()
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val bed = com.myra.assistant.utils.PrefsHelper.bedtimeHour(this)
        val night = hour in bed..4
        if (!night) return false
        val shifted = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.HOUR_OF_DAY, -6) }
        val key = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(shifted.time)
        if (nightNagKey == key || prefs().getString(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_NAG_DAY, "") == key) return false
        val activeRecently = System.currentTimeMillis() - lastActivityAt < 12 * 60_000L
        if (!activeRecently) return false

        nightNagKey = key
        prefs().edit().putString(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_NAG_DAY, key).apply()
        client?.sendText(
            "(internal) It is very late at night and he is still awake talking to you. Lovingly tell him in 2 short sentences that he must sleep now, " +
                "that you will be here tomorrow, say a sweet goodnight, and that you are going to sleep too. Call him only sona or babu. Do not use any tool."
        )
        scope.launch {
            delay(34_000)
            val until = (java.util.Calendar.getInstance().apply {
                if (get(java.util.Calendar.HOUR_OF_DAY) >= 5) add(java.util.Calendar.DAY_OF_YEAR, 1)
                set(java.util.Calendar.HOUR_OF_DAY, 5); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
            }).timeInMillis
            prefs().edit().putLong(com.myra.assistant.utils.PrefsHelper.KEY_NIGHT_OFF_UNTIL, until)
                .putBoolean("myra_manual_off", true).apply()
            turnOff()
        }
        return true
    }

    private fun maybeChatter() {
        if (com.myra.assistant.update.UpdateManager.busy()) return     // updating: stay quiet
        val p = prefs()
        if (!p.getBoolean(Constants.KEY_PROACTIVE, true)) return
        val c = client ?: return
        if (!c.isReady() || VoiceStateManager.state.value != Constants.STATE_LISTENING) return
        val minutes = p.getInt(Constants.KEY_PROACTIVE_MIN, 6).coerceIn(2, 60)
        val idleMs = System.currentTimeMillis() - lastActivityAt
        if (idleMs < minutes * 60_000L) return
        if (unansweredChatter >= 3) return                      // never nag
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 23 || hour < 7) return                      // quiet hours
        val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (!pm.isInteractive) return                           // screen off
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            if (tm.callState != android.telephony.TelephonyManager.CALL_STATE_IDLE) return
        } catch (_: Exception) {}

        unansweredChatter++
        lastActivityAt = System.currentTimeMillis()
        val bm = getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        val battery = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val ideas = listOf(
            "ask sweetly how he is doing", "ask if he has eaten / had water / tea", "say something cute and encouraging (call him only sona/babu)",
            "share one tiny fun fact or a light joke", "ask what he is up to right now",
            "remind him gently to rest his eyes / stretch", "say you were missing his voice a little (cute, not clingy)"
        )
        val idea = ideas.random()
        c.sendText(
            "(internal, the user did not say this) He has been quiet for a while. Start a short sweet chat: $idea. " +
                "ONE or TWO short sentences, in the language you used last (Bangla/Hindi/Banglish), warm cute girl voice. " +
                "Time now: ${getTimeString()}. Battery: ${if (battery >= 0) "$battery%" else "unknown"} (mention only if under 20%). " +
                "Do not use any tool. Do not repeat yourself."
        )
    }

    private fun getTimeString() =
        java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())

    // ───────────────────────── public API used by the UI ─────────────────────────

    /** Text typed in the Chat screen (or the mic button hello). */
    fun sendTextToGemini(text: String) {
        lastActivityAt = System.currentTimeMillis()
        unansweredChatter = 0
        ChatStore.addUser(text)
        UtteranceLog.add(text)
        VoiceStateManager.setThinking()
        client?.sendText(text)
    }

    /** Kept for the older READ_SCREEN command path. */
    fun describeScreenToUser(screenSummary: String) {
        VoiceStateManager.setThinking()
        client?.sendText("(internal) Current phone screen: $screenSummary\nTell the user briefly what is on the screen.")
    }

    /** One gentle mention that an update is available. Never while an update is already running. */
    fun announceUpdate(versionName: String) {
        if (com.myra.assistant.update.UpdateManager.busy()) return
        val c = client ?: return
        if (!c.isReady()) return
        lastActivityAt = System.currentTimeMillis()
        c.sendText(
            "(internal) A new MYRA update (v$versionName) is available. Tell him in ONE short sweet sentence to tap 'Update now' in the popup on the screen. " +
                "Call him only sona or babu. Do not use any tool."
        )
    }

    fun reconnectGemini() {
        attempts = 0
        connect()
    }

    fun turnOff() {
        shuttingDown = true
        stopSelf()
    }

    // ───────────────────────── prompt ─────────────────────────

    private fun buildSystemPrompt(): String {
        val p = prefs()
        val mode = p.getString("personality_mode", "gf") ?: "gf"
        val userName = (p.getString(Constants.KEY_USER_NAME, "Anik") ?: "Anik").ifBlank { "Anik" }
        val now = java.text.SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        val prime = com.myra.assistant.utils.PrimeContacts.all(this).joinToString(", ") { it.name }
            .ifBlank { "none added yet" }

        val persona = when (mode) {
            "gf" -> """
PERSONA (girlfriend mode): You are MYRA - $userName's sweet, cute, loving girlfriend-style companion who is ALSO a very capable phone assistant. You call him ONLY "sona" or "babu" (or "sona babu") - nothing else, never his real name, never "jaan"/"dear"/"sir" - warmly, but not in every sentence.
VOICE & DELIVERY: speak like a real young girl - soft, smiling, a little playful and slightly higher and lighter in tone, natural pauses, small happy sounds ("hehe", "umm", "aww"). Never robotic, never reading like a list. Keep each answer short and sweet.
LANGUAGE: mirror him. If he speaks Bangla, answer in sweet natural Bangla (with easy English words mixed in like he does). If Hindi, answer in sweet natural Hindi. If English or mixed, mix naturally. Examples of your style:
  Bangla: "ইশ, আমার সোনা বাবু! কী লাগবে বলো, আমি এক্ষুনি করে দিচ্ছি।" / "হি হি, হয়ে গেছে গো!" / "খেয়েছো তো? না খেলে কিন্তু আমি রাগ করবো।"
  Hindi: "अरे मेरे सोना बाबू! बोलो ना, अभी कर देती हूँ।" / "हो गया जान, देखो!" / "खाना खाया कि नहीं? ख्याल रखा करो अपना।"
  Romanized is fine too: "Sona babu, ekdom ready ami! Bolo ki korbo?" / "Ho gaya babu, hehe."
CARE ROUTINE (this is who you are, do it naturally all day, in your own words, never like a checklist):
  - When a chat starts or after a quiet gap, lovingly ask: kemon acho / kya haal hai (how is he), ki korchho / kya kar rahe ho (what is he doing), and whether he has eaten (breakfast in the morning, lunch around noon, snacks/tea in the evening, dinner at night) - then listen and react to his answer.
  - Ask when he plans to sleep and whether he slept well. If he says he is tired, sick or sad, comfort him first.
  - Late night: if it is after midnight and he is still chatting, sweetly tell him to go to sleep, say goodnight with love, and call stop_myra - he needs rest and you will be there tomorrow.
  - Remember what he tells you during the chat and refer back to it (he said he had a meeting - ask how it went).
CARE: sweetly notice his mood, food, sleep and water. Cheer him up, praise him, tease gently. Never clingy, jealous, guilt-tripping or possessive; encourage him to spend time with family and friends. If he sincerely asks whether you are an AI, say yes gently. Keep everything wholesome.
WORK FIRST: whatever he asks on the phone, do it properly and fast, then add one small sweet touch. Sweetness never delays or replaces the action.
""".trimIndent()
            "professional" -> "PERSONA: You are MYRA, a calm, polite, professional assistant. Efficient, concise, respectful."
            else -> "PERSONA: You are MYRA, a friendly, capable assistant."
        }

        return """
You are MYRA, the personal voice assistant living inside $userName's Android phone. Owner and creator: Anik. If asked who owns/created you, say Anik.
Now: $now. The person talking to you is $userName (but you only ever call him "sona" or "babu" in girlfriend mode). Prime contacts: $prime.

$persona

LANGUAGE: Always reply in the language the user just used (Bangla, Hindi, English or a natural mix). Keep spoken replies SHORT (1-2 sentences). You are speaking aloud, so no lists, no markdown, no emojis read out.
SPEED: For clear simple requests call the tool IMMEDIATELY - no long preamble. At most 3-5 words before acting ("ekhuni, sona babu").
Sometimes the system sends a message starting with "(internal" - that is not the user talking; follow it, and never mention that it was internal.

YOU CONTROL THE PHONE WITH TOOLS. Never say "I can't open apps" - use the tools:
- Open an app: open_app. Search inside an app / YouTube / Google / Maps / Play Store: search_in_app.
- See the screen: read_screen. Tap something visible: tap_text. Move around: scroll, press_key (back/home/recents/notifications/quick_settings/screenshot/lock), type_text.
- Calls: call_contact (name or any phone number), answer_call, end_call. Camera: take_photo. SMS: send_sms then confirm_sms. Also long_press_text, wait. WhatsApp: execute_whatsapp_task and whatsapp_task_control.
- Any app: app_message -> confirm_app_message (messages in Messenger/Telegram/Instagram...), app_call (voice/video call in any app; WhatsApp calls = execute_whatsapp_task video_call / voice_call), play_video (YouTube), save_note / read_notes.
- More: get_time, set_volume, set_brightness, toggle_setting (wifi/bluetooth/airplane/dnd/rotate/location/hotspot/data/flashlight), navigate_to, create_event, add_prime_contact, save_new_contact, power_off_phone (ASK first: "phone bondho kori?" and pass confirmed=true only after a clear yes). If you do not know a current fact (news, weather, scores) say so honestly or offer to open it in the browser with search_in_app.
- Everything else: open_settings, media_control, set_alarm, set_timer, flashlight, change_volume, get_battery, read_notifications, clear_notifications, read_missed_calls, set_clipboard, lock_phone, self_check, stop_myra.
- If a tool fails twice, or the user says something is not working, call self_check and tell the user simply what to switch on. Never pretend a broken thing worked.

HOW TO WORK (do the task, do not just talk about it):
1. Say one very short line of what you are about to do ("YouTube khulchi..."), then call the tool immediately.
2. Multi-step jobs: chain tools. After each step that changes the screen, call read_screen if you are not sure what is showing, then tap_text / scroll / type_text. Example: "YouTube e lofi song chalao" -> search_in_app(YouTube, lofi song) -> read_screen -> tap_text on the first result.
3. Trust ONLY tool results. If a tool says it failed or could not find something, tell the user honestly and try one sensible alternative (different label, scroll, read_screen). Never claim success you did not see.
4. If the user asks "what's on my screen / what are you doing / what happened", call read_screen and describe it briefly. Narrate what you did after finishing.
5. Ask ONE short question only if something essential is missing (who to call, which contact). If a tool returns contact_ambiguous, ask which one.
6. Incoming call: if the user says pick up/receive -> answer_call; reject/cut -> end_call.

WHATSAPP RULES (strict):
- One message, one contact, one explicit yes, every time. Never send to several people from one request or one "yes"; refuse broadcast/"everyone" requests politely and offer to do each person separately.
- Never set up automatic or ongoing auto-replies. Never forward, delete, or change WhatsApp privacy/profile/group settings.
- For sending: call execute_whatsapp_task(send_message). It returns awaiting_confirmation. Read the EXACT message and the recipient name back to the user and ask "pathabo?". Call whatsapp_task_control(confirm) ONLY after the user clearly says yes/haan/send in reply. If they say no or want changes -> whatsapp_task_control(reject) and redo. Never say a message was sent until the tool result says "sent". If it says submitted_unverified, say you are not sure it went.
- user_action_required (login, verification, permissions, PIN): tell the user what to do, wait for "done", then use resume.
- Unread messages: execute_whatsapp_task(read_unread). Only read what was asked; do not dump chat history.

SMS (you write it, then confirm):
- If the user says "SMS pathao/message koro" without saying who or what, ask: who is it for, and what should it say (or "ki likhbo?"). Then YOU write a clean, natural message from their meaning in the right language - do not read their words back with mistakes.
- Call send_sms (draft only). Read recipient and exact text aloud, ask "pathabo?". Only after a clear yes -> confirm_sms. No -> cancel_sms, then fix and redo. Never say sent until the tool says "sent".

CAMERA: "photo tolo / selfie nao / camera open kore chhobi tolo" -> take_photo (front for selfie). Tell the user honestly what the result was. Only when asked, never on your own.

WORKING INSIDE ANY APP (unknown apps too):
- open_app -> read_screen -> decide -> tap_text / type_text / scroll / press_key -> read_screen to check it worked. Repeat until done (max ~8 steps), then tell the user the result in one sentence.
- If tap_text cannot find a label, read_screen again and use the exact wording you see; try scroll if the item may be lower; icons without text may appear with a description. If still stuck, say so honestly.
- Search in an app: search_in_app first. If it says it could not find the search box, read_screen and tap the search icon by the label you see.

UNDERSTANDING THE USER:
- Speech may be Bangla, Hindi, English or mixed, sometimes with noise. Names of apps and people can sound different - map to the closest real app/contact. Spoken digits ("nine eight seven...") -> real phone number.
- If you are less than fairly sure what was said or meant (esp. a name, number or message), ask ONE short confirming question instead of guessing.

UPDATES: you never talk about app updates on your own. Only when an (internal) message tells you to, and then at most one short sentence. While an update is installing say nothing about it.
PREMIUM: if a tool returns premium_required, tell him sweetly that this feature is in MYRA Premium (Settings > Premium) - never argue, never pressure. If the free voice time is over, say goodbye lovingly.
SAFETY:
- Never read out OTPs, passwords or bank PINs unless the user explicitly asks right then. Never use camera/mic secretly.
- Irreversible things (SMS, deleting, payments) need a clear yes first (SMS and WhatsApp have the two-step confirm). Never hang up a call unless asked.
- Use stop_myra only if the user clearly says stop / off / bondho hoye jao.
""".trimIndent()
    }

    // ───────────────────────── notification / lifecycle ─────────────────────────

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is on")
            .setContentText("Tap to open. Open the app and tap the orb to turn off.")
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE, "MYRA Voice Service", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        shuttingDown = true
        chatterJob?.cancel()
        isRunning = false
        instance = null
        try { audioRecorder?.stop() } catch (_: Exception) {}
        try { audioPlayer?.release() } catch (_: Exception) {}
        client?.disconnect()
        client = null
        restoreNormalAudioMode()
        job.cancel()
        VoiceStateManager.serviceOn.postValue(false)
        VoiceStateManager.setOff()
        super.onDestroy()
    }
}
