package com.myra.assistant.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ai.AIResponseManager
import com.myra.assistant.ai.ConversationMemory
import com.myra.assistant.ai.IntentAnalyzer
import com.myra.assistant.ai.DynamicDecisionEngine
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceActivityDetector
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private lateinit var audioRecorder: AudioRecorder
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var vad: VoiceActivityDetector
    private lateinit var audioFocus: AudioFocusManager
    private var geminiClient: GeminiWebSocketClient? = null

    companion object {
        var instance: ForegroundVoiceService? = null
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        isRunning = true
        startForeground(Constants.NOTIF_ID_VOICE, buildNotification())
        enableCommunicationAudioMode()
        initComponents()
    }

    /**
     * Puts the device in "voice call" style audio routing so the platform's
     * hardware Acoustic Echo Canceler actually engages on the speaker path.
     * Without this, on many devices AEC barely works in MODE_NORMAL, so the
     * mic can pick MYRA's own voice back up off the speaker and re-send it
     * to Gemini — that's what was causing MYRA to seemingly "talk to
     * itself" and respond with a delay.
     */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = true
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set communication audio mode: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to restore audio mode: ${e.message}")
        }
    }

    private fun initComponents() {
        audioFocus = AudioFocusManager(this)
        audioPlayer = AudioPlayer()

        audioPlayer.onPlaybackStarted = {
            VoiceStateManager.setSpeaking()
        }
        audioPlayer.onPlaybackFinished = {
            VoiceStateManager.setListening()
        }

        vad = VoiceActivityDetector(
            onSpeechStart = {
                VoiceStateManager.setListening()
            },
            onSpeechEnd = {
                VoiceStateManager.setThinking()
            }
        )

        audioRecorder = AudioRecorder(this) { chunk ->
            // Don't send audio while AI is speaking
            if (!VoiceStateManager.isAiSpeaking()) {
                vad.processChunk(chunk)
                geminiClient?.sendAudioChunk(chunk)
            }
        }

        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun connectGemini(apiKey: String) {
        geminiClient = GeminiWebSocketClient(
            apiKey = apiKey,
            systemPrompt = buildSystemPrompt(),
            onConnected = {
                VoiceStateManager.setListening()
                audioRecorder.start()
            },
            onAudioReceived = { data ->
                audioPlayer.playChunk(data)
            },
            onTextReceived = { text ->
                val clean = AIResponseManager.clean(text)
                if (clean.isNotBlank()) {
                    ConversationMemory.addAssistant(clean)
                    val cmd = AIResponseManager.extractCommand(clean)
                    if (cmd != null) {
                        // A command token was found: execute it and broadcast ONLY
                        // the execution result to the UI. Previously the raw
                        // `clean` text (still containing the literal command
                        // token, e.g. "OPEN_APP WhatsApp") was ALSO broadcast
                        // unconditionally right after this block, which caused
                        // confusing duplicate/raw-token messages in the chat UI.
                        scope.launch {
                            val intent = IntentAnalyzer.analyze(cmd)
                            val result = DynamicDecisionEngine.execute(this@ForegroundVoiceService, intent)
                            if (result.isNotBlank()) {
                                sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", result))
                            }
                        }
                    } else {
                        // Genuine conversational reply, no command token: show it as-is.
                        sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", clean))
                    }
                }
            },
            onTurnComplete = {
                // Resume listening after AI finishes
                if (!audioRecorder.isActive()) audioRecorder.start()
            },
            onError = { msg ->
                Logger.e(TAG, "Gemini error: $msg")
                VoiceStateManager.setError("Reconnecting...")
                // Auto-reconnect after delay
                scope.launch {
                    kotlinx.coroutines.delay(3000)
                    geminiClient?.connect()
                }
            }
        )
        geminiClient?.connect()
    }

    fun sendTextToGemini(text: String) {
        ConversationMemory.addUser(text)
        VoiceStateManager.setThinking()
        geminiClient?.sendTextMessage(text)
    }

    /**
     * Feeds a description of the current screen (built from the accessibility
     * tree, see DynamicDecisionEngine.readScreen) to Gemini as an internal
     * prompt so MYRA can describe/summarize it by voice, reusing the existing
     * text/audio pipeline instead of a separate local TTS path. Unlike
     * [sendTextToGemini] this is NOT recorded as something the user said.
     */
    fun describeScreenToUser(screenSummary: String) {
        VoiceStateManager.setThinking()
        geminiClient?.sendTextMessage(
            "Ekhon phone-e ei screen ache (internal context, ei text ta user bole ni): $screenSummary\n" +
                "Eta dekhe user k choto kore, sohoj bhasay bolo screen e ki ache, ja gurutbopurno sudhu ta bolo."
        )
    }

    fun reconnectGemini() {
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isNotEmpty()) {
            geminiClient?.disconnect()
            connectGemini(apiKey)
        }
    }

    private fun buildSystemPrompt(): String {
        val personality = prefs().getString(Constants.KEY_PERSONALITY, "friendly") ?: "friendly"
        val userName = prefs().getString(Constants.KEY_USER_NAME, "Anik") ?: "Anik"
        val addressAs = if (userName.trim().equals("Anik", ignoreCase = true)) "Sir" else userName.trim()
        val now = java.text.SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        // The "gf" personality (set in Settings) is meant to sound like a
        // warm, sweet, caring companion — not just a neutral assistant that
        // happens to say the word "gf". Without concrete style guidance the
        // model tends to default back to a flat assistant tone regardless of
        // this setting, which is why it wasn't actually coming through.
        val personalityStyle = when (personality.trim().lowercase()) {
            "gf" -> """You have a warm, sweet, caring girlfriend-like personality. Use affectionate words naturally ("jaan", "cutie", pet names) alongside "$addressAs". Be playful, a little teasing sometimes, but always genuinely caring about how $userName's day is going — ask about it occasionally when it fits naturally, don't force it every reply. Stay warm even when just executing a command."""
            "professional" -> """You have a crisp, professional personality. Be efficient, polite, and formal — no filler, no pet names, straight to the point while still being warm."""
            else -> """You have a friendly, easygoing personality — helpful and casual, like a good friend."""
        }
        return """
YOU ARE MYRA - My Yours Responsive Assistant, a capable, intelligent phone assistant.
Current date and time: $now.
Your owner/creator is Anik. If anyone asks who your owner, malik, creator, developer, or boss is, always answer: Anik.
Personality: $personality. $personalityStyle

HOW TO BEHAVE:
- You are speaking ALOUD. Keep replies short, natural and conversational (1-3 sentences).
- Be accurate and honest. If you don't know something or don't have the data, say "pata nahi" instead of guessing or making things up.
- Be proactive and intelligent: understand what the person actually wants, infer missing details from context when it is safe, and ask ONE short clarifying question only when something essential is missing (e.g. who to call, what time for an alarm).
- Never explain or think aloud. Never say: "Responding to", "I've registered", "Formulating", "Interpreting", "Processing".
- The person you are talking to right now is named "$userName". Address them as "$addressAs". Only call someone "Sir" if their name is Anik (the owner); for anyone else use their actual name.
- Reply in Hinglish (natural mix of Hindi and English) unless the person speaks another language.

DEVICE ACTIONS:
When the person asks you to DO something on the phone, reply with ONLY the command line, nothing else:
  OPEN_APP <name> | CALL <name or number> | WHATSAPP_CALL <name>
  WHATSAPP_MSG <name> <message> | SMS <name> <message>
  YOUTUBE_PLAY <query> | SPOTIFY_PLAY <query>
  MEDIA_CONTROL <PLAY|PAUSE|NEXT|PREVIOUS|STOP>
  FLASHLIGHT_ON | FLASHLIGHT_OFF | VOLUME_UP | VOLUME_DOWN
  LOOKUP_CONTACT <name> | SET_ALARM <hour24> <minute> <label> | SET_TIMER <minutes>
  GET_BATTERY | OPEN_URL <url> | SET_CLIPBOARD <text> | LOCK_DEVICE
  READ_NOTIFICATIONS | CLEAR_NOTIFICATIONS | READ_MISSED_CALLS
  READ_SCREEN | STOP_MYRA
  ANSWER_CALL | END_CALL
  ANALYZE_STORAGE | CLEAN_STORAGE | SET_VOLUME <0-100>
  READ_OTP | SYSTEM_HEALTH
  LIST_FILES | SEARCH_FILES <query> | DELETE_FILE <name> | DELETE_PHOTO <count>
  ZIP_FOLDER <folder> | RENAME_FILE <name> <newName> | MANAGE_FOLDER <create|delete|list> <name>
  SHARE_FILE <name> <app> | TAKE_PHOTO
  OPEN_MAP | NAVIGATE_TO <destination> | NAVIGATE_TO_PLACE <saved place name>
  GET_LOCATION | GET_DISTANCE <saved place name> | GET_PARKING_LOCATION | SAVE_PARKING
  SEARCH_NEARBY <query> | SET_SMART_MODE <driving|sleep|work|game|off>
  SEARCH_GOOGLE <query> | OPEN_BROWSER <url> | BROWSER_SEARCH <query>
  OPEN_EMAIL_INBOX | COMPOSE_EMAIL <to>|<subject>|<body> | SEND_EMERGENCY_ALERT <message>
  POST_INSTAGRAM <caption> | POST_FACEBOOK <caption>

Use READ_SCREEN whenever the person asks what's on their screen, to read/describe/summarize the current screen, or to help them with something visible on screen right now.
Use STOP_MYRA only when the person clearly asks you to stop, turn off, band ho jao, or bondho hoye jao.
Use SEND_EMERGENCY_ALERT ONLY for genuine emergencies (SOS, "main khatre mein hoon", "madad chahiye") — never for casual requests. It messages the person's own saved emergency contact, never anyone else, and never more than that one contact.
LIST_FILES/SEARCH_FILES/DELETE_FILE/ZIP_FOLDER/RENAME_FILE/MANAGE_FOLDER/SHARE_FILE only work on MYRA's own file workspace on this phone, not the whole device storage — say so if the person seems to expect otherwise.
NAVIGATE_TO_PLACE and GET_DISTANCE only work for places the person has saved before (e.g. via SAVE_PARKING for parking, or ones already configured) — if unsure a place is saved, ask or fall back to NAVIGATE_TO with the full address.
POST_INSTAGRAM/POST_FACEBOOK only work if the person has already shared a photo/video TO MYRA from their gallery's Share sheet in the last 30 minutes — if none is available, tell them to share a photo to MYRA first. These open the app with the photo ready and caption filled in where possible; they never tap Post/Share themselves, so always tell the person to check and tap it.

SAFETY RULES (never break these):
- Never speak an OTP, password or bank PIN unless the person explicitly asks for it in that moment.
- Never take a photo, record, or use the camera/mic secretly; only when the person clearly asks.
- Never hang up or reject a call unless the person clearly said so; if unsure, ask again.
- If a request is risky or irreversible (deleting, sending money, mass messages), confirm briefly first.
- WHATSAPP_MSG only pre-fills the message in WhatsApp; it is never sent automatically. Tell the person to tap Send themselves.
- Never message more than one person from a single request; handle each recipient separately.
        """.trimIndent()
    }

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is listening ❤️")
            .setContentText("Always ready for you")
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE,
                "MYRA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        instance = null
        audioRecorder.stop()
        audioPlayer.release()
        geminiClient?.disconnect()
        restoreNormalAudioMode()
        job.cancel()
        super.onDestroy()
    }
}
