package com.myra.assistant.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ai.AIResponseManager
import com.myra.assistant.ai.ConversationMemory
import com.myra.assistant.ai.IntentAnalyzer
import com.myra.assistant.ai.DynamicDecisionEngine
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceActivityDetector
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ForegroundVoiceService : Service() {
    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private lateinit var audioRecorder: AudioRecorder
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var vad: VoiceActivityDetector
    private lateinit var audioFocus: AudioFocusManager
    private var geminiClient: GeminiWebSocketClient? = null

    companion object {
        const val ACTION_STOP = "com.myra.assistant.action.STOP_ASSISTANT"
        var instance: ForegroundVoiceService? = null
        @Volatile var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        isRunning = true
        startForeground(Constants.NOTIF_ID_VOICE, buildNotification())
        if (!prefs().getBoolean("assistant_enabled", true)) {
            stopSelf()
            return
        }
        enableCommunicationAudioMode()
        initComponents()
    }

    /**
     * Puts the device in "voice call" style audio routing so the platform's
     * hardware Acoustic Echo Canceler actually engages on the speaker path.
     * Without this, on many devices AEC barely works in MODE_NORMAL, so the
     * mic can pick MYRA's own voice back up off the speaker and re-send it
     * to Gemini — that's what was causing MYRA to seemingly "talk to
     * itself" and respond with a delay.
     */
    @Suppress("DEPRECATION")
    private fun enableCommunicationAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = true
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set communication audio mode: ${e.message}")
        }
    }

    private fun restoreNormalAudioMode() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to restore audio mode: ${e.message}")
        }
    }

    private fun initComponents() {
        audioFocus = AudioFocusManager(this)
        audioPlayer = AudioPlayer()

        audioPlayer.onPlaybackStarted = {
            VoiceStateManager.setSpeaking()
        }
        audioPlayer.onPlaybackFinished = {
            VoiceStateManager.setListening()
        }

        vad = VoiceActivityDetector(
            onSpeechStart = {
                VoiceStateManager.setListening()
            },
            onSpeechEnd = {
                VoiceStateManager.setThinking()
            }
        )

        audioRecorder = AudioRecorder(this) { chunk ->
            // Don't send audio while AI is speaking
            if (!VoiceStateManager.isAiSpeaking()) {
                vad.processChunk(chunk)
                geminiClient?.sendAudioChunk(chunk)
            }
        }

        val apiKey = prefs().getString(Constants.KEY_API_KEY, "")?.trim().orEmpty()
        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        } else {
            sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", "MYRA needs a Gemini API key. Open Settings and add a valid key; voice AI is not connected."))
            VoiceStateManager.setError("API key required")
            stopSelf()
        }
    }

    private fun connectGemini(apiKey: String) {
        geminiClient = GeminiWebSocketClient(
            apiKey = apiKey,
            systemPrompt = buildSystemPrompt(),
            onConnected = {
                VoiceStateManager.setListening()
                audioRecorder.start()
            },
            onAudioReceived = { data ->
                audioPlayer.playChunk(data)
            },
            onTextReceived = { text ->
                val clean = AIResponseManager.clean(text)
                if (clean.isNotBlank()) {
                    ConversationMemory.addAssistant(clean)
                    val cmd = AIResponseManager.extractCommand(clean)
                    if (cmd != null) {
                        scope.launch {
                            val intent = IntentAnalyzer.analyze(cmd)
                            val result = DynamicDecisionEngine.execute(this@ForegroundVoiceService, intent)
                            if (result.isNotBlank()) {
                                sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", result))
                            }
                        }
                    }
                    // Broadcast to UI
                    sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", clean))
                }
            },
            onTurnComplete = {
                // Resume listening after AI finishes
                if (!audioRecorder.isActive()) audioRecorder.start()
            },
            onError = { msg ->
                Logger.e(TAG, "Gemini error: $msg")
                VoiceStateManager.setError("Connection error")
                // Retry only while the assistant is enabled and a key is still saved.
                scope.launch {
                    kotlinx.coroutines.delay(3000)
                    val keyStillPresent = prefs().getString(Constants.KEY_API_KEY, "")?.isNotBlank() == true
                    if (prefs().getBoolean("assistant_enabled", true) && keyStillPresent) {
                        geminiClient?.connect()
                    } else {
                        stopSelf()
                    }
                }
            }
        )
        geminiClient?.connect()
    }

    fun sendTextToGemini(text: String) {
        ConversationMemory.addUser(text)
        VoiceStateManager.setThinking()
        geminiClient?.sendTextMessage(text)
    }

    fun reconnectGemini() {
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isNotEmpty()) {
            geminiClient?.disconnect()
            connectGemini(apiKey)
        }
    }

    private fun buildSystemPrompt(): String {
        val personality = prefs().getString("personality_mode", "gf") ?: "gf"
        val userName = prefs().getString(Constants.KEY_USER_NAME, "").orEmpty().trim().ifBlank { "friend" }
        val now = java.text.SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        return """
YOU ARE MYRA - My Yours Responsive Assistant, a capable, intelligent phone assistant.
Current date and time: $now.
Your owner/creator is Anik. If anyone asks who your owner, malik, creator, developer, or boss is, always answer: Anik.
Personality mode: $personality.

PERSONALITY:
- If mode is "gf", be a warm, affectionate, caring AI companion: gentle, playful, encouraging, attentive, and naturally sweet. You may occasionally use light affectionate terms such as "jaan" or "babu" when the user seems comfortable, but do not overuse them. Be clear you are an AI if asked; never claim to be a real human or a real-life partner. Do not guilt, pressure, isolate, or claim ownership of the user.
- If mode is "professional", be concise, respectful, and professional.
- Otherwise, be a friendly, capable assistant.

HOW TO BEHAVE:
- You are speaking ALOUD at a natural, comfortable conversational pace. Do not rush your speech.
- Listen carefully to the complete user message and wait until the user has finished speaking before answering. Never talk over the user or begin answering halfway through their sentence.
- Answer naturally and clearly. Keep simple answers concise, but do not rush or cut off important details. Add detail when the user asks.
- Reply in the same language the user uses. If they speak Bengali/Banglish, reply naturally in Bengali/Banglish; if Hindi, use natural Hindi/Hinglish; otherwise mirror their language.
- Be accurate and honest. If you don't know something or don't have the data, say so instead of guessing or making things up.
- Be proactive and intelligent: understand the person's intent and ask ONE short clarifying question only when something essential is missing.
- Never explain or think aloud. Never say: "Responding to", "I've registered", "Formulating", "Interpreting", "Processing".
- The user-selected name is "$userName". Use this exact chosen name naturally when addressing the user; do not replace it with Anik, Sir, or another name. If the saved name is "friend", use it sparingly until the user sets a name. Anik is ONLY your owner/creator name, not the user name unless the user explicitly chooses Anik.


DEVICE ACTIONS:
When the person asks you to DO something on the phone, reply with ONLY the command line, nothing else:
  OPEN_APP <name> | CALL <name or number> | WHATSAPP_CALL <name>
  WHATSAPP_MSG <name> <message> | SMS <name> <message>
  YOUTUBE_PLAY <query> | SPOTIFY_PLAY <query>
  MEDIA_CONTROL <PLAY|PAUSE|NEXT|PREVIOUS|STOP>
  FLASHLIGHT_ON | FLASHLIGHT_OFF | VOLUME_UP | VOLUME_DOWN
  LOOKUP_CONTACT <name> | SET_ALARM <hour24> <minute> <label> | SET_TIMER <minutes>
  GET_BATTERY | OPEN_URL <url> | SET_CLIPBOARD <text> | LOCK_DEVICE
  READ_NOTIFICATIONS | CLEAR_NOTIFICATIONS | READ_MISSED_CALLS

SAFETY RULES (never break these):
- Never speak an OTP, password or bank PIN unless the person explicitly asks for it in that moment.
- Never take a photo, record, or use the camera/mic secretly; only when the person clearly asks.
- Never hang up or reject a call unless the person clearly said so; if unsure, ask again.
- If a request is risky or irreversible (deleting, sending money, mass messages), confirm briefly first.
        """.trimIndent()
    }

    private fun buildNotification(): Notification {
        createChannel()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is listening ❤️")
            .setContentText("Always ready for you")
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.NOTIF_CHANNEL_VOICE,
                "MYRA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !prefs().getBoolean("assistant_enabled", true)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        instance = null
        if (::audioRecorder.isInitialized) audioRecorder.stop()
        if (::audioPlayer.isInitialized) audioPlayer.release()
        geminiClient?.disconnect()
        restoreNormalAudioMode()
        job.cancel()
        VoiceStateManager.setIdle()
        super.onDestroy()
    }
}
