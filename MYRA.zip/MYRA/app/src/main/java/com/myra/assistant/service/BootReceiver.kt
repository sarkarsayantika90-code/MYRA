package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            val apiKey = prefs.getString(Constants.KEY_API_KEY, "") ?: ""
            // Android 14+ does not allow a microphone foreground service to start from boot,
            // so the user turns MYRA on by tapping the orb. Older versions still auto-start.
            if (apiKey.isNotEmpty() && android.os.Build.VERSION.SDK_INT < 34) {
                ForegroundVoiceService.start(context)
            }
        }
    }
}
