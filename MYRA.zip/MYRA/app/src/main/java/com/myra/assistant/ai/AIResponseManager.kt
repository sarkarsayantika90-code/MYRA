package com.myra.assistant.ai

object AIResponseManager {

    private val THINKING_FILTERS = listOf(
        "Responding to the Greeting",
        "I've registered the Hindi greeting.",
        "Now, I'm formulating",
        "Interpreting user command",
        "adhering to appropriate cultural etiquette.",
        "Formulating",
        "Let me think",
        "Processing"
    )

    fun clean(raw: String): String {
        var result = raw
            .replace("```", "")
            .replace("**", "")
            .replace("*", "")
        for (filter in THINKING_FILTERS) {
            result = result.replace(filter, "")
        }
        return result.trim()
    }

    fun extractCommand(text: String): String? {
        val commands = listOf(
            "OPEN_APP", "CALL", "WHATSAPP_CALL", "WHATSAPP_MSG",
            "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON",
            "FLASHLIGHT_OFF", "VOLUME_UP", "VOLUME_DOWN", "SMS",
            "LOOKUP_CONTACT", "SET_ALARM", "SET_TIMER", "GET_BATTERY",
            "OPEN_URL", "SET_CLIPBOARD", "LOCK_DEVICE",
            "READ_NOTIFICATIONS", "CLEAR_NOTIFICATIONS", "READ_MISSED_CALLS", "MEDIA_CONTROL",
            "READ_SCREEN", "STOP_MYRA",
            "ANSWER_CALL", "END_CALL", "ANALYZE_STORAGE", "CLEAN_STORAGE", "SET_VOLUME",
            "READ_OTP", "SYSTEM_HEALTH",
            "LIST_FILES", "SEARCH_FILES", "DELETE_FILE", "DELETE_PHOTO", "ZIP_FOLDER",
            "RENAME_FILE", "MANAGE_FOLDER", "SHARE_FILE", "TAKE_PHOTO",
            "OPEN_MAP", "NAVIGATE_TO_PLACE", "NAVIGATE_TO", "GET_LOCATION", "GET_DISTANCE",
            "GET_PARKING_LOCATION", "SAVE_PARKING", "SEARCH_NEARBY", "SET_SMART_MODE",
            "SEARCH_GOOGLE", "OPEN_BROWSER", "BROWSER_SEARCH",
            "OPEN_EMAIL_INBOX", "COMPOSE_EMAIL", "SEND_EMERGENCY_ALERT",
            "POST_INSTAGRAM", "POST_FACEBOOK"
        )
            // Longer/more specific tokens must be checked first: "CALL" is a
            // substring of "WHATSAPP_CALL", so without this ordering a
            // WhatsApp-call reply like "WHATSAPP_CALL John" would match the
            // plain "CALL" token first (indexOf finds "CALL" inside
            // "WHATSAPP_CALL") and get misparsed as a normal phone call to
            // "CALL John" — this was silently breaking every WhatsApp call.
            .sortedByDescending { it.length }
        val upper = text.uppercase()
        for (cmd in commands) {
            val index = upper.indexOf(cmd)
            if (index != -1) {
                return text.substring(index).trim().lines().first().replace("`", "").trim()
            }
        }
        return null
    }
}
