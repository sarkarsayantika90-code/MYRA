package com.myra.assistant.ai

object AIResponseManager {

    private val THINKING_FILTERS = listOf(
        "Responding to the Greeting",
        "I've registered the Hindi greeting.",
        "Now, I'm formulating",
        "Interpreting user command",
        "adhering to appropriate cultural etiquette.",
        "Formulating",
        "Let me think",
        "Processing"
    )

    fun clean(raw: String): String {
        var result = raw
            .replace("```", "")
            .replace("**", "")
            .replace("*", "")
        for (filter in THINKING_FILTERS) {
            result = result.replace(filter, "")
        }
        return result.trim()
    }

    fun extractCommand(text: String): String? {
        val commands = listOf(
            "OPEN_APP", "CALL", "WHATSAPP_CALL", "WHATSAPP_MSG",
            "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON",
            "FLASHLIGHT_OFF", "VOLUME_UP", "VOLUME_DOWN", "SMS",
            "LOOKUP_CONTACT", "SET_ALARM", "SET_TIMER", "GET_BATTERY",
            "OPEN_URL", "SET_CLIPBOARD", "LOCK_DEVICE",
            "READ_NOTIFICATIONS", "CLEAR_NOTIFICATIONS", "READ_MISSED_CALLS", "MEDIA_CONTROL",
            "READ_SCREEN", "STOP_MYRA"
        )
            // Longer/more specific tokens must be checked first: "CALL" is a
            // substring of "WHATSAPP_CALL", so without this ordering a
            // WhatsApp-call reply like "WHATSAPP_CALL John" would match the
            // plain "CALL" token first (indexOf finds "CALL" inside
            // "WHATSAPP_CALL") and get misparsed as a normal phone call to
            // "CALL John" — this was silently breaking every WhatsApp call.
            .sortedByDescending { it.length }
        val upper = text.uppercase()
        for (cmd in commands) {
            val index = upper.indexOf(cmd)
            if (index != -1) {
                return text.substring(index).trim().lines().first().replace("`", "").trim()
            }
        }
        return null
    }
}
