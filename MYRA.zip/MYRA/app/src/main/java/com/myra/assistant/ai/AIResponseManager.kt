package com.myra.assistant.ai

object AIResponseManager {

    private val THINKING_FILTERS = listOf(
        "Responding to the Greeting",
        "I've registered the Hindi greeting.",
        "Now, I'm formulating",
        "Interpreting user command",
        "adhering to appropriate cultural etiquette.",
        "Formulating",
        "Let me think",
        "Processing"
    )

    fun clean(raw: String): String {
        var result = raw
            .replace("```", "")
            .replace(Regex("\\*\\*|(?<!\\*)\\*(?!\\*)"), "")
            .replace(Regex("(?i)\\b(?:responding to the greeting|i've registered the hindi greeting|now,? i'm formulating|interpreting user command|adhering to appropriate cultural etiquette|formulating|let me think|processing)\\b"), "")
        result = result.replace(Regex("[ \t]{2,}"), " ")
        return result.trim()
    }

    /** Only accept a structured action when the entire response is one command line.
     * This prevents ordinary conversational text that merely mentions a command
     * from accidentally triggering a phone action.
     */
    fun extractCommand(text: String): String? {
        val candidate = text.trim().removePrefix("`").removeSuffix("`").trim()
        if (candidate.isBlank() || candidate.contains('\n') || candidate.contains('\r')) return null
        val commands = listOf(
            "OPEN_APP", "CALL", "WHATSAPP_CALL", "WHATSAPP_MSG",
            "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON",
            "FLASHLIGHT_OFF", "VOLUME_UP", "VOLUME_DOWN", "SMS",
            "LOOKUP_CONTACT", "SET_ALARM", "SET_TIMER", "GET_BATTERY",
            "OPEN_URL", "SET_CLIPBOARD", "LOCK_DEVICE",
            "READ_NOTIFICATIONS", "CLEAR_NOTIFICATIONS", "READ_MISSED_CALLS", "MEDIA_CONTROL"
        )
        val command = commands.firstOrNull { candidate.equals(it, ignoreCase = true) || candidate.startsWith("$it ", ignoreCase = true) }
            ?: return null
        // Require a command token boundary and reject prose before the command.
        if (!candidate.matches(Regex("(?is)^${Regex.escape(command)}(?:\\s+[^\\r\\n]+)?$"))) return null
        return candidate
    }

}
