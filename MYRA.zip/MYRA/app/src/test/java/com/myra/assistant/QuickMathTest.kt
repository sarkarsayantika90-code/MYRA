package com.myra.assistant

import com.myra.assistant.ai.QuickMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class QuickMathTest {
    @Test fun precedence() { assertEquals(14.0, QuickMath.eval("2+3*4"), 1e-9) }
    @Test fun brackets() { assertEquals(20.0, QuickMath.eval("(2+3)*4"), 1e-9) }
    @Test fun powerIsRightAssociative() { assertEquals(512.0, QuickMath.eval("2^3^2"), 1e-9) }
    @Test fun unaryMinus() { assertEquals(-3.0, QuickMath.eval("-5+2"), 1e-9) }
    @Test fun functions() { assertEquals(4.0, QuickMath.eval("sqrt(16)"), 1e-9) }
    @Test fun divisionByZeroThrows() {
        try { QuickMath.eval("10/0"); fail() } catch (_: ArithmeticException) {}
    }
    @Test fun garbageThrows() {
        try { QuickMath.eval("2+*"); fail() } catch (_: IllegalArgumentException) {}
    }
    @Test fun formatTrimsZeros() {
        assertEquals("3", QuickMath.fmt(3.0))
        assertEquals("0.333333", QuickMath.fmt(1.0 / 3))
    }
    @Test fun temperature() { assertTrue(QuickMath.convert(100.0, "celsius", "fahrenheit")!!.contains("212")) }
    @Test fun length() { assertTrue(QuickMath.convert(1.0, "km", "mile")!!.contains("0.621371")) }
    @Test fun mixedKindsRejected() { assertNull(QuickMath.convert(1.0, "kg", "km")) }
    @Test fun emiZeroRate() { assertEquals(100.0, QuickMath.emi(1200.0, 0.0, 12), 1e-9) }
    @Test fun emiNormal() { assertEquals(8791.59, QuickMath.emi(100000.0, 10.0, 12), 0.01) }
    @Test fun bmi() { assertNotNull(QuickMath.bmiCategory(QuickMath.bmi(70.0, 175.0))); assertEquals("healthy range", QuickMath.bmiCategory(22.9)) }
}
