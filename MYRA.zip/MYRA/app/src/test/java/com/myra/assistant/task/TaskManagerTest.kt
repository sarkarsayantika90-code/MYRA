package com.myra.assistant.task

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Before
import org.junit.Test

class TaskManagerTest {

    private lateinit var repository: InMemoryTaskRepository
    private lateinit var manager: TaskManager
    private var fakeNow = 1_000_000L
    private var idCounter = 0

    @Before
    fun setup() {
        repository = InMemoryTaskRepository()
        manager = TaskManager(
            repository = repository,
            clock = { fakeNow },
            idGenerator = { "task-${idCounter++}" }
        )
    }

    @Test
    fun `create task starts QUEUED and emits TASK_CREATED`() = runTest {
        val task = manager.createTask("Research AI agents")
        assertEquals(TaskStatus.QUEUED, task.status)
        val events = repository.getEvents(task.taskId)
        assertEquals(1, events.size)
        assertEquals(TaskEventType.TASK_CREATED, events.first().eventType)
    }

    @Test
    fun `normal lifecycle QUEUED to PLANNING to RUNNING to COMPLETED`() = runTest {
        val task = manager.createTask("Organize files by type")
        manager.startPlanning(task.taskId, plan = "scan, group, move", totalSteps = 3)
        manager.beginRunning(task.taskId)
        manager.reportStepProgress(task.taskId, stepIndex = 1, progress = 33)
        manager.reportStepProgress(task.taskId, stepIndex = 3, progress = 100)
        val completed = manager.completeTask(task.taskId, verifiedResult = "Moved 12 files into 3 folders")

        assertNotNull(completed)
        assertEquals(TaskStatus.COMPLETED, completed!!.status)
        assertTrue(completed.isVerifiedComplete)
    }

    @Test
    fun `completeTask rejects blank result - no false completion`() = runTest {
        val task = manager.createTask("Do something")
        manager.startPlanning(task.taskId, "plan", 1)
        manager.beginRunning(task.taskId)
        assertThrows(IllegalArgumentException::class.java) {
            kotlinx.coroutines.runBlocking { manager.completeTask(task.taskId, verifiedResult = "") }
        }
        val current = manager.getTask(task.taskId)
        assertEquals(TaskStatus.RUNNING, current?.status)
    }

    @Test
    fun `illegal transition is rejected and task stays put`() = runTest {
        val task = manager.createTask("Do something")
        // QUEUED -> COMPLETED is not a legal transition
        val result = manager.transition(task.taskId, TaskStatus.COMPLETED)
        assertNull(result)
        val current = manager.getTask(task.taskId)
        assertEquals(TaskStatus.QUEUED, current?.status)
    }

    @Test
    fun `pause and resume roundtrip`() = runTest {
        val task = manager.createTask("Long research task")
        manager.startPlanning(task.taskId, "plan", 5)
        manager.beginRunning(task.taskId)
        val paused = manager.pause(task.taskId)
        assertEquals(TaskStatus.PAUSED, paused?.status)
        val resumed = manager.resume(task.taskId)
        assertEquals(TaskStatus.RUNNING, resumed?.status)
    }

    @Test
    fun `cancel from paused stops task and cannot resume further`() = runTest {
        val task = manager.createTask("Long research task")
        manager.startPlanning(task.taskId, "plan", 5)
        manager.beginRunning(task.taskId)
        manager.pause(task.taskId)
        val cancelled = manager.cancel(task.taskId, "user cancelled")
        assertEquals(TaskStatus.CANCELLED, cancelled?.status)
        val furtherResume = manager.resume(task.taskId)
        assertNull(furtherResume)
    }

    @Test
    fun `retry increments count then fails after max retries`() = runTest {
        val task = manager.createTask("Flaky network task")
        manager.startPlanning(task.taskId, "plan", 1)
        manager.beginRunning(task.taskId)

        // maxRetries defaults to 3
        val r1 = manager.reportFailure(task.taskId, "tool error 1")
        assertEquals(TaskStatus.RETRYING, r1?.status)
        assertEquals(1, r1?.retryCount)

        manager.transition(task.taskId, TaskStatus.RUNNING)
        val r2 = manager.reportFailure(task.taskId, "tool error 2")
        assertEquals(TaskStatus.RETRYING, r2?.status)

        manager.transition(task.taskId, TaskStatus.RUNNING)
        val r3 = manager.reportFailure(task.taskId, "tool error 3")
        assertEquals(TaskStatus.RETRYING, r3?.status)
        assertEquals(3, r3?.retryCount)

        manager.transition(task.taskId, TaskStatus.RUNNING)
        val r4 = manager.reportFailure(task.taskId, "tool error 4 - fatal")
        assertEquals(TaskStatus.FAILED, r4?.status)
    }

    @Test
    fun `confirmation flow - waiting then approve resumes`() = runTest {
        val task = manager.createTask("Delete old files")
        manager.startPlanning(task.taskId, "plan", 1)
        manager.beginRunning(task.taskId)
        val waiting = manager.requireConfirmation(task.taskId, "About to delete 40 files, confirm?")
        assertEquals(TaskStatus.WAITING_FOR_USER, waiting?.status)
        assertEquals("About to delete 40 files, confirm?", waiting?.pendingConfirmation)

        val approved = manager.approveAction(task.taskId)
        assertEquals(TaskStatus.RUNNING, approved?.status)
        assertNull(approved?.pendingConfirmation)
    }

    @Test
    fun `confirmation flow - reject fails the task`() = runTest {
        val task = manager.createTask("Delete old files")
        manager.startPlanning(task.taskId, "plan", 1)
        manager.beginRunning(task.taskId)
        manager.requireConfirmation(task.taskId, "confirm?")
        val rejected = manager.rejectAction(task.taskId, "user said no")
        assertEquals(TaskStatus.FAILED, rejected?.status)
        assertEquals("user said no", rejected?.error)
    }

    @Test
    fun `checkpoint save is retrievable for resume`() = runTest {
        val task = manager.createTask("Research task")
        manager.startPlanning(task.taskId, "plan", 10)
        manager.beginRunning(task.taskId)
        manager.saveCheckpoint(task.taskId, stepIndex = 4, stateJson = """{"sourcesRead":4}""")

        val latest = manager.getLatestCheckpoint(task.taskId)
        assertNotNull(latest)
        assertEquals(4, latest!!.stepIndex)
        assertEquals("""{"sourcesRead":4}""", latest.stateJson)
    }

    private fun assertTrue(condition: Boolean) = org.junit.Assert.assertTrue(condition)
}
