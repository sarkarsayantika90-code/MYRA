package com.myra.assistant.whatsapp

import org.junit.Assert.*
import org.junit.Test

class WhatsAppSafetyTest {
    private fun task() = WhatsAppTask("t1", "send_message", "mummy", "Mummy", "+911234567890", "late aashbo")

    @Test fun cannotSendWithoutConfirm() {
        val t = task()
        assertFalse(t.canTapSend())
        t.markAwaiting()
        assertFalse(t.canTapSend())
    }

    @Test fun confirmOpensGateOnlyForSameTaskId() {
        val t = task(); t.markAwaiting()
        assertFalse(t.confirm("other"))
        assertFalse(t.canTapSend())
        assertTrue(t.confirm("t1"))
        assertTrue(t.canTapSend())
    }

    @Test fun cannotConfirmBeforeDraftIsAwaiting() {
        val t = task()
        assertFalse(t.confirm("t1"))
        assertFalse(t.canTapSend())
    }

    @Test fun staleDraftCannotBeConfirmed() {
        val t = task(); t.markAwaiting(now = 1_000L)
        assertFalse(t.confirm("t1", now = 1_000L + WhatsAppTask.DRAFT_TTL_MS + 1))
        assertFalse(t.canTapSend())
    }

    @Test fun affirmatives() {
        listOf("haan", "yes send it", "হ্যাঁ পাঠাও", "ठीक है भेजो", "ok").forEach { assertTrue(it, ConfirmGate.isAffirmative(it)) }
    }

    @Test fun negativesWin() {
        listOf("nahi", "no don't send", "না", "ruko wait", "haan nahi mat bhejo").forEach { assertFalse(it, ConfirmGate.isAffirmative(it)) }
    }

    @Test fun originalRequestIsNotAConfirmation() {
        UtteranceLog.clear()
        UtteranceLog.add("Mummy ko message bhejo main late aaunga", now = 100)
        // read-back has not finished yet -> null, so "bhejo" in the request can never count as yes
        assertNull(UtteranceLog.sinceReadback(draftAt = 200))
        UtteranceLog.markTurnEnd(now = 300)
        assertEquals("", UtteranceLog.sinceReadback(draftAt = 200))
        UtteranceLog.add("haan bhejo", now = 400)
        assertTrue(ConfirmGate.isAffirmative(UtteranceLog.sinceReadback(draftAt = 200)!!))
    }
}
