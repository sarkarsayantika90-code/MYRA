package com.myra.assistant.task

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskStatusTest {

    @Test
    fun `terminal states have no outgoing transitions`() {
        for (terminal in listOf(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)) {
            assertTrue(terminal.isTerminal)
            assertTrue(TaskStatus.ALLOWED_TRANSITIONS[terminal].orEmpty().isEmpty())
        }
    }

    @Test
    fun `running can reach all wait states`() {
        val allowed = TaskStatus.ALLOWED_TRANSITIONS[TaskStatus.RUNNING].orEmpty()
        assertTrue(TaskStatus.WAITING_FOR_USER in allowed)
        assertTrue(TaskStatus.WAITING_FOR_PERMISSION in allowed)
        assertTrue(TaskStatus.WAITING_FOR_NETWORK in allowed)
        assertTrue(TaskStatus.PAUSED in allowed)
        assertTrue(TaskStatus.RETRYING in allowed)
        assertTrue(TaskStatus.COMPLETED in allowed)
    }

    @Test
    fun `queued cannot jump directly to completed`() {
        val allowed = TaskStatus.ALLOWED_TRANSITIONS[TaskStatus.QUEUED].orEmpty()
        assertFalse(TaskStatus.COMPLETED in allowed)
        assertFalse(TaskStatus.RUNNING in allowed)
        assertTrue(TaskStatus.PLANNING in allowed)
    }

    @Test
    fun `cancelled cannot resume`() {
        assertTrue(TaskStatus.ALLOWED_TRANSITIONS[TaskStatus.CANCELLED].orEmpty().isEmpty())
    }

    @Test
    fun `waiting states are flagged correctly`() {
        assertTrue(TaskStatus.WAITING_FOR_USER.isWaiting)
        assertTrue(TaskStatus.WAITING_FOR_PERMISSION.isWaiting)
        assertTrue(TaskStatus.WAITING_FOR_NETWORK.isWaiting)
        assertFalse(TaskStatus.RUNNING.isWaiting)
    }
}
