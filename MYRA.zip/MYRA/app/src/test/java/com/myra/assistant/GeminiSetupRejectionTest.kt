package com.myra.assistant

import com.myra.assistant.websocket.GeminiWebSocketClient
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** A bad network must never push MYRA down to the slower, simpler Gemini setup; only a real server refusal may. */
class GeminiSetupRejectionTest {
    private fun rejected(r: String) = GeminiWebSocketClient.looksLikeSetupRejection(r)

    @Test fun networkProblemsAreNotSetupRejections() {
        assertFalse(rejected("failure: Unable to resolve host \"generativelanguage.googleapis.com\""))
        assertFalse(rejected("failure: timeout"))
        assertFalse(rejected("failure: 503"))
        assertFalse(rejected("closed 1006 "))
        assertFalse(rejected("closed 1001 going away"))
    }

    @Test fun serverRefusingTheSetupIs() {
        assertTrue(rejected("closed 1007 Request contains an invalid argument."))
        assertTrue(rejected("closed 1008 Unknown name \"thinkingConfig\" at 'setup.generation_config'"))
        assertTrue(rejected("closed 1008 Operation is not implemented, or supported, or enabled."))
    }

    @Test fun badKeyOrQuotaIsNotTheSetupsFault() {
        assertFalse(rejected("closed 1008 API key not valid. Please pass a valid API key."))
        assertFalse(rejected("closed 1011 You exceeded your current quota"))
        assertFalse(rejected("closed 1008 Permission denied"))
    }
}
