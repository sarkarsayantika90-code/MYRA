package com.myra.assistant

import com.myra.assistant.voice.WakeWordMatcher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordMatcherTest {
    @Test fun acceptsGreetingThenName() {
        assertTrue(WakeWordMatcher.matches("hey myra"))
        assertTrue(WakeWordMatcher.matches("Hey Mira"))
        assertTrue(WakeWordMatcher.matches("hi meera open youtube"))
        assertTrue(WakeWordMatcher.matches("[unk] hey maira"))
    }

    @Test fun ignoresEverythingElse() {
        assertFalse(WakeWordMatcher.matches(""))
        assertFalse(WakeWordMatcher.matches("[unk]"))
        assertFalse(WakeWordMatcher.matches("myra"))               // name alone is not enough
        assertFalse(WakeWordMatcher.matches("hey there"))
        assertFalse(WakeWordMatcher.matches("mira hey"))           // wrong order
        assertFalse(WakeWordMatcher.matches("hello world"))
    }

    @Test fun grammarIsValidJsonArrayOfPhrases() {
        val g = WakeWordMatcher.grammar
        assertTrue(g.startsWith("[") && g.endsWith("]"))
        assertTrue("\"hey myra\"" in g)
        assertTrue("\"[unk]\"" in g)
    }
}
