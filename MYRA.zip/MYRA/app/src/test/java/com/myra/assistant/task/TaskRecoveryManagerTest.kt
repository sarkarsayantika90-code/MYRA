package com.myra.assistant.task

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class TaskRecoveryManagerTest {

    private lateinit var repository: InMemoryTaskRepository
    private lateinit var manager: TaskManager
    private lateinit var recovery: TaskRecoveryManager
    private var fakeNow = 1_000_000L
    private var idCounter = 0

    @Before
    fun setup() {
        repository = InMemoryTaskRepository()
        manager = TaskManager(
            repository = repository,
            clock = { fakeNow },
            idGenerator = { "task-${idCounter++}" }
        )
        recovery = TaskRecoveryManager(manager, repository)
    }

    @Test
    fun `RUNNING task found at startup is moved to PAUSED not silently completed`() = runTest {
        val task = manager.createTask("Build feature X")
        manager.startPlanning(task.taskId, "plan", 5)
        manager.beginRunning(task.taskId)
        manager.saveCheckpoint(task.taskId, 2, """{"filesModified":2}""")

        // simulate process restart: recovery runs fresh against persisted state
        val recovered = recovery.recoverInterruptedTasks()

        assertEquals(1, recovered.size)
        assertEquals(TaskStatus.PAUSED, recovered.first().status)
        // never silently marked COMPLETED
        assertTrue(recovered.none { it.status == TaskStatus.COMPLETED })
    }

    @Test
    fun `terminal and waiting tasks are left untouched`() = runTest {
        val completedTask = manager.createTask("Done task")
        manager.startPlanning(completedTask.taskId, "p", 1)
        manager.beginRunning(completedTask.taskId)
        manager.completeTask(completedTask.taskId, "verified result")

        val waitingTask = manager.createTask("Needs confirmation")
        manager.startPlanning(waitingTask.taskId, "p", 1)
        manager.beginRunning(waitingTask.taskId)
        manager.requireConfirmation(waitingTask.taskId, "confirm?")

        val recovered = recovery.recoverInterruptedTasks()

        assertEquals(0, recovered.size)
        assertEquals(TaskStatus.COMPLETED, manager.getTask(completedTask.taskId)?.status)
        assertEquals(TaskStatus.WAITING_FOR_USER, manager.getTask(waitingTask.taskId)?.status)
    }

    @Test
    fun `checkpoint survives recovery for later resume`() = runTest {
        val task = manager.createTask("Research task")
        manager.startPlanning(task.taskId, "plan", 10)
        manager.beginRunning(task.taskId)
        manager.saveCheckpoint(task.taskId, 6, """{"sourcesRead":6}""")

        recovery.recoverInterruptedTasks()

        val checkpoint = manager.getLatestCheckpoint(task.taskId)
        assertEquals(6, checkpoint?.stepIndex)
    }
}
