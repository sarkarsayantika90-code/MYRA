package com.myra.admin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlansTest {
    private val day = 86_400_000L

    @Test fun freshGrantStartsNow() { assertEquals(1000L + 30 * day, Plans.until(1000L, 0L, 30)) }
    @Test fun grantAddsOnTopOfRemainingTime() { assertEquals(1000L + 5 * day + 10 * day, Plans.until(1000L, 1000L + 5 * day, 10)) }
    @Test fun expiredPlanRestartsFromNow() { assertEquals(2000L + 7 * day, Plans.until(2000L, 1500L, 7)) }
    @Test fun lifetimeStaysLifetime() { assertEquals(-1L, Plans.until(1000L, -1L, 30)); assertEquals(-1L, Plans.until(1000L, 0L, -1)) }
    @Test fun activeChecks() {
        assertTrue(Plans.isActive(-1L, 5L)); assertTrue(Plans.isActive(10L, 5L))
        assertFalse(Plans.isActive(5L, 10L)); assertFalse(Plans.isActive(0L, 10L))
    }
    @Test fun planTableMatchesApp() {
        assertEquals(7, Plans.DAYS.size); assertEquals(-1, Plans.DAYS["lifetime"]); assertEquals(240, Plans.DAYS["eightmonth"])
    }

    @Test fun rawValuesAreTyped() {
        assertEquals(true, Plans.parseValue("true"))
        assertEquals(42L, Plans.parseValue(" 42 "))
        assertEquals(1.5, Plans.parseValue("1.5"))
        assertEquals("hello", Plans.parseValue("hello"))
    }
    @Test fun settingNamesAreValidated() {
        assertTrue(Plans.validKey("disabledTools")); assertFalse(Plans.validKey("a/b")); assertFalse(Plans.validKey("")); assertFalse(Plans.validKey("a.b"))
    }
    @Test fun customPlansOverrideDefaults() {
        Plans.current = mapOf("trial" to 3)
        assertEquals(3, Plans.all()["trial"]); Plans.current = emptyMap(); assertEquals(30, Plans.all()["monthly"])
    }
}
