package com.myra.assistant

import com.myra.assistant.auth.FirebaseRest
import org.junit.Assert.assertTrue
import org.junit.Test

class LoginMessagesTest {
    @Test fun wrongCredentialsMessageMentionsGoogle() {
        // Accounts made with "Continue with Google" have no password: the user must be told to use that button.
        val m = FirebaseRest.friendly("INVALID_LOGIN_CREDENTIALS")
        assertTrue(m, m.contains("Continue with Google"))
        assertTrue(m, m.contains("INVALID_LOGIN_CREDENTIALS"))
    }

    @Test fun staleLoginAsksForRelogin() {
        assertTrue(FirebaseRest.friendly("CREDENTIAL_TOO_OLD_LOGIN_AGAIN").contains("Log out"))
    }
}
