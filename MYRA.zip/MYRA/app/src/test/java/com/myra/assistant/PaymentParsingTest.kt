package com.myra.assistant

import com.myra.assistant.premium.PaymentAutoVerifier
import com.myra.assistant.premium.PremiumManager
import org.junit.Assert.*
import org.junit.Test

class PaymentParsingTest {
    @Test fun parsesCreditWithUtrAndAmount() {
        val c = PaymentAutoVerifier.parseCredit("Rs. 99.00 credited to your a/c XX1234 by UPI. UPI Ref No 412345678901.")
        assertNotNull(c)
        assertEquals(99.0, c!!.amount, 0.001)
        assertTrue("412345678901" in c.refs)
    }

    @Test fun ignoresDebit() {
        assertNull(PaymentAutoVerifier.parseCredit("Rs. 500 debited from your account. Ref 412345678901"))
    }

    @Test fun matchNeedsSameUtrAndEnoughAmount() {
        val list = listOf(PaymentAutoVerifier.Credit(99.0, setOf("412345678901"), 0))
        assertTrue(PaymentAutoVerifier.matches(list, "412345678901", 99))
        assertFalse(PaymentAutoVerifier.matches(list, "412345678901", 249))   // paid too little
        assertFalse(PaymentAutoVerifier.matches(list, "999999999999", 99))    // different UTR
    }

    @Test fun utrValidation() {
        assertTrue(PremiumManager.validUtr("412345678901"))
        assertFalse(PremiumManager.validUtr("12345"))
        assertFalse(PremiumManager.validUtr("41234567890a"))
    }
}
