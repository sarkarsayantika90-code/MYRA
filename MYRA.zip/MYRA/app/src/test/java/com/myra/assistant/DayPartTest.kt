package com.myra.assistant

import com.myra.assistant.utils.DayPart
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class DayPartTest {
    @Test fun partsOfTheDay() {
        assertEquals("late night", DayPart.name(0))
        assertEquals("late night", DayPart.name(4))
        assertEquals("morning", DayPart.name(5))
        assertEquals("morning", DayPart.name(11))
        assertEquals("afternoon", DayPart.name(12))
        assertEquals("evening", DayPart.name(17))
        assertEquals("night", DayPart.name(21))
        assertEquals("night", DayPart.name(23))
    }

    @Test fun neverGoodMorningAtNight() {
        for (h in listOf(0, 1, 3, 4, 21, 22, 23)) assertNotEquals("Good morning", DayPart.greeting(h))
        assertEquals("Good morning", DayPart.greeting(8))
        assertEquals("Good evening", DayPart.greeting(18))
    }
}
