# MYRA release rules.
# Debug APK builds do not run R8, but this file is kept so release builds
# also have a valid proguard configuration.
