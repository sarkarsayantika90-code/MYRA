# MYRA release rules. Keep Android components and Gson/JSON model fields stable.
-keep class com.myra.assistant.** extends android.app.Activity { *; }
-keep class com.myra.assistant.** extends android.app.Service { *; }
-keep class com.myra.assistant.** extends android.content.BroadcastReceiver { *; }
-keep class com.myra.assistant.models.** { *; }
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontwarn okhttp3.**
-dontwarn okio.**
